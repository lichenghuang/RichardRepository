﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using Bloomberglp.Blpapi;

namespace BLPQuote
{
    public class BLPQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "07:44";        
        public string RemotIp = "127.0.0.1";
        public int RemotPort = 8194;        

        public BLPQuoteFactorySetting()
        {
        }
        public BLPQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public BLPQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }

    public class BLPQuoteSource : QuoteSource
    {
        //private static readonly ILog log = LogManager.GetLogger(typeof(BLPQuoteSource));

        private Thread RoutineThread;
        private string DBConnectString = "";
        private TimeSpan tsRecover;
        //private TimeSpan RecoverTime2;
        //private TimeSpan TransCloseTime;
        private bool RecoverFlag = false;
        //private bool RecoverFlag2 = false;
        //private bool TransCloseFlag = false;
        private string RemotIp = "";
        private int RemotePort = 0;
        Dictionary<string, string> _dicIntlMonth = new Dictionary<string, string>();
        Dictionary<string, string> _dicMonth = new Dictionary<string, string>();
        Dictionary<string, string> _dicYstCls = new Dictionary<string, string>();
        Dictionary<string, string> _dicLstTrd = new Dictionary<string, string>();
        Dictionary<string, string> _dicBid = new Dictionary<string, string>();
        Dictionary<string, string> _dicAsk = new Dictionary<string, string>();
        Dictionary<string, string> _dicTime = new Dictionary<string, string>();
            
        public BLPQuoteSource(BLPQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;            
            RemotIp = QuoteSetting.RemotIp;
            RemotePort = QuoteSetting.RemotPort;
            tsRecover = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);

            _dicIntlMonth["01"] = _dicIntlMonth["1"] = "F"; _dicIntlMonth["F"] = "01";
            _dicIntlMonth["02"] = _dicIntlMonth["2"] = "G"; _dicIntlMonth["G"] = "02";
            _dicIntlMonth["03"] = _dicIntlMonth["3"] = "H"; _dicIntlMonth["H"] = "03";
            _dicIntlMonth["04"] = _dicIntlMonth["4"] = "J"; _dicIntlMonth["J"] = "04";
            _dicIntlMonth["05"] = _dicIntlMonth["5"] = "K"; _dicIntlMonth["K"] = "05";
            _dicIntlMonth["06"] = _dicIntlMonth["6"] = "M"; _dicIntlMonth["M"] = "06";
            _dicIntlMonth["07"] = _dicIntlMonth["7"] = "N"; _dicIntlMonth["N"] = "07";
            _dicIntlMonth["08"] = _dicIntlMonth["8"] = "Q"; _dicIntlMonth["Q"] = "08";
            _dicIntlMonth["09"] = _dicIntlMonth["9"] = "U"; _dicIntlMonth["U"] = "09";
            _dicIntlMonth["10"] = "V"; _dicIntlMonth["V"] = "10";
            _dicIntlMonth["11"] = "X"; _dicIntlMonth["X"] = "11";
            _dicIntlMonth["12"] = "Z"; _dicIntlMonth["Z"] = "12";

            _dicMonth["01"] = "A";
            _dicMonth["02"] = "B";
            _dicMonth["03"] = "C";
            _dicMonth["04"] = "D";
            _dicMonth["05"] = "E";
            _dicMonth["06"] = "F";
            _dicMonth["07"] = "G";
            _dicMonth["08"] = "H";
            _dicMonth["09"] = "I";
            _dicMonth["10"] = "J";
            _dicMonth["11"] = "K";
            _dicMonth["12"] = "L";
        }

        public override bool Start()
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            LoadData();
            ConnectBLP();

            if (_tDataWorker == null)
            {
                _tDataWorker = new Thread(new ThreadStart(deqData));
                _tDataWorker.Start();
            }

            SubscribeBLP();

            return base.Start();
        }

        public override bool Close()
        {
            try
            {
                if (_tDataWorker != null && _tDataWorker.IsAlive) { _tDataWorker.Abort(); _tDataWorker = null; }

                if (_sess != null)
                {
                    _sess.Stop();
                    _sess = null;
                }

                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                
                base.Close();
                
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private Thread _tDataWorker = null;
        private void deqData()
        {
            while (true)
            {
                Event eventObj = _sess.NextEvent();
                
                foreach (Bloomberglp.Blpapi.Message msg in eventObj.GetMessages())
                {
                    bool bSentFlag = false;

                    #region IF EVENT TYPE=SUBSCRIPTION_DATA THEN UPDATA DATA FIELDS

                    if (eventObj.Type == Event.EventType.SUBSCRIPTION_DATA)
                    {
                        m_PacketNum++;

                        StringBuilder sb = new StringBuilder();

                        try
                        {
                            long iCId = msg.CorrelationID.Value;
                            string sInnerCode = _dicInnerCode2[iCId];
                            string sLstPrc = string.Empty, sBid = string.Empty, sAsk = string.Empty;
                            double dLstPrc = 0, dBid = 0, dAsk = 0;
                            
                            //InnerCode => sb[0]
                            sb.Append(sInnerCode + ",");

                            //TIME => sb[1]
                            //if (msg.HasElement("TIME") && !msg.GetElement("TIME").IsNull)//check IsNull before use the field
                            //{
                            //    string sTime = msg.GetElementAsString("TIME");
                            //    if (!String.IsNullOrEmpty(sTime) && sTime.Length >= 8)
                            //    {
                            //        sTime = sTime.Substring(0, 8);
                            //        if (sTime.IndexOf(":") == 2 && sTime.LastIndexOf(":") == 5)
                            //        { sb.Append(sTime.Substring(0, 2) + sTime.Substring(3, 2) + sTime.Substring(6, 2) + "00,"); }
                            //        else
                            //        { sb.Append(DateTime.Now.ToString("HHmmssff") + ","); }
                            //    }
                            //    else
                            //    { sb.Append(DateTime.Now.ToString("HHmmssff") + ","); }
                            //    bSentFlag = true;
                            //}
                            //else
                            { sb.Append(DateTime.Now.ToString("HHmmssff") + ","); }

                            //LAST_PRICE => sb[2]
                            if (msg.HasElement("LAST_PRICE") && !msg.GetElement("LAST_PRICE").IsNull)//check IsNull before use the field
                            {
                                sLstPrc = msg.GetElementAsString("LAST_PRICE");
                                sb.Append(sLstPrc + ",");
                                bSentFlag = true;
                            }
                            else
                            { sb.Append(","); }

                            //SIZE_LAST_TRADE => sb[3]
                            if (msg.HasElement("SIZE_LAST_TRADE") && !msg.GetElement("SIZE_LAST_TRADE").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("SIZE_LAST_TRADE") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //VOLUME => sb[4]
                            if (msg.HasElement("VOLUME") && !msg.GetElement("VOLUME").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("VOLUME") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            ////****************************************************************************************************************

                            #region Bid/Ask
                            //BEST_BID1 => 5
                            if (msg.HasElement("BEST_BID1") && !msg.GetElement("BEST_BID1").IsNull)//check IsNull before use the field
                            {
                                sBid = msg.GetElementAsString("BEST_BID1");
                                sb.Append(sBid + ",");
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("BID") && !msg.GetElement("BID").IsNull)//check IsNull before use the field
                            {
                                sBid=msg.GetElementAsString("BID");
                                sb.Append(sBid + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID1_SZ => 6
                            if (msg.HasElement("BEST_BID1_SZ") && !msg.GetElement("BEST_BID1_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID1_SZ") + ",");
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("BID_SIZE") && !msg.GetElement("BID_SIZE").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BID_SIZE") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID2 => 7
                            if (msg.HasElement("BEST_BID2") && !msg.GetElement("BEST_BID2").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID2") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID2_SZ => 8
                            if (msg.HasElement("BEST_BID2_SZ") && !msg.GetElement("BEST_BID2_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID2_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID3 => 9
                            if (msg.HasElement("BEST_BID3") && !msg.GetElement("BEST_BID3").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID3") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID3_SZ => 10
                            if (msg.HasElement("BEST_BID3_SZ") && !msg.GetElement("BEST_BID3_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID3_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID4 => 11
                            if (msg.HasElement("BEST_BID4") && !msg.GetElement("BEST_BID4").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID4") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID4_SZ => 12
                            if (msg.HasElement("BEST_BID4_SZ") && !msg.GetElement("BEST_BID4_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID4_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID5 => 13
                            if (msg.HasElement("BEST_BID5") && !msg.GetElement("BEST_BID5").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID5") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID5_SZ => 14
                            if (msg.HasElement("BEST_BID5_SZ") && !msg.GetElement("BEST_BID5_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID5_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            ////****************************************************************************************************************

                            //BEST_ASK1 => 15
                            if (msg.HasElement("BEST_ASK1") && !msg.GetElement("BEST_ASK1").IsNull)//check IsNull before use the field
                            {
                                sAsk=msg.GetElementAsString("BEST_ASK1");
                                sb.Append(msg.GetElementAsString("BEST_ASK1") + ",");
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("ASK") && !msg.GetElement("ASK").IsNull)//check IsNull before use the field
                            {
                                sAsk=msg.GetElementAsString("ASK");
                                sb.Append(sAsk + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK1_SZ => 16
                            if (msg.HasElement("BEST_ASK1_SZ") && !msg.GetElement("BEST_ASK1_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK1_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("ASK_SIZE") && !msg.GetElement("ASK_SIZE").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("ASK_SIZE") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else
                            { sb.Append(","); }

                            //BEST_ASK2 => 17
                            if (msg.HasElement("BEST_ASK2") && !msg.GetElement("BEST_ASK2").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK2") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK2_SZ => 18
                            if (msg.HasElement("BEST_ASK2_SZ") && !msg.GetElement("BEST_ASK2_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK2_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK3 => 19
                            if (msg.HasElement("BEST_ASK3") && !msg.GetElement("BEST_ASK3").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK3") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK3_SZ => 20
                            if (msg.HasElement("BEST_ASK3_SZ") && !msg.GetElement("BEST_ASK3_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK3_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK4 => 21
                            if (msg.HasElement("BEST_ASK4") && !msg.GetElement("BEST_ASK4").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK4") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK4_SZ => 22
                            if (msg.HasElement("BEST_ASK4_SZ") && !msg.GetElement("BEST_ASK4_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK4_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK5 => 23
                            if (msg.HasElement("BEST_ASK5") && !msg.GetElement("BEST_ASK5").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK5") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK5_SZ => 24
                            if (msg.HasElement("BEST_ASK5_SZ") && !msg.GetElement("BEST_ASK5_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK5_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //HIGH => 25
                            if (msg.HasElement("HIGH") && !msg.GetElement("HIGH").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("HIGH") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //LOW => 26
                            if (msg.HasElement("LOW") && !msg.GetElement("LOW").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("LOW"));// + ",");
                                bSentFlag = true;
                            }
                            //else { sb.Append(","); }

                            #endregion

                            //*******SEND OUT DATA**********
                            if (bSentFlag) 
                            {
                                if (!sInnerCode.StartsWith("CNH"))
                                { 
                                    m_PackagePool.Enqueue(sb.ToString()); 
                                }
                                else if (_dicFwdInd.ContainsKey(sInnerCode))
                                {                                                                          
                                    int iFwdInd = _dicFwdInd[sInnerCode];
                                    DateTime dt;
                                    TimeSpan ts, ts2;
                                    
                                    bool bSentFlag2 = false;
                                    if (iFwdInd > 0)
                                    {
                                        if (!String.IsNullOrEmpty(sLstPrc))
                                        {
                                            _daFwdLstPrc[iFwdInd] = dLstPrc = Math.Round((_daFwdLstPrc[0] + Convert.ToDouble(sLstPrc) / 10000.0) * 10000.0) / 10000.0;
                                            _dicLstTrd[sInnerCode] = sLstPrc = Convert.ToString(dLstPrc);
                                            _dicTime[sInnerCode] = DateTime.Now.ToString("HH:mm:ss");
                                            bSentFlag2 = true;
                                        }
                                        if (!String.IsNullOrEmpty(sBid))
                                        { 
                                            _daFwdBid[iFwdInd] = dBid = Math.Round((_daFwdBid[0] + Convert.ToDouble(sBid) / 10000.0) * 10000.0) / 10000.0;
                                            _dicBid[sInnerCode] = sBid = Convert.ToString(dBid);
                                        }
                                        if (!String.IsNullOrEmpty(sAsk))
                                        {
                                            _daFwdAsk[iFwdInd] = dAsk = Math.Round((_daFwdAsk[0] + Convert.ToDouble(sAsk) / 10000.0) * 10000.0) / 10000.0;
                                            _dicAsk[sInnerCode] = sAsk = Convert.ToString(dAsk);
                                        }

                                        if (_dicRelFut.ContainsKey(sInnerCode))
                                        {
                                            string sRelFut = _dicRelFut[sInnerCode];
                                            string[] saRelFut = sRelFut.Split(',');
                                            dt = _dicLstTrdDt[saRelFut[0]];
                                            if (dt <= _dtaFwdDt[iFwdInd])
                                            {
                                                ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                                ts2 = new TimeSpan(_dtaFwdDt[iFwdInd].Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                                dLstPrc = _daFwdLstPrc[iFwdInd - 1] + (_daFwdLstPrc[iFwdInd] - _daFwdLstPrc[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                dLstPrc = Math.Round(dLstPrc * 10000.0) / 10000.0;
                                                _dicLstTrd[saRelFut[0]] = sLstPrc = Convert.ToString(dLstPrc);
                                                _dicTime[saRelFut[0]] = DateTime.Now.ToString("HH:mm:ss");
                                                dBid = _daFwdBid[iFwdInd - 1] + (_daFwdBid[iFwdInd] - _daFwdBid[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                dBid = Math.Round(dBid * 10000.0) / 10000.0;
                                                _dicBid[saRelFut[0]] = sBid = Convert.ToString(dBid);
                                                dAsk = _daFwdAsk[iFwdInd - 1] + (_daFwdAsk[iFwdInd] - _daFwdAsk[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                dAsk = Math.Round(dAsk * 10000.0) / 10000.0;
                                                _dicAsk[saRelFut[0]] = sAsk = Convert.ToString(dAsk);
                                            }
                                            else if (_dtaFwdDt[iFwdInd] <= dt)
                                            {
                                                ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                                ts2 = new TimeSpan(_dtaFwdDt[iFwdInd + 1].Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                                dLstPrc = _daFwdLstPrc[iFwdInd] + (_daFwdLstPrc[iFwdInd + 1] - _daFwdLstPrc[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                dLstPrc = Math.Round(dLstPrc * 10000.0) / 10000.0;
                                                _dicLstTrd[saRelFut[0]] = sLstPrc = Convert.ToString(dLstPrc);
                                                _dicTime[saRelFut[0]] = DateTime.Now.ToString("HH:mm:ss");
                                                dBid = _daFwdBid[iFwdInd] + (_daFwdBid[iFwdInd + 1] - _daFwdBid[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                dBid = Math.Round(dBid * 10000.0) / 10000.0;
                                                _dicBid[saRelFut[0]] = sBid = Convert.ToString(dBid);
                                                dAsk = _daFwdAsk[iFwdInd] + (_daFwdAsk[iFwdInd + 1] - _daFwdAsk[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                dAsk = Math.Round(dAsk * 10000.0) / 10000.0;
                                                _dicAsk[saRelFut[0]] = sAsk = Convert.ToString(dAsk);
                                            }

                                            if (bSentFlag2)
                                            {
                                                sb.Remove(0, sb.Length);
                                                sb.Append(saRelFut[0] + "," + DateTime.Now.ToString("HHmmssff") + "," + sLstPrc + ",,," + sBid + ",1,,,,,,,,," + sAsk + ",1,,,,,,,,,,");
                                                m_PackagePool.Enqueue(sb.ToString());
                                            }

                                            if (saRelFut.Length > 1)
                                            {
                                                dt = _dicLstTrdDt[saRelFut[1]];
                                                if (dt <= _dtaFwdDt[iFwdInd])
                                                {
                                                    ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                                    ts2 = new TimeSpan(_dtaFwdDt[iFwdInd].Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                                    dLstPrc = _daFwdLstPrc[iFwdInd - 1] + (_daFwdLstPrc[iFwdInd] - _daFwdLstPrc[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                    dLstPrc = Math.Round(dLstPrc * 10000.0) / 10000.0;
                                                    _dicLstTrd[saRelFut[1]] = sLstPrc = Convert.ToString(dLstPrc);
                                                    _dicTime[saRelFut[1]] = DateTime.Now.ToString("HH:mm:ss");
                                                    dBid = _daFwdBid[iFwdInd - 1] + (_daFwdBid[iFwdInd] - _daFwdBid[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                    dBid = Math.Round(dBid * 10000.0) / 10000.0;
                                                    _dicBid[saRelFut[1]] = sBid = Convert.ToString(dBid);
                                                    dAsk = _daFwdAsk[iFwdInd - 1] + (_daFwdAsk[iFwdInd] - _daFwdAsk[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                    dAsk = Math.Round(dAsk * 10000.0) / 10000.0;
                                                    _dicAsk[saRelFut[1]] = sAsk = Convert.ToString(dAsk);
                                                }
                                                else if (_dtaFwdDt[iFwdInd] <= dt)
                                                {
                                                    ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                                    ts2 = new TimeSpan(_dtaFwdDt[iFwdInd + 1].Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                                    dLstPrc = _daFwdLstPrc[iFwdInd] + (_daFwdLstPrc[iFwdInd + 1] - _daFwdLstPrc[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                    dLstPrc = Math.Round(dLstPrc * 10000.0) / 10000.0;
                                                    _dicLstTrd[saRelFut[1]] = sLstPrc = Convert.ToString(dLstPrc);
                                                    _dicTime[saRelFut[1]] = DateTime.Now.ToString("HH:mm:ss");
                                                    dBid = _daFwdBid[iFwdInd] + (_daFwdBid[iFwdInd + 1] - _daFwdBid[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                    dBid = Math.Round(dBid * 10000.0) / 10000.0;
                                                    _dicBid[saRelFut[1]] = sBid = Convert.ToString(dBid);
                                                    dAsk = _daFwdAsk[iFwdInd] + (_daFwdAsk[iFwdInd + 1] - _daFwdAsk[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                    dAsk = Math.Round(dAsk * 10000.0) / 10000.0;
                                                    _dicAsk[saRelFut[1]] = sAsk = Convert.ToString(dAsk);
                                                }

                                                if (bSentFlag2)
                                                {
                                                    sb.Remove(0, sb.Length);
                                                    sb.Append(saRelFut[1] + "," + DateTime.Now.ToString("HHmmssff") + "," + sLstPrc + ",,," + sBid + ",1,,,,,,,,," + sAsk + ",1,,,,,,,,,,");
                                                    m_PackagePool.Enqueue(sb.ToString());
                                                }
                                            }
                                        }
                                    }
                                    else //人民幣境外即期
                                    {
                                        if (!String.IsNullOrEmpty(sLstPrc))
                                        {
                                            _daFwdLstPrc[0] = dLstPrc = Convert.ToDouble(sLstPrc);
                                            _dicLstTrd[sInnerCode] = sLstPrc;
                                            _dtaFwdDt[0] = DateTime.Now;
                                            _dicTime[sInnerCode] = DateTime.Now.ToString("HH:mm:ss");
                                            bSentFlag2 = true;
                                        }
                                        if (!String.IsNullOrEmpty(sBid))
                                        {
                                            _daFwdBid[0] = dBid = Convert.ToDouble(sBid);
                                            _dicBid[sInnerCode] = sBid;
                                            _dtaFwdDt[0] = DateTime.Now;
                                        }
                                        if (!String.IsNullOrEmpty(sAsk))
                                        {
                                            _daFwdAsk[0] = dAsk = Convert.ToDouble(sAsk);
                                            _dicAsk[sInnerCode] = sAsk;
                                            _dtaFwdDt[0] = DateTime.Now;
                                        }

                                        if (_dicRelFut.ContainsKey(sInnerCode))
                                        {
                                            string sRelFut = _dicRelFut[sInnerCode];
                                            string[] saRelFut = sRelFut.Split(',');

                                            dt = _dicLstTrdDt[saRelFut[0]];
                                            ts = new TimeSpan(dt.Subtract(_dtaFwdDt[0]).Ticks);
                                            ts2 = new TimeSpan(_dtaFwdDt[1].Subtract(_dtaFwdDt[0]).Ticks);
                                            dLstPrc = _daFwdLstPrc[0] + (_daFwdLstPrc[1] - _daFwdLstPrc[0]) / ts2.TotalDays * ts.TotalDays;
                                            dLstPrc = Math.Round(dLstPrc * 10000.0) / 10000.0;
                                            _dicLstTrd[saRelFut[0]] = sLstPrc = Convert.ToString(dLstPrc);
                                            _dicTime[saRelFut[0]] = DateTime.Now.ToString("HH:mm:ss");
                                            dBid = _daFwdBid[0] + (_daFwdBid[1] - _daFwdBid[0]) / ts2.TotalDays * ts.TotalDays;
                                            dBid = Math.Round(dBid * 10000.0) / 10000.0;
                                            _dicBid[saRelFut[0]] = sBid = Convert.ToString(dBid);
                                            dAsk = _daFwdAsk[0] + (_daFwdAsk[1] - _daFwdAsk[0]) / ts2.TotalDays * ts.TotalDays;
                                            dAsk = Math.Round(dAsk * 10000.0) / 10000.0;
                                            _dicAsk[saRelFut[0]] = sAsk = Convert.ToString(dAsk);

                                            if (bSentFlag2)
                                            {
                                                sb.Remove(0, sb.Length);
                                                sb.Append(saRelFut[0] + "," + DateTime.Now.ToString("HHmmssff") + "," + sLstPrc + ",,," + sBid + ",1,,,,,,,,," + sAsk + ",1,,,,,,,,,,");
                                                m_PackagePool.Enqueue(sb.ToString());
                                            }

                                            if (saRelFut.Length > 1)
                                            {
                                                dt = _dicLstTrdDt[saRelFut[1]];
                                                ts = new TimeSpan(dt.Subtract(_dtaFwdDt[0]).Ticks);
                                                ts2 = new TimeSpan(_dtaFwdDt[1].Subtract(_dtaFwdDt[0]).Ticks);
                                                dLstPrc = _daFwdLstPrc[0] + (_daFwdLstPrc[1] - _daFwdLstPrc[0]) / ts2.TotalDays * ts.TotalDays;
                                                dLstPrc = Math.Round(dLstPrc * 10000.0) / 10000.0;
                                                _dicLstTrd[saRelFut[1]] = sLstPrc = Convert.ToString(dLstPrc);
                                                _dicTime[saRelFut[1]] = DateTime.Now.ToString("HH:mm:ss");
                                                dBid = _daFwdBid[0] + (_daFwdBid[1] - _daFwdBid[0]) / ts2.TotalDays * ts.TotalDays;
                                                dBid = Math.Round(dBid * 10000.0) / 10000.0;
                                                _dicBid[saRelFut[1]] = sBid = Convert.ToString(dBid);
                                                dAsk = _daFwdAsk[0] + (_daFwdAsk[1] - _daFwdAsk[0]) / ts2.TotalDays * ts.TotalDays;
                                                dAsk = Math.Round(dAsk * 10000.0) / 10000.0;
                                                _dicAsk[saRelFut[1]] = sAsk = Convert.ToString(dAsk);
                                                if (bSentFlag2)
                                                {
                                                    sb.Remove(0, sb.Length);
                                                    sb.Append(saRelFut[1] + "," + DateTime.Now.ToString("HHmmssff") + "," + sLstPrc + ",,," + sBid + ",1,,,,,,,,," + sAsk + ",1,,,,,,,,,,");
                                                    m_PackagePool.Enqueue(sb.ToString());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        { m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][deqEvent_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                    }
                    #endregion
                }
            }
        }

        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan tsNow = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                        //RecoverFlag2 = false;
                        //TransCloseFlag = false;
                    }

                    if (Math.Abs(tsNow.Subtract(tsRecover).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    //if (Math.Abs(tsNow.Subtract(RecoverTime2).TotalMinutes) < 1 && !RecoverFlag2)
                    //{
                    //    ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                    //    RecoverFlag2 = true;
                    //}

                    //if (Math.Abs(tsNow.Subtract(TransCloseTime).TotalMinutes) < 1 && !TransCloseFlag)
                    //{
                    //    ThreadPool.QueueUserWorkItem(new WaitCallback(TransCloseWork));
                    //    TransCloseFlag = true;
                    //}

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            string sBlpData = m_PackagePool.Dequeue().ToString();
                            DealWithQuote(sBlpData);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException taex)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        //private void TransCloseWork(Object stateInfo)
        //{
        //    try
        //    {
        //        foreach (PCommodity P in m_PCommodityList.Commoditys)
        //        {
        //            if (P.QCommodity.Base.CommodityId.IndexOf("HK") > -1 || P.QCommodity.Base.CommodityId.IndexOf("STW") > -1 || P.QCommodity.Base.CommodityId.IndexOf("SCN") > -1)
        //            {
        //                P.SetClose(DateTime.Now.ToString("HHmmss"), DateTime.Now.ToString("HHmmssff"), P.QCommodity.HighLow.DayHighPrice, P.QCommodity.HighLow.DayLowPrice, 0.0, P.QCommodity.Best5.BuyPriceBest1, P.QCommodity.Best5.SellPriceBest1, P.QCommodity.Match.MatchPrice, DateTime.Today, 0, P.QCommodity.Match.MatchTotalQty, 0.0, P.QCommodity.Match.MatchPrice);
        //                DoSendWrite(P.QCommodity.Close);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][TransCloseWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
        //    }
        //}       

        private void ReStartWork(Object stateInfo)
        {
            try
            {
                if (_tDataWorker != null && _tDataWorker.IsAlive) { _tDataWorker.Abort(); _tDataWorker = null; }

                m_PacketNum = 0;

                LoadData();
                ConnectBLP();

                if (_tDataWorker == null) { _tDataWorker = new Thread(new ThreadStart(deqData)); _tDataWorker.Start(); }

                SubscribeBLP();
            }
            catch (Exception ex)
            { m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
        }

        private Element GetBloombergRefDataReq(string sProdCode, string[] saFields)
        {
            bool LoopSwitch = true;

            SessionOptions sessOptTmp = new SessionOptions();
            sessOptTmp.ServerHost = "127.0.0.1";
            sessOptTmp.ServerPort = 8194;

            Session sessTmp = new Session(sessOptTmp);

            if (!sessTmp.Start())
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][GetBloombergRefData_Error] " + "[Failed to start sessTmp]");
                return null;
            }

            if (!sessTmp.OpenService("//blp/refdata"))
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][GetBloombergRefData_Error] " + "[Failed to open refdata service]");
                return null;
            }

            Service refservice = sessTmp.GetService("//blp/refdata");

            //以下設定request內容******************************************************
            Request request = refservice.CreateRequest("ReferenceDataRequest");

            //設定商品名稱
            Element secs = request.GetElement("securities");
            secs.AppendValue(sProdCode);

            //設定資料欄位
            Element flds = request.GetElement("fields");
            for (int i = 0; i < saFields.Length; i++)
            { flds.AppendValue(saFields[i]); }

            sessTmp.SendRequest(request, null);

            Element RESULT = null;
            while (LoopSwitch)
            {
                Event eventobj = sessTmp.NextEvent();
                foreach (Bloomberglp.Blpapi.Message msg in eventobj.GetMessages())
                {
                    if (eventobj.Type.ToString() == "RESPONSE")
                    {
                        Element RefDataResponse = msg.AsElement;
                        Element SecurityDataArray = RefDataResponse.GetElement("securityData");
                        Element securityData = SecurityDataArray.GetValueAsElement(0);
                        Element FieldData = securityData.GetElement("fieldData");
                        RESULT = FieldData;
                        LoopSwitch = false;
                    }
                }
            }
            sessTmp.Stop();
            sessTmp = null;

            return RESULT;
        }
        
        private Dictionary<string, string> _dicComdtyId = new Dictionary<string, string>();
        private Dictionary<string, string> _dicInnerCode = new Dictionary<string, string>();
        private Dictionary<long, string> _dicInnerCode2 = new Dictionary<long, string>();
        private Dictionary<string, bool> _dicTsQuote = new Dictionary<string, bool>();
        private Dictionary<string, bool> _dicTibco = new Dictionary<string, bool>();
        private Dictionary<string, string> _dicExch = new Dictionary<string, string>();

        private string[] _saFwdSymbol = null;
        private DateTime[] _dtaFwdDt = null;
        private double[] _daFwdBid = null;
        private double[] _daFwdAsk = null;
        private double[] _daFwdLstPrc = null;
        private Dictionary<string, int> _dicFwdInd = new Dictionary<string, int>();
        private Dictionary<string, string> _dicRelFut = new Dictionary<string, string>();
        private Dictionary<string, DateTime> _dicLstTrdDt = new Dictionary<string, DateTime>();
        
        private void LoadData()
        {
            try
            {
                #region 交易商品

                string sComdtyKind = string.Empty;
                string sInnerCode = string.Empty;
                string sComdtyId = string.Empty;
                string sExch = string.Empty;

                //============================================================

                _dicTsQuote.Clear();
                _dicTibco.Clear();

                string sql = "SELECT BLPProd,TsQuote,Tibco,Exch FROM BLPSetting";
                DataView dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);
                foreach (DataRowView dr in dv)
                {
                    string sBLPProd = string.Empty;
                    if (dr["BLPProd"] != DBNull.Value && !String.IsNullOrEmpty(dr["BLPProd"].ToString()))
                    { sBLPProd = dr["BLPProd"].ToString().Trim(); }

                    if (dr["TsQuote"] != DBNull.Value && !String.IsNullOrEmpty(dr["TsQuote"].ToString()))
                    {
                        string sFlag = dr["TsQuote"].ToString().Trim();
                        if (sFlag.Equals("Y")) { _dicTsQuote[sBLPProd] = true; }
                        else if (sFlag.Equals("N")) { _dicTsQuote[sBLPProd] = false; }
                    }

                    if (dr["Tibco"] != DBNull.Value && !String.IsNullOrEmpty(dr["Tibco"].ToString()))
                    {
                        string sFlag = dr["Tibco"].ToString().Trim();
                        if (sFlag.Equals("Y")) { _dicTibco[sBLPProd] = true; }
                        else if (sFlag.Equals("N")) { _dicTibco[sBLPProd] = false; }
                    }

                    if (dr["Exch"] != DBNull.Value && !String.IsNullOrEmpty(dr["Exch"].ToString()))
                    {
                        _dicExch[sBLPProd] = dr["Exch"].ToString().Trim();
                    }
                }

                _dicTsQuote["CNH"] = true;
                _dicTibco["CNH"] = true;
                _dicExch["CNH"] = "V_INDEX";
                //============================================================

                _dicInnerCode.Clear();
                _dicComdtyId.Clear();

                List<string> lstFwdSymbol = new List<string>();
                List<DateTime> lstFwdDt = new List<DateTime>();
                List<double> lstFwdBid = new List<double>();
                List<double> lstFwdAsk = new List<double>();
                List<double> lstFwdLstPrc = new List<double>();
                List<string> lstFutSymbol = new List<string>();
                List<DateTime> lstFutDt = new List<DateTime>();

                m_PCommodityList.Commoditys.Clear();

                sql = "SELECT comdty.InnerCode,comdty.CommodityId,comdty.CommodityNm,comdty.SettlementMonth,comdty.CommodityKind,comdty.DecimalLocate,comdty.Unit,comdty.MaturityDate,pb.ReferencePrice,pb.RiseLimitPrice,pb.FallLimitPrice FROM Commodity comdty,PBase pb WHERE comdty.CommodityId=pb.CommodityId AND (comdty.InnerCode LIKE '% Index' OR comdty.InnerCode LIKE '% Equity' OR comdty.InnerCode LIKE '% Comdty' OR comdty.InnerCode LIKE '% Curncy') ORDER BY comdty.MaturityDate";
                dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);

                DateTime dt;
                foreach (DataRowView dr in dv)
                {
                    sComdtyKind = string.Empty;
                    sInnerCode = string.Empty;
                    sComdtyId = string.Empty;
                    dt = DateTime.Today;
                    try
                    {
                        if (dr["CommodityKind"] != DBNull.Value && !String.IsNullOrEmpty(dr["CommodityKind"].ToString())) { sComdtyKind = dr["CommodityKind"].ToString().Trim(); }
                        if (dr["InnerCode"] != DBNull.Value && !String.IsNullOrEmpty(dr["InnerCode"].ToString())) { sInnerCode = dr["InnerCode"].ToString().Trim(); }
                        if (dr["CommodityId"] != DBNull.Value && !String.IsNullOrEmpty(dr["CommodityId"].ToString())) { sComdtyId = dr["CommodityId"].ToString().Trim(); }

                        PCommodity PP = null;
                        if (sComdtyKind.Equals("Future"))
                        {
                            string sCont = string.Empty;
                            if (dr["SettlementMonth"] != DBNull.Value && !String.IsNullOrEmpty(dr["SettlementMonth"].ToString()))
                            {
                                sCont = dr["SettlementMonth"].ToString().Trim();
                                PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Future);
                                PP.QCommodity.Base.CommodityKind = CommodityKind.Future;
                                PP.QCommodity.Base.SettleMentMonth = sCont;
                            }
                            if (dr["MaturityDate"] != DBNull.Value && !String.IsNullOrEmpty(dr["MaturityDate"].ToString()))
                            {
                                string sMaturityDate = dr["MaturityDate"].ToString().Trim();
                                sMaturityDate = sMaturityDate.Substring(0, sMaturityDate.IndexOf(' '));
                                string sYear = sMaturityDate.Substring(0, 4);
                                string sMonth = sMaturityDate.Substring(sMaturityDate.IndexOf('/') + 1, sMaturityDate.LastIndexOf('/') - sMaturityDate.IndexOf('/') - 1);
                                string sDay = sMaturityDate.Substring(sMaturityDate.LastIndexOf('/') + 1, sMaturityDate.Length - sMaturityDate.LastIndexOf('/') - 1);
                                dt = new DateTime(Convert.ToInt32(sYear), Convert.ToInt32(sMonth), Convert.ToInt32(sDay), 11, 0, 0);
                            }                            
                        }
                        else if (sComdtyKind.EndsWith("Stock"))
                        {
                            PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Stock);
                            PP.QCommodity.Base.CommodityKind = CommodityKind.Stock;
                        }
                        else if (sComdtyKind.EndsWith("Currency"))
                        {
                            PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Currency);
                            PP.QCommodity.Base.CommodityKind = CommodityKind.Currency;
                        }

                        if (PP != null)
                        {
                            PP.QCommodity.Base.CommodityCode = "";
                            PP.QCommodity.Base.CommodityNm = dr["CommodityNm"].ToString().Trim();
                            PP.QCommodity.Base.Market = Market.None;
                            PP.QCommodity.Base.DecimalLocate = dr["DecimalLocate"] != DBNull.Value ? Convert.ToDouble(dr["DecimalLocate"].ToString()) : 1.0;
                            PP.QCommodity.Base.Unit = dr["Unit"] != DBNull.Value ? Convert.ToInt32(dr["Unit"].ToString()) : 1;

                            double dYstCls = dr["ReferencePrice"] != DBNull.Value ? Convert.ToDouble(dr["ReferencePrice"].ToString()) : 0;
                            PP.QCommodity.Base.ReferencePrice = dYstCls;
                            PP.QCommodity.Base.RiseLimitPrice = dr["RiseLimitPrice"] != DBNull.Value ? Convert.ToDouble(dr["RiseLimitPrice"].ToString()) : 0;
                            PP.QCommodity.Base.FallLimitPrice = dr["FallLimitPrice"] != DBNull.Value ? Convert.ToDouble(dr["FallLimitPrice"].ToString()) : 0;
                                                       
                            PP.QCommodity.HighLow.DayLowPrice = PP.QCommodity.Base.ReferencePrice;
                            PP.QCommodity.HighLow.DayHighPrice = PP.QCommodity.Base.ReferencePrice;

                            PP.QCommodity.Base.InformationTime = DateTime.Now.ToString("HHmmssff");
                            PP.QCommodity.Base.InformationSeq = DateTime.Now.ToString("HHmmssff");

                            PP.QCommodity.Base.TradeDate = DateTime.Today;

                            _dicComdtyId[sInnerCode] = sComdtyId;
                            _dicInnerCode[sComdtyId] = sInnerCode;

                            if (sInnerCode.StartsWith("CNH"))
                            {
                                if (dt >= DateTime.Today)
                                {
                                    if (sInnerCode.EndsWith(" CMPN Curncy"))
                                    {
                                        lstFwdSymbol.Add(sInnerCode);
                                        lstFwdDt.Add(dt);
                                        lstFwdLstPrc.Add(dYstCls);
                                        lstFwdBid.Add(dYstCls);
                                        lstFwdAsk.Add(dYstCls);

                                        _dicFwdInd[sInnerCode] = lstFwdSymbol.Count - 1;
                                    }
                                    else
                                    {
                                        lstFutSymbol.Add(sInnerCode);
                                        lstFutDt.Add(dt);                                        
                                    }
                                    _dicLstTrdDt[sInnerCode] = dt;
                                    _dicBid[sInnerCode] = _dicAsk[sInnerCode] = _dicLstTrd[sInnerCode] = Convert.ToString(dYstCls);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                }
                //================================================================================
                //==============================整理CNH虛擬期貨==============================
                //================================================================================
                _saFwdSymbol = lstFwdSymbol.ToArray();
                _dtaFwdDt = lstFwdDt.ToArray();
                _daFwdBid = lstFwdBid.ToArray();
                _daFwdAsk = lstFwdAsk.ToArray();
                _daFwdLstPrc = lstFwdLstPrc.ToArray();

                for (int i = 0; i < lstFutSymbol.Count; i++)
                {
                    sInnerCode = lstFutSymbol[i];
                    dt = lstFutDt[i];
                    for (int j = 0; j < _dtaFwdDt.Length - 1; j++)
                    {
                        if (_dtaFwdDt[j] < dt && dt <= _dtaFwdDt[j + 1])
                        {
                            TimeSpan ts = new TimeSpan(dt.Subtract(_dtaFwdDt[j]).Ticks);
                            TimeSpan ts2 = new TimeSpan(_dtaFwdDt[j + 1].Subtract(_dtaFwdDt[j]).Ticks);
                            double dYstCls = _daFwdLstPrc[j] + (_daFwdLstPrc[j + 1] - _daFwdLstPrc[j]) / ts2.TotalDays * ts.TotalDays;
                            string sYstCls = Convert.ToString(dYstCls);

                            string sLeftFwdSymbol = _saFwdSymbol[j];
                            string sRightFwdSymbol = _saFwdSymbol[j + 1];
                            string sRelFut = string.Empty;

                            if (_dicRelFut.ContainsKey(sLeftFwdSymbol))
                            {
                                sRelFut = _dicRelFut[sLeftFwdSymbol];
                                sRelFut += "," + sInnerCode;
                            }
                            else
                            {
                                sRelFut = sInnerCode;
                            }
                            _dicRelFut[sLeftFwdSymbol] = sRelFut;

                            if (_dicRelFut.ContainsKey(sRightFwdSymbol))
                            {
                                sRelFut = _dicRelFut[sRightFwdSymbol];
                                sRelFut += "," + sInnerCode;
                            }
                            else
                            {
                                sRelFut = sInnerCode;
                            }
                            _dicRelFut[sRightFwdSymbol] = sRelFut;

                            break;
                        }
                    }
                }

                //============================================================

                #endregion
            }
            catch (Exception ex)
            { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
        }

        private SessionOptions _sessOpt = null;
        private Session _sess = null;
        private bool _bStartFlag = false;
        private bool _bOpenFlag = false;
        private void ConnectBLP()
        {
            try
            {
                if (_sess != null)
                {
                    _sess.Stop();
                    _bStartFlag = false;
                    _bOpenFlag = false;
                    _sess = null;
                }

                if (_sess == null)
                {
                    _sessOpt = new SessionOptions();
                    _sessOpt.ServerHost = RemotIp;
                    _sessOpt.ServerPort = RemotePort;//Bloomberg指定

                    _sess = new Session(_sessOpt);

                    _bStartFlag = _sess.Start();
                    if (!_bStartFlag)
                    {
                        Console.WriteLine("[BLP回報]:Failed to start session");
                        return;
                    }

                    _bOpenFlag = _sess.OpenService("//blp/mktdata");
                    if (!_bOpenFlag)
                    {
                        Console.WriteLine("[BLP回報]:Failed to open service");
                        return;
                    }                    
                }                
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][ConnectBLP_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void SubscribeBLP()
        {
            try
            {
                List<Subscription> lstSubscr = new List<Subscription>();

                if (_bStartFlag && _bOpenFlag)
                {
                    if (_dicInnerCode.Keys.Count > 0)
                    {
                        string sInnerCode = string.Empty;
                        string[] saKeys = new string[_dicInnerCode.Keys.Count];                        
                        _dicInnerCode.Keys.CopyTo(saKeys, 0);

                        long lCId = -1;
                        long[] laKeys = new long[_dicInnerCode.Keys.Count];

                        string sFields = "TIME,LAST_PRICE,SIZE_LAST_TRADE,VOLUME,"; //1~4
                        sFields += "BID,BEST_BID2,BEST_BID3,BEST_BID4,BEST_BID5,ASK,BEST_ASK2,BEST_ASK3,BEST_ASK4,BEST_ASK5,";  //5~9 10~14
                        sFields += "BID_SIZE,BEST_BID2_SZ,BEST_BID3_SZ,BEST_BID4_SZ,BEST_BID5_SZ,ASK_SIZE,BEST_ASK2_SZ,BEST_ASK3_SZ,BEST_ASK4_SZ,BEST_ASK5_SZ"; //15~24

                        for (int i = 0; i < saKeys.Length; i++)
                        {
                            sInnerCode = _dicInnerCode[saKeys[i]];
                            _dicInnerCode2[++lCId] = sInnerCode;                            
                            lstSubscr.Add(new Subscription(sInnerCode, sFields, new CorrelationID(lCId)));
                        }

                        //USE MULTI-SESSION??
                        _sess.Subscribe(lstSubscr);
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][SubscribeBLP_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void DealWithQuote(string sBlpData)
        {            
            string[] saBlpData = sBlpData.Split(',');
            try
            {
                if (_dicComdtyId.ContainsKey(saBlpData[0]))
                {
                    string sInnerCode = saBlpData[0];
                    string sComdtyId = _dicComdtyId[sInnerCode];
                    string sBLPProd = sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2);
                    PCommodity mPCommodity = m_PCommodityList.Get(sComdtyId);
                    if (mPCommodity == null) { return; }

                    string sNow = saBlpData[1];
                    string sSeq = DateTime.Now.ToString("HHmmssff");

                    bool bSendFlag = false;
                    if (!String.IsNullOrEmpty(saBlpData[2])) { mPCommodity.QCommodity.Match.MatchPrice = Convert.ToDouble(saBlpData[2]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[3])) { mPCommodity.QCommodity.Match.MatchQty = Convert.ToInt32(saBlpData[3]); }
                    if (!String.IsNullOrEmpty(saBlpData[4])) { mPCommodity.QCommodity.Match.MatchTotalQty = Convert.ToInt32(saBlpData[4]); bSendFlag = true; }
                    if (bSendFlag)
                    {
                        mPCommodity.QCommodity.Match.InformationTime = sNow;
                        mPCommodity.QCommodity.Match.InformationSeq = sSeq;
                        mPCommodity.QCommodity.Match.MatchTime = sNow;
                        if (mPCommodity.QCommodity.Match.MatchPrice != 0.0) { mPCommodity.QCommodity.Match.MatchPrices = mPCommodity.QCommodity.Match.MatchPrice; }
                        if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                        { DoSendWrite(mPCommodity.QCommodity.Match); }
                    }

                    bSendFlag = false;
                    if (!String.IsNullOrEmpty(saBlpData[5])) { mPCommodity.QCommodity.Best5.BuyPriceBest1 = Convert.ToDouble(saBlpData[5]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[6])) { mPCommodity.QCommodity.Best5.BuyQtyBest1 = Convert.ToInt32(saBlpData[6]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[7])) { mPCommodity.QCommodity.Best5.BuyPriceBest2 = Convert.ToDouble(saBlpData[7]); }
                    if (!String.IsNullOrEmpty(saBlpData[8])) { mPCommodity.QCommodity.Best5.BuyQtyBest2 = Convert.ToInt32(saBlpData[8]); }
                    if (!String.IsNullOrEmpty(saBlpData[9])) { mPCommodity.QCommodity.Best5.BuyPriceBest3 = Convert.ToDouble(saBlpData[9]); }
                    if (!String.IsNullOrEmpty(saBlpData[10])) { mPCommodity.QCommodity.Best5.BuyQtyBest3 = Convert.ToInt32(saBlpData[10]); }
                    if (!String.IsNullOrEmpty(saBlpData[11])) { mPCommodity.QCommodity.Best5.BuyPriceBest4 = Convert.ToDouble(saBlpData[11]); }
                    if (!String.IsNullOrEmpty(saBlpData[12])) { mPCommodity.QCommodity.Best5.BuyQtyBest4 = Convert.ToInt32(saBlpData[12]); }
                    if (!String.IsNullOrEmpty(saBlpData[13])) { mPCommodity.QCommodity.Best5.BuyPriceBest5 = Convert.ToDouble(saBlpData[13]); }
                    if (!String.IsNullOrEmpty(saBlpData[14])) { mPCommodity.QCommodity.Best5.BuyQtyBest5 = Convert.ToInt32(saBlpData[14]); }
                    if (!String.IsNullOrEmpty(saBlpData[15])) { mPCommodity.QCommodity.Best5.SellPriceBest1 = Convert.ToDouble(saBlpData[15]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[16])) { mPCommodity.QCommodity.Best5.SellQtyBest1 = Convert.ToInt32(saBlpData[16]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[17])) { mPCommodity.QCommodity.Best5.SellPriceBest2 = Convert.ToDouble(saBlpData[17]); }
                    if (!String.IsNullOrEmpty(saBlpData[18])) { mPCommodity.QCommodity.Best5.SellQtyBest2 = Convert.ToInt32(saBlpData[18]); }
                    if (!String.IsNullOrEmpty(saBlpData[19])) { mPCommodity.QCommodity.Best5.SellPriceBest3 = Convert.ToDouble(saBlpData[19]); }
                    if (!String.IsNullOrEmpty(saBlpData[20])) { mPCommodity.QCommodity.Best5.SellQtyBest3 = Convert.ToInt32(saBlpData[20]); }
                    if (!String.IsNullOrEmpty(saBlpData[21])) { mPCommodity.QCommodity.Best5.SellPriceBest4 = Convert.ToDouble(saBlpData[21]); }
                    if (!String.IsNullOrEmpty(saBlpData[22])) { mPCommodity.QCommodity.Best5.SellQtyBest4 = Convert.ToInt32(saBlpData[22]); }
                    if (!String.IsNullOrEmpty(saBlpData[23])) { mPCommodity.QCommodity.Best5.SellPriceBest5 = Convert.ToDouble(saBlpData[23]); }
                    if (!String.IsNullOrEmpty(saBlpData[24])) { mPCommodity.QCommodity.Best5.SellQtyBest5 = Convert.ToInt32(saBlpData[24]); }
                    if (bSendFlag)
                    {
                        mPCommodity.QCommodity.Best5.InformationTime = sNow;
                        mPCommodity.QCommodity.Best5.InformationSeq = sSeq;
                        mPCommodity.QCommodity.Best5.BuyPriceBest1s = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        if (mPCommodity.QCommodity.Best5.BuyPriceBest1s == 0.0 && mPCommodity.QCommodity.Match != null) { mPCommodity.QCommodity.Best5.BuyPriceBest1s = mPCommodity.QCommodity.Match.MatchPrice; }
                        mPCommodity.QCommodity.Best5.SellPriceBest1s = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        if (mPCommodity.QCommodity.Best5.SellPriceBest1s == 0.0 && mPCommodity.QCommodity.Match != null) { mPCommodity.QCommodity.Best5.SellPriceBest1s = mPCommodity.QCommodity.Match.MatchPrice; }
                        if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                        { DoSendWrite(mPCommodity.QCommodity.Best5); }
                    }

                    //bSendFlag = false;
                    //if (!String.IsNullOrEmpty(saBlpData[25]) && mPCommodity.QCommodity.HighLow.DayHighPrice < Convert.ToDouble(saBlpData[25])) { mPCommodity.QCommodity.HighLow.DayHighPrice = Convert.ToDouble(saBlpData[25]); bSendFlag = true; }
                    //if (!String.IsNullOrEmpty(saBlpData[26]) && mPCommodity.QCommodity.HighLow.DayLowPrice > Convert.ToDouble(saBlpData[26])) { mPCommodity.QCommodity.HighLow.DayLowPrice = Convert.ToDouble(saBlpData[26]); bSendFlag = true; }
                    //if (bSendFlag)
                    //{
                    //    mPCommodity.QCommodity.HighLow.InformationTime = sNow;
                    //    mPCommodity.QCommodity.HighLow.InformationSeq = sSeq;
                    //    mPCommodity.QCommodity.HighLow.ShowTime = sNow;
                    //    if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                    //    { DoSendWrite(mPCommodity.QCommodity.HighLow); }
                    //}
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][DealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                { obj2 = ((ICopy)obj).Copy(); }

                m_WriteDBPool.Enqueue(obj2);
            }
        }
    }
}
