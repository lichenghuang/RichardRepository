﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;

namespace WCFLimitQuote
{
    public class WCFLimitQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "0840";
        public string SubDBConnectString = "";
        public string SubSql = "";
        public string RemotIp = "";

        public WCFLimitQuoteFactorySetting()
        {
        }
        public WCFLimitQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public WCFLimitQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    public class WCFLimitQuoteSource : QuoteSource
    {
        private Thread RoutineThread;
        private QuotePush Q = null;
        private string DBConnectString = "";
        private TimeSpan RecoverTime;
        private string SubDBConnectString = "";
        private string SubSql = "";
        private string RemotIp = "";
        private bool RecoverFlag = false;
        private HashSet<string> m_ClientSubCommodity = new HashSet<string>();        
        private System.Timers.Timer tr = new System.Timers.Timer(10000);
        private object LockObj = new object();

        public WCFLimitQuoteSource(WCFLimitQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);
            SubDBConnectString = QuoteSetting.SubDBConnectString;
            SubSql = QuoteSetting.SubSql;
            RemotIp = QuoteSetting.RemotIp;
        }
        public override bool Start()
        {
            try
            {
                RoutineThread = new Thread(new ThreadStart(RoutineWork));
                RoutineThread.Start();

                base.Start();

                tr.Elapsed += new ElapsedEventHandler(tr_Elapsed);
                tr.AutoReset = false;

                Q = new QuotePush(Communication.TCP, RemotIp);
                Q.QuoteArrived += new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                Q.MsgArrived += new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                Q.Start();

                DataView dv = DeriLib.Util.ExecSqlQry(SubSql, SubDBConnectString);

                m_ClientSubCommodity.Clear();

                foreach (DataRowView dr in dv)
                    m_ClientSubCommodity.Add(dr["CommodityId"].ToString());

                if (m_ClientSubCommodity.Count > 0)
                {
                    List<string> L = m_ClientSubCommodity.ToList<string>();
                    Q.SubCommodity(L);
                }

                return true;
            }
            catch (Exception ex)
            {
                try
                {
                    tr.Start();
                    Q.Close();
                }
                catch (Exception ex2)
                {
                }
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return false;              
            }
        }
        public override bool Close()
        {
            try
            {
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                Q.Close();
                tr.Elapsed -= new ElapsedEventHandler(tr_Elapsed);
                tr.Stop();
                tr.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public void tr_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                if (Q != null)
                {
                    Q.QuoteArrived -= new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                    Q.MsgArrived -= new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                }

                Q = new QuotePush(Communication.TCP, RemotIp);
                Q.QuoteArrived += new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                Q.MsgArrived += new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                Q.Start();

                if (m_ClientSubCommodity.Count > 0)
                {
                    List<string> L = m_ClientSubCommodity.ToList<string>();
                    Q.SubCommodity(L);
                }
            }
            catch (Exception ex)
            {
                try
                {
                    tr.Start();
                    Q.Close();
                }
                catch (Exception ex2)
                {
                }
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void Q_MsgArrived(object obj)
        {
            try
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WCFLimitQuoteSource Connection Is Lost]");
                tr.Start();
            }
            catch
            {
            }
        }
        private void Q_QuoteArrived(object obj)
        {
            m_PacketNum++;
            m_PackagePool.Enqueue(obj);
        }

        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;                        
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            object obj = m_PackagePool.Dequeue();
                            DealWithQuote(obj);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ReStartWork(Object stateInfo)
        {
            try
            {                
                m_PacketNum = 0;

                if (m_ClientSubCommodity.Count > 0)
                {
                    List<string> L = m_ClientSubCommodity.ToList<string>();
                    Q.UnSubCommodity(L);
                }

                DataView dv = DeriLib.Util.ExecSqlQry(SubSql, SubDBConnectString);

                m_ClientSubCommodity.Clear();

                foreach (DataRowView dr in dv)
                {
                    if (m_QuoteSetting.IsWriteToDb)
                        DeriLib.Util.ExecSqlCmd("EXEC spClearTmpTableForCommodity '" + dr["CommodityId"].ToString() + "'", m_QuoteSetting.DBConnectString);

                    m_ClientSubCommodity.Add(dr["CommodityId"].ToString());
                }

                if (m_ClientSubCommodity.Count > 0)
                {
                    List<string> L = m_ClientSubCommodity.ToList<string>();
                    Q.SubCommodity(L);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }        
        private void DealWithQuote(object obj)
        {
            int j = 0;
            PCommodity mPCommodity = null;
            DateTime dt1;
            bool b;

            try
            {
                Type iType = obj.GetType();

                if (iType == typeof(QCommodity))
                {
                    QCommodity QCommodity = (QCommodity)obj;

                    mPCommodity = m_PCommodityList.SetNotGetFromDB(QCommodity.Base.CommodityCode, QCommodity.Base.CommodityId, QCommodity.Base.Market, QCommodity.Base.CommodityKind);
                    mPCommodity.IsLocalCommodity = true;

                    mPCommodity.SetBase(QCommodity.Base.Market, QCommodity.Base.CommodityKind, QCommodity.Base.CommodityType, QCommodity.Base.CommodityCode, QCommodity.Base.CommodityNm, QCommodity.Base.TradeDate, QCommodity.Base.InformationTime, QCommodity.Base.InformationSeq, QCommodity.Base.SettleMentMonth, QCommodity.Base.Strike, QCommodity.Base.ReferencePrice, QCommodity.Base.RiseLimitPrice, QCommodity.Base.FallLimitPrice, QCommodity.Base.RiseLimitPrice2, QCommodity.Base.FallLimitPrice2, QCommodity.Base.RiseLimitPrice3, QCommodity.Base.FallLimitPrice3, QCommodity.Base.Unit, QCommodity.Base.ProdKind, QCommodity.Base.DecimalLocate, QCommodity.Base.StrikeDecimalLocate, QCommodity.Base.InnerCode, QCommodity.Base.CommodityProperty);
                    if (m_QuoteSetting.IsWriteToDb)
                        m_WriteDBPool.Enqueue(QCommodity.Base);

                    if (QCommodity.Extra != null)
                    {
                        PCommodity Underlying = m_PCommodityList.Set(QCommodity.Extra.UnderlyingId);                        
                        mPCommodity.SetExtra(QCommodity.Extra.CommodityId, QCommodity.Extra.UnderlyingId, Underlying, QCommodity.Extra.Maturity, QCommodity.Extra.Strike, QCommodity.Extra.BarrierPrice, QCommodity.Extra.ExecRatio, QCommodity.Extra.HisVol, QCommodity.Extra.LastTradeDate, QCommodity.Extra.IssueQty, QCommodity.Extra.CancelQty, QCommodity.Extra.Duration);
                    }
                    if (QCommodity.HisVol != null)
                        mPCommodity.SetHIV(QCommodity.HisVol.CommodityId, QCommodity.HisVol.HIV1M, QCommodity.HisVol.HIV3M, QCommodity.HisVol.HIV6M, QCommodity.HisVol.HIV12M);

                    if (mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenTime == string.Empty || mPCommodity.QCommodity.Open.OpenTime == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0)
                    {
                        if (QCommodity.Open.OpenPrice != 0.0)
                        {
                            if (m_QuoteSetting.IsWriteToDb)
                                m_WriteDBPool.Enqueue(QCommodity.Open);
                        }
                    }

                    if (QCommodity.Best5.InformationSeq != string.Empty && QCommodity.Best5.InformationSeq != null)
                    {
                        b = DateTime.TryParseExact(QCommodity.Best5.InformationTime,"HHmmss",null,System.Globalization.DateTimeStyles.None,out dt1);

                        if (b && dt1.Subtract(DateTime.Now).TotalHours < 1.0)
                        {
                            //if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || mPCommodity.QCommodity.Best5.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(QCommodity.Best5.InformationSeq))
                            //{
                                if (QCommodity.Best5.BuyPriceBest1 != 0.0 || QCommodity.Best5.SellPriceBest1 != 0.0)
                                {
                                    if (m_QuoteSetting.IsWriteToDb)
                                        m_WriteDBPool.Enqueue(QCommodity.Best5);
                                }
                            //}
                        }
                    }

                    if (QCommodity.Match.InformationSeq != string.Empty && QCommodity.Match.InformationSeq != null)
                    {
                        b = DateTime.TryParseExact(QCommodity.Match.InformationTime, "HHmmss", null, System.Globalization.DateTimeStyles.None, out dt1);

                        if (b && dt1.Subtract(DateTime.Now).TotalHours < 1.0)
                        {
                            //if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || mPCommodity.QCommodity.Match.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(QCommodity.Match.InformationSeq) || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) == int.Parse(QCommodity.Match.InformationSeq) && mPCommodity.QCommodity.Match.MatchSeq < QCommodity.Match.MatchSeq) || mPCommodity.QCommodity.Match.MatchTotalAmt < QCommodity.Match.MatchTotalAmt || mPCommodity.QCommodity.Match.MatchTotalQty < QCommodity.Match.MatchTotalQty)
                            //{
                                if (m_QuoteSetting.IsWriteToDb)
                                    m_WriteDBPool.Enqueue(QCommodity.Match);
                            //}
                        }
                    }
                    if (QCommodity.HighLow.ShowTime != string.Empty && QCommodity.HighLow.ShowTime != null)
                    {
                        if (mPCommodity.QCommodity.HighLow == null || mPCommodity.QCommodity.HighLow.ShowTime == string.Empty || mPCommodity.QCommodity.HighLow.ShowTime == null || int.Parse(mPCommodity.QCommodity.HighLow.ShowTime) < int.Parse(QCommodity.HighLow.ShowTime))
                        {
                            //if (QCommodity.HighLow.DayHighPrice != 0.0 || QCommodity.HighLow.DayLowPrice != 0.0)
                            //{
                                if (m_QuoteSetting.IsWriteToDb)
                                    m_WriteDBPool.Enqueue(QCommodity.HighLow);
                            //}
                        }
                    }

                    if (QCommodity.Close.InformationTime != string.Empty && QCommodity.Close.InformationTime != null)
                    {
                        if (m_QuoteSetting.IsWriteToDb)
                            m_WriteDBPool.Enqueue(QCommodity.Close);
                    }
                    /*if (QCommodity.Greeks.InformationTime != string.Empty && QCommodity.Greeks.InformationTime != null)
                    {                                    
                        if (m_QuoteSetting.IsWriteToDb)
                            m_WriteDBPool.Enqueue(mPCommodity.QCommodity.HighLow);                            
                    }*/

                    mPCommodity.SetOpen(QCommodity.Open.OpenTime, QCommodity.Open.OpenPrice);
                    mPCommodity.SetBest5(QCommodity.Best5.InformationTime, QCommodity.Best5.InformationSeq, QCommodity.Best5.BuyPriceBest1, QCommodity.Best5.BuyQtyBest1, QCommodity.Best5.BuyPriceBest2, QCommodity.Best5.BuyQtyBest2, QCommodity.Best5.BuyPriceBest3, QCommodity.Best5.BuyQtyBest3, QCommodity.Best5.BuyPriceBest4, QCommodity.Best5.BuyQtyBest4, QCommodity.Best5.BuyPriceBest5, QCommodity.Best5.BuyQtyBest5, QCommodity.Best5.SellPriceBest1, QCommodity.Best5.SellQtyBest1, QCommodity.Best5.SellPriceBest2, QCommodity.Best5.SellQtyBest2, QCommodity.Best5.SellPriceBest3, QCommodity.Best5.SellQtyBest3, QCommodity.Best5.SellPriceBest4, QCommodity.Best5.SellQtyBest4, QCommodity.Best5.SellPriceBest5, QCommodity.Best5.SellQtyBest5, QCommodity.Best5.BuyPriceDerived, QCommodity.Best5.BuyQtyDerived, QCommodity.Best5.SellPriceDerived, QCommodity.Best5.SellQtyDerived);
                    /*if (m_QuoteSetting.IsCalculateGreeks)
                        m_CalculateGreeksPool.Enqueue(QCommodity.Best5);*/
                    mPCommodity.SetMatch(QCommodity.Match.InformationTime, QCommodity.Match.InformationSeq, QCommodity.Match.MatchSeq, QCommodity.Match.MatchTime, QCommodity.Match.MatchPrice, QCommodity.Match.MatchQty, QCommodity.Match.MatchAmt, QCommodity.Match.MatchTotalAmt, QCommodity.Match.MatchTotalQty, QCommodity.Match.MatchTotalCnt, QCommodity.Match.MatchBuyTotalCnt, QCommodity.Match.MatchSellTotalCnt);
                    /*if (m_QuoteSetting.IsCalculateGreeks)
                        m_CalculateGreeksPool.Enqueue(QCommodity.Match);*/
                    mPCommodity.SetHighLow(QCommodity.HighLow.InformationTime, QCommodity.HighLow.InformationSeq, QCommodity.HighLow.DayHighPrice, QCommodity.HighLow.DayLowPrice, QCommodity.HighLow.ShowTime);
                    mPCommodity.SetClose(QCommodity.Close.InformationTime, QCommodity.Close.InformationSeq, QCommodity.Close.DayHighPrice, QCommodity.Close.DayLowPrice, QCommodity.Close.OpenPrice, QCommodity.Close.BuyPrice, QCommodity.Close.SellPrice, QCommodity.Close.ClosePrice, QCommodity.Close.CloseDate, QCommodity.Close.MatchTotalCnt, QCommodity.Close.MatchTotalQty, QCommodity.Close.MatchTotalAmt, QCommodity.Close.ComBuyCnt, QCommodity.Close.ComBuyQty, QCommodity.Close.ComSellCnt, QCommodity.Close.ComSellQty, QCommodity.Close.ComTotalQty, QCommodity.Close.SettlementPrice, QCommodity.Close.OpenInterest, QCommodity.Close.LastCloseDate, QCommodity.Close.LastSettlementPrice, QCommodity.Close.LastOpenInterest);
                    //mPCommodity.SetGreeks(QCommodity.Greeks.InformationTime, QCommodity.Greeks.LastIV, QCommodity.Greeks.Bid1IV, QCommodity.Greeks.Bid2IV, QCommodity.Greeks.Bid3IV, QCommodity.Greeks.Bid4IV, QCommodity.Greeks.Bid5IV, QCommodity.Greeks.Ask1IV, QCommodity.Greeks.Ask2IV, QCommodity.Greeks.Ask3IV, QCommodity.Greeks.Ask4IV, QCommodity.Greeks.Ask5IV, QCommodity.Greeks.Delta, QCommodity.Greeks.Gamma, QCommodity.Greeks.Vega, QCommodity.Greeks.Theta, QCommodity.Greeks.Rho, QCommodity.Greeks.TPrice);

                    mPCommodity.Send(QCommodity);
                }
                else if (iType == typeof(QBase))
                {
                    QBase QBase = (QBase)obj;

                    mPCommodity = m_PCommodityList.SetNotGetFromDB(QBase.CommodityCode, QBase.CommodityId, QBase.Market, QBase.CommodityKind);

                    if (mPCommodity == null) { return; }

                    mPCommodity.SetBase(QBase.Market, QBase.CommodityKind, QBase.CommodityType, QBase.CommodityCode, QBase.CommodityNm, QBase.TradeDate, QBase.InformationTime, QBase.InformationSeq, QBase.SettleMentMonth, QBase.Strike, QBase.ReferencePrice, QBase.RiseLimitPrice, QBase.FallLimitPrice, QBase.RiseLimitPrice2, QBase.FallLimitPrice2, QBase.RiseLimitPrice3, QBase.FallLimitPrice3, QBase.Unit, QBase.ProdKind, QBase.DecimalLocate, QBase.StrikeDecimalLocate, QBase.InnerCode, QBase.CommodityProperty);
                    mPCommodity.Send(QBase);

                    if (m_QuoteSetting.IsWriteToDb)
                        m_WriteDBPool.Enqueue(QBase);
                }
                else if (iType == typeof(QOpen))
                {
                    QOpen QOpen = (QOpen)obj;

                    mPCommodity = m_PCommodityList.Get(QOpen.CommodityId);

                    if (mPCommodity == null) { return; }

                    if (mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenTime == string.Empty || mPCommodity.QCommodity.Open.OpenTime == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0)
                    {
                        if (m_QuoteSetting.IsWriteToDb)
                            m_WriteDBPool.Enqueue(QOpen);
                    }

                    mPCommodity.SetOpen(QOpen.OpenTime, QOpen.OpenPrice);
                    mPCommodity.Send(QOpen);
                }
                else if (iType == typeof(QBest5))
                {
                    QBest5 QBest5 = (QBest5)obj;

                    mPCommodity = m_PCommodityList.Get(QBest5.CommodityId);

                    if (mPCommodity == null) { return; }

                    b = DateTime.TryParseExact(QBest5.InformationTime, "HHmmss", null, System.Globalization.DateTimeStyles.None, out dt1);

                    if (b && dt1.Subtract(DateTime.Now).TotalHours < 1.0)
                    {
                        if (QBest5.InformationSeq != string.Empty && QBest5.InformationSeq != null)
                        {
                            if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || mPCommodity.QCommodity.Best5.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(QBest5.InformationSeq))
                            {
                                if (m_QuoteSetting.IsWriteToDb)
                                    m_WriteDBPool.Enqueue(QBest5);
                            }
                        }
                    }
                    
                    mPCommodity.SetBest5(QBest5.InformationTime, QBest5.InformationSeq, QBest5.BuyPriceBest1, QBest5.BuyQtyBest1, QBest5.BuyPriceBest2, QBest5.BuyQtyBest2, QBest5.BuyPriceBest3, QBest5.BuyQtyBest3, QBest5.BuyPriceBest4, QBest5.BuyQtyBest4, QBest5.BuyPriceBest5, QBest5.BuyQtyBest5, QBest5.SellPriceBest1, QBest5.SellQtyBest1, QBest5.SellPriceBest2, QBest5.SellQtyBest2, QBest5.SellPriceBest3, QBest5.SellQtyBest3, QBest5.SellPriceBest4, QBest5.SellQtyBest4, QBest5.SellPriceBest5, QBest5.SellQtyBest5, QBest5.BuyPriceDerived, QBest5.BuyQtyDerived, QBest5.SellPriceDerived, QBest5.SellQtyDerived);
                    /*if (m_QuoteSetting.IsCalculateGreeks)
                        m_CalculateGreeksPool.Enqueue(QBest5);*/
                    mPCommodity.Send(QBest5);
                }
                else if (iType == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;

                    mPCommodity = m_PCommodityList.Get(QMatch.CommodityId);

                    if (mPCommodity == null) { return; }

                    b = DateTime.TryParseExact(QMatch.InformationTime, "HHmmss", null, System.Globalization.DateTimeStyles.None, out dt1);

                    if (b && dt1.Subtract(DateTime.Now).TotalHours < 1.0)
                    {
                        if (QMatch.InformationSeq != string.Empty && QMatch.InformationSeq != null)
                        {
                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || mPCommodity.QCommodity.Match.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(QMatch.InformationSeq) || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) == int.Parse(QMatch.InformationSeq) && mPCommodity.QCommodity.Match.MatchSeq < QMatch.MatchSeq) || mPCommodity.QCommodity.Match.MatchTotalAmt < QMatch.MatchTotalAmt || mPCommodity.QCommodity.Match.MatchTotalQty < QMatch.MatchTotalQty)
                            {
                                if (m_QuoteSetting.IsWriteToDb)
                                    m_WriteDBPool.Enqueue(QMatch);
                            }
                        }
                    }

                    mPCommodity.SetMatch(QMatch.InformationTime, QMatch.InformationSeq, QMatch.MatchSeq, QMatch.MatchTime, QMatch.MatchPrice, QMatch.MatchQty, QMatch.MatchAmt, QMatch.MatchTotalAmt, QMatch.MatchTotalQty, QMatch.MatchTotalCnt, QMatch.MatchBuyTotalCnt, QMatch.MatchSellTotalCnt);
                    /*if (m_QuoteSetting.IsCalculateGreeks)
                        m_CalculateGreeksPool.Enqueue(QMatch);*/
                    mPCommodity.Send(QMatch);
                }
                else if (iType == typeof(QHighLow))
                {
                    QHighLow QHighLow = (QHighLow)obj;

                    mPCommodity = m_PCommodityList.Get(QHighLow.CommodityId);

                    if (mPCommodity == null) { return; }

                    if (QHighLow.ShowTime != string.Empty && QHighLow.ShowTime != null)
                    {
                        if (mPCommodity.QCommodity.HighLow == null || mPCommodity.QCommodity.HighLow.ShowTime == string.Empty || mPCommodity.QCommodity.HighLow.ShowTime == null || int.Parse(mPCommodity.QCommodity.HighLow.ShowTime) < int.Parse(QHighLow.ShowTime))
                        {
                            if (m_QuoteSetting.IsWriteToDb)
                                m_WriteDBPool.Enqueue(QHighLow);
                        }
                    }

                    mPCommodity.SetHighLow(QHighLow.InformationTime, QHighLow.InformationSeq, QHighLow.DayHighPrice, QHighLow.DayLowPrice, QHighLow.ShowTime);
                    mPCommodity.Send(QHighLow);
                }
                else if (iType == typeof(QClose))
                {
                    QClose QClose = (QClose)obj;

                    mPCommodity = m_PCommodityList.Get(QClose.CommodityId);

                    if (mPCommodity == null) { return; }

                    if (QClose.InformationTime != string.Empty && QClose.InformationTime != null)
                    {
                        if (m_QuoteSetting.IsWriteToDb)
                            m_WriteDBPool.Enqueue(QClose);
                    }

                    mPCommodity.SetClose(QClose.InformationTime, QClose.InformationSeq, QClose.DayHighPrice, QClose.DayLowPrice, QClose.OpenPrice, QClose.BuyPrice, QClose.SellPrice, QClose.ClosePrice, QClose.CloseDate, QClose.MatchTotalCnt, QClose.MatchTotalQty, QClose.MatchTotalAmt, QClose.ComBuyCnt, QClose.ComBuyQty, QClose.ComSellCnt, QClose.ComSellQty, QClose.ComTotalQty, QClose.SettlementPrice, QClose.OpenInterest, QClose.LastCloseDate, QClose.LastSettlementPrice, QClose.LastOpenInterest);
                    mPCommodity.Send(QClose);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WCFLimitDealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
         
        }
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }
    }
}
