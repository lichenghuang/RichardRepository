﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using DeriLib;

namespace SelfIndex
{
    public class SelfIndexFactorySetting : QuoteFactorySetting
    {
        public int Calculatems = 1000;
        public string STime = "0900";
        public string ETime = "2030";
        public string EstimateLabel = "";

        public SelfIndexFactorySetting()
        {
        }
        public SelfIndexFactorySetting(string Service)
            : base(Service)
        {
        }
        public SelfIndexFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    public class SelfIndexQuoteSource : QuoteSource
    {
        private Thread CalThread;
        private string DBConnectString = "";
        private TimeSpan STime;
        private TimeSpan ETime;
        private bool StartFlag = false;
        private bool EndFlag = false;
        private int Calculatems = 0;
        private string EstimateLabel = "";
        private List<EstimateCommodity> EstimateCommodityList = new List<EstimateCommodity>();

        public SelfIndexQuoteSource(SelfIndexFactorySetting QuoteSetting)
            : base((SelfIndexFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            STime = new TimeSpan(int.Parse(QuoteSetting.STime.Substring(0, 2)), int.Parse(QuoteSetting.STime.Substring(3, 2)), 0);
            ETime = new TimeSpan(int.Parse(QuoteSetting.ETime.Substring(0, 2)), int.Parse(QuoteSetting.ETime.Substring(3, 2)), 0);

            Calculatems = QuoteSetting.Calculatems;
            EstimateLabel = QuoteSetting.EstimateLabel;
        }
        public override bool Start()
        {
            LoadData();

            CalThread = new Thread(new ThreadStart(CalQuote));
            CalThread.Start();

            return base.Start();
        }
        public override bool Close()
        {
            try
            {
                if (CalThread != null && CalThread.IsAlive) { CalThread.Abort(); }
                base.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void CalQuote()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        StartFlag = false;
                        EndFlag = false;
                    }

                    if (Math.Abs(nowts.Subtract(STime).TotalMinutes) < 1 && !StartFlag)
                    {
                        LoadData();
                        StartFlag = true;
                    }

                    if (Math.Abs(nowts.Subtract(STime.Add(new TimeSpan(0, 1, 0))).TotalMinutes) < 1)
                    {
                        foreach (EstimateCommodity E in EstimateCommodityList)
                        {
                            E.Parent.QCommodity.Match.InformationSeq = "";
                            E.Parent.QCommodity.Match.InformationTime = "";
                            E.Parent.QCommodity.Match.MatchTime = "";
                            E.Parent.QCommodity.Best5.InformationSeq = "";
                            E.Parent.QCommodity.Best5.InformationTime = "";
                        }
                    }

                    if (STime <= nowts && nowts <= ETime)
                    {
                        DateTime dt = DateTime.Now;

                        foreach (EstimateCommodity E in EstimateCommodityList)
                        {
                            if (!E.Parent.CMarket.IsTrade)
                                continue;

                            CalculateEstimate(E);
                        }

                        //Console.WriteLine(DateTime.Now.Subtract(dt).TotalSeconds.ToString());
                    }

                    Thread.Sleep(Calculatems);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][CalQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void CalculateEstimate(EstimateCommodity E)
        {
            double lastprice = 0.0;
            double buyamt = 0.0;
            double sellamt = 0.0;
            double shares = 0.0;
            double weight = 0.0;
            double pert = 0.0;
            double totalshares = 0.0;            
            string nowstr = DateTime.Now.ToString("HHmmss") + "00";
            string matchseqstr = DateTime.Now.ToString("HHmmssff");
            string best5seqstr = DateTime.Now.ToString("HHmmssff");

            m_PacketNum++;
                       
            if (E.CalculateKind == EstimateCalculateKind.SelfCalculate)
            {
                foreach (EstimateElement M in E.Elements)
                    totalshares += M.Shares * M.mPCommodity.QCommodity.Match.MatchPrice;

                if (totalshares != 0.0)
                {
                    foreach (EstimateElement M in E.Elements)
                    {
                        weight = M.Shares * M.mPCommodity.QCommodity.Match.MatchPrice / totalshares;
                        if (M.mPCommodity.QCommodity.Base.ReferencePrice != 0.0)
                        {
                            pert = (M.mPCommodity.QCommodity.Match.MatchPrice - M.mPCommodity.QCommodity.Base.ReferencePrice) / M.mPCommodity.QCommodity.Base.ReferencePrice;
                            lastprice += weight * pert;

                            buyamt += M.mPCommodity.QCommodity.Best5.BuyPriceBest1 * M.mPCommodity.QCommodity.Best5.BuyQtyBest1;
                            buyamt += M.mPCommodity.QCommodity.Best5.BuyPriceBest2 * M.mPCommodity.QCommodity.Best5.BuyQtyBest2;
                            buyamt += M.mPCommodity.QCommodity.Best5.BuyPriceBest3 * M.mPCommodity.QCommodity.Best5.BuyQtyBest3;
                            buyamt += M.mPCommodity.QCommodity.Best5.BuyPriceBest4 * M.mPCommodity.QCommodity.Best5.BuyQtyBest4;
                            buyamt += M.mPCommodity.QCommodity.Best5.BuyPriceBest5 * M.mPCommodity.QCommodity.Best5.BuyQtyBest5;
                            sellamt += M.mPCommodity.QCommodity.Best5.SellPriceBest1 * M.mPCommodity.QCommodity.Best5.SellQtyBest1;
                            sellamt += M.mPCommodity.QCommodity.Best5.SellPriceBest2 * M.mPCommodity.QCommodity.Best5.SellQtyBest2;
                            sellamt += M.mPCommodity.QCommodity.Best5.SellPriceBest3 * M.mPCommodity.QCommodity.Best5.SellQtyBest3;
                            sellamt += M.mPCommodity.QCommodity.Best5.SellPriceBest4 * M.mPCommodity.QCommodity.Best5.SellQtyBest4;
                            sellamt += M.mPCommodity.QCommodity.Best5.SellPriceBest5 * M.mPCommodity.QCommodity.Best5.SellQtyBest5;
                        }
                    }
                }

                if (Math.Round(E.Parent.QCommodity.Match.MatchPrice, 8) != Math.Round(lastprice, 8) || lastprice == 0.0)
                {
                    E.Parent.SetMatch(nowstr, matchseqstr, E.Parent.QCommodity.Match.MatchTime, lastprice, 0, 0);

                    E.Parent.Send(E.Parent.QCommodity.Match);
                }

                if (Math.Round(E.Parent.QCommodity.Best5.BuyAmt, 3) != Math.Round(buyamt, 3) || Math.Round(E.Parent.QCommodity.Best5.SellAmt, 3) != Math.Round(sellamt, 3))
                {
                    E.Parent.SetBest5(E.Parent.QCommodity.Best5.InformationTime, E.Parent.QCommodity.Best5.InformationSeq, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    E.Parent.QCommodity.Best5.BuyAmt = buyamt;
                    E.Parent.QCommodity.Best5.SellAmt = sellamt;
                    E.Parent.Send(E.Parent.QCommodity.Best5);
                }
            }            
        }
        private void LoadData()
        {
            try
            {
                foreach (EstimateCommodity E in EstimateCommodityList)
                    E.Close();

                EstimateCommodityList.Clear();
                int i = 0;

                foreach (string S in EstimateLabel.Split(','))
                {
                    i++;

                    string sql = "select * from Estimate where EstimateLabel='" + S + "'";
                    DataView dv = Util.ExecSqlQry(sql, DBConnectString);

                    foreach (DataRowView dr in dv)
                    {
                        string errstr = "";

                        try
                        {
                            string EstimateCode = dr["EstimateCode"].ToString();
                            string EstimateNm = dr["EstimateNm"].ToString();

                            errstr = "EstimateCode =" + EstimateCode + ",";

                            EstimateCalculateKind sCalculateKind = (EstimateCalculateKind)Convert.ToInt32(dr["CalculateKind"].ToString());
                            Market sMarket = (Market)Enum.Parse(typeof(Market), dr["Market"].ToString());
                            CommodityKind sCommodityKind = (CommodityKind)Enum.Parse(typeof(CommodityKind), dr["CommodityKind"].ToString());

                            PCommodity mPCommodity = m_PCommodityList.SetNotGetFromDB("", EstimateCode, sMarket, sCommodityKind);

                            EstimateCommodity E = new EstimateCommodity();
                            E.EstimateLabel = S;
                            E.Parent = mPCommodity;
                            E.CalculateKind = sCalculateKind;

                            EstimateCommodityList.Add(E);

                            sql = "select CommodityId,isnull(weight,0.0) weight,isnull(shares,0) shares,isnull(insteadflag,'N') insteadflag from EstimateLink where EstimateCode='" + EstimateCode + "'";
                            DataView dv1 = Util.ExecSqlQry(sql, DBConnectString);

                            foreach (DataRowView dr1 in dv1)
                            {
                                errstr += "CommodityId =" + dr1["CommodityId"].ToString().Trim() + ",";

                                PCommodity gPCommodity = m_PCommodityList.Set(dr1["CommodityId"].ToString().Trim());

                                bool InsteadFlag = dr1["InsteadFlag"].ToString() == "N" ? false : true;

                                E.Add(new EstimateElement(gPCommodity, Convert.ToDouble(dr1["Weight"]), Convert.ToInt32(dr1["Shares"]), InsteadFlag));
                            }

                            mPCommodity.SetBase(sMarket, sCommodityKind, CommodityType.None, "", EstimateNm, DateTime.Today, "", i.ToString("00000000"), 0.0, 0.0, 0.0, 1, "", "");
                            mPCommodity.IsLocalCommodity = true;
                            DoSendWrite(mPCommodity.QCommodity.Base);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]["+errstr+"]");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }
    }
}
