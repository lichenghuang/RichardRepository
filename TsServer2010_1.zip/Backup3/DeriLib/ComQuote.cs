﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using DeriLib.Client.Quote;
using DeriLib.Quote;
using System.Threading;
using System.Timers;
using Microsoft.Office.Interop.Excel;
using Derivative.PriceModel;
using System.Data;
using System.Data.SqlClient;
using System.IO;
//using GC.DerivMonitor.PriceModel;

namespace DeriLib.Com.Quote
{
    [Guid("025C53F5-46A6-4f06-B294-99AD947E8B29")]
    [ComVisible(true)]
    public interface ComQuote_Interface
    {        
        void Start(string IP);                
        void SubCommodity(string CommodityList);        
        void UnSubCommodity(string CommodityList);        
        void Close();        
    }

    [Guid("1A1979A5-EF38-4ddf-A22D-375CFF778C5B"),
    InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    [ComVisible(true)]
    public interface ComQuote_Events
    {
        void QuoteArrived(ref string[] ValueList);
    }

    [Guid("93E57D56-B8F4-4e4e-ABDC-E38C36AE7C69"),
    ClassInterface(ClassInterfaceType.None),
    ComSourceInterfaces(typeof(DeriLib.Com.Quote.ComQuote_Events))]
    [ComVisible(true)]
    public class ComQuote : ComQuote_Interface
    {
        public delegate void QuoteArrivedHandler(ref string[] ValueList);
        public event QuoteArrivedHandler QuoteArrived; 
        private QuotePush Q = null;
        private Thread t;
        private Queue buffer = Queue.Synchronized(new Queue());
        
        ~ComQuote()
        {
            Close();
        }

        #region ComQuote_Interface 成員
        
        public void Start(string IP)
        {
            try
            {
                Q = new QuotePush(DeriLib.Client.Communication.TCP, IP);
                Q.QuoteArrived += new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                Q.Start();

                t = new Thread(new ThreadStart(DoWork));
                t.Start();
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void SubCommodity(string CommodityList)
        {
            try
            {
                if (CommodityList.Split(',').Length <= 0)
                    return;

                List<string> L = CommodityList.Split(',').ToList<string>();
                Q.SubCommodity(L);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void UnSubCommodity(string CommodityList)
        {
            try
            {
                if (CommodityList.Split(',').Length <= 0)
                    return;

                List<string> L = CommodityList.Split(',').ToList<string>();
                Q.UnSubCommodity(L);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void Close()
        {
            try
            {
                if (Q != null) 
                {
                    Q.UnSubCommodity(Q.GetSubCommodityList());
                    Q.Close();
                }

                //if (t != null && t.IsAlive) { t.Abort(); }
            }
            catch (Exception ex)
            {
            }
        }
        private void DoWork()
        {
            try
            {
                for (; ; )
                {
                    while (buffer.Count > 0)
                    {
                        string[] F = (string[])buffer.Dequeue();
                        if (F[0] == null) { continue; }
                        if (QuoteArrived != null) { QuoteArrived(ref F); }
                    }

                    Thread.Sleep(100);
                }
            }
            catch (Exception ex)
            {
            }
        }
        private void Q_QuoteArrived(object obj)
        {
            try
            {
                if (obj.GetType() == typeof(QCommodity))
                {
                    QCommodity QCommodity = (QCommodity)obj;
                    string[] F = GenerateQuotedata(QCommodity.Base);
                    buffer.Enqueue(F);
                    F = GenerateQuotedata(QCommodity.Open);
                    buffer.Enqueue(F);
                    F = GenerateQuotedata(QCommodity.Best5);
                    buffer.Enqueue(F);
                    F = GenerateQuotedata(QCommodity.Match);
                    buffer.Enqueue(F);
                    F = GenerateQuotedata(QCommodity.HighLow);
                    buffer.Enqueue(F);
                    F = GenerateQuotedata(QCommodity.Close);
                    buffer.Enqueue(F);
                    /*F = GenerateQuotedata(QCommodity.Greeks);
                    buffer.Enqueue(F);*/
                }
                else if (obj.GetType() == typeof(QBase))
                {
                    QBase QBase = (QBase)obj;
                    string[] F = GenerateQuotedata(QBase);
                    buffer.Enqueue(F);
                }
                else if (obj.GetType() == typeof(QOpen))
                {
                    QOpen QOpen = (QOpen)obj;
                    string[] F = GenerateQuotedata(QOpen);
                    buffer.Enqueue(F);
                }
                else if (obj.GetType() == typeof(QBest5))
                {
                    QBest5 QBest5 = (QBest5)obj;
                    string[] F = GenerateQuotedata(QBest5);
                    buffer.Enqueue(F);
                }
                else if (obj.GetType() == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;
                    string[] F = GenerateQuotedata(QMatch);
                    buffer.Enqueue(F);
                }
                else if (obj.GetType() == typeof(QHighLow))
                {
                    QHighLow QHighLow = (QHighLow)obj;
                    string[] F = GenerateQuotedata(QHighLow);
                    buffer.Enqueue(F);
                }
                else if (obj.GetType() == typeof(QClose))
                {
                    QClose QClose = (QClose)obj;
                    string[] F = GenerateQuotedata(QClose);
                    buffer.Enqueue(F);
                }
                /*else if (obj.GetType() == typeof(QGreeks))
                {
                    QGreeks QGreeks = (QGreeks)obj;
                    string[] F = GenerateQuotedata(QGreeks);
                    buffer.Enqueue(F);
                }*/
            }
            catch (Exception ex)
            {
            }
        }
        private string[] GenerateQuotedata(object obj)
        {
            string[] F = new string[80];

            if (obj.GetType() == typeof(QBase))
            {
                QBase QBase = (QBase)obj;

                if (QBase.CommodityId == null) { return F; }
                
                F[0] = "1";
                F[1] = QBase.InformationTime;
                F[2] = QBase.CommodityId;
                F[3] = QBase.CommodityNm;
                F[4] = QBase.TradeDate.ToString("yyyyMMdd");
                F[5] = QBase.SettleMentMonth;
                F[6] = QBase.Strike.ToString();
                F[7] = QBase.ReferencePrice.ToString();
                F[8] = QBase.RiseLimitPrice.ToString();
                F[9] = QBase.FallLimitPrice.ToString();
                F[10] = QBase.Unit.ToString();
            }
            else if (obj.GetType() == typeof(QOpen))
            {
                QOpen QOpen = (QOpen)obj;

                if (QOpen.CommodityId == null) { return F; }

                F[0] = "2";
                F[1] = QOpen.OpenTime;
                F[2] = QOpen.CommodityId;
                F[12] = QOpen.OpenPrice.ToString();
            }
            else if (obj.GetType() == typeof(QBest5))
            {
                QBest5 QBest5 = (QBest5)obj;

                if (QBest5.CommodityId == null) { return F; }

                F[0] = "3";
                F[1] = QBest5.InformationTime;
                F[2] = QBest5.CommodityId;
                F[19] = QBest5.BuyPriceBest1.ToString();
                F[20] = QBest5.BuyPriceBest2.ToString();
                F[21] = QBest5.BuyPriceBest3.ToString();
                F[22] = QBest5.BuyPriceBest4.ToString();
                F[23] = QBest5.BuyPriceBest5.ToString();
                F[24] = QBest5.SellPriceBest1.ToString();
                F[25] = QBest5.SellPriceBest2.ToString();
                F[26] = QBest5.SellPriceBest3.ToString();
                F[27] = QBest5.SellPriceBest4.ToString();
                F[28] = QBest5.SellPriceBest5.ToString();
                F[29] = QBest5.BuyQtyBest1.ToString();
                F[30] = QBest5.BuyQtyBest2.ToString();
                F[31] = QBest5.BuyQtyBest3.ToString();
                F[32] = QBest5.BuyQtyBest4.ToString();
                F[33] = QBest5.BuyQtyBest5.ToString();
                F[34] = QBest5.SellQtyBest1.ToString();
                F[35] = QBest5.SellQtyBest2.ToString();
                F[36] = QBest5.SellQtyBest3.ToString();
                F[37] = QBest5.SellQtyBest4.ToString();
                F[38] = QBest5.SellQtyBest5.ToString();
                F[61] = QBest5.BuyPriceBest1s.ToString();
                F[62] = QBest5.SellPriceBest1s.ToString();
            }
            else if (obj.GetType() == typeof(QMatch))
            {
                QMatch QMatch = (QMatch)obj;

                if (QMatch.CommodityId == null) { return F; }

                F[0] = "4";
                F[1] = QMatch.MatchTime;
                F[2] = QMatch.CommodityId;
                F[14] = QMatch.MatchPrice.ToString();
                F[15] = QMatch.MatchQty.ToString();
                F[16] = QMatch.MatchAmt.ToString();
                F[17] = QMatch.MatchTotalQty.ToString();
                F[18] = QMatch.MatchTotalAmt.ToString();
                F[60] = QMatch.MatchPrices.ToString();
            }
            else if (obj.GetType() == typeof(QHighLow))
            {
                QHighLow QHighLow = (QHighLow)obj;

                if (QHighLow.CommodityId == null) { return F; }

                F[0] = "5";
                F[1] = QHighLow.InformationTime;
                F[2] = QHighLow.CommodityId;
                F[39] = QHighLow.DayHighPrice.ToString();
                F[40] = QHighLow.DayLowPrice.ToString();
            }
            else if (obj.GetType() == typeof(QClose))
            {
                QClose QClose = (QClose)obj;

                if (QClose.CommodityId == null) { return F; }

                F[0] = "6";
                F[1] = QClose.InformationTime;
                F[2] = QClose.CommodityId;
                F[41] = QClose.CloseDate.ToString("yyyyMMdd");
                F[12] = QClose.OpenPrice.ToString();
                F[14] = QClose.ClosePrice.ToString();
                F[19] = QClose.BuyPrice.ToString();
                F[24] = QClose.SellPrice.ToString();
                F[39] = QClose.DayHighPrice.ToString();
                F[40] = QClose.DayLowPrice.ToString();
                F[17] = QClose.MatchTotalQty.ToString();
                F[18] = QClose.MatchTotalAmt.ToString();
                F[42] = QClose.SettlementPrice.ToString();
                F[43] = QClose.OpenInterest.ToString();
            }
            /*else if (obj.GetType() == typeof(QGreeks))
            {
                QGreeks QGreeks = (QGreeks)obj;

                if (QGreeks.CommodityId == null) { return F; }

                F[0] = "7";
                F[1] = QGreeks.InformationTime;
                F[2] = QGreeks.CommodityId;
                F[44] = QGreeks.LastIV.ToString();
                F[45] = QGreeks.Bid1IV.ToString();
                F[46] = QGreeks.Bid2IV.ToString();
                F[47] = QGreeks.Bid3IV.ToString();
                F[48] = QGreeks.Bid4IV.ToString();
                F[49] = QGreeks.Bid5IV.ToString();
                F[50] = QGreeks.Ask1IV.ToString();
                F[51] = QGreeks.Ask2IV.ToString();
                F[52] = QGreeks.Ask3IV.ToString();
                F[53] = QGreeks.Ask4IV.ToString();
                F[54] = QGreeks.Ask5IV.ToString();
                F[55] = QGreeks.Delta.ToString();
                F[56] = QGreeks.Gamma.ToString();
                F[57] = QGreeks.Vega.ToString();
                F[58] = QGreeks.Theta.ToString();
                F[59] = QGreeks.Rho.ToString();
            }*/

            return F;
        }
        #endregion
    }

    [ComVisible(true), ProgId("DeriLib.RTDQuote")]
    public class RTDQuote : IRtdServer
    {
        private IRTDUpdateEvent xlRTDUpdate;
        private QuotePush Q = null;
        private Dictionary<int, PriceData> PriceDataList = new Dictionary<int, PriceData>();
        private Dictionary<string, string> MappingTable = new Dictionary<string, string>();
        private Dictionary<string, CommodityData> CommodityList = new Dictionary<string, CommodityData>();        
        private List<PriceData> UpdateTopic = new List<PriceData>();
        private object LockObj = new object();
        private System.Timers.Timer tr;
        private Hashtable MapHt = Hashtable.Synchronized(new Hashtable());
        private bool IsCloseExcel = false;
        private List<string> UnSubCommodityList = new List<string>();
        private Thread RoutineTh;
        private Queue SubCommodityQ = Queue.Synchronized(new Queue());
        //private Thread t;
        //private Queue buffer = Queue.Synchronized(new Queue());

        #region IRtdServer 成員

        public object ConnectData(int TopicID, ref Array Strings, ref bool GetNewValues)
        {
            GetNewValues = true;
            object g = null;
            CommodityData sCommodityData;

            try
            {
                if (Q == null) { return "無法連至Quote Server!!"; }

                string commodityid = Strings.GetValue(0).ToString().ToUpper().Trim();

                if (MapHt.ContainsKey(commodityid)) { commodityid = MapHt[commodityid].ToString(); }
                int field = -1;
                double hedgevol = 0.0;
                double spot = 0.0;

                int.TryParse(Strings.GetValue(1).ToString(), out field);
                
                if (Strings.Length > 2)
                    double.TryParse(Strings.GetValue(2).ToString(), out hedgevol);

                if (Strings.Length > 3)
                    double.TryParse(Strings.GetValue(3).ToString(), out spot);

                if (!PriceDataList.ContainsKey(TopicID))
                    PriceDataList.Add(TopicID, new PriceData(TopicID, commodityid, field));

                PriceData mPriceData = PriceDataList[TopicID];

                mPriceData.HedgeVol = hedgevol;
                mPriceData.Spot = spot;

                if (!CommodityList.ContainsKey(commodityid))
                {
                    CommodityList.Add(commodityid, new CommodityData(commodityid));
                    //SubWork(new SubCommodity(commodityid, true));
                    SubCommodityQ.Enqueue(new SubCommodity(commodityid, true));
                    //ThreadPool.QueueUserWorkItem(new WaitCallback(SubWork), new SubCommodity(commodityid, true)); 
                }

                sCommodityData = CommodityList[commodityid];

                sCommodityData.Add(field, TopicID, mPriceData);

                //if ((field >= 55 && field <= 59) || field == 63 || field == 44)
                if ((field >= 44 && field <= 59) || field == 63)
                    mPriceData.Value = CalculateGreeks(field, sCommodityData, mPriceData.HedgeVol, mPriceData.Spot);
                else
                    mPriceData.Value = sCommodityData.F[field];

                g = mPriceData.Value;
                
                return g;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public void DisconnectData(int TopicID)
        {
            try
            {
                CommodityData sCommodityData;             
                PriceData mPriceData = null;

                if (PriceDataList.ContainsKey(TopicID))
                {
                    mPriceData = (PriceData)PriceDataList[TopicID];
                    PriceDataList.Remove(TopicID);
                }
                if (mPriceData != null && CommodityList.ContainsKey(mPriceData.CommodityId))
                {
                    sCommodityData = CommodityList[mPriceData.CommodityId];

                    sCommodityData.Remove(mPriceData.Field, TopicID);

                    if (sCommodityData.GetPriceDataLists().Count == 0 && sCommodityData.RelationCommoditys.Count == 0)
                    {
                        CommodityList.Remove(sCommodityData.CommodityId);
                        //SubWork(new SubCommodity(sCommodityData.CommodityId, false));
                        SubCommodityQ.Enqueue(new SubCommodity(sCommodityData.CommodityId, false));
                        //if (IsCloseExcel) { SubWork(new SubCommodity(sCommodityData.CommodityId, false)); }

                        if (sCommodityData.F[65] != null && CommodityList.ContainsKey(sCommodityData.F[65].ToString()))
                        {
                            CommodityData fCommodityData = CommodityList[sCommodityData.F[65].ToString()];
                            fCommodityData.RemoveRelation(sCommodityData.CommodityId);

                            if (fCommodityData.GetPriceDataLists().Count == 0 && fCommodityData.RelationCommoditys.Count == 0)
                                SubCommodityQ.Enqueue(new SubCommodity(fCommodityData.CommodityId, false));
                                //SubWork(new SubCommodity(fCommodityData.CommodityId, false));
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                string ff = "";
            }
        }

        public int Heartbeat()
        {
            return 1;
        }

        public Array RefreshData(ref int TopicCount)
        {
            try
            {
                lock (LockObj)
                {
                    object[,] rets = new object[2, UpdateTopic.Count];
                    int counter = 0;

                    foreach (PriceData mPriceData in UpdateTopic)
                    {
                        if (mPriceData.topicID != -1)
                        {
                            rets[0, counter] = mPriceData.topicID;
                            rets[1, counter] = mPriceData.Value;
                        }

                        counter++;
                    }

                    TopicCount = UpdateTopic.Count;

                    UpdateTopic.Clear();

                    return rets;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public int ServerStart(IRTDUpdateEvent CallbackObject)
        {
            System.Windows.Forms.MessageBox.Show("OK");
            //string IP = DeriLib.Properties.Settings.Default.TsIP;
            //string DBConnectString = DeriLib.Properties.Settings.Default.DBConnectString;
            string IP = Util.ReadIniString("QuoteSetting", "IP", "C:\\QuoteRTD\\QuoteRTDSetting.ini");
            string DBConnectString = Util.ReadIniString("QuoteSetting", "DBConnectString", "C:\\QuoteRTD\\QuoteRTDSetting.ini");
            
            Dictionary<string, string> TFEMonths = new Dictionary<string, string>();

            TFEMonths.Add("A", "F");
            TFEMonths.Add("B", "G");
            TFEMonths.Add("C", "H");
            TFEMonths.Add("D", "J");
            TFEMonths.Add("E", "K");
            TFEMonths.Add("F", "M");
            TFEMonths.Add("G", "N");
            TFEMonths.Add("H", "Q");
            TFEMonths.Add("I", "U");
            TFEMonths.Add("J", "V");
            TFEMonths.Add("K", "X");
            TFEMonths.Add("L", "Z");

            DataView dv = Util.ExecSqlQry("select a.commodityid,a.maturity,c.syscode from commodityextra a with (nolock),commodity b with (nolock),codemap c with (nolock) where a.commodityid=b.commodityid and b.market='TFE' and b.commoditykind='Future' and left(a.commodityid,2)=c.code and c.commoditykind='Future' and convert(varchar,a.maturity,111) >= convert(varchar,getdate(),111) order by left(a.commodityid,3),a.maturity", DBConnectString);

            string tmpstr = "";

            
                foreach (DataRowView dr in dv)
                {
                    try
                    {
                        if (dr["commodityid"].ToString().Length != 5 && dr["commodityid"].ToString().Length != 9) { continue; }

                        if (tmpstr != dr["commodityid"].ToString().Substring(0, 3))
                        {
                            if (!MapHt.ContainsKey(dr["commodityid"].ToString().Substring(0, 3) + "AA"))
                                MapHt.Add(dr["commodityid"].ToString().Substring(0, 3) + "AA", dr["commodityid"].ToString());

                            if (TFEMonths.ContainsKey(dr["commodityid"].ToString().Substring(3, 1)))
                            {
                                if (!MapHt.ContainsKey(dr["syscode"].ToString() + "AAF"))
                                    MapHt.Add(dr["syscode"].ToString() + "AAF", dr["commodityid"].ToString());
                            }
                        }
                        else
                        {
                            if (!MapHt.ContainsKey(dr["commodityid"].ToString().Substring(0, 3) + "AB"))
                            {
                                if (!MapHt.ContainsKey(dr["commodityid"].ToString().Substring(0, 3) + "AB"))
                                    MapHt.Add(dr["commodityid"].ToString().Substring(0, 3) + "AB", dr["commodityid"].ToString());

                                if (TFEMonths.ContainsKey(dr["commodityid"].ToString().Substring(3, 1)))
                                {
                                    if (!MapHt.ContainsKey(dr["syscode"].ToString() + "ABF"))
                                        MapHt.Add(dr["syscode"].ToString() + "ABF", dr["commodityid"].ToString());
                                }
                            }
                        }

                        if (TFEMonths.ContainsKey(dr["commodityid"].ToString().Substring(3, 1)))
                        {
                            if (!MapHt.ContainsKey(dr["syscode"].ToString() + TFEMonths[dr["commodityid"].ToString().Substring(3, 1)] + dr["commodityid"].ToString().Substring(4, 1) + "F"))
                                MapHt.Add(dr["syscode"].ToString() + TFEMonths[dr["commodityid"].ToString().Substring(3, 1)] + dr["commodityid"].ToString().Substring(4, 1) + "F", dr["commodityid"].ToString());
                        }

                        tmpstr = dr["commodityid"].ToString().Substring(0, 3);
                        
                    }
                    catch (Exception ex)
                    {
                        tmpstr = "";
                    }
                }
            
            try
            {
                Q = new QuotePush(DeriLib.Client.Communication.TCP, IP);
                Q.QuoteArrived += new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                Q.MsgArrived += new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                Q.Start();
            }
            catch (Exception ex)
            {
                Q = null;
            }
            //t = new Thread(new ThreadStart(DoWork));
            //t.Start();
            tr = new System.Timers.Timer(500);
            tr.Elapsed += new  ElapsedEventHandler(tr_Elapsed);
            tr.Start();

            RoutineTh = new Thread(new ThreadStart(RoutineWork));
            RoutineTh.Start();

            xlRTDUpdate = CallbackObject;
            
            return 1;
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    try
                    {
                        while (SubCommodityQ.Count > 0)
                        {
                            SubCommodity mSubCommodity = (SubCommodity)SubCommodityQ.Dequeue();

                            if (mSubCommodity.CommodityId != "")
                            {
                                List<string> L = new List<string>();
                                L.Add(mSubCommodity.CommodityId);

                                if (mSubCommodity.IsSub)
                                {
                                    UnSubCommodityList.AddRange(L);
                                    Q.SubCommodity(L);
                                }
                                else
                                    Q.UnSubCommodity(L);
                            }
                        }
                    }
                    catch (Exception ex2)
                    {
                    }

                    Thread.Sleep(1);
                }
            }
            catch (Exception ex)
            {
            }
        }
        private void SubWork(Object stateInfo)
        {
            try
            {
                SubCommodity mSubCommodity = (SubCommodity)stateInfo;

                if (mSubCommodity.CommodityId != "")
                {
                    List<string> L = new List<string>();
                    L.Add(mSubCommodity.CommodityId);

                    if (mSubCommodity.IsSub)
                    {
                        UnSubCommodityList.AddRange(L);
                        Q.SubCommodity(L);
                    }
                    else
                        Q.UnSubCommodity(L);
                }
            }
            catch (Exception ex)
            {
            }
        }       
        public void tr_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                if (UpdateTopic.Count > 0) 
                { 
                    xlRTDUpdate.UpdateNotify(); 
                }
            }
            catch (Exception ex)
            {
                string gg = "";
            }
            
        }
        private void Q_MsgArrived(object obj)
        {
            try
            {
                foreach (PriceData mPriceData in PriceDataList.Values)
                {
                    mPriceData.Value = "報價連線斷線,請重開Excel!!";
                    UpdateTopic.Add(mPriceData);
                }
            }
            catch (Exception ex)
            {
            }
        }
        private void Q_QuoteArrived(object obj)
        {
            try
            {
                if (obj.GetType() == typeof(QCommodity))
                {
                    QCommodity QCommodity = (QCommodity)obj;

                    //if (QCommodity.Base.CommodityId == "TXO07900D0" || QCommodity.Base.CommodityId == "TXO07900P0" || QCommodity.Base.CommodityId == "1000")
                    //    QCommodity = QCommodity;
                    object[] F = GenerateQuotedata(QCommodity.Base);
                    if (QCommodity.Extra != null)
                        F = GenerateQuotedata(QCommodity.Extra);
                    if (QCommodity.HisVol != null)
                        F = GenerateQuotedata(QCommodity.HisVol);
                    F = GenerateQuotedata(QCommodity.Open);                    
                    F = GenerateQuotedata(QCommodity.Best5);                    
                    F = GenerateQuotedata(QCommodity.Match);                    
                    F = GenerateQuotedata(QCommodity.HighLow);                    
                    F = GenerateQuotedata(QCommodity.Close);
                    //F = GenerateQuotedata(QCommodity.Greeks);                    
                }
                else if (obj.GetType() == typeof(QBase))
                {
                    QBase QBase = (QBase)obj;
                    object[] F = GenerateQuotedata(QBase);                    
                }
                else if (obj.GetType() == typeof(QOpen))
                {
                    QOpen QOpen = (QOpen)obj;
                    object[] F = GenerateQuotedata(QOpen);                    
                }
                else if (obj.GetType() == typeof(QBest5))
                {
                    QBest5 QBest5 = (QBest5)obj;
                    object[] F = GenerateQuotedata(QBest5);                    
                }
                else if (obj.GetType() == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;
                    object[] F = GenerateQuotedata(QMatch);                    
                }
                else if (obj.GetType() == typeof(QHighLow))
                {
                    QHighLow QHighLow = (QHighLow)obj;
                    object[] F = GenerateQuotedata(QHighLow);                    
                }
                else if (obj.GetType() == typeof(QClose))
                {
                    QClose QClose = (QClose)obj;
                    object[] F = GenerateQuotedata(QClose);                   
                }
                /*else if (obj.GetType() == typeof(QGreeks))
                {
                    QGreeks QGreeks = (QGreeks)obj;
                    object[] F = GenerateQuotedata(QGreeks);
                }*/
                else if (obj.GetType() == typeof(QCommodityExtra))
                {
                    QCommodityExtra QCommodityExtra = (QCommodityExtra)obj;
                    object[] F = GenerateQuotedata(QCommodityExtra);
                }

                //xlRTDUpdate.UpdateNotify();
            }
            catch (Exception ex)
            {
                string ff = "";
            }
        }
        private object[] GenerateQuotedata(object obj)
        {
            object[] F = new object[90];
            CommodityData mCommodityData = null;

            try
            {
                if (obj.GetType() == typeof(QBase))
                {
                    QBase QBase = (QBase)obj;
                                        
                    lock (LockObj)
                    {
                        if (QBase.CommodityId == null || !CommodityList.ContainsKey(QBase.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QBase.CommodityId];
                        F = CommodityList[QBase.CommodityId].F;
                    }

                    if (QBase.InformationTime != "") { F[1] = QBase.InformationTime; }
                    F[2] = QBase.CommodityId;
                    F[3] = QBase.CommodityNm;
                    F[4] = QBase.TradeDate.ToString("yyyyMMdd");
                    F[5] = QBase.SettleMentMonth;
                    F[66] = QBase.CommodityType;
                    //F[6] = QBase.Strike;
                    F[7] = QBase.ReferencePrice;
                    F[8] = QBase.RiseLimitPrice;
                    F[9] = QBase.FallLimitPrice;
                    F[10] = QBase.Unit;

                    if (F[69] == null)
                    {
                        F[69] = 1.0;
                        SetValue(69, mCommodityData, F[69]);
                    }

                    SetValue(1, mCommodityData, F[1]);
                    SetValue(2, mCommodityData, F[2]);
                    SetValue(3, mCommodityData, F[3]);
                    SetValue(4, mCommodityData, F[4]);
                    SetValue(5, mCommodityData, F[5]);
                    SetValue(66, mCommodityData, F[66]);
                    SetValue(7, mCommodityData, F[7]);
                    SetValue(8, mCommodityData, F[8]);
                    SetValue(9, mCommodityData, F[9]);
                    SetValue(10, mCommodityData, F[10]);                    
                }
                else if (obj.GetType() == typeof(QOpen))
                {
                    QOpen QOpen = (QOpen)obj;

                    lock (LockObj)
                    {
                        if (QOpen.CommodityId == null || !CommodityList.ContainsKey(QOpen.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QOpen.CommodityId];
                        F = CommodityList[QOpen.CommodityId].F;
                    }

                    if (QOpen.OpenTime != "") { F[1] = QOpen.OpenTime; }
                    F[2] = QOpen.CommodityId;
                    F[11] = QOpen.OpenTime;
                    F[12] = QOpen.OpenPrice;

                    SetValue(1, mCommodityData, F[1]);
                    SetValue(2, mCommodityData, F[2]);
                    SetValue(11, mCommodityData, F[11]);
                    SetValue(12, mCommodityData, F[12]);
                }
                else if (obj.GetType() == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;

                    lock (LockObj)
                    {
                        if (QMatch.CommodityId == null || !CommodityList.ContainsKey(QMatch.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QMatch.CommodityId];
                        F = CommodityList[QMatch.CommodityId].F;
                    }

                    if (QMatch.MatchTime != "") { F[1] = QMatch.MatchTime; }                    
                    F[2] = QMatch.CommodityId;
                    F[13] = QMatch.MatchTime;
                    F[14] = QMatch.MatchPrice;
                    F[15] = QMatch.MatchQty;
                    F[16] = QMatch.MatchAmt;
                    F[17] = QMatch.MatchTotalQty;
                    F[18] = QMatch.MatchTotalAmt;
                    F[60] = QMatch.MatchPrices;

                    double refprice = 0.0;

                    if (F[7] != null && F[7] is double){refprice = (double)F[7];}
                    if (refprice != 0.0) 
                    {
                        if (QMatch.MatchPrice != 0.0)
                        {
                            F[64] = (QMatch.MatchPrice - refprice) / refprice;
                            F[78] = QMatch.MatchPrice - refprice;
                        }
                        else
                        {
                            F[64] = 0.0;
                            F[78] = 0.0;
                        }
                    }
                        
                    SetValue(1, mCommodityData, F[1]);
                    SetValue(2, mCommodityData, F[2]);
                    SetValue(13, mCommodityData, F[13]);
                    SetValue(14, mCommodityData, F[14]);
                    SetValue(15, mCommodityData, F[15]);
                    SetValue(16, mCommodityData, F[16]);
                    SetValue(17, mCommodityData, F[17]);
                    SetValue(18, mCommodityData, F[18]);
                    SetValue(60, mCommodityData, F[60]);
                    SetValue(64, mCommodityData, F[64]);
                    SetValue(78, mCommodityData, F[78]);

                    CalculateLastIV(mCommodityData);
                    CalculateGreeks(mCommodityData);
                    foreach (CommodityData gCommodityData in mCommodityData.RelationCommoditys)
                    {
                        CalculateLastIV(gCommodityData);
                        CalculateBest5IV(gCommodityData);
                        CalculateGreeks(gCommodityData);
                    }
                }
                else if (obj.GetType() == typeof(QBest5))
                {
                    QBest5 QBest5 = (QBest5)obj;

                    lock (LockObj)
                    {
                        if (QBest5.CommodityId == null || !CommodityList.ContainsKey(QBest5.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QBest5.CommodityId];
                        F = CommodityList[QBest5.CommodityId].F;
                    }
                    
                    if (QBest5.InformationTime != "") { F[1] = QBest5.InformationTime; }                    
                    F[2] = QBest5.CommodityId;
                    F[19] = QBest5.BuyPriceBest1;
                    F[20] = QBest5.BuyPriceBest2;
                    F[21] = QBest5.BuyPriceBest3;
                    F[22] = QBest5.BuyPriceBest4;
                    F[23] = QBest5.BuyPriceBest5;
                    F[24] = QBest5.SellPriceBest1;
                    F[25] = QBest5.SellPriceBest2;
                    F[26] = QBest5.SellPriceBest3;
                    F[27] = QBest5.SellPriceBest4;
                    F[28] = QBest5.SellPriceBest5;
                    F[29] = QBest5.BuyQtyBest1;
                    F[30] = QBest5.BuyQtyBest2;
                    F[31] = QBest5.BuyQtyBest3;
                    F[32] = QBest5.BuyQtyBest4;
                    F[33] = QBest5.BuyQtyBest5;
                    F[34] = QBest5.SellQtyBest1;
                    F[35] = QBest5.SellQtyBest2;
                    F[36] = QBest5.SellQtyBest3;
                    F[37] = QBest5.SellQtyBest4;
                    F[38] = QBest5.SellQtyBest5;
                    F[61] = QBest5.BuyPriceBest1s;
                    F[62] = QBest5.SellPriceBest1s;
                    F[79] = QBest5.BuyAmt;
                    F[80] = QBest5.SellAmt;

                    SetValue(1, mCommodityData, F[1]);
                    SetValue(2, mCommodityData, F[2]);
                    SetValue(19, mCommodityData, F[19]);
                    SetValue(20, mCommodityData, F[20]);
                    SetValue(21, mCommodityData, F[21]);
                    SetValue(22, mCommodityData, F[22]);
                    SetValue(23, mCommodityData, F[23]);
                    SetValue(24, mCommodityData, F[24]);
                    SetValue(25, mCommodityData, F[25]);
                    SetValue(26, mCommodityData, F[26]);
                    SetValue(27, mCommodityData, F[27]);
                    SetValue(28, mCommodityData, F[28]);
                    SetValue(29, mCommodityData, F[29]);
                    SetValue(30, mCommodityData, F[30]);
                    SetValue(31, mCommodityData, F[31]);
                    SetValue(32, mCommodityData, F[32]);
                    SetValue(33, mCommodityData, F[33]);
                    SetValue(34, mCommodityData, F[34]);
                    SetValue(35, mCommodityData, F[35]);
                    SetValue(36, mCommodityData, F[36]);
                    SetValue(37, mCommodityData, F[37]);
                    SetValue(38, mCommodityData, F[38]);
                    SetValue(61, mCommodityData, F[61]);
                    SetValue(62, mCommodityData, F[62]);
                    SetValue(79, mCommodityData, F[79]);
                    SetValue(80, mCommodityData, F[80]);

                    CalculateBest5IV(mCommodityData);
                }
                else if (obj.GetType() == typeof(QHighLow))
                {
                    QHighLow QHighLow = (QHighLow)obj;

                    lock (LockObj)
                    {
                        if (QHighLow.CommodityId == null || !CommodityList.ContainsKey(QHighLow.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QHighLow.CommodityId];
                        F = CommodityList[QHighLow.CommodityId].F;
                    }

                    if (QHighLow.InformationTime != "") { F[1] = QHighLow.InformationTime; }                    
                    F[2] = QHighLow.CommodityId;
                    F[39] = QHighLow.DayHighPrice;
                    F[40] = QHighLow.DayLowPrice;

                    SetValue(1, mCommodityData, F[1]);
                    SetValue(2, mCommodityData, F[2]);
                    SetValue(39, mCommodityData, F[39]);
                    SetValue(40, mCommodityData, F[40]);
                }
                else if (obj.GetType() == typeof(QClose))
                {
                    QClose QClose = (QClose)obj;

                    lock (LockObj)
                    {
                        if (QClose.CommodityId == null || !CommodityList.ContainsKey(QClose.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QClose.CommodityId];
                        F = CommodityList[QClose.CommodityId].F;
                    }

                    if (QClose.InformationTime != "") { F[1] = QClose.InformationTime; }                    
                    F[2] = QClose.CommodityId;
                    F[41] = QClose.CloseDate.ToString("yyyyMMdd");
                    /*F[12] = QClose.OpenPrice;
                    F[14] = QClose.ClosePrice;
                    F[19] = QClose.BuyPrice;
                    F[24] = QClose.SellPrice;
                    F[39] = QClose.DayHighPrice;
                    F[40] = QClose.DayLowPrice;
                    F[17] = QClose.MatchTotalQty;
                    F[18] = QClose.MatchTotalAmt;*/
                    F[42] = QClose.SettlementPrice;
                    F[43] = QClose.OpenInterest;
                    F[74] = QClose.LastCloseDate.ToString("yyyyMMdd");
                    F[75] = QClose.LastSettlementPrice;
                    F[76] = QClose.LastOpenInterest;

                    SetValue(1, mCommodityData, F[1]);
                    SetValue(2, mCommodityData, F[2]);
                    SetValue(41, mCommodityData, F[41]);
                    SetValue(42, mCommodityData, F[42]);
                    SetValue(43, mCommodityData, F[43]);
                    SetValue(74, mCommodityData, F[74]);
                    SetValue(75, mCommodityData, F[75]);
                    SetValue(76, mCommodityData, F[76]);

                    CalculateLastLastIV(mCommodityData);

                    foreach (CommodityData gCommodityData in mCommodityData.RelationCommoditys)
                        CalculateLastLastIV(gCommodityData);
                }                
                else if (obj.GetType() == typeof(QCommodityExtra))
                {
                    QCommodityExtra QCommodityExtra = (QCommodityExtra)obj;

                    lock (LockObj)
                    {
                        if (QCommodityExtra.CommodityId == null || !CommodityList.ContainsKey(QCommodityExtra.CommodityId)) { return F; }    
                        mCommodityData = CommodityList[QCommodityExtra.CommodityId];
                        F = CommodityList[QCommodityExtra.CommodityId].F;
                    }

                    F[65] = QCommodityExtra.UnderlyingId;
                    F[67] = QCommodityExtra.Maturity;
                    F[68] = QCommodityExtra.BarrierPrice;
                    F[69] = QCommodityExtra.ExecRatio;                    
                    F[71] = QCommodityExtra.HisVol;
                    F[6] =  QCommodityExtra.Strike;

                    SetValue(65, mCommodityData,F[65]);
                    SetValue(66, mCommodityData, F[66]);
                    SetValue(67, mCommodityData, F[67]);
                    SetValue(68, mCommodityData, F[68]);
                    SetValue(69, mCommodityData, F[69]);
                    SetValue(71, mCommodityData, F[71]);
                    SetValue(6, mCommodityData, F[6]);

                    if (!CommodityList.ContainsKey(QCommodityExtra.UnderlyingId))
                    {
                        CommodityList.Add(QCommodityExtra.UnderlyingId, new CommodityData(QCommodityExtra.UnderlyingId));
                        //ThreadPool.QueueUserWorkItem(new WaitCallback(SubWork), new SubCommodity(QCommodityExtra.UnderlyingId, true)); 
                        SubCommodityQ.Enqueue(new SubCommodity(QCommodityExtra.UnderlyingId, true));
                    }

                    CommodityData fCommodityData = CommodityList[QCommodityExtra.UnderlyingId];

                    mCommodityData.Underlying = fCommodityData;
                    fCommodityData.AddRelation(mCommodityData);
                }
                else if (obj.GetType() == typeof(QHistoricalVol))
                {
                    QHistoricalVol QHistoricalVol = (QHistoricalVol)obj;

                    lock (LockObj)
                    {
                        if (QHistoricalVol.CommodityId == null || !CommodityList.ContainsKey(QHistoricalVol.CommodityId)) { return F; }
                        mCommodityData = CommodityList[QHistoricalVol.CommodityId];
                        F = CommodityList[QHistoricalVol.CommodityId].F;
                    }

                    F[70] = QHistoricalVol.HIV1M;
                    F[71] = QHistoricalVol.HIV3M;
                    F[72] = QHistoricalVol.HIV6M;
                    F[73] = QHistoricalVol.HIV12M;
                    
                    SetValue(70, mCommodityData, F[70]);
                    SetValue(71, mCommodityData, F[71]);
                    SetValue(72, mCommodityData, F[72]);
                    SetValue(73, mCommodityData, F[73]);
                }

                return F;
            }
            catch (Exception ex)
            {
                return F;
            }
        }        
        private void SetValue(int Field, CommodityData mCommodityData,object Val)
        {
            List<PriceData> L = mCommodityData.GetPriceDataLists(Field);

            if (L == null || L.Count == 0) { return; }

            lock (LockObj)
            {
                foreach (PriceData mPriceData in L)
                {
                    if (mPriceData.Value != Val)
                    {

                        mPriceData.Value = Val;
                        UpdateTopic.Add(mPriceData);
                    }
                }
            }
        }
        private void CalculateBest5IV(CommodityData mCommodityData)
        {
            double bidiv1 = 0.0;
            double bidiv2 = 0.0;
            double bidiv3 = 0.0;
            double bidiv4 = 0.0;
            double bidiv5 = 0.0;
            double askiv1 = 0.0;
            double askiv2 = 0.0;
            double askiv3 = 0.0;
            double askiv4 = 0.0;
            double askiv5 = 0.0;
            double bid1 = 0.0;
            double bid2 = 0.0;
            double bid3 = 0.0;
            double bid4 = 0.0;
            double bid5 = 0.0;
            double ask1 = 0.0;
            double ask2 = 0.0;
            double ask3 = 0.0;
            double ask4 = 0.0;
            double ask5 = 0.0;
            string underlying = "";
            CommodityType mCommodityType = CommodityType.None;
            DateTime maturity = new DateTime();
            double barrier = 0.0;
            double execratio = 0.0;
            double spot = 0.0;
            double strike = 0.0;
            double val = 0.0;

            if (mCommodityData.F[61] != null)
                bid1 = (double)mCommodityData.F[61];
            if (mCommodityData.F[20] != null)
                bid2 = (double)mCommodityData.F[20];
            if (mCommodityData.F[21] != null)
                bid3 = (double)mCommodityData.F[21];
            if (mCommodityData.F[22] != null)
                bid4 = (double)mCommodityData.F[22];
            if (mCommodityData.F[23] != null)
                bid5 = (double)mCommodityData.F[23];
            if (mCommodityData.F[62] != null)
                ask1 = (double)mCommodityData.F[62];
            if (mCommodityData.F[25] != null)
                ask2 = (double)mCommodityData.F[25];
            if (mCommodityData.F[26] != null)
                ask3 = (double)mCommodityData.F[26];
            if (mCommodityData.F[27] != null)
                ask4 = (double)mCommodityData.F[27];
            if (mCommodityData.F[28] != null)
                ask5 = (double)mCommodityData.F[28];
            if (mCommodityData.F[65] != null)
                underlying = mCommodityData.F[65].ToString();
            if (mCommodityData.F[66] != null)
                mCommodityType = (CommodityType)mCommodityData.F[66];
            if (mCommodityData.F[67] != null)
                maturity = (DateTime)mCommodityData.F[67];
            if (mCommodityData.F[68] != null)
                barrier = (double)mCommodityData.F[68];
            if (mCommodityData.F[69] != null)
                execratio = (double)mCommodityData.F[69];
            if (mCommodityData.F[6] != null)
                strike = (double)mCommodityData.F[6];

            /*if (mCommodityData.Underlying != null && mCommodityType != CommodityType.None && mCommodityData.F[6] != null && mCommodityData.F[67] != null && mCommodityData.Underlying.F[60] != null)
            {
                spot = (double)mCommodityData.Underlying.F[60];

                bidiv1 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid1 / execratio);
                bidiv2 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid2 / execratio);
                bidiv3 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid3 / execratio);
                bidiv4 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid4 / execratio);
                bidiv5 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid5 / execratio);
                askiv1 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask1 / execratio);
                askiv2 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask2 / execratio);
                askiv3 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask3 / execratio);
                askiv4 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask4 / execratio);
                askiv5 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask5 / execratio);
            }   
 
            if (double.IsNaN(bidiv1) && double.IsInfinity(bidiv1)) { bidiv1 = 0.0; }
            if (double.IsNaN(bidiv2) && double.IsInfinity(bidiv2)) { bidiv2 = 0.0; }
            if (double.IsNaN(bidiv3) && double.IsInfinity(bidiv3)) { bidiv3 = 0.0; }
            if (double.IsNaN(bidiv4) && double.IsInfinity(bidiv4)) { bidiv4 = 0.0; }
            if (double.IsNaN(bidiv5) && double.IsInfinity(bidiv5)) { bidiv5 = 0.0; }
            if (double.IsNaN(askiv1) && double.IsInfinity(askiv1)) { askiv1 = 0.0; }
            if (double.IsNaN(askiv2) && double.IsInfinity(askiv2)) { askiv2 = 0.0; }
            if (double.IsNaN(askiv3) && double.IsInfinity(askiv3)) { askiv3 = 0.0; }
            if (double.IsNaN(askiv4) && double.IsInfinity(askiv4)) { askiv4 = 0.0; }
            if (double.IsNaN(askiv5) && double.IsInfinity(askiv5)) { askiv5 = 0.0; }

            mCommodityData.F[45] = bidiv1;
            mCommodityData.F[46] = bidiv2;
            mCommodityData.F[47] = bidiv3;
            mCommodityData.F[48] = bidiv4;
            mCommodityData.F[49] = bidiv5;
            mCommodityData.F[50] = askiv1;
            mCommodityData.F[51] = askiv2;
            mCommodityData.F[52] = askiv3;
            mCommodityData.F[53] = askiv4;
            mCommodityData.F[54] = askiv5;

            SetValue(45, mCommodityData, mCommodityData.F[45]);
            SetValue(46, mCommodityData, mCommodityData.F[46]);
            SetValue(47, mCommodityData, mCommodityData.F[47]);
            SetValue(48, mCommodityData, mCommodityData.F[48]);
            SetValue(49, mCommodityData, mCommodityData.F[49]);
            SetValue(50, mCommodityData, mCommodityData.F[50]);
            SetValue(51, mCommodityData, mCommodityData.F[51]);
            SetValue(52, mCommodityData, mCommodityData.F[52]);
            SetValue(53, mCommodityData, mCommodityData.F[53]);
            SetValue(54, mCommodityData, mCommodityData.F[54]);*/

            if (mCommodityData.Underlying == null || mCommodityType == CommodityType.None || mCommodityData.F[6] == null || mCommodityData.F[67] == null || mCommodityData.Underlying.F[60] == null)
                return;

            /*spot = (double)mCommodityData.Underlying.F[60];

            bidiv1 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid1 / execratio);
            bidiv2 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid2 / execratio);
            bidiv3 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid3 / execratio);
            bidiv4 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid4 / execratio);
            bidiv5 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid5 / execratio);
            askiv1 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask1 / execratio);
            askiv2 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask2 / execratio);
            askiv3 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask3 / execratio);
            askiv4 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask4 / execratio);
            askiv5 = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask5 / execratio);

            if (double.IsNaN(bidiv1) && double.IsInfinity(bidiv1)) { bidiv1 = 0.0; }
            if (double.IsNaN(bidiv2) && double.IsInfinity(bidiv2)) { bidiv2 = 0.0; }
            if (double.IsNaN(bidiv3) && double.IsInfinity(bidiv3)) { bidiv3 = 0.0; }
            if (double.IsNaN(bidiv4) && double.IsInfinity(bidiv4)) { bidiv4 = 0.0; }
            if (double.IsNaN(bidiv5) && double.IsInfinity(bidiv5)) { bidiv5 = 0.0; }
            if (double.IsNaN(askiv1) && double.IsInfinity(askiv1)) { askiv1 = 0.0; }
            if (double.IsNaN(askiv2) && double.IsInfinity(askiv2)) { askiv2 = 0.0; }
            if (double.IsNaN(askiv3) && double.IsInfinity(askiv3)) { askiv3 = 0.0; }
            if (double.IsNaN(askiv4) && double.IsInfinity(askiv4)) { askiv4 = 0.0; }
            if (double.IsNaN(askiv5) && double.IsInfinity(askiv5)) { askiv5 = 0.0; }

            mCommodityData.F[45] = bidiv1;
            mCommodityData.F[46] = bidiv2;
            mCommodityData.F[47] = bidiv3;
            mCommodityData.F[48] = bidiv4;
            mCommodityData.F[49] = bidiv5;
            mCommodityData.F[50] = askiv1;
            mCommodityData.F[51] = askiv2;
            mCommodityData.F[52] = askiv3;
            mCommodityData.F[53] = askiv4;
            mCommodityData.F[54] = askiv5;*/

            int[] r = { 45, 46, 47, 48, 49, 50, 51, 52, 53, 54 };

            foreach (int Field in r)
            {
                foreach (PriceData mPriceData in mCommodityData.GetPriceDataLists(Field))
                {
                    spot = mPriceData.Spot;
                    if (spot == 0.0) { spot = (double)mCommodityData.Underlying.F[60]; }

                    if (Field == 45)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid1 / execratio);
                    else if (Field == 46)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid2 / execratio);
                    else if (Field == 47)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid3 / execratio);
                    else if (Field == 48)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid4 / execratio);
                    else if (Field == 49)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, bid5 / execratio);
                    else if (Field == 50)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask1 / execratio);
                    else if (Field == 51)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask2 / execratio);
                    else if (Field == 52)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask3 / execratio);
                    else if (Field == 53)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask4 / execratio);
                    else if (Field == 54)
                        val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, ask5 / execratio);

                    if (double.IsNaN(val) && double.IsInfinity(val)) { val = 0.0; }                        

                    PriceData gPriceData = mCommodityData.Get(mPriceData.Field, mPriceData.topicID);
                    if (gPriceData != null)
                    {
                        gPriceData.Value = val;
                        UpdateTopic.Add(gPriceData);
                    }
                }
            }
        }
        private void CalculateLastIV(CommodityData mCommodityData)
        {
            double lastiv = 0.0;
            double last = 0.0;
            string underlying = "";
            CommodityType mCommodityType = CommodityType.None;
            DateTime maturity = new DateTime();
            double barrier = 0.0;
            double execratio = 0.0;
            double spot = 0.0;
            double strike = 0.0;

            if (mCommodityData.F[60] != null)
                last = (double)mCommodityData.F[60];
            if (mCommodityData.F[65] != null)
                underlying = mCommodityData.F[65].ToString();
            if (mCommodityData.F[66] != null)
                mCommodityType = (CommodityType)mCommodityData.F[66];
            if (mCommodityData.F[67] != null)
                maturity = (DateTime)mCommodityData.F[67];
            if (mCommodityData.F[68] != null)
                barrier = (double)mCommodityData.F[68];
            if (mCommodityData.F[69] != null)
                execratio = (double)mCommodityData.F[69];
            if (mCommodityData.F[6] != null)
                strike = (double)mCommodityData.F[6];

            /*if (mCommodityData.Underlying != null && mCommodityType != CommodityType.None && mCommodityData.F[6] != null && mCommodityData.F[67] != null && mCommodityData.Underlying.F[60] != null)
            {
                spot = (double)mCommodityData.Underlying.F[60];

                lastiv = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
            }
            if (double.IsNaN(lastiv) && double.IsInfinity(lastiv)) { lastiv = 0.0; }

            mCommodityData.F[44] = lastiv;

            SetValue(44, mCommodityData, mCommodityData.F[44]);*/

            if (mCommodityData.Underlying == null || mCommodityType == CommodityType.None || mCommodityData.F[6] == null || mCommodityData.F[67] == null || mCommodityData.Underlying.F[60] == null)
                return;

            foreach (PriceData mPriceData in mCommodityData.GetPriceDataLists(44))
            {                
                spot = mPriceData.Spot;
                if (spot == 0.0) { spot = (double)mCommodityData.Underlying.F[60]; }
                             
                lastiv = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);

                if (double.IsNaN(lastiv) && double.IsInfinity(lastiv)) { lastiv = 0.0; }
                mCommodityData.F[44] = lastiv;

                PriceData gPriceData = mCommodityData.Get(mPriceData.Field, mPriceData.topicID);
                if (gPriceData != null)
                {
                    gPriceData.Value = lastiv;
                    UpdateTopic.Add(gPriceData);
                }
            }
        }
        private void CalculateLastLastIV(CommodityData mCommodityData)
        {
            double lastiv = 0.0;
            double last = 0.0;
            string underlying = "";
            CommodityType mCommodityType = CommodityType.None;
            DateTime maturity = new DateTime();
            double barrier = 0.0;
            double execratio = 0.0;
            double spot = 0.0;
            double strike = 0.0;

            if (mCommodityData.F[75] != null)
                last = (double)mCommodityData.F[75];
            if (mCommodityData.F[65] != null)
                underlying = mCommodityData.F[65].ToString();
            if (mCommodityData.F[66] != null)
                mCommodityType = (CommodityType)mCommodityData.F[66];
            if (mCommodityData.F[67] != null)
                maturity = (DateTime)mCommodityData.F[67];
            if (mCommodityData.F[68] != null)
                barrier = (double)mCommodityData.F[68];
            if (mCommodityData.F[69] != null)
                execratio = (double)mCommodityData.F[69];
            if (mCommodityData.F[6] != null)
                strike = (double)mCommodityData.F[6];

            if (mCommodityData.Underlying != null && mCommodityType != CommodityType.None && mCommodityData.F[6] != null && mCommodityData.F[67] != null && mCommodityData.Underlying.F[75] != null)
            {
                spot = (double)mCommodityData.Underlying.F[75];
                lastiv = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
            }
            if (double.IsNaN(lastiv) && double.IsInfinity(lastiv)) { lastiv = 0.0; }

            mCommodityData.F[77] = lastiv;

            SetValue(77, mCommodityData, mCommodityData.F[77]);
        }
        private void CalculateGreeks(CommodityData mCommodityData)
        {
            double val = 0.0;
            string underlying = "";
            CommodityType mCommodityType = CommodityType.None;
            DateTime maturity = new DateTime();
            double barrier = 0.0;
            double execratio = 0.0;
            double spot = 0.0;
            double strike = 0.0;

            if (mCommodityData.F[65] != null)
                underlying = mCommodityData.F[65].ToString();
            if (mCommodityData.F[66] != null)
                mCommodityType = (CommodityType)mCommodityData.F[66];
            if (mCommodityData.F[67] != null)
                maturity = (DateTime)mCommodityData.F[67];
            if (mCommodityData.F[68] != null)
                barrier = (double)mCommodityData.F[68];
            if (mCommodityData.F[69] != null)
                execratio = (double)mCommodityData.F[69];
            if (mCommodityData.F[6] != null)
                strike = (double)mCommodityData.F[6];

            int[] r = { 55, 56, 57, 58, 59, 63 };


            if (mCommodityData.Underlying == null || mCommodityType == CommodityType.None || mCommodityData.F[6] == null || mCommodityData.F[67] == null || mCommodityData.Underlying.F[60] == null)
            {
                foreach (int Field in r)
                {
                    foreach (PriceData mPriceData in mCommodityData.GetPriceDataLists(Field))
                    {                        
                        if (Field == 55)
                            val = execratio;
                        else 
                           val = 0.0;                        

                        PriceData gPriceData = mCommodityData.Get(mPriceData.Field, mPriceData.topicID);
                        if (gPriceData != null)
                        {
                            gPriceData.Value = val;
                            UpdateTopic.Add(gPriceData);
                        }
                    }
                }
            }
            else
            {
                //spot = (double)mCommodityData.Underlying.F[60];
                
                foreach (int Field in r)
                {
                    foreach (PriceData mPriceData in mCommodityData.GetPriceDataLists(Field))
                    {
                        double HedgeVol = mPriceData.HedgeVol;
                        spot = mPriceData.Spot;
                        if (spot == 0.0) { spot = (double)mCommodityData.Underlying.F[60]; }

                        if (HedgeVol == 0.0 && mCommodityData.Underlying.F[71] != null) { HedgeVol = (double)mCommodityData.Underlying.F[71]; }
                        if (HedgeVol != 0.0)
                        {
                            if (Field == 55)
                                val = Greeks.CalcDelta((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio;
                            else if (Field == 56)
                                val = Greeks.CalcGamma((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio;
                            else if (Field == 57)
                                val = Greeks.CalcVega((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio/100.0;
                            else if (Field == 58)
                                val = Greeks.CalcTheta((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio/365.0;
                            else if (Field == 59)
                                val = Greeks.CalcRho((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio/100.0;
                            else if (Field == 63)
                                val = Greeks.CalcTPrice((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio;
                        }

                        PriceData gPriceData = mCommodityData.Get(mPriceData.Field, mPriceData.topicID);
                        if (gPriceData != null)
                        {
                            gPriceData.Value = val;
                            UpdateTopic.Add(gPriceData);
                        }
                    }
                }
            }
        }
        private double CalculateGreeks(int Field, CommodityData mCommodityData, double HedgeVol, double spot)
        {
            double val = 0.0;
            string underlying = "";
            CommodityType mCommodityType = CommodityType.None;
            DateTime maturity = new DateTime();
            double barrier = 0.0;
            double execratio = 0.0;
            //double spot = 0.0;
            double strike = 0.0;
            double last = 0.0;

            if (mCommodityData.F[Field] != null) { val = (double)mCommodityData.F[Field]; }

            if (mCommodityData.GetPriceDataLists(Field).Count == 0)
                return val;

            if (mCommodityData.F[65] != null)
                underlying = mCommodityData.F[65].ToString();
            if (mCommodityData.F[66] != null)
                mCommodityType = (CommodityType)mCommodityData.F[66];
            if (mCommodityData.F[67] != null)
                maturity = (DateTime)mCommodityData.F[67];
            if (mCommodityData.F[68] != null)
                barrier = (double)mCommodityData.F[68];
            if (mCommodityData.F[69] != null)
                execratio = (double)mCommodityData.F[69];
            if (mCommodityData.F[6] != null)
                strike = (double)mCommodityData.F[6];

            if (mCommodityData.Underlying == null || mCommodityType == CommodityType.None || mCommodityData.F[6] == null || mCommodityData.F[67] == null || mCommodityData.Underlying.F[60] == null)
            {
                if (Field == 55)
                    val = execratio;
                else
                    val = 0.0;
            }
            else
            {
                //spot = (double)mCommodityData.Underlying.F[60];
                if (spot == 0.0) { spot = (double)mCommodityData.Underlying.F[60]; }

                if (Field == 44)
                {
                    if (mCommodityData.F[60] != null) last = (double)mCommodityData.F[60]; 
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);                    
                }
                else if (Field == 45)
                {
                    if (mCommodityData.F[61] != null) last = (double)mCommodityData.F[61];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 46)
                {
                    if (mCommodityData.F[20] != null) last = (double)mCommodityData.F[20];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 47)
                {
                    if (mCommodityData.F[21] != null) last = (double)mCommodityData.F[21];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 48)
                {
                    if (mCommodityData.F[22] != null) last = (double)mCommodityData.F[22];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 49)
                {
                    if (mCommodityData.F[23] != null) last = (double)mCommodityData.F[23];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 50)
                {
                    if (mCommodityData.F[62] != null) last = (double)mCommodityData.F[62];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 51)
                {
                    if (mCommodityData.F[25] != null) last = (double)mCommodityData.F[25];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 52)
                {
                    if (mCommodityData.F[26] != null) last = (double)mCommodityData.F[26];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 53)
                {
                    if (mCommodityData.F[27] != null) last = (double)mCommodityData.F[27];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else if (Field == 54)
                {
                    if (mCommodityData.F[28] != null) last = (double)mCommodityData.F[28];
                    val = Greeks.CalcIV((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, last / execratio);
                }
                else
                {
                    if (HedgeVol == 0.0 && mCommodityData.Underlying.F[71] != null) { HedgeVol = (double)mCommodityData.Underlying.F[71]; }
                    if (HedgeVol != 0.0)
                    {
                        if (Field == 55)
                            val = Greeks.CalcDelta((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio;
                        else if (Field == 56)
                            val = Greeks.CalcGamma((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio;
                        else if (Field == 57)
                            val = Greeks.CalcVega((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio / 100.0;
                        else if (Field == 58)
                            val = Greeks.CalcTheta((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio / 365.0;
                        else if (Field == 59)
                            val = Greeks.CalcRho((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio / 100.0;
                        else if (Field == 63)
                            val = Greeks.CalcTPrice((enumOption)mCommodityType, spot, strike, barrier, Math.Abs(strike - barrier), maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, HedgeVol) * execratio;

                    }
                }
            }

            return val;
        }        
        public void ServerTerminate()
        {
            try
            {
                //if (DeriLib.Properties.Settings.Default.TsIP == "") { DeriLib.Properties.Settings.Default.TsIP = "localhost"; }
                //if (DeriLib.Properties.Settings.Default.DBConnectString == "") { DeriLib.Properties.Settings.Default.DBConnectString = "SERVER=172.16.1.112;DATABASE=TsQuote;UID=TsAP;PWD=TsAP"; }

                //Properties.Settings.Default.Save();
                
                List<int> L = PriceDataList.Keys.ToList<int>();
                
                foreach (int topicid in L)
                    DisconnectData(topicid);

                Q.UnSubCommodity(UnSubCommodityList);

                if (RoutineTh != null && RoutineTh.IsAlive)
                    RoutineTh.Abort();

                xlRTDUpdate = null;
                Q.Close();
                tr.Elapsed -= new ElapsedEventHandler(tr_Elapsed);
                tr.Stop();
                tr.Dispose();
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }

        #endregion
    }
    public class CommodityData
    {
        public string CommodityId = "";
        //public CommodityKind sCommodityKind = CommodityKind.Stock;
        public CommodityData Underlying;
        
        public object[] F = new object[90];
        public Dictionary<int, Dictionary<int, PriceData>> m_PriceDataList = new Dictionary<int, Dictionary<int, PriceData>>();//Dictionary<field, Dictionary<topicID, PriceData>>
        private Dictionary<string, CommodityData> m_RelationCommoditys = new Dictionary<string, CommodityData>();
        private object LockObj = new object();

        public CommodityData(string CommodityId)
        {
            this.CommodityId = CommodityId;
        }

        public PriceData Get(int Field, int TopicID)
        {
            lock (LockObj)
            {
                if (m_PriceDataList.ContainsKey(Field) && m_PriceDataList[Field].ContainsKey(TopicID))
                    return m_PriceDataList[Field][TopicID];
                else
                    return null;
            }
        }
        public void Add(int Field, int TopicID, PriceData mPriceData)
        {
            lock (LockObj)
            {
                if (!m_PriceDataList.ContainsKey(Field))
                    m_PriceDataList.Add(Field, new Dictionary<int, PriceData>());

                Dictionary<int, PriceData> PriceDatas = m_PriceDataList[Field];

                if (!PriceDatas.ContainsKey(TopicID))
                    PriceDatas.Add(TopicID, mPriceData);
            }
        }
        public void Remove(int Field, int TopicID)
        {
            lock (LockObj)
            {
                if (m_PriceDataList.ContainsKey(Field))
                {
                    Dictionary<int, PriceData> PriceDatas = m_PriceDataList[Field];

                    if (PriceDatas.ContainsKey(TopicID))
                        PriceDatas.Remove(TopicID);

                    if (PriceDatas.Count == 0)
                        m_PriceDataList.Remove(Field);
                }
            }
        }
        public List<PriceData> GetPriceDataLists(int Field)
        {
            List<PriceData> L = new List<PriceData>();

            lock (LockObj)
            {
                if (m_PriceDataList.ContainsKey(Field))
                {
                    Dictionary<int, PriceData> PriceDatas = m_PriceDataList[Field];
                    L = PriceDatas.Values.ToList<PriceData>();                    
                }
            }

            return L;
        }
        public List<PriceData> GetPriceDataLists()
        {
            List<PriceData> L = new List<PriceData>();

            lock (LockObj)
            {
                foreach (Dictionary<int, PriceData> PriceDatas in m_PriceDataList.Values.ToList<Dictionary<int, PriceData>>())
                    L.AddRange(PriceDatas.Values.ToList<PriceData>());
            }

            return L;
        }

        public void AddRelation(CommodityData CommodityData)
        {
            lock (LockObj)
            {
                if (!m_RelationCommoditys.ContainsKey(CommodityData.CommodityId))
                    m_RelationCommoditys.Add(CommodityData.CommodityId, CommodityData);
                else
                    m_RelationCommoditys[CommodityData.CommodityId] = CommodityData;
            }
        }
        public void RemoveRelation(string CommodityId)
        {
            lock (LockObj)
            {
                if (m_RelationCommoditys.ContainsKey(CommodityId))
                    m_RelationCommoditys.Remove(CommodityId);
            }
        }
        public List<CommodityData> RelationCommoditys
        {
            get
            {
                List<CommodityData> L = new List<CommodityData>();

                lock (LockObj)
                {
                    L = m_RelationCommoditys.Values.ToList<CommodityData>();
                }

                return L;
            }
        }
    }
    public class PriceData
    {
        public int topicID = -1;
        public string CommodityId = "";
        public int Field = -1;
        public object Value = null;
        public double HedgeVol = 0.0;
        public double Spot = 0.0;

        public PriceData(int topicID, string CommodityId, int Field)
        {
            this.topicID = topicID;
            this.CommodityId = CommodityId;
            this.Field = Field;
        }
    }        
    public class SubCommodity
    {
        public string CommodityId = "";
        public bool IsSub = true;

        public SubCommodity(string CommodityId, bool IsSub)
        {
            this.CommodityId = CommodityId;
            this.IsSub = IsSub;
        }
    }
}
