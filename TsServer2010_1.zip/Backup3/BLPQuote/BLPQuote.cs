﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using Bloomberglp.Blpapi;

namespace BLPQuote
{
    public class BLPQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "07:40";        
        public string RemotIp = "127.0.0.1";
        public int RemotPort = 8194;        

        public BLPQuoteFactorySetting()
        {
        }
        public BLPQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public BLPQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }

    public class BLPQuoteSource : QuoteSource
    {
        //private static readonly ILog log = LogManager.GetLogger(typeof(BLPQuoteSource));

        private Thread RoutineThread;
        private string DBConnectString = "";
        private TimeSpan tsRecover;
        //private TimeSpan RecoverTime2;
        //private TimeSpan TransCloseTime;
        private bool RecoverFlag = false;
        //private bool RecoverFlag2 = false;
        //private bool TransCloseFlag = false;
        private string RemotIp = "";
        private int RemotePort = 0;
        Dictionary<string, string> dicIntlMonth = new Dictionary<string, string>();
        Dictionary<string, string> dicMonth = new Dictionary<string, string>();
        Dictionary<string, string> dicYstCls = new Dictionary<string, string>();
            
        public BLPQuoteSource(BLPQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;            
            RemotIp = QuoteSetting.RemotIp;
            RemotePort = QuoteSetting.RemotPort;
            tsRecover = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);

            dicIntlMonth["01"] = dicIntlMonth["1"] = "F"; dicIntlMonth["F"] = "01";
            dicIntlMonth["02"] = dicIntlMonth["2"] = "G"; dicIntlMonth["G"] = "02";
            dicIntlMonth["03"] = dicIntlMonth["3"] = "H"; dicIntlMonth["H"] = "03";
            dicIntlMonth["04"] = dicIntlMonth["4"] = "J"; dicIntlMonth["J"] = "04";
            dicIntlMonth["05"] = dicIntlMonth["5"] = "K"; dicIntlMonth["K"] = "05";
            dicIntlMonth["06"] = dicIntlMonth["6"] = "M"; dicIntlMonth["M"] = "06";
            dicIntlMonth["07"] = dicIntlMonth["7"] = "N"; dicIntlMonth["N"] = "07";
            dicIntlMonth["08"] = dicIntlMonth["8"] = "Q"; dicIntlMonth["Q"] = "08";
            dicIntlMonth["09"] = dicIntlMonth["9"] = "U"; dicIntlMonth["U"] = "09";
            dicIntlMonth["10"] = "V"; dicIntlMonth["V"] = "10";
            dicIntlMonth["11"] = "X"; dicIntlMonth["X"] = "11";
            dicIntlMonth["12"] = "Z"; dicIntlMonth["Z"] = "12";

            dicMonth["01"] = "A";
            dicMonth["02"] = "B";
            dicMonth["03"] = "C";
            dicMonth["04"] = "D";
            dicMonth["05"] = "E";
            dicMonth["06"] = "F";
            dicMonth["07"] = "G";
            dicMonth["08"] = "H";
            dicMonth["09"] = "I";
            dicMonth["10"] = "J";
            dicMonth["11"] = "K";
            dicMonth["12"] = "L";
        }

        public override bool Start()
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            LoadData();
            ConnectBLP();

            if (_tEventWorker == null)
            {
                _tEventWorker = new Thread(new ThreadStart(deqEvent));
                _tEventWorker.Start();
            }

            SubscribeBLP();

            return base.Start();
        }

        public override bool Close()
        {
            try
            {
                if (_tEventWorker != null && _tEventWorker.IsAlive) { _tEventWorker.Abort(); _tEventWorker = null; }

                if (_sess != null)
                {
                    _sess.Stop();
                    _sess = null;
                }

                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                
                base.Close();
                
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private Thread _tEventWorker = null;
        private void deqEvent()
        {
            while (true)
            {
                Event eventObj = _sess.NextEvent();
                
                foreach (Bloomberglp.Blpapi.Message msg in eventObj.GetMessages())
                {
                    bool bSentFlag = false;

                    #region IF EVENT TYPE=SUBSCRIPTION_DATA THEN UPDATA DATA FIELDS

                    if (eventObj.Type == Event.EventType.SUBSCRIPTION_DATA)
                    {
                        m_PacketNum++;

                        StringBuilder sb = new StringBuilder();

                        try
                        {
                            long iCId = msg.CorrelationID.Value;
                            string sInnerCode = _dicInnerCode[iCId];
                            string sLstPrc = string.Empty;
                            string sBid = string.Empty;
                            string sAsk = string.Empty;
                            
                            //InnerCode => 0
                            sb.Append(sInnerCode + ",");

                            //TIME => 1
                            //if (msg.HasElement("TIME") && !msg.GetElement("TIME").IsNull)//check IsNull before use the field
                            //{
                            //    string sTime = msg.GetElementAsString("TIME");
                            //    if (!String.IsNullOrEmpty(sTime) && sTime.Length >= 8)
                            //    {
                            //        sTime = sTime.Substring(0, 8);
                            //        if (sTime.IndexOf(":") == 2 && sTime.LastIndexOf(":") == 5)
                            //        { sb.Append(sTime.Substring(0, 2) + sTime.Substring(3, 2) + sTime.Substring(6, 2) + "00,"); }
                            //        else
                            //        { sb.Append(DateTime.Now.ToString("HHmmssff") + ","); }
                            //    }
                            //    else
                            //    { sb.Append(DateTime.Now.ToString("HHmmssff") + ","); }
                            //    bSentFlag = true;
                            //}
                            //else
                            { sb.Append(DateTime.Now.ToString("HHmmssff") + ","); }

                            //LAST_PRICE => 2
                            if (msg.HasElement("LAST_PRICE") && !msg.GetElement("LAST_PRICE").IsNull)//check IsNull before use the field
                            {
                                sLstPrc=msg.GetElementAsString("LAST_PRICE");
                                sb.Append(sLstPrc + ",");
                                bSentFlag = true;
                            }
                            else
                            { sb.Append(","); }

                            //SIZE_LAST_TRADE => 3
                            if (msg.HasElement("SIZE_LAST_TRADE") && !msg.GetElement("SIZE_LAST_TRADE").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("SIZE_LAST_TRADE") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //VOLUME => 4
                            if (msg.HasElement("VOLUME") && !msg.GetElement("VOLUME").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("VOLUME") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            ////****************************************************************************************************************

                            #region BID ASK
                            //BEST_BID1 => 5
                            if (msg.HasElement("BEST_BID1") && !msg.GetElement("BEST_BID1").IsNull)//check IsNull before use the field
                            {
                                sBid=msg.GetElementAsString("BEST_BID1");
                                sb.Append(sBid + ",");
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("BID") && !msg.GetElement("BID").IsNull)//check IsNull before use the field
                            {
                                sBid=msg.GetElementAsString("BID");
                                sb.Append(sBid + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID1_SZ => 6
                            if (msg.HasElement("BEST_BID1_SZ") && !msg.GetElement("BEST_BID1_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID1_SZ") + ",");
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("BID_SIZE") && !msg.GetElement("BID_SIZE").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BID_SIZE") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID2 => 7
                            if (msg.HasElement("BEST_BID2") && !msg.GetElement("BEST_BID2").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID2") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID2_SZ => 8
                            if (msg.HasElement("BEST_BID2_SZ") && !msg.GetElement("BEST_BID2_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID2_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID3 => 9
                            if (msg.HasElement("BEST_BID3") && !msg.GetElement("BEST_BID3").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID3") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID3_SZ => 10
                            if (msg.HasElement("BEST_BID3_SZ") && !msg.GetElement("BEST_BID3_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID3_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID4 => 11
                            if (msg.HasElement("BEST_BID4") && !msg.GetElement("BEST_BID4").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID4") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID4_SZ => 12
                            if (msg.HasElement("BEST_BID4_SZ") && !msg.GetElement("BEST_BID4_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID4_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID5 => 13
                            if (msg.HasElement("BEST_BID5") && !msg.GetElement("BEST_BID5").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID5") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_BID5_SZ => 14
                            if (msg.HasElement("BEST_BID5_SZ") && !msg.GetElement("BEST_BID5_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_BID5_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            ////****************************************************************************************************************

                            //BEST_ASK1 => 15
                            if (msg.HasElement("BEST_ASK1") && !msg.GetElement("BEST_ASK1").IsNull)//check IsNull before use the field
                            {
                                sAsk=msg.GetElementAsString("BEST_ASK1");
                                sb.Append(msg.GetElementAsString("BEST_ASK1") + ",");
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("ASK") && !msg.GetElement("ASK").IsNull)//check IsNull before use the field
                            {
                                sAsk=msg.GetElementAsString("ASK");
                                sb.Append(sAsk + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK1_SZ => 16
                            if (msg.HasElement("BEST_ASK1_SZ") && !msg.GetElement("BEST_ASK1_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK1_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else if (msg.HasElement("ASK_SIZE") && !msg.GetElement("ASK_SIZE").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("ASK_SIZE") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else
                            { sb.Append(","); }

                            //BEST_ASK2 => 17
                            if (msg.HasElement("BEST_ASK2") && !msg.GetElement("BEST_ASK2").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK2") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK2_SZ => 18
                            if (msg.HasElement("BEST_ASK2_SZ") && !msg.GetElement("BEST_ASK2_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK2_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK3 => 19
                            if (msg.HasElement("BEST_ASK3") && !msg.GetElement("BEST_ASK3").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK3") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK3_SZ => 20
                            if (msg.HasElement("BEST_ASK3_SZ") && !msg.GetElement("BEST_ASK3_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK3_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK4 => 21
                            if (msg.HasElement("BEST_ASK4") && !msg.GetElement("BEST_ASK4").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK4") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK4_SZ => 22
                            if (msg.HasElement("BEST_ASK4_SZ") && !msg.GetElement("BEST_ASK4_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK4_SZ") + ",");//ASK1 SZ is the last field no need to add ','
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK5 => 23
                            if (msg.HasElement("BEST_ASK5") && !msg.GetElement("BEST_ASK5").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK5") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //BEST_ASK5_SZ => 24
                            if (msg.HasElement("BEST_ASK5_SZ") && !msg.GetElement("BEST_ASK5_SZ").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("BEST_ASK5_SZ") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //HIGH => 25
                            if (msg.HasElement("HIGH") && !msg.GetElement("HIGH").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("HIGH") + ",");
                                bSentFlag = true;
                            }
                            else { sb.Append(","); }

                            //LOW => 26
                            if (msg.HasElement("LOW") && !msg.GetElement("LOW").IsNull)//check IsNull before use the field
                            {
                                sb.Append(msg.GetElementAsString("LOW"));// + ",");
                                bSentFlag = true;
                            }
                            //else { sb.Append(","); }

                            #endregion

                            //*******SEND OUT DATA**********
                            if (bSentFlag) 
                            {
                                if (!sInnerCode.StartsWith("CNH"))
                                { 
                                    m_PackagePool.Enqueue(sb.ToString()); 
                                }
                                else if (_dicRelFut.ContainsKey(sInnerCode) && _dicFwdInd.ContainsKey(sInnerCode))
                                {
                                    string sRelFut = _dicRelFut[sInnerCode];
                                    string[] saRelFut = sRelFut.Split(',');                                        
                                    int iFwdInd = _dicFwdInd[sInnerCode];
                                    DateTime dt;
                                    TimeSpan ts, ts2;
                                    double dLstPrc, dBid, dAsk;

                                    bool bSentFlag2 = false;
                                    if (iFwdInd > 0)
                                    {
                                        if (!String.IsNullOrEmpty(sLstPrc))
                                        { 
                                            _daFwdLstPrc[iFwdInd] = Math.Round((_daFwdLstPrc[0] + Convert.ToDouble(sLstPrc) / 10000.0) * 10000.0) / 10000.0;
                                            bSentFlag2 = true;
                                        }
                                        if (!String.IsNullOrEmpty(sBid))
                                        { _daFwdBid[iFwdInd] = Math.Round((_daFwdBid[0] + Convert.ToDouble(sBid) / 10000.0) * 10000.0) / 10000.0; }
                                        if (!String.IsNullOrEmpty(sAsk))
                                        { _daFwdAsk[iFwdInd] = Math.Round((_daFwdAsk[0] + Convert.ToDouble(sAsk) / 10000.0) * 10000.0) / 10000.0; }
                                                                                
                                        dLstPrc = 0; dBid = 0; dAsk = 0;
                                        dt = _dicLstTrdDt[saRelFut[0]];
                                        if (dt <= _dtaFwdDt[iFwdInd])
                                        {
                                            ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                            ts2 = new TimeSpan(_dtaFwdDt[iFwdInd].Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);                                            
                                            dLstPrc = _daFwdLstPrc[iFwdInd - 1] + (_daFwdLstPrc[iFwdInd] - _daFwdLstPrc[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays; 
                                            dBid = _daFwdBid[iFwdInd - 1] + (_daFwdBid[iFwdInd] - _daFwdBid[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays; 
                                            dAsk = _daFwdAsk[iFwdInd - 1] + (_daFwdAsk[iFwdInd] - _daFwdAsk[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays; 
                                        }
                                        else if (_dtaFwdDt[iFwdInd] < dt)
                                        {
                                            ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                            ts2 = new TimeSpan(_dtaFwdDt[iFwdInd + 1].Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                            dLstPrc = _daFwdLstPrc[iFwdInd] + (_daFwdLstPrc[iFwdInd + 1] - _daFwdLstPrc[iFwdInd]) / ts2.TotalDays * ts.TotalDays; 
                                            dBid = _daFwdBid[iFwdInd] + (_daFwdBid[iFwdInd + 1] - _daFwdBid[iFwdInd]) / ts2.TotalDays * ts.TotalDays; 
                                            dAsk = _daFwdAsk[iFwdInd] + (_daFwdAsk[iFwdInd + 1] - _daFwdAsk[iFwdInd]) / ts2.TotalDays * ts.TotalDays; 
                                        }

                                        if (bSentFlag2)
                                        {
                                            sb.Remove(0, sb.Length);
                                            sb.Append(saRelFut[0] + "," + DateTime.Now.ToString("HHmmssff") + "," + Convert.ToString(Math.Round(dLstPrc * 10000.0) / 10000.0) + ",,," + Convert.ToString(Math.Round(dBid * 10000.0) / 10000.0) + ",,,,,,,,,," + Convert.ToString(Math.Round(dAsk * 10000.0) / 10000.0) + ",,,,,,,,,,,");
                                            m_PackagePool.Enqueue(sb.ToString());
                                        }

                                        if (saRelFut.Length > 1)
                                        {
                                            dLstPrc = 0; dBid = 0; dAsk = 0;
                                            dt = _dicLstTrdDt[saRelFut[1]];
                                            if (dt <= _dtaFwdDt[iFwdInd])
                                            {
                                                ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                                ts2 = new TimeSpan(_dtaFwdDt[iFwdInd].Subtract(_dtaFwdDt[iFwdInd - 1]).Ticks);
                                                dLstPrc = _daFwdLstPrc[iFwdInd - 1] + (_daFwdLstPrc[iFwdInd] - _daFwdLstPrc[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                dBid = _daFwdBid[iFwdInd - 1] + (_daFwdBid[iFwdInd] - _daFwdBid[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                                dAsk = _daFwdAsk[iFwdInd - 1] + (_daFwdAsk[iFwdInd] - _daFwdAsk[iFwdInd - 1]) / ts2.TotalDays * ts.TotalDays;
                                            }
                                            else if (_dtaFwdDt[iFwdInd] < dt)
                                            {
                                                ts = new TimeSpan(dt.Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                                ts2 = new TimeSpan(_dtaFwdDt[iFwdInd + 1].Subtract(_dtaFwdDt[iFwdInd]).Ticks);
                                                dLstPrc = _daFwdLstPrc[iFwdInd] + (_daFwdLstPrc[iFwdInd + 1] - _daFwdLstPrc[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                dBid = _daFwdBid[iFwdInd] + (_daFwdBid[iFwdInd + 1] - _daFwdBid[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                                dAsk = _daFwdAsk[iFwdInd] + (_daFwdAsk[iFwdInd + 1] - _daFwdAsk[iFwdInd]) / ts2.TotalDays * ts.TotalDays;
                                            }

                                            if (bSentFlag2)
                                            {
                                                sb.Remove(0, sb.Length);
                                                sb.Append(saRelFut[1] + "," + DateTime.Now.ToString("HHmmssff") + "," + Convert.ToString(Math.Round(dLstPrc * 10000.0) / 10000.0) + ",,," + Convert.ToString(Math.Round(dBid * 10000.0) / 10000.0) + ",,,,,,,,,," + Convert.ToString(Math.Round(dAsk * 10000.0) / 10000.0) + ",,,,,,,,,,,");
                                                m_PackagePool.Enqueue(sb.ToString());
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (!String.IsNullOrEmpty(sLstPrc))
                                        {
                                            _daFwdLstPrc[0] = Convert.ToDouble(sLstPrc);
                                            bSentFlag2 = true;
                                        }
                                        if (!String.IsNullOrEmpty(sBid))
                                        { _daFwdBid[0] = Convert.ToDouble(sBid); }
                                        if (!String.IsNullOrEmpty(sAsk))
                                        { _daFwdAsk[0] = Convert.ToDouble(sAsk); }

                                        dLstPrc = 0; dBid = 0; dAsk = 0;
                                        dt = _dicLstTrdDt[saRelFut[0]];
                                        ts = new TimeSpan(dt.Subtract(_dtaFwdDt[0]).Ticks);
                                        ts2 = new TimeSpan(_dtaFwdDt[1].Subtract(_dtaFwdDt[0]).Ticks);
                                        dLstPrc = _daFwdLstPrc[0] + (_daFwdLstPrc[1] - _daFwdLstPrc[0]) / ts2.TotalDays * ts.TotalDays; 
                                        dBid = _daFwdBid[0] + (_daFwdBid[1] - _daFwdBid[0]) / ts2.TotalDays * ts.TotalDays; 
                                        dAsk = _daFwdAsk[0] + (_daFwdAsk[1] - _daFwdAsk[0]) / ts2.TotalDays * ts.TotalDays;

                                        if (bSentFlag2)
                                        {
                                            sb.Remove(0, sb.Length);
                                            sb.Append(saRelFut[0] + "," + DateTime.Now.ToString("HHmmssff") + "," + Convert.ToString(Math.Round(dLstPrc * 10000.0) / 10000.0) + ",,," + Convert.ToString(Math.Round(dBid * 10000.0) / 10000.0) + ",,,,,,,,,," + Convert.ToString(Math.Round(dAsk * 10000.0) / 10000.0) + ",,,,,,,,,,,");
                                            m_PackagePool.Enqueue(sb.ToString());
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        { m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][deqEvent_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                    }
                    #endregion
                }
            }
        }

        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan tsNow = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                        //RecoverFlag2 = false;
                        //TransCloseFlag = false;
                    }

                    if (Math.Abs(tsNow.Subtract(tsRecover).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    //if (Math.Abs(tsNow.Subtract(RecoverTime2).TotalMinutes) < 1 && !RecoverFlag2)
                    //{
                    //    ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                    //    RecoverFlag2 = true;
                    //}

                    //if (Math.Abs(tsNow.Subtract(TransCloseTime).TotalMinutes) < 1 && !TransCloseFlag)
                    //{
                    //    ThreadPool.QueueUserWorkItem(new WaitCallback(TransCloseWork));
                    //    TransCloseFlag = true;
                    //}

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            string sBlpData = m_PackagePool.Dequeue().ToString();
                            DealWithQuote(sBlpData);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException taex)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        //private void TransCloseWork(Object stateInfo)
        //{
        //    try
        //    {
        //        foreach (PCommodity P in m_PCommodityList.Commoditys)
        //        {
        //            if (P.QCommodity.Base.CommodityId.IndexOf("HK") > -1 || P.QCommodity.Base.CommodityId.IndexOf("STW") > -1 || P.QCommodity.Base.CommodityId.IndexOf("SCN") > -1)
        //            {
        //                P.SetClose(DateTime.Now.ToString("HHmmss"), DateTime.Now.ToString("HHmmssff"), P.QCommodity.HighLow.DayHighPrice, P.QCommodity.HighLow.DayLowPrice, 0.0, P.QCommodity.Best5.BuyPriceBest1, P.QCommodity.Best5.SellPriceBest1, P.QCommodity.Match.MatchPrice, DateTime.Today, 0, P.QCommodity.Match.MatchTotalQty, 0.0, P.QCommodity.Match.MatchPrice);
        //                DoSendWrite(P.QCommodity.Close);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][TransCloseWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
        //    }
        //}       

        private void ReStartWork(Object stateInfo)
        {
            try
            {
                if (_tEventWorker != null && _tEventWorker.IsAlive) { _tEventWorker.Abort(); _tEventWorker = null; }

                m_PacketNum = 0;

                LoadData();
                ConnectBLP();

                if (_tEventWorker == null) { _tEventWorker = new Thread(new ThreadStart(deqEvent)); _tEventWorker.Start(); }

                SubscribeBLP();
            }
            catch (Exception ex)
            { m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
        }

        private Element GetBloombergRefDataReq(string sProdCode, string[] saFields)
        {
            bool LoopSwitch = true;

            SessionOptions sessOptTmp = new SessionOptions();
            sessOptTmp.ServerHost = "127.0.0.1";
            sessOptTmp.ServerPort = 8194;

            Session sessTmp = new Session(sessOptTmp);

            if (!sessTmp.Start())
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][GetBloombergRefData_Error] " + "[Failed to start sessTmp]");
                return null;
            }

            if (!sessTmp.OpenService("//blp/refdata"))
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][GetBloombergRefData_Error] " + "[Failed to open refdata service]");
                return null;
            }

            Service refservice = sessTmp.GetService("//blp/refdata");

            //以下設定request內容******************************************************
            Request request = refservice.CreateRequest("ReferenceDataRequest");

            //設定商品名稱
            Element secs = request.GetElement("securities");
            secs.AppendValue(sProdCode);

            //設定資料欄位
            Element flds = request.GetElement("fields");
            for (int i = 0; i < saFields.Length; i++)
            { flds.AppendValue(saFields[i]); }

            sessTmp.SendRequest(request, null);

            Element RESULT = null;
            while (LoopSwitch)
            {
                Event eventobj = sessTmp.NextEvent();
                foreach (Bloomberglp.Blpapi.Message msg in eventobj.GetMessages())
                {
                    if (eventobj.Type.ToString() == "RESPONSE")
                    {
                        Element RefDataResponse = msg.AsElement;
                        Element SecurityDataArray = RefDataResponse.GetElement("securityData");
                        Element securityData = SecurityDataArray.GetValueAsElement(0);
                        Element FieldData = securityData.GetElement("fieldData");
                        RESULT = FieldData;
                        LoopSwitch = false;
                    }
                }
            }
            sessTmp.Stop();
            sessTmp = null;

            return RESULT;
        }
        
        private Dictionary<string, string> _dicComdtyId = new Dictionary<string, string>();
        private Dictionary<long, string> _dicInnerCode = new Dictionary<long, string>();
        private Dictionary<string, bool> _dicTsQuote = new Dictionary<string, bool>();
        private Dictionary<string, bool> _dicTibco = new Dictionary<string, bool>();
        private Dictionary<string, string> _dicExch = new Dictionary<string, string>();

        private string[] _saFwdSymbol = null;
        private DateTime[] _dtaFwdDt = null;
        private double[] _daFwdBid = null;
        private double[] _daFwdAsk = null;
        private double[] _daFwdLstPrc = null;
        private Dictionary<string, int> _dicFwdInd = new Dictionary<string, int>();
        private Dictionary<string, string> _dicRelFut = new Dictionary<string, string>();
        private Dictionary<string, DateTime> _dicLstTrdDt = new Dictionary<string, DateTime>();
        
        private void LoadData()
        {
            try
            {
                #region 交易商品

                string sComdtyKind = string.Empty;
                string sInnerCode = string.Empty;
                string sComdtyId = string.Empty;
                string sExch = string.Empty;

                string sYstCls = "0";
                double dYstCls = 0;
                string sUpLmt = "1000000";
                string sLoLmt = "-1000000";

                //============================================================
                
                _dicTsQuote.Clear();
                _dicTibco.Clear();

                string sql = "SELECT BLPProd,TsQuote,Tibco,Exch FROM BLPSetting";
                DataView dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);
                foreach (DataRowView dr in dv)
                {
                    string sBLPProd = string.Empty;
                    if (dr["BLPProd"] != DBNull.Value && !String.IsNullOrEmpty(dr["BLPProd"].ToString()))
                    { sBLPProd = dr["BLPProd"].ToString().Trim(); }

                    if (dr["TsQuote"] != DBNull.Value && !String.IsNullOrEmpty(dr["TsQuote"].ToString()))
                    { 
                        string sFlag = dr["TsQuote"].ToString().Trim();
                        if (sFlag.Equals("Y")) { _dicTsQuote[sBLPProd] = true; }
                        else if (sFlag.Equals("N")) { _dicTsQuote[sBLPProd] = false; }
                    }

                    if (dr["Tibco"] != DBNull.Value && !String.IsNullOrEmpty(dr["Tibco"].ToString()))
                    {
                        string sFlag = dr["Tibco"].ToString().Trim();
                        if (sFlag.Equals("Y")) { _dicTibco[sBLPProd] = true; }
                        else if (sFlag.Equals("N")) { _dicTibco[sBLPProd] = false; }
                    }

                    if (dr["Exch"] != DBNull.Value && !String.IsNullOrEmpty(dr["Exch"].ToString())) 
                    {
                        _dicExch[sBLPProd] = dr["Exch"].ToString().Trim();
                    }
                }

                _dicTsQuote["CNH"] = true;
                _dicTibco["CNH"] = true;
                _dicExch["CNH"] = "V_INDEX";
                //============================================================
                
                long iCId = -1;

                _dicInnerCode.Clear();
                _dicComdtyId.Clear();
                
                List<string> lstFwdSymbol = new List<string>();
                List<DateTime> lstFwdDt = new List<DateTime>();
                List<double> lstFwdBid = new List<double>();
                List<double> lstFwdAsk = new List<double>();
                List<double> lstFwdLstPrc = new List<double>();

                lstFwdSymbol.Clear();
                lstFwdSymbol.Add("CNH CMPN Curncy");
                lstFwdDt.Clear();
                lstFwdDt.Add(DateTime.Now);
                _dicInnerCode[++iCId] = "CNH CMPN Curncy";

                lstFwdLstPrc.Clear();
                lstFwdBid.Clear();
                lstFwdAsk.Clear();

                Element refdata = GetBloombergRefDataReq("CNH CMPN Curncy", new string[] { "PX_LAST", "PX_CLOSE", "PX_YEST_CLOSE", "PX_CLOSE_1D" });
                if (refdata.HasElement("PX_LAST") && !refdata.GetElement("PX_LAST").IsNull)
                { sYstCls = refdata.GetElementAsString("PX_LAST"); }
                else if (refdata.HasElement("PX_CLOSE") && !refdata.GetElement("PX_CLOSE").IsNull)
                { sYstCls = refdata.GetElementAsString("PX_CLOSE"); }
                else if (refdata.HasElement("PX_YEST_CLOSE") && !refdata.GetElement("PX_YEST_CLOSE").IsNull)
                { sYstCls = refdata.GetElementAsString("PX_YEST_CLOSE"); }
                else if (refdata.HasElement("PX_CLOSE_1D") && !refdata.GetElement("PX_CLOSE_1D").IsNull)
                { sYstCls = refdata.GetElementAsString("PX_CLOSE_1D"); }
                dYstCls = Convert.ToDouble(sYstCls);
                dicYstCls["CNH CMPN Curncy"] = sYstCls;
                
                lstFwdLstPrc.Add(dYstCls);
                lstFwdBid.Add(dYstCls);
                lstFwdAsk.Add(dYstCls);
                _dicFwdInd["CNH CMPN Curncy"] = 0;

                m_PCommodityList.Commoditys.Clear();

                sql = "SELECT InnerCode,CommodityId,CommodityNm,SettlementMonth,CommodityKind,DecimalLocate,Unit,MaturityDate FROM Commodity WHERE InnerCode LIKE '% Index' OR InnerCode LIKE '% Equity' OR InnerCode LIKE '% Comdty' OR InnerCode LIKE '% Curncy' ORDER BY MaturityDate";
                dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);
                
                foreach (DataRowView dr in dv)
                {
                    sComdtyKind = string.Empty;
                    sInnerCode = string.Empty;
                    sComdtyId = string.Empty;

                    sYstCls = "0";
                    dYstCls = 0;
                    sUpLmt = "1000000";
                    sLoLmt = "-1000000";

                    try
                    {                        
                        if (dr["CommodityKind"] != DBNull.Value && !String.IsNullOrEmpty(dr["CommodityKind"].ToString())) { sComdtyKind = dr["CommodityKind"].ToString().Trim(); }                        
                        if (dr["InnerCode"] != DBNull.Value && !String.IsNullOrEmpty(dr["InnerCode"].ToString())) { sInnerCode = dr["InnerCode"].ToString().Trim(); }                        
                        if (dr["CommodityId"] != DBNull.Value && !String.IsNullOrEmpty(dr["CommodityId"].ToString())) { sComdtyId = dr["CommodityId"].ToString().Trim(); }
                        
                        PCommodity PP = null;
                        if (sComdtyKind.Equals("Future"))
                        {
                            if (sInnerCode.Contains("M CMPN Curncy") || sInnerCode.Contains("M Curncy"))  //遠期合約(紐約報價或預定報價)
                            {
                                string sMaturityDate = string.Empty;
                                if (dr["MaturityDate"] != DBNull.Value && !String.IsNullOrEmpty(dr["MaturityDate"].ToString()))
                                {
                                    lstFwdSymbol.Add(sInnerCode);                                   
                                    sMaturityDate = dr["MaturityDate"].ToString().Trim();
                                    sMaturityDate = sMaturityDate.Substring(0, sMaturityDate.IndexOf(' '));
                                    string sYear = sMaturityDate.Substring(0, 4);
                                    string sMonth = sMaturityDate.Substring(sMaturityDate.IndexOf('/') + 1, sMaturityDate.LastIndexOf('/') - sMaturityDate.IndexOf('/') - 1);
                                    string sDay = sMaturityDate.Substring(sMaturityDate.LastIndexOf('/') + 1, sMaturityDate.Length - sMaturityDate.LastIndexOf('/') - 1);
                                    DateTime dt = new DateTime(Convert.ToInt32(sYear), Convert.ToInt32(sMonth), Convert.ToInt32(sDay), 11, 0, 0);
                                    lstFwdDt.Add(dt);
                                }
                            }
                            else  //期貨
                            {
                                string sCont = string.Empty;
                                if (dr["SettlementMonth"] != DBNull.Value && !String.IsNullOrEmpty(dr["SettlementMonth"].ToString()))
                                {
                                    sCont = dr["SettlementMonth"].ToString().Trim();
                                    PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Future);
                                    PP.QCommodity.Base.CommodityKind = CommodityKind.Future;    //目前沒有'遠期合約'選項
                                    PP.QCommodity.Base.SettleMentMonth = sCont;
                                }
                            }
                        }
                        else if (sComdtyKind.EndsWith("Stock"))
                        {
                            PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Stock);
                            PP.QCommodity.Base.CommodityKind = CommodityKind.Stock;
                        }
                        else if (sComdtyKind.Equals("Forward"))
                        {
                            string sMaturityDate = string.Empty;                                
                            if (dr["MaturityDate"] != DBNull.Value && !String.IsNullOrEmpty(dr["MaturityDate"].ToString()))
                            {
                                lstFwdSymbol.Add(sInnerCode);
                                sMaturityDate = dr["MaturityDate"].ToString().Trim();
                                sMaturityDate = sMaturityDate.Substring(0, sMaturityDate.IndexOf(' '));
                                string sYear = sMaturityDate.Substring(0, 4);
                                string sMonth = sMaturityDate.Substring(sMaturityDate.IndexOf('/') + 1, sMaturityDate.LastIndexOf('/') - sMaturityDate.IndexOf('/') - 1);
                                string sDay = sMaturityDate.Substring(sMaturityDate.LastIndexOf('/') + 1, sMaturityDate.Length - sMaturityDate.LastIndexOf('/') - 1);
                                DateTime dt = new DateTime(Convert.ToInt32(sYear), Convert.ToInt32(sMonth), Convert.ToInt32(sDay), 11, 0, 0);
                                lstFwdDt.Add(dt);
                            }
                        }

                        refdata = GetBloombergRefDataReq(sInnerCode, new string[] { "PX_LAST", "PX_CLOSE", "PX_YEST_CLOSE", "PX_CLOSE_1D", "DAILY_LIMIT_UP", "DAILY_LIMIT_DOWN" });

                        if (refdata.HasElement("PX_LAST") && !refdata.GetElement("PX_LAST").IsNull)
                        { sYstCls = refdata.GetElementAsString("PX_LAST"); }
                        else if (refdata.HasElement("PX_CLOSE") && !refdata.GetElement("PX_CLOSE").IsNull)
                        { sYstCls = refdata.GetElementAsString("PX_CLOSE"); }
                        else if (refdata.HasElement("PX_YEST_CLOSE") && !refdata.GetElement("PX_YEST_CLOSE").IsNull)
                        { sYstCls = refdata.GetElementAsString("PX_YEST_CLOSE"); }
                        else if (refdata.HasElement("PX_CLOSE_1D") && !refdata.GetElement("PX_CLOSE_1D").IsNull)
                        { sYstCls = refdata.GetElementAsString("PX_CLOSE_1D"); }
                        dYstCls = Convert.ToDouble(sYstCls);
                        dicYstCls[sInnerCode] = sYstCls;                        

                        if (PP != null)
                        {
                            PP.QCommodity.Base.CommodityCode = "";
                            PP.QCommodity.Base.CommodityNm = dr["CommodityNm"].ToString().Trim();
                            PP.QCommodity.Base.Market = Market.None;
                            PP.QCommodity.Base.DecimalLocate = dr["DecimalLocate"] != DBNull.Value ? Convert.ToDouble(dr["DecimalLocate"].ToString()) : 1.0;
                            PP.QCommodity.Base.Unit = dr["Unit"] != DBNull.Value ? Convert.ToInt32(dr["Unit"].ToString()) : 1;

                            if (refdata.HasElement("DAILY_LIMIT_UP") && !refdata.GetElement("DAILY_LIMIT_UP").IsNull)
                            {
                                if (Convert.ToDouble(refdata.GetElementAsString("DAILY_LIMIT_UP")) > Convert.ToDouble(sYstCls))
                                { sUpLmt = refdata.GetElementAsString("DAILY_LIMIT_UP"); }
                            }

                            if (refdata.HasElement("DAILY_LIMIT_DOWN") && !refdata.GetElement("DAILY_LIMIT_DOWN").IsNull)
                            {
                                if (Convert.ToDouble(refdata.GetElementAsString("DAILY_LIMIT_DOWN")) < Convert.ToDouble(sYstCls))
                                { sLoLmt = refdata.GetElementAsString("DAILY_LIMIT_DOWN"); }
                            }

                            PP.QCommodity.Base.ReferencePrice = Double.Parse(sYstCls);
                            PP.QCommodity.Base.RiseLimitPrice = Double.Parse(sUpLmt);
                            PP.QCommodity.Base.FallLimitPrice = Double.Parse(sLoLmt);

                            PP.QCommodity.HighLow.DayLowPrice = Double.MaxValue;
                            PP.QCommodity.HighLow.DayHighPrice = Double.MinValue;

                            PP.QCommodity.Base.InformationTime = DateTime.Now.ToString("HHmmssff");
                            PP.QCommodity.Base.InformationSeq = DateTime.Now.ToString("HHmmssff");

                            PP.QCommodity.Base.TradeDate = DateTime.Today;

                            DeriLib.Util.ExecSqlCmd("EXEC spClearTmpTableForCommodity '" + sComdtyId + "'", m_QuoteSetting.DBConnectString);

                            _dicInnerCode[++iCId] = sInnerCode;
                            _dicComdtyId[sInnerCode] = sComdtyId;

                            string sBLPProd = sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2);
                            if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd] && _dicExch.ContainsKey(sBLPProd))
                            {
                                string sSql0 = "SELECT * FROM [OrcLiquidator].[dbo].[GDKCommodity] WHERE CommodityId = '" + _dicComdtyId[sInnerCode] + "'";
                                string sSql1 = "UPDATE [OrcLiquidator].[dbo].[GDKCommodity] SET DataSource='Bloomberg-" + sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2) + "',MDate='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "' WHERE CommodityId = '" + sComdtyId + "'";
                                string sSql2 = "INSERT INTO [OrcLiquidator].[dbo].[GDKCommodity] (Exchange,CommodityId,CommodityKind,DataSource) VALUES('" + _dicExch[sBLPProd] + "','" + sComdtyId + "','Future','Bloomberg-" + sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2) + "')";
                                sql = "IF EXISTS (" + sSql0 + ") " + sSql1 + " ELSE " + sSql2;
                                DeriLib.Util.ExecSqlCmd(sql, m_QuoteSetting.DBConnectString);
                            }

                            if (_dicTsQuote.ContainsKey(sBLPProd) && _dicTsQuote[sBLPProd])
                            { DoSendWrite(PP.QCommodity.Base); }
                        }
                        else
                        {
                            dYstCls = Math.Round((lstFwdLstPrc[0] + dYstCls / 10000.0) * 10000.0) / 10000.0;
                            lstFwdLstPrc.Add(dYstCls);
                            lstFwdBid.Add(dYstCls);
                            lstFwdAsk.Add(dYstCls);
                            _dicFwdInd[sInnerCode] = lstFwdLstPrc.Count - 1;

                            _dicInnerCode[++iCId] = sInnerCode;
                        }
                    }
                    catch (Exception ex)
                    { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                }

                //============================================================

                _saFwdSymbol = lstFwdSymbol.ToArray();
                _dtaFwdDt = lstFwdDt.ToArray();
                _daFwdBid = lstFwdBid.ToArray();
                _daFwdAsk = lstFwdAsk.ToArray();
                _daFwdLstPrc = lstFwdLstPrc.ToArray();

                List<string> lstFutSymbol = new List<string>();
                lstFutSymbol.Add("RHA1 Curncy");
                lstFutSymbol.Add("RHA2 Curncy");
                lstFutSymbol.Add("RHA3 Curncy");
                lstFutSymbol.Add("RHA4 Curncy");
                lstFutSymbol.Add("RHA5 Curncy");
                for (int i = 0; i < lstFutSymbol.Count; i++)
                {
                    sInnerCode = string.Empty;
                    sComdtyId = string.Empty;
                    string sCont = string.Empty;
                    
                    sYstCls = "0";
                    dYstCls = 0;
                    sUpLmt = "1000000";
                    sLoLmt = "-1000000";

                    try
                    {
                        string sFutSymbol = lstFutSymbol[i];
                        refdata = GetBloombergRefDataReq(sFutSymbol, new string[] { "LAST_TRADEABLE_DT" });
                        
                        string sLstTrdDt = string.Empty;
                        DateTime dt;

                        //結束交易日期
                        if (refdata.HasElement("LAST_TRADEABLE_DT") && !refdata.GetElement("LAST_TRADEABLE_DT").IsNull)
                        {                        
                            sLstTrdDt = refdata.GetElementAsString("LAST_TRADEABLE_DT");
                            string sDay = sLstTrdDt.Substring(sLstTrdDt.LastIndexOf('-') + 1, sLstTrdDt.Length - sLstTrdDt.LastIndexOf('-') - 1);
                            string sMonth = sLstTrdDt.Substring(sLstTrdDt.IndexOf('-') + 1, sLstTrdDt.LastIndexOf('-') - sLstTrdDt.IndexOf('-') - 1);
                            string sYear = sLstTrdDt.Substring(0, sLstTrdDt.IndexOf('-'));
                            dt = new DateTime(Convert.ToInt32(sYear), Convert.ToInt32(sMonth), Convert.ToInt32(sDay), 11, 0, 0);
                            sCont = sYear + sMonth;
                            sInnerCode = "CNH" + dicIntlMonth[sMonth] + sYear.Substring(3, 1) + " Curncy";
                            sComdtyId = "CNH" + dicMonth[sMonth] + sYear.Substring(3, 1);
                            _dicLstTrdDt[sInnerCode] = dt;
                        
                            PCommodity PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Future);
                            PP.QCommodity.Base.CommodityKind = CommodityKind.Future;    //暫訂為'虛擬期貨'
                            PP.QCommodity.Base.SettleMentMonth = sCont;
                            
                            PP.QCommodity.Base.CommodityCode = "";
                            PP.QCommodity.Base.CommodityNm = "CNH虛擬期貨";
                            PP.QCommodity.Base.Market = Market.None;
                            PP.QCommodity.Base.DecimalLocate = 1.0;
                            PP.QCommodity.Base.Unit = 1;

                            for (int j = 0; j < _dtaFwdDt.Length - 1; j++)
                            {
                                if (_dtaFwdDt[j] < dt && dt <= _dtaFwdDt[j + 1])
                                {
                                    TimeSpan ts = new TimeSpan(dt.Subtract(_dtaFwdDt[j]).Ticks);
                                    TimeSpan ts2 = new TimeSpan(_dtaFwdDt[j + 1].Subtract(_dtaFwdDt[j]).Ticks);
                                    dYstCls = _daFwdLstPrc[j] + (_daFwdLstPrc[j + 1] - _daFwdLstPrc[j]) / ts2.TotalDays * ts.TotalDays;
                                    sYstCls = Convert.ToString(dYstCls);
                                    
                                    string sLeftFwdSymbol = _saFwdSymbol[j];
                                    string sRightFwdSymbol = _saFwdSymbol[j + 1];
                                    string sRelFut = string.Empty;

                                    if (_dicRelFut.ContainsKey(sLeftFwdSymbol))
                                    { 
                                        sRelFut = _dicRelFut[sLeftFwdSymbol];
                                        sRelFut += "," + sInnerCode;
                                    }
                                    else
                                    {
                                        sRelFut = sInnerCode; 
                                    }
                                    _dicRelFut[sLeftFwdSymbol] = sRelFut;

                                    if (_dicRelFut.ContainsKey(sRightFwdSymbol))
                                    {
                                        sRelFut = _dicRelFut[sRightFwdSymbol];
                                        sRelFut += "," + sInnerCode;
                                    }
                                    else
                                    {
                                        sRelFut = sInnerCode; 
                                    }
                                    _dicRelFut[sRightFwdSymbol] = sRelFut;

                                    break;
                                }
                            }

                            PP.QCommodity.Base.ReferencePrice = Double.Parse(sYstCls);
                            PP.QCommodity.Base.RiseLimitPrice = Double.Parse(sUpLmt);
                            PP.QCommodity.Base.FallLimitPrice = Double.Parse(sLoLmt);

                            PP.QCommodity.HighLow.DayLowPrice = Double.MaxValue;
                            PP.QCommodity.HighLow.DayHighPrice = Double.MinValue;

                            PP.QCommodity.Base.InformationTime = DateTime.Now.ToString("HHmmssff");
                            PP.QCommodity.Base.InformationSeq = DateTime.Now.ToString("HHmmssff");

                            PP.QCommodity.Base.TradeDate = DateTime.Today;

                            DeriLib.Util.ExecSqlCmd("EXEC spClearTmpTableForCommodity '" + sComdtyId + "'", m_QuoteSetting.DBConnectString);

                            _dicInnerCode[++iCId] = sInnerCode;
                            _dicComdtyId[sInnerCode] = sComdtyId;

                            string sBLPProd = sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2);
                            if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd] && _dicExch.ContainsKey(sBLPProd))
                            {
                                string sSql0 = "SELECT * FROM [OrcLiquidator].[dbo].[GDKCommodity] WHERE CommodityId = '" + _dicComdtyId[sInnerCode] + "'";
                                string sSql1 = "UPDATE [OrcLiquidator].[dbo].[GDKCommodity] SET DataSource='Bloomberg-CNH',MDate='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "' WHERE CommodityId = '" + sComdtyId + "'";
                                string sSql2 = "INSERT INTO [OrcLiquidator].[dbo].[GDKCommodity] (Exchange,CommodityId,CommodityKind,DataSource) VALUES('" + _dicExch[sBLPProd] + "','" + sComdtyId + "','Future','Bloomberg-CNH')";

                                sql = "IF EXISTS (" + sSql0 + ") " + sSql1 + " ELSE " + sSql2;
                                DeriLib.Util.ExecSqlCmd(sql, m_QuoteSetting.DBConnectString);

                                sql = "UPDATE [TsQuote].[dbo].[Commodity] SET MaturityDate='" + _dicLstTrdDt[sInnerCode].ToString("yyyy-MM-dd HH:mm:ss") + "', UnderlyingId='CNH.FX', CurrencyId='CNH.FX' WHERE CommodityId='" + sComdtyId + "'";
                                DeriLib.Util.ExecSqlCmd(sql, m_QuoteSetting.DBConnectString); 
                            }

                            if (_dicTsQuote.ContainsKey(sBLPProd) && _dicTsQuote[sBLPProd])
                            { DoSendWrite(PP.QCommodity.Base); }
                        }
                    }
                    catch (Exception ex)
                    { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                }

                #endregion
            }
            catch (Exception ex)
            { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
        }

        private SessionOptions _sessOpt = null;
        private Session _sess = null;
        private bool _bStartFlag = false;
        private bool _bOpenFlag = false;
        private void ConnectBLP()
        {
            try
            {
                if (_sess != null)
                {
                    _sess.Stop();
                    _bStartFlag = false;
                    _bOpenFlag = false;
                    _sess = null;
                }

                if (_sess == null)
                {
                    _sessOpt = new SessionOptions();
                    _sessOpt.ServerHost = RemotIp;
                    _sessOpt.ServerPort = RemotePort;//Bloomberg指定

                    _sess = new Session(_sessOpt);

                    _bStartFlag = _sess.Start();
                    if (!_bStartFlag)
                    {
                        Console.WriteLine("[BLP回報]:Failed to start session");
                        return;
                    }

                    _bOpenFlag = _sess.OpenService("//blp/mktdata");
                    if (!_bOpenFlag)
                    {
                        Console.WriteLine("[BLP回報]:Failed to open service");
                        return;
                    }                    
                }                
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][ConnectBLP_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void SubscribeBLP()
        {
            try
            {
                List<Subscription> lstSubscr = new List<Subscription>();

                if (_bStartFlag && _bOpenFlag)
                {
                    if (_dicInnerCode.Keys.Count > 0)
                    {
                        long[] laKeys = new long[_dicInnerCode.Keys.Count];
                        _dicInnerCode.Keys.CopyTo(laKeys, 0);

                        string sFields = "TIME,LAST_PRICE,SIZE_LAST_TRADE,VOLUME,"; //1~4
                        sFields += "BID,BEST_BID2,BEST_BID3,BEST_BID4,BEST_BID5,ASK,BEST_ASK2,BEST_ASK3,BEST_ASK4,BEST_ASK5,";  //5~9 10~14
                        sFields += "BID_SIZE,BEST_BID2_SZ,BEST_BID3_SZ,BEST_BID4_SZ,BEST_BID5_SZ,ASK_SIZE,BEST_ASK2_SZ,BEST_ASK3_SZ,BEST_ASK4_SZ,BEST_ASK5_SZ"; //15~24

                        for (int i = 0; i < laKeys.Length; i++)
                        {
                            long lCId = laKeys[i];
                            string sInnerCode = _dicInnerCode[lCId];
                            lstSubscr.Add(new Subscription(sInnerCode, sFields, new CorrelationID(lCId)));
                        }

                        //USE MULTI-SESSION??
                        _sess.Subscribe(lstSubscr);
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][SubscribeBLP_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void DealWithQuote(string sBlpData)
        {            
            string[] saBlpData = sBlpData.Split(',');
            try
            {
                if (_dicComdtyId.ContainsKey(saBlpData[0]))
                {
                    string sInnerCode = saBlpData[0];
                    string sComdtyId = _dicComdtyId[sInnerCode];
                    string sBLPProd = sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2);
                    PCommodity mPCommodity = m_PCommodityList.Get(sComdtyId);
                    if (mPCommodity == null) { return; }

                    string sNow = saBlpData[1];
                    string sSeq = DateTime.Now.ToString("HHmmssff");

                    bool bSendFlag = false;
                    if (!String.IsNullOrEmpty(saBlpData[2])) { mPCommodity.QCommodity.Match.MatchPrice = Convert.ToDouble(saBlpData[2]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[3])) { mPCommodity.QCommodity.Match.MatchQty = Convert.ToInt32(saBlpData[3]); }
                    if (!String.IsNullOrEmpty(saBlpData[4])) { mPCommodity.QCommodity.Match.MatchTotalQty = Convert.ToInt32(saBlpData[4]); bSendFlag = true; }
                    if (bSendFlag)
                    {
                        mPCommodity.QCommodity.Match.InformationTime = sNow;
                        mPCommodity.QCommodity.Match.InformationSeq = sSeq;
                        mPCommodity.QCommodity.Match.MatchTime = sNow;
                        if (mPCommodity.QCommodity.Match.MatchPrice != 0.0) { mPCommodity.QCommodity.Match.MatchPrices = mPCommodity.QCommodity.Match.MatchPrice; }
                        if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                        { DoSendWrite(mPCommodity.QCommodity.Match); }
                    }

                    bSendFlag = false;
                    if (!String.IsNullOrEmpty(saBlpData[5])) { mPCommodity.QCommodity.Best5.BuyPriceBest1 = Convert.ToDouble(saBlpData[5]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[6])) { mPCommodity.QCommodity.Best5.BuyQtyBest1 = Convert.ToInt32(saBlpData[6]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[7])) { mPCommodity.QCommodity.Best5.BuyPriceBest2 = Convert.ToDouble(saBlpData[7]); }
                    if (!String.IsNullOrEmpty(saBlpData[8])) { mPCommodity.QCommodity.Best5.BuyQtyBest2 = Convert.ToInt32(saBlpData[8]); }
                    if (!String.IsNullOrEmpty(saBlpData[9])) { mPCommodity.QCommodity.Best5.BuyPriceBest3 = Convert.ToDouble(saBlpData[9]); }
                    if (!String.IsNullOrEmpty(saBlpData[10])) { mPCommodity.QCommodity.Best5.BuyQtyBest3 = Convert.ToInt32(saBlpData[10]); }
                    if (!String.IsNullOrEmpty(saBlpData[11])) { mPCommodity.QCommodity.Best5.BuyPriceBest4 = Convert.ToDouble(saBlpData[11]); }
                    if (!String.IsNullOrEmpty(saBlpData[12])) { mPCommodity.QCommodity.Best5.BuyQtyBest4 = Convert.ToInt32(saBlpData[12]); }
                    if (!String.IsNullOrEmpty(saBlpData[13])) { mPCommodity.QCommodity.Best5.BuyPriceBest5 = Convert.ToDouble(saBlpData[13]); }
                    if (!String.IsNullOrEmpty(saBlpData[14])) { mPCommodity.QCommodity.Best5.BuyQtyBest5 = Convert.ToInt32(saBlpData[14]); }
                    if (!String.IsNullOrEmpty(saBlpData[15])) { mPCommodity.QCommodity.Best5.SellPriceBest1 = Convert.ToDouble(saBlpData[15]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[16])) { mPCommodity.QCommodity.Best5.SellQtyBest1 = Convert.ToInt32(saBlpData[16]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[17])) { mPCommodity.QCommodity.Best5.SellPriceBest2 = Convert.ToDouble(saBlpData[17]); }
                    if (!String.IsNullOrEmpty(saBlpData[18])) { mPCommodity.QCommodity.Best5.SellQtyBest2 = Convert.ToInt32(saBlpData[18]); }
                    if (!String.IsNullOrEmpty(saBlpData[19])) { mPCommodity.QCommodity.Best5.SellPriceBest3 = Convert.ToDouble(saBlpData[19]); }
                    if (!String.IsNullOrEmpty(saBlpData[20])) { mPCommodity.QCommodity.Best5.SellQtyBest3 = Convert.ToInt32(saBlpData[20]); }
                    if (!String.IsNullOrEmpty(saBlpData[21])) { mPCommodity.QCommodity.Best5.SellPriceBest4 = Convert.ToDouble(saBlpData[21]); }
                    if (!String.IsNullOrEmpty(saBlpData[22])) { mPCommodity.QCommodity.Best5.SellQtyBest4 = Convert.ToInt32(saBlpData[22]); }
                    if (!String.IsNullOrEmpty(saBlpData[23])) { mPCommodity.QCommodity.Best5.SellPriceBest5 = Convert.ToDouble(saBlpData[23]); }
                    if (!String.IsNullOrEmpty(saBlpData[24])) { mPCommodity.QCommodity.Best5.SellQtyBest5 = Convert.ToInt32(saBlpData[24]); }
                    if (bSendFlag)
                    {
                        mPCommodity.QCommodity.Best5.InformationTime = sNow;
                        mPCommodity.QCommodity.Best5.InformationSeq = sSeq;
                        mPCommodity.QCommodity.Best5.BuyPriceBest1s = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        if (mPCommodity.QCommodity.Best5.BuyPriceBest1s == 0.0 && mPCommodity.QCommodity.Match != null) { mPCommodity.QCommodity.Best5.BuyPriceBest1s = mPCommodity.QCommodity.Match.MatchPrice; }
                        mPCommodity.QCommodity.Best5.SellPriceBest1s = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        if (mPCommodity.QCommodity.Best5.SellPriceBest1s == 0.0 && mPCommodity.QCommodity.Match != null) { mPCommodity.QCommodity.Best5.SellPriceBest1s = mPCommodity.QCommodity.Match.MatchPrice; }
                        if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                        { DoSendWrite(mPCommodity.QCommodity.Best5); }
                    }

                    bSendFlag = false;
                    if (!String.IsNullOrEmpty(saBlpData[25]) && mPCommodity.QCommodity.HighLow.DayHighPrice < Convert.ToDouble(saBlpData[25])) { mPCommodity.QCommodity.HighLow.DayHighPrice = Convert.ToDouble(saBlpData[25]); bSendFlag = true; }
                    if (!String.IsNullOrEmpty(saBlpData[26]) && mPCommodity.QCommodity.HighLow.DayLowPrice > Convert.ToDouble(saBlpData[26])) { mPCommodity.QCommodity.HighLow.DayLowPrice = Convert.ToDouble(saBlpData[26]); bSendFlag = true; }
                    if (bSendFlag)
                    {
                        mPCommodity.QCommodity.HighLow.InformationTime = sNow;
                        mPCommodity.QCommodity.HighLow.InformationSeq = sSeq;
                        mPCommodity.QCommodity.HighLow.ShowTime = sNow;
                        if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                        { DoSendWrite(mPCommodity.QCommodity.HighLow); }
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][DealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                { obj2 = ((ICopy)obj).Copy(); }

                m_WriteDBPool.Enqueue(obj2);
            }
        }
    }
}
