﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using TIBCO.Rendezvous;

namespace PushToOrc
{
    public class PushToOrcFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "0830";
        public int TibcoService = 9011;
        public string TibcoNetwork = ";239.16.1.2";
        public string TibcoDaemon = "10.10.1.29:7500";
        public string TibcoSubject = "ExecutionReport";
        public string SubSql = "";

        public PushToOrcFactorySetting()
        {
        }
        public PushToOrcFactorySetting(string Service)
            : base(Service)
        {
        }
        public PushToOrcFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    public class PushToOrcSource : QuoteSource
    {
        private Thread RoutineThread;
        private string DBConnectString = "";
        private TimeSpan RecoverTime;
        private bool RecoverFlag = false;
        private int TibcoService;
        private string TibcoNetwork = "";
        private string TibcoDaemon = "";
        private string TibcoSubject = "";
        private string SubSql = "";
        private Dictionary<string, GDKCommodity> PushCommoditys = new Dictionary<string, GDKCommodity>();
        private Transport transport = null;
        private object LockObj = new object();
        
        public PushToOrcSource(PushToOrcFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);
            TibcoService = QuoteSetting.TibcoService;
            TibcoNetwork = QuoteSetting.TibcoNetwork;
            TibcoDaemon = QuoteSetting.TibcoDaemon;
            TibcoSubject = QuoteSetting.TibcoSubject;
            SubSql = QuoteSetting.SubSql;
        }
        public override bool Start()
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            base.Start();

            ConnectTibco();
            LoadData();

            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "]Start");

            return true;
        }
        private void ConnectTibco()
        {
            try
            {
                /*try
                {
                    TIBCO.Rendezvous.Environment.Close();
                }
                catch
                {
                }*/

                if (!base.IsTibcoOpen)
                {
                    base.IsTibcoOpen = true;
                    TIBCO.Rendezvous.Environment.Open();
                }

                transport = new NetTransport(TibcoService.ToString(), TibcoNetwork, TibcoDaemon);
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ConnectTibco_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void LoadData()
        {
            try
            {
                string sql = SubSql;
                DataView dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);

                lock (LockObj)
                {
                    foreach (DataRowView dr in dv)
                    {
                        try
                        {                            
                            //PCommodity PP = m_PCommodityList.Get(dr["CommodityId"].ToString());
                            PCommodity PP = m_PCommodityList.Set("", dr["CommodityId"].ToString(), Market.None, (CommodityKind)Enum.Parse(typeof(CommodityKind), dr["CommodityKind"].ToString()));

                            if (PP == null)
                            {
                                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error][" + dr["CommodityId"].ToString() + "]PCommodity is null");
                                continue;
                            }

                            if (!PushCommoditys.ContainsKey(dr["CommodityId"].ToString())) { PushCommoditys.Add(dr["CommodityId"].ToString(), new GDKCommodity(dr["Exchange"].ToString(), PP)); }

                            PP.QuoteUpdateEvent += new PCommodity.QuoteUpdateHandler(PP_QuoteUpdateEvent);
                            m_PacketNum++;
                            m_PackagePool.Enqueue(PP.QCommodity);
                        }
                        catch (Exception ee)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ee.Message + "][" + ee.StackTrace + "][" + dr["CommodityId"].ToString() + "]");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void PP_QuoteUpdateEvent(object sender, object obj)
        {
            if (m_PacketNum < int.MaxValue) { m_PacketNum++; }

            m_PackagePool.Enqueue(obj);
        }

        public override bool Close()
        {
            try
            {
                foreach (GDKCommodity G in PushCommoditys.Values)
                    G.PCommodity.QuoteUpdateEvent -= new PCommodity.QuoteUpdateHandler(PP_QuoteUpdateEvent);

                PushCommoditys.Clear();
            
                m_PacketNum = 0;

                /*try
                {
                    TIBCO.Rendezvous.Environment.Close();
                }
                catch
                {
                }*/

                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "]Close");

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            object obj = (object)m_PackagePool.Dequeue();
                            DealWithQuote(obj);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ReStartWork(Object stateInfo)
        {
            try
            {
                foreach (GDKCommodity G in PushCommoditys.Values)
                    G.PCommodity.QuoteUpdateEvent -= new PCommodity.QuoteUpdateHandler(PP_QuoteUpdateEvent);

                PushCommoditys.Clear();
                
                m_PacketNum = 0;

                ConnectTibco();
                LoadData();

                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "]ReStart");
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void DealWithQuote(object obj)
        {
            try
            {
                if (obj.GetType() == typeof(DeriLib.Quote.QCommodity))
                {
                    DeriLib.Quote.QCommodity QCommodity = (DeriLib.Quote.QCommodity)obj;

                    GDKCommodity gdkcommodity = PushCommoditys[QCommodity.Base.CommodityId];

                    DeriLib.Quote.QMatch QMatch = QCommodity.Match;

                    TIBCO.Rendezvous.Message message = new TIBCO.Rendezvous.Message();
                    message.SendSubject = TibcoSubject;

                    message.AddField("Exchange", gdkcommodity.Exchange, 0);
                    message.AddField("MSGTYPE", "ST.OMS.SERVER.Price.XQ", 0);
                    message.AddField("Symbol", CommodityMap(QMatch.CommodityId), 0);
                    message.AddField("ModifyTime", DateTime.Now.ToString("yyyyMMdd_HHmmssfff"), 0);
                    message.AddField("Price_UpdateField", 4, 0);

                    message.AddField("Deal", QMatch.MatchPrice, 0);
                    message.AddField("LotSize", QMatch.MatchQty, 0);
                    message.AddField("TotalDealLots", QMatch.MatchTotalQty, 0);

                    transport.Send(message);

                    DeriLib.Quote.QBest5 QBest5 = QCommodity.Best5;

                    message = new TIBCO.Rendezvous.Message();
                    message.SendSubject = TibcoSubject;

                    message.AddField("Exchange", gdkcommodity.Exchange, 0);
                    message.AddField("MSGTYPE", "ST.OMS.SERVER.Price.XQ", 0);
                    message.AddField("Symbol", CommodityMap(QBest5.CommodityId), 0);
                    message.AddField("ModifyTime", DateTime.Now.ToString("yyyyMMdd_HHmmssfff"), 0);
                    message.AddField("Price_UpdateField", 8, 0);

                    message.AddField("BestOrderPrice_Bid_0", QBest5.BuyPriceBest1, 0);
                    message.AddField("BestOrderLots_Bid_0", QBest5.BuyQtyBest1, 0);
                    message.AddField("BestOrderPrice_Ask_0", QBest5.SellPriceBest1, 0);
                    message.AddField("BestOrderLots_Ask_0", QBest5.SellQtyBest1, 0);
                    message.AddField("BestOrderPrice_Bid_1", QBest5.BuyPriceBest2, 0);
                    message.AddField("BestOrderLots_Bid_1", QBest5.BuyQtyBest2, 0);
                    message.AddField("BestOrderPrice_Ask_1", QBest5.SellPriceBest2, 0);
                    message.AddField("BestOrderLots_Ask_1", QBest5.SellQtyBest2, 0);
                    message.AddField("BestOrderPrice_Bid_2", QBest5.BuyPriceBest3, 0);
                    message.AddField("BestOrderLots_Bid_2", QBest5.BuyQtyBest3, 0);
                    message.AddField("BestOrderPrice_Ask_2", QBest5.SellPriceBest3, 0);
                    message.AddField("BestOrderLots_Ask_2", QBest5.SellQtyBest3, 0);
                    message.AddField("BestOrderPrice_Bid_3", QBest5.BuyPriceBest4, 0);
                    message.AddField("BestOrderLots_Bid_3", QBest5.BuyQtyBest4, 0);
                    message.AddField("BestOrderPrice_Ask_3", QBest5.SellPriceBest4, 0);
                    message.AddField("BestOrderLots_Ask_3", QBest5.SellQtyBest4, 0);
                    message.AddField("BestOrderPrice_Bid_4", QBest5.BuyPriceBest5, 0);
                    message.AddField("BestOrderLots_Bid_4", QBest5.BuyQtyBest5, 0);
                    message.AddField("BestOrderPrice_Ask_4", QBest5.SellPriceBest5, 0);
                    message.AddField("BestOrderLots_Ask_4", QBest5.SellQtyBest5, 0);

                    transport.Send(message);
                }
                else if (obj.GetType() == typeof(DeriLib.Quote.QBase))
                {
                    DeriLib.Quote.QBase QBase = (DeriLib.Quote.QBase)obj;

                    GDKCommodity gdkcommodity = PushCommoditys[QBase.CommodityId];

                    TIBCO.Rendezvous.Message message = new TIBCO.Rendezvous.Message();
                    message.SendSubject = TibcoSubject;

                    message.AddField("Exchange", gdkcommodity.Exchange, 0);
                    message.AddField("MSGTYPE", "ST.OMS.SERVER.Price.XQ", 0);
                    message.AddField("Symbol", CommodityMap(QBase.CommodityId), 0);
                    message.AddField("ModifyTime", DateTime.Now.ToString("yyyyMMdd_HHmmssfff"), 0);
                    message.AddField("Price_UpdateField", 2, 0);

                    message.AddField("Reference", QBase.ReferencePrice, 0);
                    message.AddField("UpLimit", QBase.RiseLimitPrice, 0);
                    message.AddField("DownLimit", QBase.FallLimitPrice, 0);

                    transport.Send(message);
                }
                else if (obj.GetType() == typeof(DeriLib.Quote.QMatch))
                {
                    DeriLib.Quote.QMatch QMatch = (DeriLib.Quote.QMatch)obj;

                    GDKCommodity gdkcommodity = PushCommoditys[QMatch.CommodityId];

                    TIBCO.Rendezvous.Message message = new TIBCO.Rendezvous.Message();
                    message.SendSubject = TibcoSubject;

                    message.AddField("Exchange", gdkcommodity.Exchange, 0);
                    message.AddField("MSGTYPE", "ST.OMS.SERVER.Price.XQ", 0);
                    message.AddField("Symbol", CommodityMap(QMatch.CommodityId), 0);
                    message.AddField("ModifyTime", DateTime.Now.ToString("yyyyMMdd_HHmmssfff"), 0);
                    message.AddField("Price_UpdateField", 4, 0);

                    message.AddField("Deal", QMatch.MatchPrice, 0);
                    message.AddField("LotSize", QMatch.MatchQty, 0);
                    message.AddField("TotalDealLots", QMatch.MatchTotalQty, 0);

                    transport.Send(message);
                }
                else if (obj.GetType() == typeof(DeriLib.Quote.QHighLow))
                {
                    DeriLib.Quote.QHighLow QHighLow = (DeriLib.Quote.QHighLow)obj;

                    GDKCommodity gdkcommodity = PushCommoditys[QHighLow.CommodityId];

                    TIBCO.Rendezvous.Message message = new TIBCO.Rendezvous.Message();
                    message.SendSubject = TibcoSubject;

                    message.AddField("Exchange", gdkcommodity.Exchange, 0);
                    message.AddField("MSGTYPE", "ST.OMS.SERVER.Price.XQ", 0);
                    message.AddField("Symbol", CommodityMap(QHighLow.CommodityId), 0);
                    message.AddField("ModifyTime", DateTime.Now.ToString("yyyyMMdd_HHmmssfff"), 0);
                    message.AddField("Price_UpdateField", 16, 0);

                    message.AddField("High", QHighLow.DayHighPrice, 0);
                    message.AddField("Low", QHighLow.DayLowPrice, 0);

                    transport.Send(message);
                }
                else if (obj.GetType() == typeof(DeriLib.Quote.QBest5))
                {
                    DeriLib.Quote.QBest5 QBest5 = (DeriLib.Quote.QBest5)obj;

                    GDKCommodity gdkcommodity = PushCommoditys[QBest5.CommodityId];

                    TIBCO.Rendezvous.Message message = new TIBCO.Rendezvous.Message();
                    message.SendSubject = TibcoSubject;

                    message.AddField("Exchange", gdkcommodity.Exchange, 0);
                    message.AddField("MSGTYPE", "ST.OMS.SERVER.Price.XQ", 0);
                    message.AddField("Symbol", CommodityMap(QBest5.CommodityId), 0);
                    message.AddField("ModifyTime", DateTime.Now.ToString("yyyyMMdd_HHmmssfff"), 0);
                    message.AddField("Price_UpdateField", 8, 0);

                    message.AddField("BestOrderPrice_Bid_0", QBest5.BuyPriceBest1, 0);
                    message.AddField("BestOrderLots_Bid_0", QBest5.BuyQtyBest1, 0);
                    message.AddField("BestOrderPrice_Ask_0", QBest5.SellPriceBest1, 0);
                    message.AddField("BestOrderLots_Ask_0", QBest5.SellQtyBest1, 0);
                    message.AddField("BestOrderPrice_Bid_1", QBest5.BuyPriceBest2, 0);
                    message.AddField("BestOrderLots_Bid_1", QBest5.BuyQtyBest2, 0);
                    message.AddField("BestOrderPrice_Ask_1", QBest5.SellPriceBest2, 0);
                    message.AddField("BestOrderLots_Ask_1", QBest5.SellQtyBest2, 0);
                    message.AddField("BestOrderPrice_Bid_2", QBest5.BuyPriceBest3, 0);
                    message.AddField("BestOrderLots_Bid_2", QBest5.BuyQtyBest3, 0);
                    message.AddField("BestOrderPrice_Ask_2", QBest5.SellPriceBest3, 0);
                    message.AddField("BestOrderLots_Ask_2", QBest5.SellQtyBest3, 0);
                    message.AddField("BestOrderPrice_Bid_3", QBest5.BuyPriceBest4, 0);
                    message.AddField("BestOrderLots_Bid_3", QBest5.BuyQtyBest4, 0);
                    message.AddField("BestOrderPrice_Ask_3", QBest5.SellPriceBest4, 0);
                    message.AddField("BestOrderLots_Ask_3", QBest5.SellQtyBest4, 0);
                    message.AddField("BestOrderPrice_Bid_4", QBest5.BuyPriceBest5, 0);
                    message.AddField("BestOrderLots_Bid_4", QBest5.BuyQtyBest5, 0);
                    message.AddField("BestOrderPrice_Ask_4", QBest5.SellPriceBest5, 0);
                    message.AddField("BestOrderLots_Ask_4", QBest5.SellQtyBest5, 0);

                    transport.Send(message);
                }                
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithQuote_Error][" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private string CommodityMap(string Commodityid)
        {
            string tmp = Commodityid;
            string h = "";
            string h2 = DateTime.Today.Year.ToString().Substring(2, 1);
            int m = DateTime.Today.Month;

            switch (tmp.Substring(tmp.Length-2,1))
            {
                case "A":
                    h = "F";
                    if (m > 1) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "B":
                    h = "G";
                    if (m > 2) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "C":
                    h = "H";
                    if (m > 3) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "D":
                    h = "J";
                    if (m > 4) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "E":
                    h = "K";
                    if (m > 5) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "F":
                    h = "M";
                    if (m > 6) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "G":
                    h = "N";
                    if (m > 7) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "H":
                    h = "Q";
                    if (m > 8) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "I":
                    h = "U";
                    if (m > 9) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "J":
                    h = "V";
                    if (m > 10) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "K":
                    h = "X";
                    if (m > 11) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                case "L":
                    h = "Z";
                    if (m > 12) { h2 = DateTime.Today.AddYears(1).Year.ToString().Substring(2, 1); }
                    break;
                default:
                    break;
            }

            tmp = tmp.Substring(0, tmp.Length - 2) + "-" + h + DateTime.Today.Year.ToString().Substring(2,1) + tmp.Substring(tmp.Length - 1, 1);
            //Console.WriteLine(Commodityid + " - " + tmp);
            return tmp;
        }
    }

    public class GDKCommodity
    {
        public string Exchange = "";
        public PCommodity PCommodity = null;

        public GDKCommodity(string Exchange, PCommodity PCommodity)
        {
            this.Exchange = Exchange;
            this.PCommodity = PCommodity;
        }
    }
}
