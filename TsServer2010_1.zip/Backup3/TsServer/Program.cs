﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;

namespace TSServer
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                string t = Application.ProductName;

                Process[] localAll = Process.GetProcessesByName(t);

                if (localAll.Length > 1)
                {
                    MessageBox.Show("TsServer已開啟,若要重新開啟,請先關閉已開啟之TsServer", "TsServer已開啟", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                    return;
                }

                /*Process ps = new Process();
                ps.StartInfo.FileName = Application.StartupPath + "\\FtpUpdateC.exe";
                ps.Start();
                ps.WaitForExit();*/
            }
            catch
            {
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmTSServer());
        }
    }
}
