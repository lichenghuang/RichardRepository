﻿namespace TSServer
{
    partial class frmTSServer
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTSServer));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolShow = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmMain = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmShow = new System.Windows.Forms.ToolStripMenuItem();
            this.lsOutPut = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reBootTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "TSServer";
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolShow,
            this.toolStripMenuItem5,
            this.tsmMain,
            this.toolStripMenuItem2,
            this.tsmShow});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(171, 98);
            // 
            // toolShow
            // 
            this.toolShow.Name = "toolShow";
            this.toolShow.Size = new System.Drawing.Size(170, 22);
            this.toolShow.Tag = "Show";
            this.toolShow.Text = "Show(&S)";
            this.toolShow.Click += new System.EventHandler(this.mnuClick);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(170, 22);
            this.toolStripMenuItem5.Tag = "ShowConnections";
            this.toolStripMenuItem5.Text = "ShowConnections(&C)";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.mnuClick);
            // 
            // tsmMain
            // 
            this.tsmMain.Name = "tsmMain";
            this.tsmMain.Size = new System.Drawing.Size(170, 22);
            this.tsmMain.Tag = "Main";
            this.tsmMain.Text = "Main(&M)";
            this.tsmMain.Click += new System.EventHandler(this.mnuClick);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(167, 6);
            // 
            // tsmShow
            // 
            this.tsmShow.Name = "tsmShow";
            this.tsmShow.Size = new System.Drawing.Size(170, 22);
            this.tsmShow.Tag = "Exit";
            this.tsmShow.Text = "Exit(&X)";
            this.tsmShow.Click += new System.EventHandler(this.mnuClick);
            // 
            // lsOutPut
            // 
            this.lsOutPut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsOutPut.FormattingEnabled = true;
            this.lsOutPut.HorizontalScrollbar = true;
            this.lsOutPut.ItemHeight = 12;
            this.lsOutPut.Location = new System.Drawing.Point(0, 24);
            this.lsOutPut.Name = "lsOutPut";
            this.lsOutPut.Size = new System.Drawing.Size(436, 256);
            this.lsOutPut.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionOToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(436, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionOToolStripMenuItem
            // 
            this.optionOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingTToolStripMenuItem,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem1,
            this.exitXToolStripMenuItem,
            this.reBootTestToolStripMenuItem});
            this.optionOToolStripMenuItem.Name = "optionOToolStripMenuItem";
            this.optionOToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.optionOToolStripMenuItem.Text = "Option(&O)";
            // 
            // settingTToolStripMenuItem
            // 
            this.settingTToolStripMenuItem.Name = "settingTToolStripMenuItem";
            this.settingTToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.settingTToolStripMenuItem.Tag = "Main";
            this.settingTToolStripMenuItem.Text = "Main(&M)";
            this.settingTToolStripMenuItem.Click += new System.EventHandler(this.mnuClick);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(170, 22);
            this.toolStripMenuItem3.Tag = "ShowConnections";
            this.toolStripMenuItem3.Text = "ShowConnections(&C)";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.mnuClick);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(170, 22);
            this.toolStripMenuItem4.Tag = "Minimize";
            this.toolStripMenuItem4.Text = "Minimize(&Z)";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.mnuClick);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(167, 6);
            // 
            // exitXToolStripMenuItem
            // 
            this.exitXToolStripMenuItem.Name = "exitXToolStripMenuItem";
            this.exitXToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.exitXToolStripMenuItem.Tag = "Exit";
            this.exitXToolStripMenuItem.Text = "Exit(&X)";
            this.exitXToolStripMenuItem.Click += new System.EventHandler(this.mnuClick);
            // 
            // reBootTestToolStripMenuItem
            // 
            this.reBootTestToolStripMenuItem.Name = "reBootTestToolStripMenuItem";
            this.reBootTestToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.reBootTestToolStripMenuItem.Text = "ReBootTest";
            this.reBootTestToolStripMenuItem.Click += new System.EventHandler(this.reBootTestToolStripMenuItem_Click);
            // 
            // frmTSServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 280);
            this.Controls.Add(this.lsOutPut);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmTSServer";
            this.Text = "TSServer";
            this.Load += new System.EventHandler(this.TSServer_Load);
            this.Activated += new System.EventHandler(this.TSServer_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TSServer_FormClosing);
            this.Resize += new System.EventHandler(this.TSServer_Resize);
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmMain;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tsmShow;
        private System.Windows.Forms.ListBox lsOutPut;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolShow;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem reBootTestToolStripMenuItem;
    }
}

