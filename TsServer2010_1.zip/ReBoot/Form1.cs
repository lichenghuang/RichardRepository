﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Text;

namespace ReBoot
{
    public partial class Form1 : Form
    {
        #region winInet.dll宣告
        private const short MAX_PATH = 260;
        private const short NO_ERROR = 0;
        private const short FILE_ATTRIBUTE_READONLY = 0x00000001;
        private const short FILE_ATTRIBUTE_HIDDEN = 0x00000002;
        private const short FILE_ATTRIBUTE_SYSTEM = 0x00000004;
        private const short FILE_ATTRIBUTE_DIRECTORY = 0x00000010;
        private const short FILE_ATTRIBUTE_ARCHIVE = 0x00000020;
        private const short FILE_ATTRIBUTE_NORMAL = 0x00000080;
        private const short FILE_ATTRIBUTE_TEMPORARY = 0x00000100;
        private const short FILE_ATTRIBUTE_COMPRESSED = 0x00000800;
        private const short FILE_ATTRIBUTE_OFFLINE = 0x00001000;

        private struct FILETIME
        {
            public int dwLowDateTime;
            public int dwHighDateTime;
        }

        private struct SYSTEMTIME //16 Bytes
        {
            public short wYear;
            public short wMonth;
            public short wDayOfWeek;
            public short wDay;
            public short wHour;
            public short wMinute;
            public short wSecond;
            public short wMilliseconds;
        }

        private struct WIN32_FIND_DATA
        {
            public int dwFileAttributes;
            public FILETIME ftCreationTime;
            public FILETIME ftLastAccessTime;
            public FILETIME ftLastWriteTime;
            public int nFileSizeHigh;
            public int nFileSizeLow;
            public int dwReserved0;
            public int dwReserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = MAX_PATH)]
            public string cFileName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
            public string cAlternate;
        }

        private struct INTERNET_ASYNC_RESULT
        {
            public long dwResult;
            public long dwError;
        }

        private const short ERROR_NO_MORE_FILES = 18;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern int FileTimeToSystemTime(ref FILETIME lpFileTime, ref SYSTEMTIME lpSystemTime);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int InternetConnect(int hInternetSession, string sServerName, short nServerPort, string sUsername, string sPassword, int lService, int lFlags, int lContext);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int InternetFindNextFile(int hFind, ref WIN32_FIND_DATA lpvFindData);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int FtpFindFirstFile(int hFtpSession, string lpszSearchFile, ref WIN32_FIND_DATA lpFindFileData, int dwFlags, int dwContent);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool FtpGetFile(int hFtpSession, string lpszRemoteFile, string lpszNewFile, bool fFailIfExists, int dwFlagsAndAttributes, int dwFlags, int dwContext);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool FtpPutFile(int hFtpSession, string lpszLocalFile, string lpszRemoteFile, int dwFlags, int dwContext);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool FtpSetCurrentDirectory(int hFtpSession, string lpszDirectory);
        // Initializes an application's use of the Win32 Internet functions
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int InternetOpen(string sAgent, int lAccessType, string sProxyName, string sProxyBypassg, int lFlags);
        [DllImport("wininet.dll", SetLastError = true)]
        // Closes a single Internet handle or a subtree of Internet handles.
        private static extern short InternetCloseHandle(int hInet);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern long InternetSetStatusCallback(long hInternet, long lpfnInternetCallback);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern void MoveMemory(ref long pTo, ref long pFrom, long lSize);
        // User agent constant.
        private const string scUserAgent = "c# wininet";
        // Use registry access settings.
        private const short INTERNET_OPEN_TYPE_PRECONFIG = 0;
        private const short INTERNET_OPEN_TYPE_DIRECT = 1;
        private const short INTERNET_OPEN_TYPE_PROXY = 3;
        private const short INTERNET_INVALID_PORT_NUMBER = 0;

        private const short FTP_TRANSFER_TYPE_ASCII = 0x00000001;
        private const short FTP_TRANSFER_TYPE_BINARY = 0x00000002;
        private const int INTERNET_FLAG_PASSIVE = 0x08000000;
        // Type of service to access.
        private const short INTERNET_SERVICE_FTP = 1;
        private const short INTERNET_SERVICE_GOPHER = 2;
        private const short INTERNET_SERVICE_HTTP = 3;
        // Brings the data across the wire even if it locally cached.
        private const uint INTERNET_FLAG_RELOAD = 0x80000000;
        private const int INTERNET_FLAG_KEEP_CONNECTION = 0x00400000;
        private const int INTERNET_FLAG_MULTIPART = 0x00200000;

        private const int INTERNET_FLAG_DONT_CACHE = 0x00400000;
        private const int INTERNET_FLAG_EXISTING_CONNECT = 0x00200000;

        #endregion

        public static string ExeName = "TSServer.exe";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Show();

            Application.DoEvents();

            string processname = ExeName.Substring(0, ExeName.IndexOf('.') == -1 ? ExeName.Length : ExeName.IndexOf('.'));
                        
            Process[] localAll = Process.GetProcessesByName(processname);

            if (localAll.Length == 0) 
            { 
                MessageBox.Show("No Find processname!!");
                this.Close();
                return;
            }

            foreach (Process KillPro in localAll)
            {
                try
                {
                    KillPro.CloseMainWindow();
                    KillPro.WaitForExit(20000);
                    KillPro.Kill();
                }
                catch
                {
                }
            }

            for (int i = 0; i < 400; i++)
            {
                Application.DoEvents();
                Thread.Sleep(100);
            }

            Process.Start(ExeName);

            this.Close();
        }
    }
}
