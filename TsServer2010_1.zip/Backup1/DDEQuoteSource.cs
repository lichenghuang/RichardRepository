﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using NDde;

namespace DDEQuote
{
    [Serializable]
    public class DDEServiceObj
    {
        public bool IsConnected = false;
        public string DDEService = "";
        public Hashtable DDETopicHt = Hashtable.Synchronized(new Hashtable());

        public DDEServiceObj(string DDEService)
        {
            this.DDEService = DDEService;
        }

    }
    [Serializable]
    public class DDETopicObj
    {
        public bool IsConnected = false;
        public string DDEService = "";
        public string DDETopic = "";
        public DdeClient Client = null;
        public Hashtable ItemHt = new Hashtable();

        public DDETopicObj(string DDEService, string DDETopic)
        {
            this.DDEService = DDEService;
            this.DDETopic = DDETopic;
        }

    }
    [Serializable]
    public class DDEDataObj
    {
        public string DDEService = "";
        public string DDETopic = "";
        public string Item = "";
        public string Val = "";

        public DDEDataObj(string DDEService, string DDETopic, string Item, string Val)
        {
            this.DDEService = DDEService;
            this.DDETopic = DDETopic;
            this.Item = Item;
            this.Val = Val;
        }
    }
    public class DDEQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "0830";

        public DDEQuoteFactorySetting()
        {
        }
        public DDEQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public DDEQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    public class DDEQuoteSource : QuoteSource
    {
        private Thread RoutineThread;
        private string DBConnectString = "";
        private TimeSpan RecoverTime;
        private TimeSpan RecoverTime2 = new TimeSpan(14, 30, 0);
        private TimeSpan TransCloseTime = new TimeSpan(16, 12, 0);
        private bool RecoverFlag = false;
        private bool RecoverFlag2 = false;
        private bool TransCloseFlag = false;
        private Hashtable ServiceObjHt = Hashtable.Synchronized(new Hashtable());
        private Dictionary<string, CommodityKind> DDECommoditys = new Dictionary<string, CommodityKind>();
        private Dictionary<string, string> STWMaps = new Dictionary<string, string>();
        private object LockObj = new object();

        public DDEQuoteSource(DDEQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);
        }
        public override bool Start()
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            base.Start();

            LoadData();
            SetDDE();

            return true;
        }
        private void LoadData()
        {
            try
            {
                DDEServiceObj iServiceObj;
                DDETopicObj iTopicObj;

                InitialSTWCode();

                string sql = "select b.commoditynm,b.commodityid,b.commoditykind,b.market,b.settlementmonth,b.commoditycode from DDECommodityList a,commodity b where a.commodityid=b.commodityid";
                sql += " union select * from (select top 2 b.commoditynm,b.commodityid,b.commoditykind,b.market,b.settlementmonth,b.commoditycode from commodityextra a,commodity b where a.commodityid=b.commodityid and left(a.commodityid,3) ='STW' and convert(varchar,a.maturity,112)>=convert(varchar,getdate(),112) order by a.maturity) a";
                sql += " union select * from (select top 2 b.commoditynm,b.commodityid,b.commoditykind,b.market,b.settlementmonth,b.commoditycode from commodityextra a,commodity b where a.commodityid=b.commodityid and left(a.commodityid,3) ='SCN' and convert(varchar,a.maturity,112)>=convert(varchar,getdate(),112) order by a.maturity) a";
                DataView dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);
                //DataView dv = DeriLib.Util.ExecSqlQry("select * from DDECommodityList where commodityid like '%STW%'", m_QuoteSetting.DBConnectString);

                lock (LockObj)
                {
                    foreach (DataRowView dr in dv)
                    {
                        try
                        {
                            PCommodity PP = m_PCommodityList.Set("", GetTWSCode(dr["CommodityId"].ToString()), Market.None, (CommodityKind)Enum.Parse(typeof(CommodityKind), dr["CommodityKind"].ToString()));
                            PP.QCommodity.Base.CommodityNm = dr["commoditynm"].ToString();

                            if (dr["Market"] != DBNull.Value && dr["Market"].ToString() != "") { PP.QCommodity.Base.Market = (Market)Enum.Parse(typeof(Market), dr["Market"].ToString()); }
                            if (dr["settlementmonth"] != DBNull.Value && dr["settlementmonth"].ToString() != "") { PP.QCommodity.Base.SettleMentMonth = dr["settlementmonth"].ToString(); }
                            if (dr["commoditykind"] != DBNull.Value && dr["commoditykind"].ToString() != "") { PP.QCommodity.Base.CommodityKind = (CommodityKind)Enum.Parse(typeof(CommodityKind), dr["commoditykind"].ToString()); }
                            if (dr["commoditycode"] != DBNull.Value && dr["commoditycode"].ToString() != "") { PP.QCommodity.Base.CommodityCode = dr["commoditycode"].ToString(); }
                        }
                        catch(Exception ee)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ee.Message + "][" + ee.StackTrace + "][" + dr["CommodityId"].ToString() + "]");
                        }
                    }

                    m_PCommodityList.Set("", "GLD.TW", Market.None, CommodityKind.Index);
                }

                dv = DeriLib.Util.ExecSqlQry("select * from DDECommodity", m_QuoteSetting.DBConnectString);
                //dv = DeriLib.Util.ExecSqlQry("select * from DDECommodity where item like '%STW%'", m_QuoteSetting.DBConnectString);
                 
                lock (LockObj)
                {
                    foreach (DataRowView dr in dv)
                    {
                        try
                        {
                            iServiceObj = null;
                            iTopicObj = null;

                            string service = dr["Service"].ToString();
                            string topic = dr["Topic"].ToString();
                            string item = dr["Item"].ToString();

                            string CommodityId = item.Substring(0, item.IndexOf("-"));
                            CommodityKind k = (CommodityKind)Enum.Parse(typeof(CommodityKind), dr["CommodityKind"].ToString());

                            if (!DDECommoditys.ContainsKey(CommodityId)) { DDECommoditys.Add(CommodityId, k); }

                            if (!ServiceObjHt.ContainsKey(service))
                            {
                                iServiceObj = new DDEServiceObj(service);
                                ServiceObjHt.Add(service, iServiceObj);
                            }
                            else
                                iServiceObj = (DDEServiceObj)ServiceObjHt[service];

                            if (!iServiceObj.DDETopicHt.ContainsKey(topic))
                            {
                                iTopicObj = new DDETopicObj(service, topic);
                                iServiceObj.DDETopicHt.Add(topic, iTopicObj);
                            }
                            else
                                iTopicObj = (DDETopicObj)iServiceObj.DDETopicHt[topic];

                            iTopicObj.ItemHt.Add(item, null);
                        }
                        catch (Exception er)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + er.Message + "][" + er.StackTrace + "][" + dr["CommodityId"].ToString() + "]");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void SetDDE()
        {
            lock (LockObj)
            {
                foreach (DDEServiceObj gServiceObj in ServiceObjHt.Values)
                {
                    foreach (DDETopicObj gTopicObj in gServiceObj.DDETopicHt.Values)
                    {
                        try
                        {
                            DdeContext context = new DdeContext();
                            DdeClient _Client = new DdeClient(gServiceObj.DDEService, gTopicObj.DDETopic, context);
                            _Client.Advise += new DdeClient.AdviseEventHandler(this.DdeClient_Advise);
                            _Client.Disconnected += new DdeClient.DisconnectedEventHandler(this.DdeClient_Disconnected);
                            gTopicObj.Client = _Client;

                            gTopicObj.Client.Connect();

                            foreach (string item in gTopicObj.ItemHt.Keys)
                            {
                                byte[] data = null;

                                try
                                {
                                    data = gTopicObj.Client.Request(item, 1, 60000);
                                }
                                catch (Exception err)
                                {                                    
                                    m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][SetDDE_Error] " + "[" + err.Message + "][" + err.StackTrace + "]");
                                    continue;
                                }

                                string val = System.Text.Encoding.Default.GetString(data).Replace("\r\n", "");
                                string str = gTopicObj.DDEService + "|" + gTopicObj.DDETopic + "!" + item + "=" + val;
                                m_PacketNum++;
                                DDEDataObj iDDEDataObj = new DDEDataObj(gTopicObj.DDEService, gTopicObj.DDETopic, item, val);
                                m_PackagePool.Enqueue(iDDEDataObj);
                                gTopicObj.Client.StartAdvise(item, 1, true, 60000);
                            }
                            gTopicObj.IsConnected = true;
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][SetDDE_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }
                }
            }
        }
        private void DdeClient_Advise(object sender, DdeClient.AdviseEventArgs args)
        {
            // This method is executed on the UI thread.
            DdeClient iDdeClient = (DdeClient)sender;
            string val = System.Text.Encoding.Default.GetString(args.Data).Replace("\r\n", "");
            string str = iDdeClient.Service + "|" + iDdeClient.Topic + "!" + args.Item + "=" + val;

            m_PacketNum++;
            DDEDataObj iDDEDataObj = new DDEDataObj(iDdeClient.Service, iDdeClient.Topic, args.Item, val);
            m_PackagePool.Enqueue(iDDEDataObj);

        }
        private void DdeClient_Disconnected(object sender, DdeClient.DisconnectedEventArgs args)
        {
            DdeClient iDdeClient = (DdeClient)sender;

            string str = iDdeClient.Service + "|" + iDdeClient.Topic;

            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][" + str + " Disconnected]");
        }

        public override bool Close()
        {
            try
            {
                lock (LockObj)
                {
                    foreach (DDEServiceObj iServiceObj in ServiceObjHt.Values)
                    {
                        iServiceObj.IsConnected = false;
                        foreach (DDETopicObj iTopicObj in iServiceObj.DDETopicHt.Values)
                        {
                            try
                            {
                                if (iTopicObj.IsConnected)
                                {
                                    iTopicObj.Client.Disconnect();
                                    iTopicObj.IsConnected = false;
                                    iTopicObj.Client = null;
                                }
                            }
                            catch (DdeException ex)
                            {
                                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DDE_Close_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                            }
                        }

                        iServiceObj.DDETopicHt.Clear();
                    }

                    ServiceObjHt.Clear();
                }

                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                        RecoverFlag2 = false;
                        TransCloseFlag = false;
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime2).TotalMinutes) < 1 && !RecoverFlag2)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag2 = true;
                    }

                    if (Math.Abs(nowts.Subtract(TransCloseTime).TotalMinutes) < 1 && !TransCloseFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(TransCloseWork));
                        TransCloseFlag = true;
                    }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            DDEDataObj obj = (DDEDataObj)m_PackagePool.Dequeue();
                            DealWithQuote(obj);

                            if (obj.Item.Substring(0, obj.Item.IndexOf("-")) == "GLD.FX")
                                DealWithQuoteGLD_TW(obj);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ReStartWork(Object stateInfo)
        {
            try
            {
                lock (LockObj)
                {
                    foreach (DDEServiceObj iServiceObj in ServiceObjHt.Values)
                    {
                        iServiceObj.IsConnected = false;
                        foreach (DDETopicObj iTopicObj in iServiceObj.DDETopicHt.Values)
                        {
                            try
                            {
                                if (iTopicObj.IsConnected)
                                {
                                    iTopicObj.Client.Disconnect();
                                    iTopicObj.IsConnected = false;
                                    iTopicObj.Client = null;
                                }
                            }
                            catch (DdeException ex)
                            {
                                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DDE_Close_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                            }
                        }

                        iServiceObj.DDETopicHt.Clear();
                    }

                    ServiceObjHt.Clear();
                }

                m_PacketNum = 0;

                LoadData();
                SetDDE();
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void TransCloseWork(Object stateInfo)
        {
            try
            {
                foreach (PCommodity P in m_PCommodityList.Commoditys)
                {
                    if (P.QCommodity.Base.CommodityId.IndexOf("HK") > -1 || P.QCommodity.Base.CommodityId.IndexOf("STW") > -1 || P.QCommodity.Base.CommodityId.IndexOf("SCN") > -1)
                    {
                        P.SetClose(DateTime.Now.ToString("HHmmss"), DateTime.Now.ToString("HHmmssff"), P.QCommodity.HighLow.DayHighPrice, P.QCommodity.HighLow.DayLowPrice, 0.0, P.QCommodity.Best5.BuyPriceBest1, P.QCommodity.Best5.SellPriceBest1, P.QCommodity.Match.MatchPrice, DateTime.Today, 0, P.QCommodity.Match.MatchTotalQty, 0.0, P.QCommodity.Match.MatchPrice);
                        DoSendWrite(P.QCommodity.Close);
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][TransCloseWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }       
        private void DealWithQuote(DDEDataObj mDDEDataObj)
        {
            try
            {
                PCommodity mPCommodity = null;

                if (mDDEDataObj.Item.IndexOf("-") == -1) { return; }

                if (mDDEDataObj.Item.IndexOf("CN") > -1)                
                {
                    mPCommodity = null;
                }

                string CommodityId = GetTWSCode(mDDEDataObj.Item.Substring(0, mDDEDataObj.Item.IndexOf("-")));
                string Item = mDDEDataObj.Item.Substring(mDDEDataObj.Item.IndexOf("-") + 1, mDDEDataObj.Item.Length - mDDEDataObj.Item.IndexOf("-") - 1);

                if (Item == "Name" || Item == "PreClose")
                {
                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }
                    
                    mPCommodity.IsLocalCommodity = true;

                    double refprice = 0.0;
                    string commoditynm = "";

                    if (Item == "Name")
                    {
                        if (mPCommodity.QCommodity.Base != null) { refprice = mPCommodity.QCommodity.Base.ReferencePrice; }
                        commoditynm = mPCommodity.QCommodity.Base.CommodityNm;

                        //if (mPCommodity.CommodityId.IndexOf("STW")>-1)
                        //    commoditynm = mDDEDataObj.Val;

                        CommodityKind k = CommodityKind.None;

                        if (DDECommoditys.ContainsKey(CommodityId))
                            k = (CommodityKind)DDECommoditys[CommodityId];

                        string nowstr = DateTime.Now.ToString("HHmmss") + "00";
                        string seqstr = DateTime.Now.ToString("HHmmssff");

                        //if (CommodityId.Length >= 3 && CommodityId.Substring(0,3) == "TWS")
                        //    mPCommodity.SetBase(Market.TFE, CommodityKind.Future, CommodityType.None, "TWS", "新加坡摩台期", DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, refprice * 1.1, refprice * 0.9, refprice * 1.15, refprice * 0.85, 0.0, 0.0, 1, "I", 1, 1, "", "");
                        //else
                        //    mPCommodity.SetBase(Market.None, k, CommodityType.None, "", commoditynm, DateTime.Today, "", "", refprice, 0.0, 0.0, 1, "", "");
                        mPCommodity.SetBase(mPCommodity.QCommodity.Base.Market, mPCommodity.QCommodity.Base.CommodityKind, mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Base.CommodityCode, mPCommodity.QCommodity.Base.CommodityNm, DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, refprice * 1.1, refprice * 0.9, refprice * 1.15, refprice * 0.85, 0.0, 0.0, 1, mPCommodity.QCommodity.Base.ProdKind, 1, 1, "", "");
                    }
                    else if (Item == "PreClose")
                    {
                        double.TryParse(mDDEDataObj.Val, out refprice);
                        if (mPCommodity.QCommodity.Base != null) { commoditynm = mPCommodity.QCommodity.Base.CommodityNm; }

                        CommodityKind k = CommodityKind.None;

                        if (DDECommoditys.ContainsKey(CommodityId))
                            k = (CommodityKind)DDECommoditys[CommodityId];

                        //if (CommodityId.Length >= 3 && CommodityId.Substring(0, 3) == "TWS")
                        //    mPCommodity.SetBase(Market.TFE, CommodityKind.Future, CommodityType.None, "TWS", "新加坡摩台期", DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, refprice * 1.1, refprice * 0.9, refprice * 1.15, refprice * 0.85, 0.0, 0.0, 1, "I", 1, 1, "", "");
                        //else
                        //    mPCommodity.SetBase(Market.None, k, CommodityType.None, "", commoditynm, DateTime.Today, "", "", refprice, 0.0, 0.0, 1, "", "");
                        mPCommodity.SetBase(mPCommodity.QCommodity.Base.Market, mPCommodity.QCommodity.Base.CommodityKind, mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Base.CommodityCode, mPCommodity.QCommodity.Base.CommodityNm, DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, refprice * 1.1, refprice * 0.9, refprice * 1.15, refprice * 0.85, 0.0, 0.0, 1, mPCommodity.QCommodity.Base.ProdKind, 1, 1, "", "");
                    }
                    DoSendWrite(mPCommodity.QCommodity.Base);
                }
                else if (Item == "Time")
                {
                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    string time = mDDEDataObj.Val.Replace(":", "");
                    string seq = mDDEDataObj.Val.Replace(":", "");
                    int k = 0;
                    double last = 0.0;
                    int qty = 0;
                    int totalqty = 0;
                    double bid = 0.0;
                    int bidqty = 0;
                    double ask = 0.0;
                    int askqty = 0;
                    double high = 0.0;
                    double low = 0.0;

                    if (mPCommodity.QCommodity.Match != null)
                    {
                        last = mPCommodity.QCommodity.Match.MatchPrice;
                        qty = mPCommodity.QCommodity.Match.MatchQty;
                        totalqty = mPCommodity.QCommodity.Match.MatchTotalQty;
                    }

                    if (mPCommodity.QCommodity.Best5 != null)
                    {
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }

                    if (mPCommodity.QCommodity.HighLow != null)
                    {
                        high = mPCommodity.QCommodity.HighLow.DayHighPrice;                        
                        low = mPCommodity.QCommodity.HighLow.DayLowPrice;                        
                    }

                    if (seq == "--") 
                    {
                        if (m_QuoteSetting.IsWriteToDb)
                        {
                            DeriLib.Util.ExecSqlCmd("EXEC spClearTmpTableForCommodity '" + CommodityId + "'", m_QuoteSetting.DBConnectString);
                        }

                        if (mPCommodity.QCommodity.Match != null)
                        {
                            mPCommodity.SetMatch("000000", "00000000", 1, "000000", 0.0, 0, 0.0, 0.0, 0, 0, 0, 0);
                            DoSendWrite(mPCommodity.QCommodity.Match);
                        }

                        if (mPCommodity.QCommodity.Best5 != null)
                        {
                            mPCommodity.SetBest5("000000", "00000000", 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                            DoSendWrite(mPCommodity.QCommodity.Best5);
                        }

                        if (mPCommodity.QCommodity.HighLow != null)
                        {
                            mPCommodity.SetHighLow("000000", "00000000", 0.0, 0.0, "000000");
                            DoSendWrite(mPCommodity.QCommodity.HighLow);
                        }

                        return; 
                    }

                    if (mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == "")
                        seq += "00";

                    if (mPCommodity.QCommodity.Match.InformationSeq != null && mPCommodity.QCommodity.Match.InformationSeq.Length != 0 && seq == mPCommodity.QCommodity.Match.InformationSeq.Substring(0, 6))
                    {
                        int.TryParse(mPCommodity.QCommodity.Match.InformationSeq.Substring(6, 2), out k);
                        k++;
                        seq += k.ToString("00");
                    }
                    else
                        seq += "00";

                    if (mPCommodity.QCommodity.Match != null)
                    {
                        /*mPCommodity.QCommodity.Match.InformationSeq = seq;
                        mPCommodity.QCommodity.Match.InformationTime = time;
                        mPCommodity.QCommodity.Match.MatchTime = time;*/
                        mPCommodity.SetMatch(time, seq, 1, time, mPCommodity.QCommodity.Match.MatchPrice, mPCommodity.QCommodity.Match.MatchQty, 0.0, 0.0, mPCommodity.QCommodity.Match.MatchTotalQty, 0, 0, 0);
                        DoSendWrite(mPCommodity.QCommodity.Match);
                    }

                    if (mPCommodity.QCommodity.Best5 != null)
                    {
                        /*mPCommodity.QCommodity.Best5.InformationSeq = seq;
                        mPCommodity.QCommodity.Best5.InformationTime = time;*/
                        mPCommodity.SetBest5(time, seq, mPCommodity.QCommodity.Best5.BuyPriceBest1, mPCommodity.QCommodity.Best5.BuyQtyBest1, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, mPCommodity.QCommodity.Best5.SellPriceBest1, mPCommodity.QCommodity.Best5.SellQtyBest1, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                        DoSendWrite(mPCommodity.QCommodity.Best5);
                    }

                    if (mPCommodity.QCommodity.HighLow != null)
                    {
                        mPCommodity.SetHighLow(time, seq, mPCommodity.QCommodity.HighLow.DayHighPrice, mPCommodity.QCommodity.HighLow.DayLowPrice, time);
                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                    }
                }
                else if (Item == "Price" || Item == "Volume" || Item == "TotalVolume")
                {
                    double last = 0.0;
                    double qty = 0;
                    double totalqty = 0;

                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    //if (CommodityId == "0010.HK")
                    //    totalqty = totalqty;

                    if (Item == "Price")
                    {
                        if (CommodityId.IndexOf(".FX") > -1)
                        {
                            if (Math.Round(mPCommodity.QCommodity.Best5.BuyPriceBest1, 3) == 0.0 || Math.Round(mPCommodity.QCommodity.Best5.SellPriceBest1, 3) == 0.0) { return; }

                            last = (mPCommodity.QCommodity.Best5.BuyPriceBest1 + mPCommodity.QCommodity.Best5.SellPriceBest1) / 2.0;
                        }
                        else
                        {
                            double.TryParse(mDDEDataObj.Val, out last);
                            if (Math.Round(mPCommodity.QCommodity.Match.MatchPrice, 6) == Math.Round(last, 6)) { return; }
                        }

                        qty = mPCommodity.QCommodity.Match.MatchQty;
                        totalqty = mPCommodity.QCommodity.Match.MatchTotalQty;
                    }
                    else if (Item == "Volume")
                    {
                        double.TryParse(mDDEDataObj.Val, out qty);
                        if (mPCommodity.QCommodity.Match.MatchQty == (int)qty) { return; }
                        last = mPCommodity.QCommodity.Match.MatchPrice;
                        totalqty = mPCommodity.QCommodity.Match.MatchTotalQty;
                    }
                    else if (Item == "TotalVolume")
                    {
                        double.TryParse(mDDEDataObj.Val, out totalqty);
                        if (mPCommodity.QCommodity.Match.MatchTotalQty == (int)totalqty) { return; }
                        last = mPCommodity.QCommodity.Match.MatchPrice;
                        qty = mPCommodity.QCommodity.Match.MatchQty;
                    }

                    mPCommodity.SetMatch(mPCommodity.QCommodity.Match.InformationTime, mPCommodity.QCommodity.Match.InformationSeq, 1, mPCommodity.QCommodity.Match.MatchTime, last, (int)qty, 0.0, 0.0, (int)totalqty, 0, 0, 0);
                    DoSendWrite(mPCommodity.QCommodity.Match);
                }
                else if (Item == "High" || Item == "Low")
                {
                    double high = 0.0;
                    double low = 0;
                    
                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    if (Item == "High")
                    {
                        double.TryParse(mDDEDataObj.Val, out high);
                        low = mPCommodity.QCommodity.HighLow.DayLowPrice;
                    }
                    else if (Item == "Low")
                    {
                        double.TryParse(mDDEDataObj.Val, out low);
                        high = mPCommodity.QCommodity.HighLow.DayHighPrice;
                    }

                    mPCommodity.SetHighLow(mPCommodity.QCommodity.HighLow.InformationTime, mPCommodity.QCommodity.HighLow.InformationSeq, high, low, mPCommodity.QCommodity.HighLow.InformationTime);
                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                }
                else if (Item == "Bid" || Item == "BestBidSize" || Item == "Ask" || Item == "BestAskSize")
                {
                    double bid = 0.0;
                    double bidqty = 0;
                    double ask = 0.0;
                    double askqty = 0;

                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    if (Item == "Bid")
                    {
                        double.TryParse(mDDEDataObj.Val, out bid);
                        if (Math.Round(mPCommodity.QCommodity.Best5.BuyPriceBest1, 6) == Math.Round(bid, 6)) { return; }
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }
                    else if (Item == "BestBidSize")
                    {
                        double.TryParse(mDDEDataObj.Val, out bidqty);
                        if (mPCommodity.QCommodity.Best5.BuyQtyBest1 == (int)bidqty) { return; }
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }
                    else if (Item == "Ask")
                    {
                        double.TryParse(mDDEDataObj.Val, out ask);
                        if (Math.Round(mPCommodity.QCommodity.Best5.SellPriceBest1, 6) == Math.Round(ask, 6)) { return; }
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }
                    else if (Item == "BestAskSize")
                    {
                        double.TryParse(mDDEDataObj.Val, out askqty);
                        if (mPCommodity.QCommodity.Best5.SellQtyBest1 == (int)askqty) { return; }
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                    }

                    mPCommodity.SetBest5(mPCommodity.QCommodity.Best5.InformationTime, mPCommodity.QCommodity.Best5.InformationSeq, bid, (int)bidqty, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, ask, (int)askqty, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    DoSendWrite(mPCommodity.QCommodity.Best5);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithQuoteGLD_TW(DDEDataObj mDDEDataObj)
        {
            try
            {
                PCommodity mPCommodity = null;
                double USDCurrency = 30.0;

                if (mDDEDataObj.Item.IndexOf("-") == -1) { return; }

                PCommodity USDCommodity = m_PCommodityList.Get("TWD.FX");

                if (USDCommodity != null && USDCommodity.QCommodity != null) 
                {
                    if (USDCommodity.QCommodity.Match.MatchPrice == 0.0 && USDCommodity.QCommodity.Base.ReferencePrice != 0.0)
                        USDCurrency = USDCommodity.QCommodity.Base.ReferencePrice;
                    else if (USDCommodity.QCommodity.Match.MatchPrice != 0.0)
                        USDCurrency = USDCommodity.QCommodity.Match.MatchPrice;
                }

                string CommodityId = "GLD.TW";
                string Item = mDDEDataObj.Item.Substring(mDDEDataObj.Item.IndexOf("-") + 1, mDDEDataObj.Item.Length - mDDEDataObj.Item.IndexOf("-") - 1);

                if (Item == "Name" || Item == "PreClose")
                {
                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    mPCommodity.IsLocalCommodity = true;

                    double refprice = 0.0;
                    string commoditynm = "";

                    if (Item == "Name")
                    {
                        if (mPCommodity.QCommodity.Base != null) { refprice = mPCommodity.QCommodity.Base.ReferencePrice; }
                        commoditynm = "台幣黃金";

                        CommodityKind k = CommodityKind.Index;

                        string nowstr = DateTime.Now.ToString("HHmmss") + "00";
                        string seqstr = DateTime.Now.ToString("HHmmssff");

                        //mPCommodity.SetBase(Market.None, k, CommodityType.None, "", commoditynm, DateTime.Today, "", "", refprice, 0.0, 0.0, 1, "", "");
                        mPCommodity.SetBase(mPCommodity.QCommodity.Base.Market, mPCommodity.QCommodity.Base.CommodityKind, mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Base.CommodityCode, mPCommodity.QCommodity.Base.CommodityNm, DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, refprice * 1.1, refprice * 0.9, refprice * 1.15, refprice * 0.85, 0.0, 0.0, 1, mPCommodity.QCommodity.Base.ProdKind, 1, 1, "", "");
                    }
                    else if (Item == "PreClose")
                    {
                        double.TryParse(mDDEDataObj.Val, out refprice);

                        refprice = refprice / 31.1035 * 3.75 * 0.9999 / 0.995 * USDCurrency;
                        if (mPCommodity.QCommodity.Base != null) { commoditynm = mPCommodity.QCommodity.Base.CommodityNm; }

                        CommodityKind k = CommodityKind.None;

                        if (DDECommoditys.ContainsKey(CommodityId))
                            k = (CommodityKind)DDECommoditys[CommodityId];

                        //if (CommodityId.Length >= 3 && CommodityId.Substring(0, 3) == "TWS")
                        //    mPCommodity.SetBase(Market.TFE, CommodityKind.Future, CommodityType.None, "TWS", "新加坡摩台期", DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1, "I", 1, 1, "", "");
                        //else
                        //    mPCommodity.SetBase(Market.None, k, CommodityType.None, "", commoditynm, DateTime.Today, "", "", refprice, 0.0, 0.0, 1, "", "");
                        mPCommodity.SetBase(mPCommodity.QCommodity.Base.Market, mPCommodity.QCommodity.Base.CommodityKind, mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Base.CommodityCode, mPCommodity.QCommodity.Base.CommodityNm, DateTime.Today, DateTime.Now.ToString("HHmmss") + "00", DateTime.Now.ToString("HHmmssff"), mPCommodity.QCommodity.Base.SettleMentMonth, 0, refprice, refprice * 1.1, refprice * 0.9, refprice * 1.15, refprice * 0.85, 0.0, 0.0, 1, mPCommodity.QCommodity.Base.ProdKind, 1, 1, "", "");
                    }
                    DoSendWrite(mPCommodity.QCommodity.Base);
                }
                else if (Item == "Time")
                {
                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    string time = mDDEDataObj.Val.Replace(":", "");
                    string seq = mDDEDataObj.Val.Replace(":", "");
                    int k = 0;
                    double last = 0.0;
                    int qty = 0;
                    int totalqty = 0;
                    double bid = 0.0;
                    int bidqty = 0;
                    double ask = 0.0;
                    int askqty = 0;
                    double high = 0.0;
                    double low = 0.0;

                    if (mPCommodity.QCommodity.Match != null)
                    {
                        last = mPCommodity.QCommodity.Match.MatchPrice;
                        qty = mPCommodity.QCommodity.Match.MatchQty;
                        totalqty = mPCommodity.QCommodity.Match.MatchTotalQty;
                    }

                    if (mPCommodity.QCommodity.Best5 != null)
                    {
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }

                    if (mPCommodity.QCommodity.HighLow != null)
                    {
                        high = mPCommodity.QCommodity.HighLow.DayHighPrice;
                        low = mPCommodity.QCommodity.HighLow.DayLowPrice;
                    }

                    if (seq == "--")
                    {
                        if (m_QuoteSetting.IsWriteToDb)
                        {
                            DeriLib.Util.ExecSqlCmd("EXEC spClearTmpTableForCommodity '" + CommodityId + "'", m_QuoteSetting.DBConnectString);
                        }

                        if (mPCommodity.QCommodity.Match != null)
                        {
                            mPCommodity.SetMatch("000000", "00000000", 1, "000000", 0.0, 0, 0.0, 0.0, 0, 0, 0, 0);
                            DoSendWrite(mPCommodity.QCommodity.Match);
                        }

                        if (mPCommodity.QCommodity.Best5 != null)
                        {
                            mPCommodity.SetBest5("000000", "00000000", 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                            DoSendWrite(mPCommodity.QCommodity.Best5);
                        }

                        if (mPCommodity.QCommodity.HighLow != null)
                        {
                            mPCommodity.SetHighLow("000000", "00000000", 0.0, 0.0, "000000");
                            DoSendWrite(mPCommodity.QCommodity.HighLow);
                        }

                        return;
                    }

                    if (mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == "")
                        seq += "00";

                    if (mPCommodity.QCommodity.Match.InformationSeq != null && mPCommodity.QCommodity.Match.InformationSeq.Length != 0 && seq == mPCommodity.QCommodity.Match.InformationSeq.Substring(0, 6))
                    {
                        int.TryParse(mPCommodity.QCommodity.Match.InformationSeq.Substring(6, 2), out k);
                        k++;
                        seq += k.ToString("00");
                    }
                    else
                        seq += "00";

                    if (mPCommodity.QCommodity.Match != null)
                    {
                        /*mPCommodity.QCommodity.Match.InformationSeq = seq;
                        mPCommodity.QCommodity.Match.InformationTime = time;
                        mPCommodity.QCommodity.Match.MatchTime = time;*/
                        mPCommodity.SetMatch(time, seq, 1, time, mPCommodity.QCommodity.Match.MatchPrice, mPCommodity.QCommodity.Match.MatchQty, 0.0, 0.0, mPCommodity.QCommodity.Match.MatchTotalQty, 0, 0, 0);
                        DoSendWrite(mPCommodity.QCommodity.Match);
                    }

                    if (mPCommodity.QCommodity.Best5 != null)
                    {
                        /*mPCommodity.QCommodity.Best5.InformationSeq = seq;
                        mPCommodity.QCommodity.Best5.InformationTime = time;*/
                        mPCommodity.SetBest5(time, seq, mPCommodity.QCommodity.Best5.BuyPriceBest1, mPCommodity.QCommodity.Best5.BuyQtyBest1, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, mPCommodity.QCommodity.Best5.SellPriceBest1, mPCommodity.QCommodity.Best5.SellQtyBest1, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                        DoSendWrite(mPCommodity.QCommodity.Best5);
                    }

                    if (mPCommodity.QCommodity.HighLow != null)
                    {
                        mPCommodity.SetHighLow(time, seq, mPCommodity.QCommodity.HighLow.DayHighPrice, mPCommodity.QCommodity.HighLow.DayLowPrice, time);
                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                    }
                }
                else if (Item == "Price" || Item == "Volume" || Item == "TotalVolume")
                {
                    double last = 0.0;
                    double qty = 0;
                    double totalqty = 0;

                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    if (Item == "Price")
                    {                        
                        double.TryParse(mDDEDataObj.Val, out last);

                        last = last / 31.1035 * 3.75 * 0.9999 / 0.995 * USDCurrency;

                        if (Math.Round(mPCommodity.QCommodity.Match.MatchPrice, 6) == Math.Round(last, 6)) { return; }                        

                        qty = mPCommodity.QCommodity.Match.MatchQty;
                        totalqty = mPCommodity.QCommodity.Match.MatchTotalQty;
                    }
                    else if (Item == "Volume")
                    {
                        double.TryParse(mDDEDataObj.Val, out qty);
                        if (mPCommodity.QCommodity.Match.MatchQty == (int)qty) { return; }
                        last = mPCommodity.QCommodity.Match.MatchPrice;
                        totalqty = mPCommodity.QCommodity.Match.MatchTotalQty;
                    }
                    else if (Item == "TotalVolume")
                    {
                        double.TryParse(mDDEDataObj.Val, out totalqty);
                        if (mPCommodity.QCommodity.Match.MatchTotalQty == (int)totalqty) { return; }
                        last = mPCommodity.QCommodity.Match.MatchPrice;
                        qty = mPCommodity.QCommodity.Match.MatchQty;
                    }

                    mPCommodity.SetMatch(mPCommodity.QCommodity.Match.InformationTime, mPCommodity.QCommodity.Match.InformationSeq, 1, mPCommodity.QCommodity.Match.MatchTime, last, (int)qty, 0.0, 0.0, (int)totalqty, 0, 0, 0);
                    DoSendWrite(mPCommodity.QCommodity.Match);
                }
                else if (Item == "High" || Item == "Low")
                {
                    double high = 0.0;
                    double low = 0;

                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    if (Item == "High")
                    {
                        double.TryParse(mDDEDataObj.Val, out high);
                        high = high / 31.1035 * 3.75 * 0.9999 / 0.995 * USDCurrency;
                        low = mPCommodity.QCommodity.HighLow.DayLowPrice;
                    }
                    else if (Item == "Low")
                    {
                        double.TryParse(mDDEDataObj.Val, out low);
                        low = low / 31.1035 * 3.75 * 0.9999 / 0.995 * USDCurrency;
                        high = mPCommodity.QCommodity.HighLow.DayHighPrice;
                    }

                    mPCommodity.SetHighLow(mPCommodity.QCommodity.HighLow.InformationTime, mPCommodity.QCommodity.HighLow.InformationSeq, high, low, mPCommodity.QCommodity.HighLow.InformationTime);
                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                }
                else if (Item == "Bid" || Item == "BestBidSize" || Item == "Ask" || Item == "BestAskSize")
                {
                    double bid = 0.0;
                    double bidqty = 0;
                    double ask = 0.0;
                    double askqty = 0;

                    mPCommodity = m_PCommodityList.Get(CommodityId);
                    if (mPCommodity == null) { return; }

                    if (Item == "Bid")
                    {
                        double.TryParse(mDDEDataObj.Val, out bid);
                        bid = bid / 31.1035 * 3.75 * 0.9999 / 0.995 * USDCurrency;
                        if (Math.Round(mPCommodity.QCommodity.Best5.BuyPriceBest1, 6) == Math.Round(bid, 6)) { return; }
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }
                    else if (Item == "BestBidSize")
                    {
                        double.TryParse(mDDEDataObj.Val, out bidqty);
                        if (mPCommodity.QCommodity.Best5.BuyQtyBest1 == (int)bidqty) { return; }
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }
                    else if (Item == "Ask")
                    {
                        double.TryParse(mDDEDataObj.Val, out ask);
                        ask = ask / 31.1035 * 3.75 * 0.9999 / 0.995 * USDCurrency;
                        if (Math.Round(mPCommodity.QCommodity.Best5.SellPriceBest1, 6) == Math.Round(ask, 6)) { return; }
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        askqty = mPCommodity.QCommodity.Best5.SellQtyBest1;
                    }
                    else if (Item == "BestAskSize")
                    {
                        double.TryParse(mDDEDataObj.Val, out askqty);
                        if (mPCommodity.QCommodity.Best5.SellQtyBest1 == (int)askqty) { return; }
                        bid = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                        bidqty = mPCommodity.QCommodity.Best5.BuyQtyBest1;
                        ask = mPCommodity.QCommodity.Best5.SellPriceBest1;
                    }

                    mPCommodity.SetBest5(mPCommodity.QCommodity.Best5.InformationTime, mPCommodity.QCommodity.Best5.InformationSeq, bid, (int)bidqty, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, ask, (int)askqty, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    DoSendWrite(mPCommodity.QCommodity.Best5);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithQuoteGLD_TW_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }
        private void InitialSTWCode()
        {
            try
            {
                DataView dv = DeriLib.Util.ExecSqlQry("select top 2 commodityid from commodityextra where left(commodityid,3) = 'STW' and convert(varchar,maturity,112)>=convert(varchar,getdate(),112) order by maturity", m_QuoteSetting.DBConnectString);

                STWMaps.Clear();

                STWMaps.Add("STW*1.SG",dv[0][0].ToString());
                STWMaps.Add("STW*2.SG", dv[1][0].ToString());

                dv = DeriLib.Util.ExecSqlQry("select top 2 commodityid from commodityextra where left(commodityid,3) = 'SCN' and convert(varchar,maturity,112)>=convert(varchar,getdate(),112) order by maturity", m_QuoteSetting.DBConnectString);

                STWMaps.Add("CN*1.SG", dv[0][0].ToString());
                STWMaps.Add("CN*2.SG", dv[1][0].ToString());
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][InitialSTWCode_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private string GetTWSCode(string STWCode)
        {
            try
            {
                if (STWMaps.ContainsKey(STWCode)) { return STWMaps[STWCode]; }
                else return STWCode;
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][GetTWSCode_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return STWCode;
            }
        }
    }
}
