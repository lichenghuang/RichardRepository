﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using log4net;
using log4net.Config;
using KGI.TW.Der.STQuote.QuoteData;
using KGI.TW.Der.STQuote;
using KGI.TW.Der.STQuote.Util;
using KGI.TW.Der.STDepthMonitor;
using KGI.TW.Der.DAO.MSSql.ST;
using KGI.TW.Der.STOptionMonitor;

namespace NAVQuote
{
    public class NAVQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "0840";        
        public string RemotIp = "";
        public int RemotPort = 7442;
        public STQuoteAPI mQuoteAPI = null;

        public NAVQuoteFactorySetting()
        {
        }
        public NAVQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public NAVQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }

    public class NAVQuoteSource : QuoteSource
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(NAVQuoteSource));

        private Thread RoutineThread;
        private string DBConnectString = "";
        //private string SubCommodity = "";
        private TimeSpan RecoverTime;
        private string RemotIp = "";
        private bool RecoverFlag = false;        
        //private Dictionary<string, PCommodity> Commoditys = new Dictionary<string, PCommodity>();
        private Dictionary<string, NAVCommodity> NAVCommoditys = new Dictionary<string, NAVCommodity>();
        public STQuoteAPI mQuoteAPI = null;

        public NAVQuoteSource(NAVQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;            
            RemotIp = QuoteSetting.RemotIp;            
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);
        }
        public override bool Start()
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            LoadData();
            ConnectGW();

            return base.Start();
        }       
        public override bool Close()
        {
            try
            {
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                if (mQuoteAPI != null)
                {
                    mQuoteAPI.DisConnect();
                    mQuoteAPI = null;
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
                
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            NAVCommodity obj = (NAVCommodity)m_PackagePool.Dequeue();
                            DealWithQuote(obj);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ReStartWork(Object stateInfo)
        {
            try
            {
                m_PacketNum = 0;

                LoadData();
                ConnectGW();
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void LoadData()
        {
            try
            {
                string sql = "select a.*,b.commoditynm from navcommodity a,commodity b where a.commodityid=b.commodityid";
                DataView dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);

                NAVCommoditys.Clear();

                int i = 0;

                foreach (DataRowView dr in dv)
                {
                    i++;

                    NAVCommoditys.Add(dr["feedcode"].ToString(),new NAVCommodity(dr["commodityid"].ToString(),dr["feedcode"].ToString(),dr["exchange"].ToString(),dr["market"].ToString(),dr["session"].ToString()));
                    PCommodity PP = m_PCommodityList.Set("", dr["CommodityId"].ToString(), Market.None, CommodityKind.Index);

                    PP.SetBase(Market.None, CommodityKind.Index, CommodityType.None, "", dr["commoditynm"].ToString(), DateTime.Today, "", i.ToString("00000000"), 0.0, 0.0, 0.0, 1, "", "");
                    PP.IsLocalCommodity = true;
                    DoSendWrite(PP.QCommodity.Base);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ConnectGW()
        {
            try
            {
                if (mQuoteAPI != null)
                {
                    mQuoteAPI.DisConnect();
                    mQuoteAPI = null;
                }

                if (mQuoteAPI == null)
                {
                    mQuoteAPI = new STQuoteAPI();
                    mQuoteAPI.SettingFilename = "QuoteAPIPlugin.xml";
                    mQuoteAPI.OnConnectStatus += new Action<int, string>(marketDataSource_OnConnectStatus);
                    mQuoteAPI.OnDeal += new Action<IMarketDataSource, IDeal>(marketDataSource_OnDeal);
                    mQuoteAPI.OnError += new Action<string, int, string>(marketDataSource_OnError);
                    mQuoteAPI.Log = new Log4NetWrapper(log);
                }

                mQuoteAPI.Connect();

                foreach (NAVCommodity C in NAVCommoditys.Values)
                {
                    GeneralMarketDataSub subInfo = new GeneralMarketDataSub() { Exchange = C.Exchange, Market = C.Market, Symbol = C.FeedCode, Session = C.Session };

                    if (mQuoteAPI.SubIndex(subInfo) == -1)                 
                        m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Sub_Error] " + "[" + C.CommodityId + "]");
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ConnectGW_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void marketDataSource_OnConnectStatus(int statusCode, string reason)
        {
            if (statusCode != 101 && statusCode != 201)
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Connect_Error]["+statusCode+"]["+reason+"]");            
        }
        private void marketDataSource_OnDeal(IMarketDataSource source, IDeal deal)
        {
            #region Log
            string msgTitle = "DealInfo: ";
            string msg = "";

            msg = string.Format("Exchange {0}, Symbol:{1} Session:{2}, Deal:{3}, Quatity:{4}, ExchTime:{5}, TotalQuatity:{6}",
                deal.Exchange, deal.Symbol, deal.Session, deal.Deal, deal.Quatity, deal.ExchTime.ToString("hh:mm:ss:ffff"), deal.TotalQuantity);                
            //Console.WriteLine(msgTitle + msg);

            if (NAVCommoditys.ContainsKey(deal.Symbol))
            {
                m_PacketNum++;
                NAVCommodity C = NAVCommoditys[deal.Symbol];
                C.Price = deal.Deal;
                m_PackagePool.Enqueue(C);
            }

            #endregion

        }
        private void marketDataSource_OnError(string serviceCode, int errorCode, string msg)
        {
            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][OnError][" + serviceCode + "][" + errorCode + "][" + msg + "]");
        }
        private void DealWithQuote(NAVCommodity C)
        {
            try
            {                
                PCommodity mPCommodity = m_PCommodityList.Get(C.CommodityId);
                if (mPCommodity == null) { return; }

                string nowstr = DateTime.Now.ToString("HHmmss") + "00";
                string seqstr = DateTime.Now.ToString("HHmmssff");
                
                mPCommodity.SetMatch(nowstr, seqstr, 1, nowstr, C.Price, 0, 0.0, 0.0, 0, 0, 0, 0);

                DoSendWrite(mPCommodity.QCommodity.Match);
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }
    }

    public class NAVCommodity
    {
        public string CommodityId = "";
        public string FeedCode = "";
        public string Exchange = "";
        public string Market = "";
        public string Session = "";
        public double Price = 0.0;
        public int Qty = 0;
        public int TotalQty = 0;
        public double Bid1P = 0.0;
        public int Bid1Q = 0;
        public double Ask1P = 0.0;
        public int Ask1Q = 0;

        public NAVCommodity(string CommodityId, string FeedCode, string Exchange, string Market, string Session)
        {
            this.CommodityId = CommodityId;
            this.FeedCode = FeedCode;
            this.Exchange = Exchange;
            this.Market = Market;
            this.Session = Session;
            this.CommodityId = CommodityId;
        }
    }

    public class Log4NetWrapper : ILogWrapper
    {
        private ILog log = null;

        public Log4NetWrapper(ILog log)
        {
            this.log = log;
        }

        #region ILogWrapper 成員

        public void Info(string msg)
        {
            log.Info(msg);
        }

        public void Debug(string msg)
        {
            log.Debug(msg);
        }

        public void Warn(string msg)
        {
            log.Warn(msg);
        }

        public void Error(string msg)
        {
            log.Error(msg);
        }

        #endregion
    }
}
