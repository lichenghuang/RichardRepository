﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace DeriLib.TSModel
{
    public delegate void ErrorHandler(string DataSource,string ErrMsg);

    public abstract class ServiceSetting
    {
        public string Service;
        public string Note;
        public string Assembly;
        public string EntityType;
        public string ServiceType;

        public ServiceSetting()
        {
        }
        public ServiceSetting(string Service, string Note)
        {
            this.Service = Service;
            this.Note = Note;
        }
    }

    public abstract class DataSourceSetting
    {
        public string Service;
        public string DataSource;
        public string Note;
        public string Assembly;
        public string EntityType;

        public DataSourceSetting()
        {
        }
        public DataSourceSetting(string Service)
        {
            this.Service = Service;         
        }
        public DataSourceSetting(string Service, string DataSource, string Note)
        {
            this.Service = Service;
            this.DataSource = DataSource;
            this.Note = Note;
        }
    }

    public interface ITSServer
    {
        int Connections { get; }
        string Service { get;}
        string Note { get; }
        bool Start();
        bool AddDataSource(ITSFactory DataSource);
        bool RemoveDataSource(string DataSource);
        Dictionary<string, ITSFactory> DataSources{get;}
        bool Close();
        List<IClientState> ClientStates { get; }
        void RemoveClientState(string IP, int Port);
        Queue ErrorQueue { get;}
        event ErrorHandler ErrorFire;
    }

    public interface ITSFactory
    {
        int SendPacketNum { get; }
        int ReceivePacketNum { get; }
        int ReadDBNum { get; }
        int WriteDBNum { get; }
        string DataSource { get; }
        string Note { get; }
        bool Start();
        bool Close();
        Queue ErrorQueue { get; }
        event ErrorHandler ErrorFire;
    }

    public interface IClientState
    {
        string IP { get; }
        int Port { get; }
        DateTime LoginTime { get; }
        List<string> SubList { get; }
        void Close();
    }
}
