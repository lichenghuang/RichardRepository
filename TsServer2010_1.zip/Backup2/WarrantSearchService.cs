﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WarrantSearch;

namespace DeriLib.WarrantSearch
{    
    public class WarrantSearchService
    {
        public List<string> GetWarrants(string filter)
        {
            if (filter != "")
                filter = " and " + filter;
                
            filter = "warrantid<>'' " + filter;
            WarrantService sWarrantService = new WarrantService();
            WarrantInfo[] f = sWarrantService.GetWarrants(filter);

            List<string> L = new List<string>();

            foreach (WarrantInfo w in f)
                L.Add(w.WarrId);

            return L;
        }
    }
}
