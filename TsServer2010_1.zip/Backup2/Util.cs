﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Runtime.Serialization;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace DeriLib
{
    public class Util
    {
        #region winInet.dll宣告
        private const short MAX_PATH = 260;
        private const short NO_ERROR = 0;
        private const short FILE_ATTRIBUTE_READONLY = 0x00000001;
        private const short FILE_ATTRIBUTE_HIDDEN = 0x00000002;
        private const short FILE_ATTRIBUTE_SYSTEM = 0x00000004;
        private const short FILE_ATTRIBUTE_DIRECTORY = 0x00000010;
        private const short FILE_ATTRIBUTE_ARCHIVE = 0x00000020;
        private const short FILE_ATTRIBUTE_NORMAL = 0x00000080;
        private const short FILE_ATTRIBUTE_TEMPORARY = 0x00000100;
        private const short FILE_ATTRIBUTE_COMPRESSED = 0x00000800;
        private const short FILE_ATTRIBUTE_OFFLINE = 0x00001000;

        private struct FILETIME
        {
            public int dwLowDateTime;
            public int dwHighDateTime;
        }

        private struct SYSTEMTIME //16 Bytes
        {
            public short wYear;
            public short wMonth;
            public short wDayOfWeek;
            public short wDay;
            public short wHour;
            public short wMinute;
            public short wSecond;
            public short wMilliseconds;
        }

        private struct WIN32_FIND_DATA
        {
            public int dwFileAttributes;
            public FILETIME ftCreationTime;
            public FILETIME ftLastAccessTime;
            public FILETIME ftLastWriteTime;
            public int nFileSizeHigh;
            public int nFileSizeLow;
            public int dwReserved0;
            public int dwReserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = MAX_PATH)]
            public string cFileName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
            public string cAlternate;
        }

        private struct INTERNET_ASYNC_RESULT
        {
            public long dwResult;
            public long dwError;
        }

        private const short ERROR_NO_MORE_FILES = 18;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern int FileTimeToSystemTime(ref FILETIME lpFileTime, ref SYSTEMTIME lpSystemTime);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int InternetConnect(int hInternetSession, string sServerName, short nServerPort, string sUsername, string sPassword, int lService, int lFlags, int lContext);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int InternetFindNextFile(int hFind, ref WIN32_FIND_DATA lpvFindData);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int FtpFindFirstFile(int hFtpSession, string lpszSearchFile, ref WIN32_FIND_DATA lpFindFileData, int dwFlags, int dwContent);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool FtpGetFile(int hFtpSession, string lpszRemoteFile, string lpszNewFile, bool fFailIfExists, int dwFlagsAndAttributes, int dwFlags, int dwContext);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool FtpPutFile(int hFtpSession, string lpszLocalFile, string lpszRemoteFile, int dwFlags, int dwContext);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool FtpSetCurrentDirectory(int hFtpSession, string lpszDirectory);
        // Initializes an application's use of the Win32 Internet functions
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern int InternetOpen(string sAgent, int lAccessType, string sProxyName, string sProxyBypassg, int lFlags);
        [DllImport("wininet.dll", SetLastError = true)]
        // Closes a single Internet handle or a subtree of Internet handles.
        private static extern short InternetCloseHandle(int hInet);
        [DllImport("wininet.dll", SetLastError = true)]
        private static extern long InternetSetStatusCallback(long hInternet, long lpfnInternetCallback);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern void MoveMemory(ref long pTo, ref long pFrom, long lSize);
        // User agent constant.
        private const string scUserAgent = "c# wininet";
        // Use registry access settings.
        private const short INTERNET_OPEN_TYPE_PRECONFIG = 0;
        private const short INTERNET_OPEN_TYPE_DIRECT = 1;
        private const short INTERNET_OPEN_TYPE_PROXY = 3;
        private const short INTERNET_INVALID_PORT_NUMBER = 0;

        private const short FTP_TRANSFER_TYPE_ASCII = 0x00000001;
        private const short FTP_TRANSFER_TYPE_BINARY = 0x00000002;
        private const int INTERNET_FLAG_PASSIVE = 0x08000000;
        // Type of service to access.
        private const short INTERNET_SERVICE_FTP = 1;
        private const short INTERNET_SERVICE_GOPHER = 2;
        private const short INTERNET_SERVICE_HTTP = 3;
        // Brings the data across the wire even if it locally cached.
        private const uint INTERNET_FLAG_RELOAD = 0x80000000;
        private const int INTERNET_FLAG_KEEP_CONNECTION = 0x00400000;
        private const int INTERNET_FLAG_MULTIPART = 0x00200000;

        private const int INTERNET_FLAG_DONT_CACHE = 0x00400000;
        private const int INTERNET_FLAG_EXISTING_CONNECT = 0x00200000;

        #endregion
        #region ReadWriteINI宣告
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
        #endregion

        public static DataView ExecSqlQry(string sql, string connstr)
        {
            SqlConnection conn = new SqlConnection(connstr);

            try
            {
                SqlDataAdapter adp = new SqlDataAdapter();
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.Text;

                adp.SelectCommand = cmd;
                DataSet ds = new DataSet("TMP");
                adp.Fill(ds);
                DataView iDataView = ds.Tables[0].DefaultView;

                conn.Close();
                return iDataView;
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                throw ex;
            }
        }
        public static bool ExecSqlCmd(string sql, string connstr)
        {
            SqlConnection conn = new SqlConnection(connstr);

            try
            {
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                cmd.CommandTimeout = 300;
                cmd.ExecuteNonQuery();                
                conn.Close();
                return true;
            }
            catch (Exception ex)
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                throw ex;
            }
        }
        public static bool FunChechSum(byte[] nCheckByte, byte nCheckSum)
        {
            //byte[] nCheckByte;

            int XORMask = 0;

            //以Bit處理結果和以Byte相同
            //nCheckByte = Big5.GetBytes(sChechSum);
            try
            {
                for (int nCount = 0; nCount < nCheckByte.Length; nCount++)
                    XORMask ^= nCheckByte[nCount];

                if (XORMask != (int)nCheckSum)
                    return false;
                else
                    return true;
            }
            catch
            {
                return false;
            }
        }
        public static void WriteIniString(string section, string key, string val, string filePath)
        {
            WritePrivateProfileString(section, key, val, filePath);
        }
        public static string ReadIniString(string section, string key, string filePath)
        {
            StringBuilder temp = new StringBuilder(255);
            GetPrivateProfileString(section, key, "", temp, 255, filePath);
            return temp.ToString();
        }
        public static bool IsNaturalNumber(string str)
        {
            System.Text.RegularExpressions.Regex reg1 = new System.Text.RegularExpressions.Regex(@"^[A-Za-z0-9]+$");
            return reg1.IsMatch(str);
        }
    }
    public class dMath
    {
        private static double StandardDeviation(double[] data)
        {
            double ret = 0;
            double DataAverage = 0;
            double TotalVariance = 0;
            int Max = 0;
         
            try
            {

              Max = data.Length;
        				
              if (Max == 0) { return ret; }

              DataAverage = Average(data);

              for(int i=0;i<Max;i++)
              {
                TotalVariance += Math.Pow(data[i] - DataAverage,2); 
              }

              ret = Math.Sqrt(SafeDivide(TotalVariance,Max));

            }
            catch (Exception) { throw; }
            return ret;
        }

        private static double Average(double[] data)
        {
            double ret = 0;
            double DataTotal = 0;
         
            try
            {
         
              for(int i=0;i<data.Length;i++)
              {
                DataTotal += data[i]; 
              }

              return SafeDivide(DataTotal,data.Length);

            }
            catch (Exception) { throw; }
        }

        private static double SafeDivide(double value1,double value2)
        {
            double ret = 0;

            try
            {

              if ((value1 == 0) || ( value2 == 0)) { return ret; }

              ret =  value1 / value2;
            
            }
            catch (Exception) { throw; }
            return ret;
        }
    }
}
