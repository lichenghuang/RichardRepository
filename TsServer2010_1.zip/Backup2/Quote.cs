﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.IO.Pipes;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
//using NDde;

//using GC.DerivMonitor.PriceModel;

namespace DeriLib.Quote
{
    [ServiceBehavior(
        InstanceContextMode = InstanceContextMode.Single, 
        ConcurrencyMode = ConcurrencyMode.Multiple        
        )]
    public class Quote : IQuoteClient, IDisposable, DeriLib.TSModel.ITSServer
    {
        #region 變數宣告
        private CMarketList m_CMarketList = null;        
        private QuoteSourceList m_QuoteSourceList = null;
        private PCommodityList m_PCommodityList = null;        
        private ClientStateList m_ClientStateList = null;
        
        private QuoteSetting Setting = null;
        private Thread RoutineThread;
        private Thread SendQuoteThread;
        private Thread WriteH1TicksThread;
        private Thread WriteH5TicksThread;
        private Thread WritePipeThread;
        private StreamWriter gStateLog = null;//錯誤寫檔
        private bool notFinishFirstWork = false;
        private Queue m_ErrQueue = Queue.Synchronized(new Queue());
        private Queue m_ErrQueueOut = Queue.Synchronized(new Queue());
        private SqlCommand cmdH1Ticks;
        private SqlCommand cmdH5Ticks;
        private SqlConnection aconn;
        private SqlConnection bconn;
        #endregion

        public Quote(QuoteSetting Setting)
        {
            try
            {
                this.Setting = Setting;

                IniValue();                
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][Quote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void IniValue()
        {
            try
            {
                IniStateLogLog();
                m_CMarketList = new CMarketList(Setting.DBConnectString);
                m_PCommodityList = new PCommodityList(Setting, m_CMarketList);
                m_ClientStateList = new ClientStateList();
                m_QuoteSourceList = new QuoteSourceList();
                
                CmdStore();
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][IniValue_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void AddQuoteSource(QuoteSource QuoteSource)
        {            
            if (!m_QuoteSourceList.ContainKey(QuoteSource.QuoteSetting.DataSource))
            {
                try
                {
                    QuoteSource.PCommodityList = m_PCommodityList;
                    QuoteSource.CMarket = m_CMarketList.Get(QuoteSource.QuoteSetting.Market);
                    m_QuoteSourceList.Set(QuoteSource);
                    if (QuoteSource.QuoteSetting.DBConnectString == "")
                        QuoteSource.QuoteSetting.DBConnectString = Setting.DBConnectString;
                    QuoteSource.Start();
                }
                catch (Exception ex)
                {
                    m_QuoteSourceList.Remove(QuoteSource.DataSource);
                    QuoteSource.Close();
                    throw ex;
                }
            }
            else
            {
                QuoteSource.Close();                
            }           
        }
        private void RemoveQuoteSource(string DataSource)
        {
            m_QuoteSourceList.Remove(DataSource);         
        }
        private PCommodityList PCommodityList
        {
            get { return m_PCommodityList; }
        }
        private CMarketList CMarketList
        {
            get { return m_CMarketList; }
        }
        private QuoteSourceList QuoteSourceList
        {
            get { return m_QuoteSourceList; }
        }
        private ClientStateList ClientStateList
        {
            get { return m_ClientStateList; }
        }
        private void IniStateLogLog()
        {
            try
            {
                if (gStateLog != null) { gStateLog.Close(); }
                    
                gStateLog = File.AppendText(Setting.LogFileFolder + "\\" + DateTime.Today.ToString("yyyyMMdd") + "TsQuote_StateLog.txt");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][IniLog_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void RoutineWork()
        {
            try
            {
                int count = 0;
                TimeSpan alivediff = new TimeSpan(0,1,0);

                for (; ; )
                {
                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        notFinishFirstWork = true;
                    }

                    if (DateTime.Now.TimeOfDay.TotalHours >= 1.1 && DateTime.Now.TimeOfDay.TotalHours < 1.2 && notFinishFirstWork)
                    {
                        try
                        {
                            IniStateLogLog();
                            ClearNonMarketPacketNum();
                            
                            foreach (CMarket CMarket in m_CMarketList.Markets)
                            {
                                if (Setting.IsExecuteSchedule)
                                    Util.ExecSqlCmd("EXEC spTransLClose " + ((int)CMarket.Market).ToString(), Setting.DBConnectString);
                            }

                            m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][RoutineWork]First Work Have Finished!");
                            notFinishFirstWork = false;
                        }
                        catch (Exception ex3)
                        {
                            m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                        }
                    }

                    foreach (CMarket CMarket in m_CMarketList.Markets)
                    {
                        if (CMarket.OpenTime == string.Empty || CMarket.CloseTime == string.Empty) { continue; }

                        
                        DateTime dt = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, CMarket.TimeZone);
                        TimeSpan nowts = new TimeSpan(dt.Hour, dt.Minute, 0);
                        TimeSpan opents = new TimeSpan(int.Parse(CMarket.OpenTime.Substring(0, 2)), int.Parse(CMarket.OpenTime.Substring(2, 2)), 0);
                        TimeSpan closets = new TimeSpan(int.Parse(CMarket.CloseTime.Substring(0, 2)), int.Parse(CMarket.CloseTime.Substring(2, 2)), 0);

                        if (CMarket.TradeDate.Date != dt.Date)
                        {
                            CMarket.TradeDate = dt.Date;
                            CMarket.IsTrade = CheckTradeDay(CMarket.Market, dt.Date.ToString("yyyyMMdd"));
                            CMarket.OpenWorkFlag = false;
                            CMarket.OpenWorkFlag2 = false;
                            CMarket.OpenWorkFlag3 = false;
                            CMarket.CloseWorkFlag = false;
                            CMarket.CloseWorkFlag2 = false;
                        }

                        if (Math.Abs(nowts.Subtract(opents.Subtract(new TimeSpan(2, 0, 0))).TotalMinutes) < 1 && !CMarket.OpenWorkFlag)
                        {
                            CMarket.OpenWorkFlag = true;
                            ThreadPool.QueueUserWorkItem(new WaitCallback(OpenWork), CMarket);
                        }
                        if (Math.Abs(nowts.Subtract(opents.Subtract(new TimeSpan(0, 30, 0))).TotalMinutes) < 1 && !CMarket.OpenWorkFlag2 && CMarket.IsTrade)
                        {
                            CMarket.OpenWorkFlag2 = true;
                            ThreadPool.QueueUserWorkItem(new WaitCallback(OpenWork2), CMarket);                          
                        }
                        if (Math.Abs(nowts.Subtract(opents.Subtract(new TimeSpan(0, 5, 0))).TotalMinutes) < 1 && !CMarket.OpenWorkFlag3 && CMarket.IsTrade)
                        {                         
                            CMarket.OpenWorkFlag3 = true;
                            ThreadPool.QueueUserWorkItem(new WaitCallback(OpenWork3), CMarket);                                                        
                        }
                        if (Math.Abs(nowts.Subtract(closets.Add(new TimeSpan(0, 15, 0))).TotalMinutes) < 1 && !CMarket.CloseWorkFlag && CMarket.IsTrade)
                        {
                            CMarket.CloseWorkFlag = true;
                            ThreadPool.QueueUserWorkItem(new WaitCallback(CloseWork), CMarket);                                                       
                        }
                    }

                    while (m_QuoteSourceList.ErrPool.Count > 0)
                    {
                        m_ErrQueue.Enqueue(m_QuoteSourceList.ErrPool.Dequeue().ToString());

                        if (m_ErrQueue.Count > 100)
                            m_ErrQueue.Dequeue();
                    }

                    while (m_ErrQueue.Count > 0)
                    {
                        string errstr = m_ErrQueue.Dequeue().ToString();
                        m_ErrQueueOut.Enqueue(errstr);
                        WriteToStateLog(errstr);
                    }

                    count++;
                    if (count == 7200) { count = 0; }

                    if (count % 60 == 0)
                    {
                        foreach (ClientState ClientState in m_ClientStateList.ClientStates)
                        {
                            try
                            {
                                ICommunicationObject commObj = ClientState.Callback as ICommunicationObject;
                                
                                if (commObj != null && (commObj.State == CommunicationState.Closed))                                
                                    m_ClientStateList.Remove(ClientState.Callback);                                
                                else if (ClientState != null && DateTime.Now.Subtract(ClientState.AliveTime) > alivediff)
                                    m_ClientStateList.Remove(ClientState.Callback);
                            }
                            catch (Exception ex)
                            {
                                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                            }
                        }
                    }

                    /*if (count == 36000)
                    {
                        m_PCommodityList.ClearExpireCommodity();
                    }

                    if (count == 7200)
                    {
                        foreach (PCommodity PCommodity in m_PCommodityList.Commoditys)
                        {
                            if (PCommodity.Subscribes.Count == 0 && PCommodity.CMarket == null)
                                m_PCommodityList.Remove(PCommodity.CommodityId);
                        }

                        foreach (ClientState ClientState in m_ClientStateList.ClientStates)
                        {
                            if (ClientState.SubList.Count == 0)
                                m_ClientStateList.Remove(ClientState.Callback);
                        }
                    }*/

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void SendQuoteWork()
        {
            try
            {
                for (; ; )
                {
                    try
                    {
                        //foreach (ClientState C in m_ClientStateList.ClientStates)
                        //    C.SendData();
                    }
                    catch (Exception ex3)
                    {
                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][SendQuoteWork_Error] " + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][SendQuoteWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void WriteH1TicksWork()
        {
            try
            {
                string nowmatchtime = "";
                string oldmatchtime = "";
                TimeSpan wts = new TimeSpan(8, 46, 0);
                TimeSpan wte = new TimeSpan(13, 50, 0);
                TimeSpan swts = new TimeSpan(9, 1, 0);
                TimeSpan swte = new TimeSpan(13, 35, 0);
                int i = 0;

                for (; ; )
                {
                    try
                    {
                        if (DateTime.Now.TimeOfDay >= wts && DateTime.Now.TimeOfDay <= wte)
                        {
                            DateTime dt = DateTime.Now;
                            nowmatchtime = dt.ToString("HHmm00");

                            if (oldmatchtime != nowmatchtime)
                            {
                                i = 0;

                                foreach (PCommodity P in m_PCommodityList.Commoditys)
                                {
                                    try
                                    {
                                        /*if (P.QCommodity.Base.CommodityKind == CommodityKind.Future || P.QCommodity.Base.CommodityKind == CommodityKind.Index || P.QCommodity.Base.CommodityKind == CommodityKind.ETF || P.QCommodity.Base.CommodityId == "2827.HK")
                                        {
                                            bool exitflag = false;

                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Future && !(P.CommodityId.IndexOf("EXF") > -1 || P.CommodityId.IndexOf("FXF") > -1 || P.CommodityId.IndexOf("TXF") > -1 || P.CommodityId.IndexOf("MXF") > -1 || P.CommodityId.IndexOf("TWS") > -1))
                                                exitflag = true;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Future && P.CommodityId.IndexOf("/") > -1)
                                                exitflag = true;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Index && (P.CommodityId != "1000" && P.CommodityId != "4000" && P.CommodityId != "1014"))
                                                exitflag = true;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.ETF && (P.CommodityId != "0050" && P.CommodityId != "0050R" && P.CommodityId != "0055" && P.CommodityId != "0055R" && P.CommodityId != "0061"))
                                                exitflag = true;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Stock && P.CommodityId != "2827.HK")
                                                exitflag = true;

                                            if (exitflag) { continue; }*/
                                        if (P.QCommodity.Base.CommodityKind == CommodityKind.CB || P.QCommodity.Base.CommodityKind == CommodityKind.ETF || P.QCommodity.Base.CommodityKind == CommodityKind.Future || P.QCommodity.Base.CommodityKind == CommodityKind.Index || P.QCommodity.Base.CommodityKind == CommodityKind.REITs || P.QCommodity.Base.CommodityKind == CommodityKind.Stock || P.QCommodity.Base.CommodityKind == CommodityKind.TDR)
                                        {
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Future && !(P.CommodityId.IndexOf("EXF") > -1 || P.CommodityId.IndexOf("FXF") > -1 || P.CommodityId.IndexOf("TXF") > -1 || P.CommodityId.IndexOf("MXF") > -1 || P.CommodityId.IndexOf("TWS") > -1))
                                                continue;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Future && P.CommodityId.IndexOf("/") > -1)
                                                continue;
                                            if (P.QCommodity.Base.CommodityKind != CommodityKind.Future && (DateTime.Now.TimeOfDay < swts || DateTime.Now.TimeOfDay > swte))
                                                continue;

                                            if (!m_CMarketList.Get(Market.TSE).IsTrade) { continue; }

                                            if (bconn.State == ConnectionState.Closed) { bconn.Open(); }

                                            cmdH1Ticks.Parameters["@CommodityId"].Value = P.CommodityId;
                                            cmdH1Ticks.Parameters["@MatchTime"].Value = nowmatchtime;
                                            cmdH1Ticks.Parameters["@MatchPrice"].Value = P.QCommodity.Match.MatchPrice;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Index)
                                                cmdH1Ticks.Parameters["@MatchTotalQty"].Value = Convert.ToInt64(P.QCommodity.Match.MatchTotalAmt);
                                            else
                                                cmdH1Ticks.Parameters["@MatchTotalQty"].Value = P.QCommodity.Match.MatchTotalQty;
                                            cmdH1Ticks.Parameters["@BuyPriceBest1"].Value = P.QCommodity.Best5.BuyPriceBest1;
                                            cmdH1Ticks.Parameters["@BuyQtyBest1"].Value = P.QCommodity.Best5.BuyQtyBest1;
                                            cmdH1Ticks.Parameters["@SellPriceBest1"].Value = P.QCommodity.Best5.SellPriceBest1;
                                            cmdH1Ticks.Parameters["@SellQtyBest1"].Value = P.QCommodity.Best5.SellQtyBest1;

                                            cmdH1Ticks.ExecuteNonQuery();
                                            i++;
                                            if (i % 100 == 0) { Thread.Sleep(1); }
                                        }
                                    }
                                    catch (Exception ex3)
                                    {
                                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteH1TicksWork_Error]["+P.CommodityId+"]" + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                                    }
                                }

                                oldmatchtime = nowmatchtime;
                            }
                        }
                    }
                    catch (Exception ex3)
                    {
                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteH1TicksWork_Error] " + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteH5TicksWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void WriteH5TicksWork()
        {
            try
            {
                string nowmatchtime = "";
                string oldmatchtime = "";
                TimeSpan wts = new TimeSpan(8, 50, 0);
                TimeSpan wte = new TimeSpan(13, 50, 0);
                TimeSpan swts = new TimeSpan(9, 5, 0);
                TimeSpan swte = new TimeSpan(13, 35, 0);
                int i = 0;

                for (; ; )
                {
                    try
                    {
                        if (DateTime.Now.TimeOfDay >= wts && DateTime.Now.TimeOfDay <= wte)
                        {
                            DateTime dt = DateTime.Now;
                            nowmatchtime = dt.ToString("HHmm00");

                            if (oldmatchtime != nowmatchtime && int.Parse(dt.ToString("mm")) % 5 == 0)
                            {
                                i = 0;

                                foreach (PCommodity P in m_PCommodityList.Commoditys)
                                {
                                    try
                                    {
                                        if (P.QCommodity.Base.CommodityKind == CommodityKind.CB || P.QCommodity.Base.CommodityKind == CommodityKind.ETF || P.QCommodity.Base.CommodityKind == CommodityKind.Future || P.QCommodity.Base.CommodityKind == CommodityKind.Index || P.QCommodity.Base.CommodityKind == CommodityKind.REITs || P.QCommodity.Base.CommodityKind == CommodityKind.Stock || P.QCommodity.Base.CommodityKind == CommodityKind.TDR )
                                        {
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Future && !(P.CommodityId.IndexOf("EXF") > -1 || P.CommodityId.IndexOf("FXF") > -1 || P.CommodityId.IndexOf("TXF") > -1 || P.CommodityId.IndexOf("MXF") > -1 || P.CommodityId.IndexOf("TWS") > -1))
                                                continue;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Future && P.CommodityId.IndexOf("/") > -1)
                                                continue;
                                            if (P.QCommodity.Base.CommodityKind != CommodityKind.Future && (DateTime.Now.TimeOfDay < swts || DateTime.Now.TimeOfDay > swte))
                                                continue;

                                            if (!m_CMarketList.Get(Market.TSE).IsTrade) { continue; }

                                            if (aconn.State == ConnectionState.Closed) { aconn.Open(); }

                                            cmdH5Ticks.Parameters["@CommodityId"].Value = P.CommodityId;
                                            cmdH5Ticks.Parameters["@MatchTime"].Value = nowmatchtime;
                                            cmdH5Ticks.Parameters["@MatchPrice"].Value = P.QCommodity.Match.MatchPrice;
                                            if (P.QCommodity.Base.CommodityKind == CommodityKind.Index)
                                                cmdH5Ticks.Parameters["@MatchTotalQty"].Value = Convert.ToInt64(P.QCommodity.Match.MatchTotalAmt);
                                            else
                                                cmdH5Ticks.Parameters["@MatchTotalQty"].Value = P.QCommodity.Match.MatchTotalQty;
                                            cmdH5Ticks.Parameters["@BuyPriceBest1"].Value = P.QCommodity.Best5.BuyPriceBest1;
                                            cmdH5Ticks.Parameters["@BuyQtyBest1"].Value = P.QCommodity.Best5.BuyQtyBest1;
                                            cmdH5Ticks.Parameters["@SellPriceBest1"].Value = P.QCommodity.Best5.SellPriceBest1;
                                            cmdH5Ticks.Parameters["@SellQtyBest1"].Value = P.QCommodity.Best5.SellQtyBest1;

                                            cmdH5Ticks.ExecuteNonQuery();
                                            i++;
                                            if (i % 100 == 0) { Thread.Sleep(1); }
                                        }
                                    }
                                    catch (Exception ex3)
                                    {
                                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteH5TicksWork_Error]["+P.CommodityId+"]" + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                                    }
                                }

                                oldmatchtime = nowmatchtime;
                            }
                        }
                    }
                    catch (Exception ex3)
                    {
                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteH5TicksWork_Error] " + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteH5TicksWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void WritePipeWork()
        {
            try
            {
                NamedPipeClientStream NP = new NamedPipeClientStream(".", "Ticks");
                StreamWriter sw = null;

                for (; ; )
                {
                    try
                    {
                        if (!NP.IsConnected)                         
                        { 
                            NP.Connect(500);
                            sw = new StreamWriter(NP);
                            sw.AutoFlush = true;
                        }
                    }
                    catch (Exception exx)
                    {
                        string gg = "";
                    }

                    foreach (QuoteSource QS in m_QuoteSourceList.QuoteSources)
                    {
                        try
                        {
                            while (QS.TicksPool.Count > 0)
                            {
                                string str = QS.TicksPool.Dequeue().ToString();

                                if (NP.IsConnected) { sw.WriteLine(str); }
                                    
                                /*object obj = QS.TicksPool.Dequeue();
                                PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

                                StringBuilder str = new StringBuilder();
                                str.Append(mPCommodity.QCommodity.Base.CommodityId);

                                str.Append("," + mPCommodity.QCommodity.Base.CommodityId);
                                str.Append("," + mPCommodity.QCommodity.Match.MatchTime);
                                str.Append("," + mPCommodity.QCommodity.Match.MatchPrice);
                                str.Append("," + mPCommodity.QCommodity.Match.MatchQty);
                                str.Append("," + mPCommodity.QCommodity.Match.MatchTotalQty);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest1);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest1);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest2);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest2);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest3);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest3);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest4);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest4);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest5);
                                str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest5);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest1);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest1);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest2);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest2);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest3);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest3);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest4);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest4);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest5);
                                str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest5);

                                if (NP.IsConnected)
                                    sw.WriteLine(str.ToString());*/     
                            }
                        }
                        catch (Exception ex)
                        {
                            m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WritePipeWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WritePipeWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ClearNonMarketPacketNum()
        {
            try
            {
                foreach (QuoteSource iQuoteSource in m_QuoteSourceList.QuoteSources)
                {
                    if (iQuoteSource.CMarket == null)
                        iQuoteSource.SetReceivePacket(0);
                }
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ClearNonMarketPacketNum_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void OpenWork(Object stateInfo)
        {
            try
            {
                CMarket CMarket = (CMarket)stateInfo;

                CMarket.TransLastClosePrice();
                CMarket.ClearHIVExtra();

                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][OpenWork]" + CMarket.MarketId + " Open Work 1 Have Finished!");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][OpenWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }       
        private void OpenWork2(Object stateInfo)
        {
            try
            {
                CMarket CMarket = (CMarket)stateInfo;

                CMarket.CommoditysClear();
                CMarket.InnerCodeClear();
                CMarket.InitialQuoteSourcePacketNum();

                if (Setting.IsExecuteSchedule)
                    Util.ExecSqlCmd("EXEC spClearTmpTable " + ((int)CMarket.Market).ToString(), Setting.DBConnectString);

                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][OpenWork]" + CMarket.MarketId + " Open Work 2 Have Finished!");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][OpenWork2_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void OpenWork3(Object stateInfo)
        {
            try
            {
                CMarket CMarket = (CMarket)stateInfo;

                CMarket.MarketClear();

                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][OpenWork]" + CMarket.MarketId + " Open Work 3 Have Finished!");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][OpenWork3_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }         
        private void CloseWork(Object stateInfo)
        {
            try
            {
                CMarket CMarket = (CMarket)stateInfo;

                //if (CMarket.Subscribes.Count > 0)
                //    return;

                foreach (PCommodity PCommodity in CMarket.Commoditys)
                {
                    try
                    {
                        /*if (CMarket.IsTrade && PCommodity.Subscribes.Count == 0)
                            m_PCommodityList.Remove(PCommodity.CommodityId);*/
                        if (PCommodity.QCommodity.Extra != null && PCommodity.QCommodity.Extra.Maturity.AddDays(7) < DateTime.Today)
                                m_PCommodityList.Remove(PCommodity.CommodityId);                        
                    }
                    catch (Exception ex)
                    {
                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][CloseWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                    }
                }

                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][CloseWork]" + CMarket.MarketId + " Close Work 1 Have Finished!");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][CloseWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        #region Method

        public void Start()
        {
            try
            {
                RoutineThread = new Thread(new ThreadStart(RoutineWork));
                RoutineThread.Start();

                SendQuoteThread = new Thread(new ThreadStart(SendQuoteWork));
                SendQuoteThread.Start();

                if (Setting.IsWriteH5Ticks)
                {
                    m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][Enable WriteH5Ticks]");
                    WritePipeThread = new Thread(new ThreadStart(WritePipeWork));
                    WritePipeThread.Start();

                    WriteH1TicksThread = new Thread(new ThreadStart(WriteH1TicksWork));
                    WriteH1TicksThread.Start();

                    WriteH5TicksThread = new Thread(new ThreadStart(WriteH5TicksWork));
                    WriteH5TicksThread.Start();
                }
               
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][TsQuote Started]");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        public void Close()
        {
            try
            {
                if (Setting.IsWriteH5Ticks && WriteH1TicksThread != null && WriteH1TicksThread.IsAlive) { WriteH1TicksThread.Abort(); }
                if (Setting.IsWriteH5Ticks && WriteH5TicksThread != null && WriteH5TicksThread.IsAlive) { WriteH5TicksThread.Abort(); }
                if (Setting.IsWriteH5Ticks && WritePipeThread != null && WritePipeThread.IsAlive) { WritePipeThread.Abort(); }
                if (SendQuoteThread != null && SendQuoteThread.IsAlive) { SendQuoteThread.Abort(); }                
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }                
                if (m_QuoteSourceList != null) { m_QuoteSourceList.Close(); }                
                if (m_PCommodityList != null) { m_PCommodityList.Close(); }                
                if (m_CMarketList != null) { m_CMarketList.Close(); }                
                if (m_ClientStateList != null) { m_ClientStateList.Close(); }                

                WriteToStateLog("[Quote][" + DateTime.Now.ToString() + "][TsQuote Closed]");

                gStateLog.Close();
            }
            catch (Exception ex)
            {
                WriteToStateLog("[Quote][" + DateTime.Now.ToString() + "][Close_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private bool CheckTradeDay(Market Market,string TodayStr)//判斷是否為交易日
        {
            bool sIsTradeDay = true;
            
            try
            {
                string sql = "select istrade from tradedate where convert(varchar,tradedate,112)='" + TodayStr + "'";
                DataView dv = Util.ExecSqlQry(sql, Setting.DBConnectString);

                if (dv.Count > 0)                
                    sIsTradeDay = dv[0]["IsTrade"].ToString() == "Y" ? true : false;

                return sIsTradeDay;
            }
            catch (Exception ex)
            {
                return sIsTradeDay;
            }
        }
        private void WriteToStateLog(string str)
        {
            try
            {
                lock (gStateLog)
                {
                    gStateLog.WriteLine(str);
                    gStateLog.Flush();
                }
            }
            catch (Exception ex)
            {
            }
        }
        private void CmdStore()
        {
            cmdH1Ticks = new SqlCommand("spH1Ticks");
            cmdH1Ticks.CommandType = CommandType.StoredProcedure;
            cmdH5Ticks = new SqlCommand("spH5Ticks");
            cmdH5Ticks.CommandType = CommandType.StoredProcedure;

            aconn = new SqlConnection(Setting.DBConnectString);
            cmdH5Ticks.Connection = aconn;
                        
            cmdH5Ticks.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdH5Ticks.Parameters.Add("@MatchTime", SqlDbType.VarChar, 8);
            cmdH5Ticks.Parameters.Add("@MatchPrice", SqlDbType.Float);            
            cmdH5Ticks.Parameters.Add("@MatchTotalQty", SqlDbType.BigInt);
            cmdH5Ticks.Parameters.Add("@BuyPriceBest1", SqlDbType.Float);
            cmdH5Ticks.Parameters.Add("@BuyQtyBest1", SqlDbType.Int);            
            cmdH5Ticks.Parameters.Add("@SellPriceBest1", SqlDbType.Float);
            cmdH5Ticks.Parameters.Add("@SellQtyBest1", SqlDbType.Int);

            bconn = new SqlConnection(Setting.DBConnectString);
            cmdH1Ticks.Connection = bconn;

            cmdH1Ticks.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdH1Ticks.Parameters.Add("@MatchTime", SqlDbType.VarChar, 8);
            cmdH1Ticks.Parameters.Add("@MatchPrice", SqlDbType.Float);
            cmdH1Ticks.Parameters.Add("@MatchTotalQty", SqlDbType.BigInt);
            cmdH1Ticks.Parameters.Add("@BuyPriceBest1", SqlDbType.Float);
            cmdH1Ticks.Parameters.Add("@BuyQtyBest1", SqlDbType.Int);
            cmdH1Ticks.Parameters.Add("@SellPriceBest1", SqlDbType.Float);
            cmdH1Ticks.Parameters.Add("@SellQtyBest1", SqlDbType.Int);            
        }
        /*private string GetCommodityIdFromSysCode(string SYSCommodityId)
        {
            try
            {
                string SYSCode = "";
                string Code = "";
                string CommodityId = "";
                string month = "";

                if (SYSCommodityId.IndexOf("W") == -1) { return SYSCommodityId; }
                if (SYSCommodityId.Length == 5){SYSCode = SYSCommodityId.Substring(0,3);}
                else if (SYSCommodityId.Length == 6) { SYSCode = SYSCommodityId.Substring(0, 4); }
                else { return SYSCommodityId; }

                if (SYSCommodityId.Substring(SYSCommodityId.Length - 2, 2) != "AA" && SYSCommodityId.Substring(SYSCommodityId.Length - 2, 2) != "AB")
                {
                    month = SYSCommodityId.Substring(SYSCommodityId.Length - 2, 1);
                    month = m_PCommodityList.GetTFEMonth(month);
                    if (month == "") { return SYSCommodityId; }
                    month += SYSCommodityId.Substring(SYSCommodityId.Length - 1, 1);
                }   
                else
                    month = SYSCommodityId.Substring(SYSCommodityId.Length - 2, 2);
                
                foreach (CMarket iCMarket in m_CMarketList.Markets)
                {
                    Code = iCMarket.GetCode(SYSCode);
                    if (Code != "") { break; }
                }

                CommodityId = Code + "F" + month;

                return CommodityId;
                
            }
            catch (Exception ex)
            {
                WriteToStateLog("[Quote][" + DateTime.Now.ToString() + "][GetCommodityIdFromSysCode_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return SYSCommodityId;
            }
        }
        private string GetCommodityIdFromLastCode(string CommodityId)
        {
            try
            {
                CodeMap CodeMap = null;

                if (CommodityId.Length != 5 && CommodityId.Substring(CommodityId.Length - 2, 2) != "AA" && CommodityId.Substring(CommodityId.Length - 2, 2) != "AB")
                    return CommodityId;

                string Code = CommodityId.Substring(0, 2);
                
                foreach (CMarket iCMarket in m_CMarketList.Markets)
                {
                    CodeMap  = iCMarket.GetCodeMap(CommodityKind.Future, Code);
                    if (CodeMap != null) { break; }
                }

                if (CodeMap == null) { return CommodityId; }

                PCommodity PCommodity = CodeMap.GetCommodity(CommodityId.Substring(CommodityId.Length - 2, 2));

                if (PCommodity != null) { CommodityId = PCommodity.CommodityId; }


                return CommodityId;

            }
            catch (Exception ex)
            {
                WriteToStateLog("[Quote][" + DateTime.Now.ToString() + "][GetCommodityIdFromLastCode_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return CommodityId;
            }
        }*/
        #endregion

        #region IDisposable 成員

        public void Dispose()
        {
            Close();
        }

        #endregion

        #region IQuoteClient 成員

        List<string> IQuoteClient.SubCommodity(List<string> CommodityList)
        {
            try
            {
                //IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                
                ClientState ClientState = m_ClientStateList.Set(OperationContext.Current);

                foreach (string CommodityId in CommodityList)
                {
                    string jCommodityId = "";

                    try
                    {
                        jCommodityId = CommodityId.ToUpper().Trim();
                        if (jCommodityId.IndexOf("/") > -1) { continue; }

                        if (ClientState.SubList.Contains(jCommodityId)) { continue; }

                        CMarket mCMarket = m_CMarketList.Get(jCommodityId);

                        if (mCMarket == null)
                        {

                            if (jCommodityId == "FQUERY")
                            {
                                PCommodityList.FQuery.Set(ClientState);
                                ClientState.Set(PCommodityList.FQuery);
                                continue;
                            }
                            if (jCommodityId == "OQUERY")
                            {
                                PCommodityList.OQuery.Set(ClientState);
                                ClientState.Set(PCommodityList.OQuery);
                                continue;
                            }
                            /*string lCommodityId = GetCommodityIdFromSysCode(jCommodityId);
                            lCommodityId = GetCommodityIdFromLastCode(lCommodityId);*/
                            //string lCommodityId = jCommodityId;

                            //PCommodity PCommodity = m_PCommodityList.Get(lCommodityId);

                            /*bool localhascommodity = PCommodity == null ? false : true;

                           PCommodity = m_PCommodityList.Set(lCommodityId);

                           if (!localhascommodity) { PCommodity.IsLocalCommodity = false; }

                           
                           if (!PCommodity.IsLocalCommodity && !m_QuoteSourceList.MarketExit(PCommodity.CMarket))*/
                            PCommodity PCommodity = m_PCommodityList.Set(jCommodityId);

                            if (!PCommodity.IsLocalCommodity && !m_QuoteSourceList.MarketExit(PCommodity.CMarket))
                            {
                                QuoteSource jQuoteSource = m_QuoteSourceList.GetWCFQuoteSource();

                                //if (jQuoteSource != null && !((WCFQuoteSource)jQuoteSource).IsPermanentCommodity(PCommodity)) 
                                if (jQuoteSource != null && !((WCFQuoteSource)jQuoteSource).IsPermanentCommodity(PCommodity) && !((WCFQuoteSource)jQuoteSource).ClientSubCommoditys.Contains(PCommodity.CommodityId))
                                {
                                    List<string> L = new List<string>();
                                    L.Add(PCommodity.CommodityId);
                                    ((WCFQuoteSource)jQuoteSource).AddClientSubCommodity(PCommodity.CommodityId);
                                    ((WCFQuoteSource)jQuoteSource).ReSubCommodity(L);
                                }
                            }

                            if (PCommodity != null && PCommodity.QCommodity != null && PCommodity.QCommodity.Base != null)
                            {
                                PCommodity.Set(ClientState);
                                ClientState.Set(PCommodity);

                                ClientState.AddData(PCommodity.QCommodity);
                            }
                        }
                        else
                        {
                            mCMarket.SetSubscribe(ClientState);
                            ClientState.Set(mCMarket);

                            foreach (PCommodity PCommodity in mCMarket.Commoditys)
                                ClientState.AddData(PCommodity.QCommodity);
                        }
                    }
                    catch (Exception ex)
                    {
                        m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][SubCommodity_Error][" + jCommodityId + "]" + "[" + ex.Message + "][" + ex.StackTrace + "]");                     
                    }
                }

                return ClientState.SubList;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][SubCommodity_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }
        }
        List<string> IQuoteClient.UnSubCommodity(List<string> CommodityList)
        {
            try
            {
                //IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                ClientState ClientState = m_ClientStateList.Set(OperationContext.Current);

                foreach (string CommodityId in CommodityList)
                {
                    string jCommodityId = CommodityId.ToUpper().Trim();

                    if (jCommodityId.IndexOf("/") > -1) { continue; }

                    CMarket mCMarket = m_CMarketList.Get(jCommodityId);

                    if (mCMarket == null)
                    {
                        if (jCommodityId == "FQUERY")
                        {
                            PCommodityList.FQuery.Remove(ClientState);
                            ClientState.Remove(PCommodityList.FQuery);
                            continue;
                        }
                        if (jCommodityId == "OQUERY")
                        {
                            PCommodityList.OQuery.Remove(ClientState);
                            ClientState.Remove(PCommodityList.OQuery);
                            continue;
                        }
                        //string lCommodityId = GetCommodityIdFromSysCode(jCommodityId);                        
                        //lCommodityId = GetCommodityIdFromLastCode(lCommodityId);
                        //string lCommodityId = jCommodityId;

                        PCommodity PCommodity = m_PCommodityList.Get(jCommodityId);

                        if (PCommodity != null)
                        {
                            PCommodity.Remove(ClientState);
                            ClientState.Remove(PCommodity);

                            if (PCommodity.Subscribes.Count == 0 && !PCommodity.IsLocalCommodity && !m_QuoteSourceList.MarketExit(PCommodity.CMarket))
                            {
                                QuoteSource jQuoteSource = m_QuoteSourceList.GetWCFQuoteSource();

                                if (jQuoteSource != null && !((WCFQuoteSource)jQuoteSource).IsPermanentCommodity(PCommodity) && ((WCFQuoteSource)jQuoteSource).ClientSubCommoditys.Contains(PCommodity.CommodityId))
                                {
                                    List<string> L = new List<string>();
                                    L.Add(PCommodity.CommodityId);
                                    ((WCFQuoteSource)jQuoteSource).RemoveClientSubCommodity(PCommodity.CommodityId);                                    
                                    ((WCFQuoteSource)jQuoteSource).UnSubCommodity(L);
                                    m_PCommodityList.Remove(PCommodity.CommodityId);
                                }
                            }
                        }
                    }
                    else
                    {
                        mCMarket.RemoveSubscribe(ClientState);
                        ClientState.Remove(mCMarket);
                    }
                }

                return ClientState.SubList;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][UnSubCommodity_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }
        }
              
        List<QCommodity> IQuoteClient.GetImage(List<string> CommodityList)
        {
            try
            {
                List<QCommodity> L = new List<QCommodity>();

                foreach (string CommodityId in CommodityList)
                {
                    string jCommodityId = CommodityId.ToUpper().Trim();

                    if (jCommodityId.IndexOf("/") > -1) { continue; }
                    //string lCommodityId = GetCommodityIdFromSysCode(jCommodityId);
                    //lCommodityId = GetCommodityIdFromLastCode(lCommodityId);                    
                    string lCommodityId = jCommodityId;

                    PCommodity PCommodity = m_PCommodityList.Get(lCommodityId);

                    if (PCommodity != null && PCommodity.QCommodity != null && PCommodity.QCommodity.Base != null)
                        L.Add(PCommodity.QCommodity);                    
                }

                return L;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][GetImage_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }
        }
        List<QSimpleCommodity> IQuoteClient.GetSimpleImage(List<string> CommodityList)
        {
            return null;
        }
        List<string> IQuoteClient.GetSubCommodityList()
        {
            IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

            ClientState ClientState = m_ClientStateList.Get(Callback);

            if (ClientState != null)
                return ClientState.SubList;
            else
                return new List<string>();
        }
        List<QMatch> IQuoteClient.GetCommodityTicks(string CommodityId)
        {
            throw new NotImplementedException();
        }
        void IQuoteClient.Close()
        {
            try
            {
                IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                ClientState ClientState = m_ClientStateList.Get(Callback);

                if (ClientState != null)
                    ClientStateList.Remove(Callback);
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ClientClose_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        bool IQuoteClient.GetAlived()
        {
            try
            {
                IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                ClientState ClientState = m_ClientStateList.Get(Callback);
                if (ClientState != null) { ClientState.AliveTime = DateTime.Now; }
                return true;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][GetAlived_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return false;
            }
        }

        #endregion       
            
        //#region IQuoteServer 成員

        /*public void SetQBase(QBase QBase)
        {
            PCommodity PCommodity = PCommodityList.Set(QBase.CommodityId);
            SetBase(PCommodity, QBase.Market, QBase.CommodityKind, QBase.CommodityType, QBase.CommodityNm, QBase.TradeDate, QBase.InformationTime, QBase.InformationSeq, QBase.SettleMentMonth, QBase.Strike, QBase.ReferencePrice, QBase.RiseLimitPrice, QBase.FallLimitPrice, QBase.RiseLimitPrice2, QBase.FallLimitPrice2, QBase.RiseLimitPrice3, QBase.FallLimitPrice3, QBase.Unit, QBase.ProdKind, QBase.DecimalLocate, QBase.StrikeDecimalLocate, QBase.InnerCode);
        }

        public void SetQOpen(QOpen QOpen)
        {
            PCommodity PCommodity = PCommodityList.Set(QOpen.CommodityId);
            SetOpen(PCommodity, QOpen.OpenTime, QOpen.OpenPrice);
        }

        public void SetQBest5(QBest5 QBest5)
        {
            PCommodity PCommodity = PCommodityList.Set(QBest5.CommodityId);
            SetBest5(PCommodity, QBest5.InformationTime, QBest5.InformationSeq, QBest5.BuyPriceBest1, QBest5.BuyQtyBest1, QBest5.BuyPriceBest2, QBest5.BuyQtyBest2, QBest5.BuyPriceBest3, QBest5.BuyQtyBest3, QBest5.BuyPriceBest4, QBest5.BuyQtyBest4, QBest5.BuyPriceBest5, QBest5.BuyQtyBest5, QBest5.SellPriceBest1, QBest5.SellQtyBest1, QBest5.SellPriceBest2, QBest5.SellQtyBest2, QBest5.SellPriceBest3, QBest5.SellQtyBest3, QBest5.SellPriceBest4, QBest5.SellQtyBest4, QBest5.SellPriceBest5, QBest5.SellQtyBest5, QBest5.BuyPriceDerived, QBest5.BuyQtyDerived, QBest5.SellPriceDerived, QBest5.SellQtyDerived);
        }

        public void SetQMatch(QMatch QMatch)
        {
            PCommodity PCommodity = PCommodityList.Set(QMatch.CommodityId);
            SetMatch(PCommodity, QMatch.InformationTime, QMatch.InformationSeq, QMatch.MatchSeq, QMatch.MatchTime, QMatch.MatchPrice, QMatch.MatchQty, QMatch.MatchAmt, QMatch.MatchTotalAmt, QMatch.MatchTotalQty, QMatch.MatchTotalCnt, QMatch.MatchBuyTotalCnt, QMatch.MatchSellTotalCnt);
        }

        public void SetQHighLow(QHighLow QHighLow)
        {
            PCommodity PCommodity = PCommodityList.Set(QHighLow.CommodityId);
            SetHighLow(PCommodity, QHighLow.InformationTime, QHighLow.InformationSeq, QHighLow.DayHighPrice, QHighLow.DayLowPrice, QHighLow.ShowTime);
        }

        public void SetQClose(QClose QClose)
        {
            PCommodity PCommodity = PCommodityList.Set(QClose.CommodityId);
            SetClose(PCommodity, QClose.InformationTime, QClose.InformationSeq, QClose.DayHighPrice, QClose.DayLowPrice, QClose.OpenPrice, QClose.BuyPrice, QClose.SellPrice, QClose.ClosePrice, QClose.CloseDate, QClose.MatchTotalCnt, QClose.MatchTotalQty, QClose.MatchTotalAmt, QClose.ComBuyCnt, QClose.ComBuyQty, QClose.ComSellCnt, QClose.ComSellQty, QClose.ComTotalQty, QClose.SettlementPrice, QClose.OpenInterest);
        }

        public void SetQCommodity(QCommodity QCommodity)
        {
            SetQBase(QCommodity.Base);
            SetQOpen(QCommodity.Open);
            SetQBest5(QCommodity.Best5);
            SetQMatch(QCommodity.Match);
            SetQHighLow(QCommodity.HighLow);
            SetQClose(QCommodity.Close);
        }*/
        /*public void SetQuote(object obj)
        {
            Type iType = obj.GetType();

            if (iType == typeof(QBase))
            {
                QBase QBase = (QBase)obj;

                PCommodity PCommodity = PCommodityList.Set(QBase.CommodityId);
                SetBase(PCommodity, QBase.Market, QBase.CommodityKind, QBase.CommodityType, QBase.CommodityNm, QBase.TradeDate, QBase.InformationTime, QBase.InformationSeq, QBase.SettleMentMonth, QBase.Strike, QBase.ReferencePrice, QBase.RiseLimitPrice, QBase.FallLimitPrice, QBase.RiseLimitPrice2, QBase.FallLimitPrice2, QBase.RiseLimitPrice3, QBase.FallLimitPrice3, QBase.Unit, QBase.ProdKind, QBase.DecimalLocate, QBase.StrikeDecimalLocate, QBase.InnerCode);
            }
            else if (iType == typeof(QOpen))
            {
                QOpen QOpen = (QOpen)obj;

                PCommodity PCommodity = PCommodityList.Set(QOpen.CommodityId);
                SetOpen(PCommodity, QOpen.OpenTime, QOpen.OpenPrice);
            }
            else if (iType == typeof(QBest5))
            {
                QBest5 QBest5 = (QBest5)obj;

                PCommodity PCommodity = PCommodityList.Set(QBest5.CommodityId);
                SetBest5(PCommodity, QBest5.InformationTime, QBest5.InformationSeq, QBest5.BuyPriceBest1, QBest5.BuyQtyBest1, QBest5.BuyPriceBest2, QBest5.BuyQtyBest2, QBest5.BuyPriceBest3, QBest5.BuyQtyBest3, QBest5.BuyPriceBest4, QBest5.BuyQtyBest4, QBest5.BuyPriceBest5, QBest5.BuyQtyBest5, QBest5.SellPriceBest1, QBest5.SellQtyBest1, QBest5.SellPriceBest2, QBest5.SellQtyBest2, QBest5.SellPriceBest3, QBest5.SellQtyBest3, QBest5.SellPriceBest4, QBest5.SellQtyBest4, QBest5.SellPriceBest5, QBest5.SellQtyBest5, QBest5.BuyPriceDerived, QBest5.BuyQtyDerived, QBest5.SellPriceDerived, QBest5.SellQtyDerived);
            }
            else if (iType == typeof(QMatch))
            {
                QMatch QMatch = (QMatch)obj;

                PCommodity PCommodity = PCommodityList.Set(QMatch.CommodityId);
                SetMatch(PCommodity, QMatch.InformationTime, QMatch.InformationSeq, QMatch.MatchSeq, QMatch.MatchTime, QMatch.MatchPrice, QMatch.MatchQty, QMatch.MatchAmt, QMatch.MatchTotalAmt, QMatch.MatchTotalQty, QMatch.MatchTotalCnt, QMatch.MatchBuyTotalCnt, QMatch.MatchSellTotalCnt);
            }
            else if (iType == typeof(QHighLow))
            {
                QHighLow QHighLow = (QHighLow)obj;

                PCommodity PCommodity = PCommodityList.Set(QHighLow.CommodityId);
                SetHighLow(PCommodity, QHighLow.InformationTime, QHighLow.InformationSeq, QHighLow.DayHighPrice, QHighLow.DayLowPrice, QHighLow.ShowTime);
            }
            else if (iType == typeof(QClose))
            {
                QClose QClose = (QClose)obj;

                PCommodity PCommodity = PCommodityList.Set(QClose.CommodityId);
                SetClose(PCommodity, QClose.InformationTime, QClose.InformationSeq, QClose.DayHighPrice, QClose.DayLowPrice, QClose.OpenPrice, QClose.BuyPrice, QClose.SellPrice, QClose.ClosePrice, QClose.CloseDate, QClose.MatchTotalCnt, QClose.MatchTotalQty, QClose.MatchTotalAmt, QClose.ComBuyCnt, QClose.ComBuyQty, QClose.ComSellCnt, QClose.ComSellQty, QClose.ComTotalQty, QClose.SettlementPrice, QClose.OpenInterest);
            }
            else if (iType == typeof(QCommodity))
            {
                QCommodity QCommodity = (QCommodity)obj;

                SetQBase(QCommodity.Base);
                SetQOpen(QCommodity.Open);
                SetQBest5(QCommodity.Best5);
                SetQMatch(QCommodity.Match);
                SetQHighLow(QCommodity.HighLow);
                SetQClose(QCommodity.Close);
            }            
        }*/
        //#endregion    
    
        #region ITSServer 成員

        int DeriLib.TSModel.ITSServer.Connections
        {
            get { throw new NotImplementedException(); }
        }

        string DeriLib.TSModel.ITSServer.Service
        {
            get { return Setting.Service; }
        }

        string DeriLib.TSModel.ITSServer.Note
        {
            get { return Setting.Note; }
        }

        bool DeriLib.TSModel.ITSServer.Start()
        {
            this.Start();
            return true;
        }

        bool DeriLib.TSModel.ITSServer.AddDataSource(DeriLib.TSModel.ITSFactory DataSource)
        {
            QuoteSource QuoteSource = DataSource as QuoteSource;

            if (QuoteSource != null)
            {
                AddQuoteSource(QuoteSource);
                return true;
            }
            else
                return false;
        }

        bool DeriLib.TSModel.ITSServer.RemoveDataSource(string DataSource)
        {
            RemoveQuoteSource(DataSource);
            return true;
        }

        bool DeriLib.TSModel.ITSServer.Close()
        {
            this.Close();
            return true;
        }

        List<IClientState> DeriLib.TSModel.ITSServer.ClientStates
        {
            get 
            {                
                List<IClientState> L = new List<IClientState>();

                foreach (ClientState C in m_ClientStateList.ClientStates)
                    L.Add((IClientState)C);
                return L;
            }
        }

        void DeriLib.TSModel.ITSServer.RemoveClientState(string IP, int Port)
        {
            m_ClientStateList.Remove(IP,Port);
        }
        Queue DeriLib.TSModel.ITSServer.ErrorQueue
        {
            get { return m_ErrQueueOut; }
        }

        Dictionary<string, DeriLib.TSModel.ITSFactory> DeriLib.TSModel.ITSServer.DataSources
        {
            get 
            {
                List<QuoteSource> L = m_QuoteSourceList.QuoteSources;
                Dictionary<string, DeriLib.TSModel.ITSFactory> I = new Dictionary<string,DeriLib.TSModel.ITSFactory>();

                foreach (QuoteSource d in L)
                {
                    I.Add(d.DataSource, (DeriLib.TSModel.ITSFactory)d);
                }

                return I;
            }
        }

        event DeriLib.TSModel.ErrorHandler DeriLib.TSModel.ITSServer.ErrorFire
        {
            add { throw new NotImplementedException(); }
            remove { throw new NotImplementedException(); }
        }

        #endregion
                
    }

    #region 資料型態

    public delegate void CallbackDelegate<T>(T t);

    public class QuoteSetting : TSModel.ServiceSetting
    {
        public string DBConnectString = "";
        public bool IsExecuteSchedule = false;
        public bool IsWriteH5Ticks = false;
        public string LogFileFolder = "";
        public bool LoadCommodityExtra = false;

        public QuoteSetting()
        {
        }
        public QuoteSetting(string Service, string Note)
            : base(Service, Note)
        {

        }
    }

    public class QuoteFactorySetting : TSModel.DataSourceSetting
    {
        public string LogFileFolder = "";
        public string DBConnectString = "";
        public bool IsWriteToDb = false;
        public bool IsWriteToLog = false;        
        public bool IsCheckLost = false;
        public bool IsRegisterAll = false;
        public bool IsReloadData = false;
        public bool IsSendTicks = false;
        public bool IsWriteTicks = false;
        //public bool IsCalculateGreeks = false;
        public QuoteSourceKind QuoteSourceKind;
        public Market Market;             
        public int DataSendms = 0;                
        public string LocalIp = "";        
        public int LocalPort = 0;
        public string MultiCastIp = "";
        public int Speed = 1;
        public string FileStartTime = "";

        public QuoteFactorySetting()
        {
        }
        public QuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public QuoteFactorySetting(string Service,string DataSource, string Note)
            : base(Service,DataSource, Note)
        {
        }
    }

    public class WCFQuoteFactorySetting : QuoteFactorySetting
    {
        public string SubCommodity = "";
        public string RemotIp = "";        
        
        public WCFQuoteFactorySetting()
        {
        }
        public WCFQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public WCFQuoteFactorySetting(string Service,string DataSource, string Note)
            : base(Service,DataSource, Note)
        {
        }
    }

    public class EstimateQuoteFactorySetting : QuoteFactorySetting
    {
        public int Calculatems = 1000;
        public string STime = "0900";
        public string ETime = "2030";
        public string EstimateLabel = "";

        public EstimateQuoteFactorySetting()
        {
        }
        public EstimateQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public EstimateQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    public class IPushQuoteFactorySetting : QuoteFactorySetting
    {
        public string SubCommodity = "TWS";
        public string RecoverTime = "0830";        

        public IPushQuoteFactorySetting()
        {
        }
        public IPushQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public IPushQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    

    public interface IQuoteCallBacks
    {
        [OperationContract(IsOneWay = true)]
        void QCommodityArrived(QCommodity QCommodity);
        [OperationContract(IsOneWay = true)]
        void QBaseArrived(QBase QBase);
        [OperationContract(IsOneWay = true)]
        void QOpenArrived(QOpen QOpen);
        [OperationContract(IsOneWay = true)]
        void QBest5Arrived(QBest5 QBest5);
        [OperationContract(IsOneWay = true)]
        void QMatchArrived(QMatch QMatch);
        [OperationContract(IsOneWay = true)]
        void QHighLowArrived(QHighLow QHighLow);        
        [OperationContract(IsOneWay = true)]
        void QCloseArrived(QClose QClose);
        //[OperationContract(IsOneWay = true)]
        //void QGreeksArrived(QGreeks QGreeks);
        [OperationContract(IsOneWay = true)]
        void QQueryArrived(QueryCls QueryCls);
        [OperationContract(IsOneWay = true)]
        void QExtraArrived(QCommodityExtra QCommodityExtra);
        //[OperationContract(IsOneWay = true)]
        //void QOrderArrived(QOrder QOrder);
        [OperationContract(IsOneWay = true)]
        void QSimpleCommodityArrived(QSimpleCommodity QSimpleCommodity);
        [OperationContract(IsOneWay = true)]
        void QSimpleBaseArrived(QSimpleBase QSimpleBase);
        /*[OperationContract(IsOneWay = true)]
        void QMatchBest5Arrived(QMatchBest5 QMatchBest5);*/
        [OperationContract(IsOneWay = true)]
        void QSimpleMatchArrived(QSimpleMatch QSimpleMatch);
        [OperationContract(IsOneWay = true)]
        void QSimpleBest5Arrived(QSimpleBest5 QSimpleBest5);
    }

    public interface IQCommodity
    {
        QCommodity GetQCommodity();
    }
    public interface ICopy
    {
        object Copy();
    }

    [ServiceContract(SessionMode = SessionMode.Required,CallbackContract = typeof(IQuoteCallBacks))]
    public interface IQuoteClient
    {
        [OperationContract]
        List<string> SubCommodity(List<string> CommodityList);
        [OperationContract]
        List<string> UnSubCommodity(List<string> CommodityList);
        [OperationContract]
        List<QCommodity> GetImage(List<string> CommodityList);
        [OperationContract]
        List<QSimpleCommodity> GetSimpleImage(List<string> CommodityList);
        [OperationContract]
        List<string> GetSubCommodityList();
        [OperationContract]
        List<QMatch> GetCommodityTicks(string CommodityId);
        [OperationContract]        
        void Close();
        [OperationContract]
        bool GetAlived();
    }

    /*[ServiceContract(SessionMode = SessionMode.Required)]
    public interface IQuoteServer
    {
        [OperationContract]
        void SetQBase(QBase QBase);
        [OperationContract]
        void SetQOpen(QOpen QOpen);
        [OperationContract]
        void SetQBest5(QBest5 QBest5);
        [OperationContract]
        void SetQMatch(QMatch QMatch);
        [OperationContract]
        void SetQHighLow(QHighLow QHighLow);
        [OperationContract]
        void SetQClose(QClose QClose);
        [OperationContract]
        void SetQCommodity(QCommodity QCommodity);
        [OperationContract]
        List<string> SubCommodity(List<string> CommodityList);
        [OperationContract]
        List<string> UnSubCommodity(List<string> CommodityList);
    }  */
    /*public interface IQuoteServer
    {
        [OperationContract]
        void SetQuote(object obj);        
    } */

    [DataContract(Namespace = "http://Topderivatives.com")]
    public enum Market:int
    {
        [EnumMemberAttribute]
        None = 0,
        [EnumMemberAttribute]
        TSE = 1,
        [EnumMemberAttribute]
        OTC = 2,
        [EnumMemberAttribute]
        TFE = 3,
        [EnumMemberAttribute]
        PreOtc = 4,
        [EnumMemberAttribute]
        HKE = 5,
        [EnumMemberAttribute]
        SGX = 6,
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public enum CommodityKind : int
    {
        [EnumMemberAttribute]
        None = 0,
        [EnumMemberAttribute]
        Stock = 1,
        [EnumMemberAttribute]
        Warrant = 2,
        [EnumMemberAttribute]
        CB = 3,        
        [EnumMemberAttribute]
        Index = 4,
        [EnumMemberAttribute]
        Future = 5,
        [EnumMemberAttribute]
        Option = 6,
        [EnumMemberAttribute]
        ETF = 7,
        [EnumMemberAttribute]
        TDR = 8,
        [EnumMemberAttribute]
        REITs = 9,
        [EnumMemberAttribute]
        Bond = 10,
        [EnumMemberAttribute]
        Currency = 11,
    }
    
    [DataContract(Namespace = "http://Topderivatives.com")]
    public enum CommodityType : int
    {
        [EnumMemberAttribute]
        None = 0,
        [EnumMemberAttribute]
        Call = 1,
        [EnumMemberAttribute]
        Put = 2,
        [EnumMemberAttribute]
        DIC = 3,
        [EnumMemberAttribute]
        UIC = 4,
        [EnumMemberAttribute]
        DOC = 5,
        [EnumMemberAttribute]
        UOC = 6,
        [EnumMemberAttribute]
        DIP = 7,
        [EnumMemberAttribute]
        UIP = 8,
        [EnumMemberAttribute]
        DOP = 9,
        [EnumMemberAttribute]
        UOP = 10
    }
    public enum QuoteSourceKind : int
    {
        [EnumMemberAttribute]
        None = 0,
        [EnumMemberAttribute]
        Tse_Udp = 1,
        [EnumMemberAttribute]
        Otc_Udp = 2,
        [EnumMemberAttribute]
        TfeFx_Udp = 3,
        [EnumMemberAttribute]
        TfeOp_Udp = 4,
        [EnumMemberAttribute]
        Tse_File = 5,
        [EnumMemberAttribute]
        Otc_File = 6,
        [EnumMemberAttribute]
        TfeFx_File = 7,
        [EnumMemberAttribute]
        TfeOp_File = 8,
        [EnumMemberAttribute]
        Tse2_Udp = 9,
        [EnumMemberAttribute]
        Otc2_Udp = 10
    }

    public enum EstimateCalculateKind : int
    {
        [EnumMemberAttribute]
        None = 0,
        [EnumMemberAttribute]
        IndexShares = 1,
        [EnumMemberAttribute]
        IndexWeight = 2,
        [EnumMemberAttribute]
        ETFShares = 3,
        [EnumMemberAttribute]
        ETFWeight = 4,
        [EnumMemberAttribute]
        SelfCalculate = 5
    }

    public enum EstimateCalculateType : int
    {
        [EnumMemberAttribute]
        Reference = 0,
        [EnumMemberAttribute]
        Last = 1,
        [EnumMemberAttribute]
        Bid1 = 2,
        [EnumMemberAttribute]
        Ask1 = 3,
        [EnumMemberAttribute]
        Yestoday = 4
    }

    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QBase : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public Market Market { get; set; }
        [DataMember]
        public CommodityKind CommodityKind { get; set; }
        [DataMember]
        public CommodityType CommodityType { get; set; }
        [DataMember]
        public string CommodityCode { get; set; }
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string CommodityNm { get; set; }
        [DataMember]
        public DateTime TradeDate { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public string SettleMentMonth { get; set; }
        [DataMember]
        public double Strike { get; set; }
        [DataMember]
        public double ReferencePrice { get; set; }
        [DataMember]
        public double RiseLimitPrice { get; set; }        
        [DataMember]
        public double FallLimitPrice { get; set; }
        [DataMember]
        public double RiseLimitPrice2 { get; set; }
        [DataMember]
        public double FallLimitPrice2 { get; set; }
        [DataMember]
        public double RiseLimitPrice3 { get; set; }
        [DataMember]
        public double FallLimitPrice3 { get; set; }
        [DataMember]
        public int Unit { get; set; }
        [DataMember]
        public string ProdKind { get; set; }
        [DataMember]
        public double DecimalLocate { get; set; }
        [DataMember]
        public double StrikeDecimalLocate { get; set; }
        [DataMember]
        public string InnerCode { get; set; }
        [DataMember]
        public string CommodityProperty { get; set; }
        //[DataMember]
        //public string SYSCode { get; set; }
        //[DataMember]
        //public string LastCode { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QBase(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;

            CommodityCode = "";
            CommodityId = "";            
            Market = Market.None;
            CommodityKind = CommodityKind.None;
            CommodityType = CommodityType.None;
            CommodityNm = "";
            InformationTime = "";
            InformationSeq = "";
            SettleMentMonth = "";
            Strike = 0.0;
            ReferencePrice = 0.0;
            RiseLimitPrice = 0.0;
            FallLimitPrice = 0.0;
            RiseLimitPrice2 = 0.0;
            FallLimitPrice2 = 0.0;
            RiseLimitPrice3 = 0.0;
            FallLimitPrice3 = 0.0;
            Unit = 1;
            ProdKind = "";
            DecimalLocate = 0.0;
            StrikeDecimalLocate = 0.0;
            InnerCode = "";
            CommodityProperty = "";
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QOpen : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string OpenTime { get; set; }        
        [DataMember]
        public double OpenPrice { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QOpen(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QBest5 : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public double BuyPriceBest1 { get; set; }
        [DataMember]
        public int BuyQtyBest1 { get; set; }
        [DataMember]
        public double BuyPriceBest2 { get; set; }
        [DataMember]
        public int BuyQtyBest2 { get; set; }
        [DataMember]
        public double BuyPriceBest3 { get; set; }
        [DataMember]
        public int BuyQtyBest3 { get; set; }
        [DataMember]
        public double BuyPriceBest4 { get; set; }
        [DataMember]
        public int BuyQtyBest4 { get; set; }
        [DataMember]
        public double BuyPriceBest5 { get; set; }
        [DataMember]
        public int BuyQtyBest5 { get; set; }
        [DataMember]
        public double SellPriceBest1 { get; set; }
        [DataMember]
        public int SellQtyBest1 { get; set; }
        [DataMember]
        public double SellPriceBest2 { get; set; }
        [DataMember]
        public int SellQtyBest2 { get; set; }
        [DataMember]
        public double SellPriceBest3 { get; set; }
        [DataMember]
        public int SellQtyBest3 { get; set; }
        [DataMember]
        public double SellPriceBest4 { get; set; }
        [DataMember]
        public int SellQtyBest4 { get; set; }
        [DataMember]
        public double SellPriceBest5 { get; set; }
        [DataMember]
        public int SellQtyBest5 { get; set; }
        [DataMember]
        public double BuyPriceDerived { get; set; }
        [DataMember]
        public int BuyQtyDerived { get; set; }
        [DataMember]
        public double SellPriceDerived { get; set; }
        [DataMember]
        public int SellQtyDerived { get; set; }
        [DataMember]
        public double BuyPriceBest1s { get; set; }
        [DataMember]
        public double SellPriceBest1s { get; set; }
        [DataMember]
        public double BuyAmt { get; set; }
        [DataMember]
        public double SellAmt { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QBest5(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QMatch : IQCommodity, IExtensibleDataObject,ICopy
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public int MatchSeq { get; set; }
        [DataMember]
        public string MatchTime { get; set; }
        [DataMember]
        public double MatchPrice { get; set; }
        [DataMember]
        public int MatchQty { get; set; }
        [DataMember]
        public double MatchAmt { get; set; }
        [DataMember]
        public double MatchTotalAmt { get; set; }
        [DataMember]
        public int MatchTotalQty { get; set; }
        [DataMember]
        public int MatchTotalCnt { get; set; }
        [DataMember]
        public int MatchBuyTotalCnt { get; set; }
        [DataMember]
        public int MatchSellTotalCnt { get; set; }
        [DataMember]
        public double MatchPrices { get; set; }
        [DataMember]
        public int FallRiseTag { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QMatch(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    /*[DataContract(Namespace = "http://Topderivatives.com")]
    public class QGreeks : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }        
        [DataMember]
        public double LastIV { get; set; }
        [DataMember]
        public double Bid1IV { get; set; }
        [DataMember]
        public double Bid2IV { get; set; }
        [DataMember]
        public double Bid3IV { get; set; }
        [DataMember]
        public double Bid4IV { get; set; }
        [DataMember]
        public double Bid5IV { get; set; }
        [DataMember]
        public double Ask1IV { get; set; }
        [DataMember]
        public double Ask2IV { get; set; }
        [DataMember]
        public double Ask3IV { get; set; }
        [DataMember]
        public double Ask4IV { get; set; }
        [DataMember]
        public double Ask5IV { get; set; }
        [DataMember]
        public double Delta { get; set; }
        [DataMember]
        public double Gamma { get; set; }
        [DataMember]
        public double Vega { get; set; }
        [DataMember]
        public double Theta { get; set; }
        [DataMember]
        public double Rho { get; set; }
        [DataMember]
        public double TPrice { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QGreeks(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }*/
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QHighLow : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public double DayHighPrice { get; set; }
        [DataMember]
        public double DayLowPrice { get; set; }
        [DataMember]
        public string ShowTime { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QHighLow(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    /*[DataContract(Namespace = "http://Topderivatives.com")]
    public class QOrder : IExtensibleDataObject
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public int BuyOrderCnt { get; set; }
        [DataMember]
        public int BuyQuantity { get; set; }
        [DataMember]
        public int SellOrderCnt { get; set; }
        [DataMember]
        public int SellQuantity { get; set; }
        public ExtensionDataObject ExtensionData { get; set; }
    }*/
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QClose : IQCommodity, IExtensibleDataObject,ICopy
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public double DayHighPrice { get; set; }
        [DataMember]
        public double DayLowPrice { get; set; }
        [DataMember]
        public double OpenPrice { get; set; }
        [DataMember]
        public double BuyPrice { get; set; }
        [DataMember]
        public double SellPrice { get; set; }
        [DataMember]
        public double ClosePrice { get; set; }
        [DataMember]
        public DateTime CloseDate { get; set; }
        //[DataMember]
        //public int BuyOrderCnt;
        //[DataMember]
        //public int BuyQty;
        //[DataMember]
        //public int SellCnt;
        //[DataMember]
        //public int SellQty;
        [DataMember]
        public int MatchTotalCnt { get; set; }
        [DataMember]
        public int MatchTotalQty { get; set; }
        [DataMember]
        public double MatchTotalAmt { get; set; }
        [DataMember]
        public int ComBuyCnt { get; set; }
        [DataMember]
        public int ComBuyQty { get; set; }
        [DataMember]
        public int ComSellCnt { get; set; }
        [DataMember]
        public int ComSellQty { get; set; }
        [DataMember]
        public int ComTotalQty { get; set; }
        [DataMember]
        public double SettlementPrice { get; set; }
        [DataMember]
        public int OpenInterest { get; set; }
        [DataMember]
        public double LastSettlementPrice { get; set; }
        [DataMember]
        public int LastOpenInterest { get; set; }
        [DataMember]
        public DateTime LastCloseDate { get; set; }
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QClose(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QCommodity : IQCommodity, IExtensibleDataObject
    {
        [DataMember]
        public QBase Base { get; set; }        
        [DataMember]
        public QOpen Open { get; set; }
        [DataMember]
        public QBest5 Best5 { get; set; }
        [DataMember]
        public QMatch Match { get; set; }
        [DataMember]
        public QHighLow HighLow { get; set; }
        //[DataMember]
        //public QOrder Order { get; set; }
        [DataMember]
        public QClose Close { get; set; }
        /*[DataMember]
        public QGreeks Greeks { get; set; }*/
        [DataMember]
        public QCommodityExtra Extra { get; set; }
        [DataMember]
        public QHistoricalVol HisVol { get; set; }
        [DataMember]
        public List<QMatch> Ticks { get; set; }
        public PCommodity PCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QCommodity(PCommodity PCommodity)
        {
            this.PCommodity = PCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return this;
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QCommodityExtra : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string CommodityId;
        [DataMember]
        public string UnderlyingId;        
        [DataMember]
        public DateTime Maturity;
        [DataMember]
        public double Strike;
        [DataMember]
        public double BarrierPrice;
        [DataMember]
        public double ExecRatio;
        [DataMember]
        public double HisVol;
        [DataMember]
        public DateTime LastTradeDate;
        [DataMember]
        public int IssueQty;
        [DataMember]
        public int CancelQty;
        [DataMember]
        public DateTime IssueDate;
        [DataMember]
        public int Duration;
        
        public PCommodity Underlying;

        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QCommodityExtra(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QHistoricalVol : IQCommodity, IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string CommodityId;        
        [DataMember]
        public double HIV1M;
        [DataMember]
        public double HIV3M;
        [DataMember]
        public double HIV6M;
        [DataMember]
        public double HIV12M;
        
        public QCommodity QCommodity;
        public ExtensionDataObject ExtensionData { get; set; }

        public QHistoricalVol(QCommodity QCommodity)
        {
            this.QCommodity = QCommodity;
        }

        public QCommodity GetQCommodity()
        {
            return QCommodity;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
        
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QueryCls : IExtensibleDataObject, ICopy
    {
        [DataMember]
        public string FOFlag = "";
        [DataMember]
        public string CommodityId = "";
        [DataMember]
        public string InformationTime = "";
        [DataMember]
        public string InformationSeq = "";
        [DataMember]
        public string DisClosureTime = "";
        [DataMember]
        public int DurationTime = 0;

        public ExtensionDataObject ExtensionData { get; set; }
        public QueryCls(string FOFlag, string CommodityId, string InformationTime, string InformationSeq, string DisClosureTime, int DurationTime)
        {
            this.FOFlag = FOFlag;
            this.CommodityId = CommodityId;
            this.InformationTime = InformationTime;
            this.InformationSeq = InformationSeq;
            this.DisClosureTime = DisClosureTime;
            this.DurationTime = DurationTime;
        }
        public object Copy()
        {
            return this.MemberwiseClone();
        }
    }
    public class HTicks
    {
        public string TradeDate = "";
        public string CommodityId="";
        public string InformationTime="";
        public string InformationSeq="";
        public int MatchSeq=0;
        public string MatchTime="";
        public double MatchPrice=0.0;
        public int MatchQty=0;
        public int MatchTotalQty=0;
        public double BuyPriceBest1 = 0.0;
        public int BuyQtyBest1 = 0;
        public double SellPriceBest1 = 0.0;
        public int SellQtyBest1 = 0;
    }

    [DataContract(Namespace = "http://Topderivatives.com")]
    public enum QMatchBest5Type : int
    {
        [EnumMemberAttribute]
        None = 0,
        [EnumMemberAttribute]
        Last = 1,
        [EnumMemberAttribute]
        Best5 = 2,
        [EnumMemberAttribute]
        LastAndBest5 = 3,        
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QSimpleCommodity : IExtensibleDataObject
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public QSimpleBase QSimpleBase { get; set; }
        /*[DataMember]
        public QMatchBest5 QMatchBest5 { get; set; }*/
        [DataMember]
        public QSimpleBest5 QSimpleBest5 { get; set; }
        [DataMember]
        public QSimpleMatch QSimpleMatch { get; set; }
        public ExtensionDataObject ExtensionData { get; set; }

        public QSimpleCommodity(string CommodityId)
        {
            this.CommodityId = CommodityId;
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QSimpleBase : IExtensibleDataObject
    {        
        [DataMember]
        public string CommodityId { get; set; }        
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public double ReferencePrice { get; set; }
        [DataMember]
        public double RiseLimitPrice { get; set; }
        [DataMember]
        public double FallLimitPrice { get; set; }
        [DataMember]
        public double DecimalLocate { get; set; }        
        public ExtensionDataObject ExtensionData { get; set; }

        public QSimpleBase(string CommodityId)
        {
            this.CommodityId = CommodityId;
        }
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QSimpleMatch : IExtensibleDataObject
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }        
        [DataMember]
        public int MatchSeq { get; set; }
        [DataMember]
        public string MatchTime { get; set; }
        [DataMember]
        public double MatchPrice { get; set; }
        [DataMember]
        public int MatchQty { get; set; }
        [DataMember]
        public int MatchTotalQty { get; set; }                
        [DataMember]
        public double MatchAmt { get; set; }
        [DataMember]
        public double MatchTotalAmt { get; set; }
        public ExtensionDataObject ExtensionData { get; set; }

        public QSimpleMatch(string CommodityId)
        {
            this.CommodityId = CommodityId;
        }       
    }
    [DataContract(Namespace = "http://Topderivatives.com")]
    public class QSimpleBest5 : IExtensibleDataObject
    {
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string InformationTime { get; set; }
        [DataMember]
        public string InformationSeq { get; set; }
        [DataMember]
        public double BuyPriceBest1 { get; set; }
        [DataMember]
        public int BuyQtyBest1 { get; set; }
        [DataMember]
        public double BuyPriceBest2 { get; set; }
        [DataMember]
        public int BuyQtyBest2 { get; set; }
        [DataMember]
        public double BuyPriceBest3 { get; set; }
        [DataMember]
        public int BuyQtyBest3 { get; set; }
        [DataMember]
        public double BuyPriceBest4 { get; set; }
        [DataMember]
        public int BuyQtyBest4 { get; set; }
        [DataMember]
        public double BuyPriceBest5 { get; set; }
        [DataMember]
        public int BuyQtyBest5 { get; set; }
        [DataMember]
        public double SellPriceBest1 { get; set; }
        [DataMember]
        public int SellQtyBest1 { get; set; }
        [DataMember]
        public double SellPriceBest2 { get; set; }
        [DataMember]
        public int SellQtyBest2 { get; set; }
        [DataMember]
        public double SellPriceBest3 { get; set; }
        [DataMember]
        public int SellQtyBest3 { get; set; }
        [DataMember]
        public double SellPriceBest4 { get; set; }
        [DataMember]
        public int SellQtyBest4 { get; set; }
        [DataMember]
        public double SellPriceBest5 { get; set; }
        [DataMember]
        public int SellQtyBest5 { get; set; }
        public ExtensionDataObject ExtensionData { get; set; }

        public QSimpleBest5(string CommodityId)
        {
            this.CommodityId = CommodityId;
        }
    }
    /*[DataContract(Namespace = "http://Topderivatives.com")]
    public class QMatchBest5 : IExtensibleDataObject
    {
        [DataMember]
        public QMatchBest5Type QMatchBest5Type { get; set; }
        [DataMember]
        public string CommodityId { get; set; }
        [DataMember]
        public string MatchInformationTime { get; set; }
        [DataMember]
        public string MatchInformationSeq { get; set; }
        [DataMember]
        public int MatchSeq { get; set; }
        [DataMember]
        public string MatchTime { get; set; }
        [DataMember]
        public double MatchPrice { get; set; }
        [DataMember]
        public int MatchQty { get; set; }
        [DataMember]
        public double MatchAmt { get; set; }
        [DataMember]
        public double MatchTotalAmt { get; set; }
        [DataMember]
        public int MatchTotalQty { get; set; }                
        [DataMember]
        public string Best5InformationTime { get; set; }
        [DataMember]
        public string Best5InformationSeq { get; set; }
        [DataMember]
        public double BuyPriceBest1 { get; set; }
        [DataMember]
        public int BuyQtyBest1 { get; set; }
        [DataMember]
        public double BuyPriceBest2 { get; set; }
        [DataMember]
        public int BuyQtyBest2 { get; set; }
        [DataMember]
        public double BuyPriceBest3 { get; set; }
        [DataMember]
        public int BuyQtyBest3 { get; set; }
        [DataMember]
        public double BuyPriceBest4 { get; set; }
        [DataMember]
        public int BuyQtyBest4 { get; set; }
        [DataMember]
        public double BuyPriceBest5 { get; set; }
        [DataMember]
        public int BuyQtyBest5 { get; set; }
        [DataMember]
        public double SellPriceBest1 { get; set; }
        [DataMember]
        public int SellQtyBest1 { get; set; }
        [DataMember]
        public double SellPriceBest2 { get; set; }
        [DataMember]
        public int SellQtyBest2 { get; set; }
        [DataMember]
        public double SellPriceBest3 { get; set; }
        [DataMember]
        public int SellQtyBest3 { get; set; }
        [DataMember]
        public double SellPriceBest4 { get; set; }
        [DataMember]
        public int SellQtyBest4 { get; set; }
        [DataMember]
        public double SellPriceBest5 { get; set; }
        [DataMember]
        public int SellQtyBest5 { get; set; }
        public ExtensionDataObject ExtensionData { get; set; }

        public QMatchBest5(string CommodityId)
        {
            this.CommodityId = CommodityId;
        }
    }    */
    #endregion
    #region 物件

    public class PCommodity
    {
        public delegate void QuoteUpdateHandler(object sender, object obj);
        public event QuoteUpdateHandler QuoteUpdateEvent;

        public string CommodityId;
        public QCommodity QCommodity;
        //public QCommodityExtra QCommodityExtra;
        public CodeMap CodeMap;
        public CMarket CMarket;
        public bool IsLocalCommodity = false;
        private HashSet<ClientState> m_Subscribes = new HashSet<ClientState>();
        //private Dictionary<string,PCommodity> m_RelationCommoditys = new Dictionary<string,PCommodity>();
        private object LockObj = new object();
        private object SetInfoLockObj = new object();
        
        public PCommodity(string CommodityId)
        {
            this.CommodityId = CommodityId;
            this.QCommodity = new QCommodity(this);
            this.QCommodity.Base = new QBase(this.QCommodity);
            this.QCommodity.Base.CommodityId = CommodityId;
            this.QCommodity.Open = new QOpen(this.QCommodity);
            this.QCommodity.Open.CommodityId = CommodityId;
            this.QCommodity.Best5 = new QBest5(this.QCommodity);
            this.QCommodity.Best5.CommodityId = CommodityId;
            this.QCommodity.Match = new QMatch(this.QCommodity);
            this.QCommodity.Match.CommodityId = CommodityId;
            this.QCommodity.HighLow = new QHighLow(this.QCommodity);
            this.QCommodity.HighLow.CommodityId = CommodityId;
            this.QCommodity.Close = new QClose(this.QCommodity);
            this.QCommodity.Close.CommodityId = CommodityId;
            //this.QCommodity.Greeks = new QGreeks(this.QCommodity);
            //this.QCommodity.Greeks.CommodityId = CommodityId;
        }
        
        public void SetBase(Market Market, CommodityKind CommodityKind, CommodityType CommodityType, string CommodityCode, string CommodityNm, DateTime TradeDate, string InformationTime, string InformationSeq
                             , string SettleMentMonth, double Strike, double ReferencePrice, double RiseLimitPrice, double FallLimitPrice, double RiseLimitPrice2, double FallLimitPrice2
                             , double RiseLimitPrice3, double FallLimitPrice3, int Unit, string ProdKind, double DecimalLocate, double StrikeDecimalLocate, string InnerCode,string CommodityProperty)
        {            
            //if (CMarket != null && InnerCode != string.Empty && InnerCode != null) { CMarket.SetInnerCode(InnerCode, this); }    

            if (QCommodity.Base == null)
            {
                /*QCommodity.Base = new QBase(this.QCommodity);
                QCommodity.Open = new QOpen(this.QCommodity);
                QCommodity.Best5 = new QBest5(this.QCommodity);
                QCommodity.Match = new QMatch(this.QCommodity);
                QCommodity.HighLow = new QHighLow(this.QCommodity);
                QCommodity.Close = new QClose(this.QCommodity);
                QCommodity.Greeks = new QGreeks(this.QCommodity);*/
                if (QCommodity.Ticks != null)
                    QCommodity.Ticks.Clear();
            }       

            QCommodity.Base.CommodityId = CommodityId;
            QCommodity.Base.Market = Market;
            QCommodity.Base.CommodityKind = CommodityKind;
            QCommodity.Base.CommodityType = CommodityType;
            QCommodity.Base.CommodityCode = CommodityCode;
            QCommodity.Base.CommodityNm = CommodityNm;
            QCommodity.Base.TradeDate = TradeDate;
            QCommodity.Base.InformationTime = InformationTime;
            QCommodity.Base.InformationSeq = InformationSeq;
            QCommodity.Base.SettleMentMonth = SettleMentMonth;
            QCommodity.Base.Strike = Strike;
            QCommodity.Base.ReferencePrice = ReferencePrice;
            QCommodity.Base.RiseLimitPrice = RiseLimitPrice;
            QCommodity.Base.FallLimitPrice = FallLimitPrice;
            QCommodity.Base.RiseLimitPrice2 = RiseLimitPrice2;
            QCommodity.Base.FallLimitPrice2 = FallLimitPrice2;
            QCommodity.Base.RiseLimitPrice3 = RiseLimitPrice3;
            QCommodity.Base.FallLimitPrice3 = FallLimitPrice3;
            QCommodity.Base.Unit = Unit;
            QCommodity.Base.ProdKind = ProdKind;
            QCommodity.Base.DecimalLocate = DecimalLocate;
            QCommodity.Base.StrikeDecimalLocate = StrikeDecimalLocate;
            QCommodity.Base.InnerCode = InnerCode;
            QCommodity.Base.CommodityProperty = CommodityProperty;
        }
        public void SetBase(Market Market, CommodityKind CommodityKind, CommodityType CommodityType, string CommodityCode, string CommodityNm, DateTime TradeDate, string InformationTime, string InformationSeq
                             , double ReferencePrice, double RiseLimitPrice, double FallLimitPrice, int Unit, string InnerCode, string CommodityProperty)
        {
            //if (CMarket != null && InnerCode != string.Empty && InnerCode != null) { CMarket.SetInnerCode(InnerCode, this); }

            if (QCommodity.Base == null)
            {
                /*QCommodity.Base = new QBase(this.QCommodity);
                QCommodity.Open = new QOpen(this.QCommodity);
                QCommodity.Best5 = new QBest5(this.QCommodity);
                QCommodity.Match = new QMatch(this.QCommodity);
                QCommodity.HighLow = new QHighLow(this.QCommodity);
                QCommodity.Close = new QClose(this.QCommodity);
                QCommodity.Greeks = new QGreeks(this.QCommodity);*/
                if (QCommodity.Ticks != null)
                    QCommodity.Ticks.Clear();
            }
            
            QCommodity.Base.CommodityId = CommodityId;
            QCommodity.Base.Market = Market;
            QCommodity.Base.CommodityKind = CommodityKind;
            QCommodity.Base.CommodityType = CommodityType;
            QCommodity.Base.CommodityCode = CommodityCode;
            QCommodity.Base.CommodityNm = CommodityNm;
            QCommodity.Base.TradeDate = TradeDate;
            QCommodity.Base.InformationTime = InformationTime;
            QCommodity.Base.InformationSeq = InformationSeq;
            QCommodity.Base.ReferencePrice = ReferencePrice;
            QCommodity.Base.RiseLimitPrice = RiseLimitPrice;
            QCommodity.Base.FallLimitPrice = FallLimitPrice;
            QCommodity.Base.Unit = Unit;            
            QCommodity.Base.InnerCode = InnerCode;
            QCommodity.Base.CommodityProperty = CommodityProperty;
            //return QCommodity.Base.Copy();
        }
        public void SetOpen(string OpenTime, double OpenPrice)
        {
            if (QCommodity.Open == null){QCommodity.Open = new QOpen(this.QCommodity);}                

            QCommodity.Open.CommodityId = CommodityId;
            QCommodity.Open.OpenTime = OpenTime;            
            QCommodity.Open.OpenPrice = OpenPrice;
            //return QCommodity.Open.Copy();
        }
        public void SetBest5(string InformationTime, string InformationSeq, double BuyPriceBest1, int BuyQtyBest1, double BuyPriceBest2, int BuyQtyBest2, double BuyPriceBest3, int BuyQtyBest3
                             , double BuyPriceBest4, int BuyQtyBest4, double BuyPriceBest5, int BuyQtyBest5, double SellPriceBest1, int SellQtyBest1, double SellPriceBest2, int SellQtyBest2
                             , double SellPriceBest3, int SellQtyBest3, double SellPriceBest4, int SellQtyBest4, double SellPriceBest5, int SellQtyBest5, double BuyPriceDerived, int BuyQtyDerived
                             , double SellPriceDerived, int SellQtyDerived)
        {
            if (QCommodity.Best5 == null){QCommodity.Best5 = new QBest5(this.QCommodity);}
                
            QCommodity.Best5.CommodityId = CommodityId;
            QCommodity.Best5.InformationTime = InformationTime;
            QCommodity.Best5.InformationSeq = InformationSeq;
            QCommodity.Best5.BuyPriceBest1 = BuyPriceBest1;
            QCommodity.Best5.BuyQtyBest1 = BuyQtyBest1;
            QCommodity.Best5.BuyPriceBest2 = BuyPriceBest2;
            QCommodity.Best5.BuyQtyBest2 = BuyQtyBest2;
            QCommodity.Best5.BuyPriceBest3 = BuyPriceBest3;
            QCommodity.Best5.BuyQtyBest3 = BuyQtyBest3;
            QCommodity.Best5.BuyPriceBest4 = BuyPriceBest4;
            QCommodity.Best5.BuyQtyBest4 = BuyQtyBest4;
            QCommodity.Best5.BuyPriceBest5 = BuyPriceBest5;
            QCommodity.Best5.BuyQtyBest5 = BuyQtyBest5;
            QCommodity.Best5.SellPriceBest1 = SellPriceBest1;
            QCommodity.Best5.SellQtyBest1 = SellQtyBest1;
            QCommodity.Best5.SellPriceBest2 = SellPriceBest2;
            QCommodity.Best5.SellQtyBest2 = SellQtyBest2;
            QCommodity.Best5.SellPriceBest3 = SellPriceBest3;
            QCommodity.Best5.SellQtyBest3 = SellQtyBest3;
            QCommodity.Best5.SellPriceBest4 = SellPriceBest4;
            QCommodity.Best5.SellQtyBest4 = SellQtyBest4;
            QCommodity.Best5.SellPriceBest5 = SellPriceBest5;
            QCommodity.Best5.SellQtyBest5 = SellQtyBest5;
            QCommodity.Best5.BuyPriceDerived = BuyPriceDerived;
            QCommodity.Best5.BuyQtyDerived = BuyQtyDerived;
            QCommodity.Best5.SellPriceDerived = SellPriceDerived;
            QCommodity.Best5.SellQtyDerived = SellQtyDerived;

            QCommodity.Best5.BuyPriceBest1s = QCommodity.Best5.BuyPriceBest1;
            if (QCommodity.Best5.BuyPriceBest1s == 0.0 && QCommodity.Match != null) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Match.MatchPrice; }
            if (QCommodity.Best5.BuyPriceBest1s == 0.0 && QCommodity.Close != null) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Close.LastSettlementPrice; }

            QCommodity.Best5.SellPriceBest1s = QCommodity.Best5.SellPriceBest1;
            if (QCommodity.Best5.SellPriceBest1s == 0.0 && QCommodity.Match != null) { QCommodity.Best5.SellPriceBest1s = QCommodity.Match.MatchPrice; }
            if (QCommodity.Best5.SellPriceBest1s == 0.0 && QCommodity.Close != null) { QCommodity.Best5.SellPriceBest1s = QCommodity.Close.LastSettlementPrice; }
            //return QCommodity.Best5.Copy();
        }
        public void SetBest5(string InformationTime, string InformationSeq, double BuyPriceBest1, int BuyQtyBest1, double BuyPriceBest2, int BuyQtyBest2, double BuyPriceBest3, int BuyQtyBest3
                             , double BuyPriceBest4, int BuyQtyBest4, double BuyPriceBest5, int BuyQtyBest5, double SellPriceBest1, int SellQtyBest1, double SellPriceBest2, int SellQtyBest2
                             , double SellPriceBest3, int SellQtyBest3, double SellPriceBest4, int SellQtyBest4, double SellPriceBest5, int SellQtyBest5)
        {
            if (QCommodity.Best5 == null){QCommodity.Best5 = new QBest5(this.QCommodity);}                

            QCommodity.Best5.CommodityId = CommodityId;
            QCommodity.Best5.InformationTime = InformationTime;
            QCommodity.Best5.InformationSeq = InformationSeq;
            QCommodity.Best5.BuyPriceBest1 = BuyPriceBest1;
            QCommodity.Best5.BuyQtyBest1 = BuyQtyBest1;
            QCommodity.Best5.BuyPriceBest2 = BuyPriceBest2;
            QCommodity.Best5.BuyQtyBest2 = BuyQtyBest2;
            QCommodity.Best5.BuyPriceBest3 = BuyPriceBest3;
            QCommodity.Best5.BuyQtyBest3 = BuyQtyBest3;
            QCommodity.Best5.BuyPriceBest4 = BuyPriceBest4;
            QCommodity.Best5.BuyQtyBest4 = BuyQtyBest4;
            QCommodity.Best5.BuyPriceBest5 = BuyPriceBest5;
            QCommodity.Best5.BuyQtyBest5 = BuyQtyBest5;
            QCommodity.Best5.SellPriceBest1 = SellPriceBest1;
            QCommodity.Best5.SellQtyBest1 = SellQtyBest1;
            QCommodity.Best5.SellPriceBest2 = SellPriceBest2;
            QCommodity.Best5.SellQtyBest2 = SellQtyBest2;
            QCommodity.Best5.SellPriceBest3 = SellPriceBest3;
            QCommodity.Best5.SellQtyBest3 = SellQtyBest3;
            QCommodity.Best5.SellPriceBest4 = SellPriceBest4;
            QCommodity.Best5.SellQtyBest4 = SellQtyBest4;
            QCommodity.Best5.SellPriceBest5 = SellPriceBest5;
            QCommodity.Best5.SellQtyBest5 = SellQtyBest5;

            QCommodity.Best5.BuyPriceBest1s = QCommodity.Best5.BuyPriceBest1;
            if (QCommodity.Best5.BuyPriceBest1s == 0.0 && QCommodity.Match != null) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Match.MatchPrice; }
            if (QCommodity.Best5.BuyPriceBest1s == 0.0 && QCommodity.Close != null) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Close.LastSettlementPrice; }

            QCommodity.Best5.SellPriceBest1s = QCommodity.Best5.SellPriceBest1;
            if (QCommodity.Best5.SellPriceBest1s == 0.0 && QCommodity.Match != null) { QCommodity.Best5.SellPriceBest1s = QCommodity.Match.MatchPrice; }
            if (QCommodity.Best5.SellPriceBest1s == 0.0 && QCommodity.Close != null) { QCommodity.Best5.SellPriceBest1s = QCommodity.Close.LastSettlementPrice; }
            //return QCommodity.Best5.Copy();
        }
        public void SetMatch(string InformationTime, string InformationSeq, int MatchSeq, string MatchTime, double MatchPrice, int MatchQty, double MatchAmt, double MatchTotalAmt, int MatchTotalQty
                             , int MatchTotalCnt, int MatchBuyTotalCnt, int MatchSellTotalCnt)
        {
            if (QCommodity.Match == null){QCommodity.Match = new QMatch(this.QCommodity);}                

            QCommodity.Match.CommodityId = CommodityId;
            QCommodity.Match.InformationTime = InformationTime;
            QCommodity.Match.InformationSeq = InformationSeq;
            QCommodity.Match.MatchSeq = MatchSeq;
            QCommodity.Match.MatchTime = MatchTime;
            QCommodity.Match.MatchPrice = MatchPrice;
            QCommodity.Match.MatchQty = MatchQty;
            QCommodity.Match.MatchAmt = MatchAmt;
            QCommodity.Match.MatchTotalAmt = MatchTotalAmt;
            QCommodity.Match.MatchTotalQty = MatchTotalQty;
            QCommodity.Match.MatchTotalCnt = MatchTotalCnt;
            QCommodity.Match.MatchBuyTotalCnt = MatchBuyTotalCnt;
            QCommodity.Match.MatchSellTotalCnt = MatchSellTotalCnt;

            if (QCommodity.Match.MatchPrice != 0.0) { QCommodity.Match.MatchPrices = QCommodity.Match.MatchPrice; }                      
            if (QCommodity.Match.MatchPrices == 0.0 && QCommodity.Close != null) { QCommodity.Match.MatchPrices = QCommodity.Close.LastSettlementPrice; }

            //return QCommodity.Match.Copy();
        }
        public void SetMatch(string InformationTime, string InformationSeq, string MatchTime, double MatchPrice, int MatchQty, int MatchTotalQty)
        {
            if (QCommodity.Match == null){QCommodity.Match = new QMatch(this.QCommodity);}                

            QCommodity.Match.CommodityId = CommodityId;
            QCommodity.Match.InformationTime = InformationTime;
            QCommodity.Match.InformationSeq = InformationSeq;
            QCommodity.Match.MatchSeq = 1;
            QCommodity.Match.MatchTime = MatchTime;
            QCommodity.Match.MatchPrice = MatchPrice;
            QCommodity.Match.MatchQty = MatchQty;
            QCommodity.Match.MatchTotalQty = MatchTotalQty;

            if (QCommodity.Match.MatchPrice != 0.0) { QCommodity.Match.MatchPrices = QCommodity.Match.MatchPrice; }            
            if (QCommodity.Match.MatchPrices == 0.0 && QCommodity.Close != null) { QCommodity.Match.MatchPrices = QCommodity.Close.LastSettlementPrice; }
            //return QCommodity.Match.Copy();
        }
        public void SetMatch(string InformationTime, string InformationSeq, string MatchTime, double MatchPrice, double MatchAmt, double MatchTotalAmt)
        {
            if (QCommodity.Match == null){QCommodity.Match = new QMatch(this.QCommodity);}                

            QCommodity.Match.CommodityId = CommodityId;
            QCommodity.Match.InformationTime = InformationTime;
            QCommodity.Match.InformationSeq = InformationSeq;
            QCommodity.Match.MatchSeq = 1;
            QCommodity.Match.MatchTime = MatchTime;
            QCommodity.Match.MatchPrice = MatchPrice;
            QCommodity.Match.MatchAmt = MatchAmt;
            QCommodity.Match.MatchTotalAmt = MatchTotalAmt;

            if (QCommodity.Match.MatchPrice != 0.0) { QCommodity.Match.MatchPrices = QCommodity.Match.MatchPrice; }            
            if (QCommodity.Match.MatchPrices == 0.0 && QCommodity.Close != null) { QCommodity.Match.MatchPrices = QCommodity.Close.LastSettlementPrice; }
            //return QCommodity.Match.Copy();
        }
        public void SetHighLow(string InformationTime, string InformationSeq, double DayHighPrice, double DayLowPrice, string ShowTime)
        {
            if (QCommodity.HighLow == null){QCommodity.HighLow = new QHighLow(this.QCommodity);}                

            QCommodity.HighLow.CommodityId = CommodityId;
            QCommodity.HighLow.InformationTime = InformationTime;
            QCommodity.HighLow.InformationSeq = InformationSeq;
            QCommodity.HighLow.DayHighPrice = DayHighPrice;
            QCommodity.HighLow.DayLowPrice = DayLowPrice;
            QCommodity.HighLow.ShowTime = ShowTime;
            //return QCommodity.HighLow.Copy();
        }
        public void SetClose(string InformationTime, string InformationSeq, double DayHighPrice, double DayLowPrice, double OpenPrice, double BuyPrice, double SellPrice, double ClosePrice, DateTime CloseDate
                             , int MatchTotalCnt, int MatchTotalQty, double MatchTotalAmt, int ComBuyCnt, int ComBuyQty, int ComSellCnt, int ComSellQty, int ComTotalQty, double SettlementPrice, int OpenInterest)
        {
            if (QCommodity.Close == null){QCommodity.Close = new QClose(this.QCommodity);}                

            QCommodity.Close.CommodityId = CommodityId;
            QCommodity.Close.InformationTime = InformationTime;            
            QCommodity.Close.InformationSeq = InformationSeq;            
            QCommodity.Close.DayHighPrice = DayHighPrice;            
            QCommodity.Close.DayLowPrice = DayLowPrice;            
            QCommodity.Close.OpenPrice = OpenPrice;            
            QCommodity.Close.BuyPrice = BuyPrice;            
            QCommodity.Close.SellPrice = SellPrice;            
            QCommodity.Close.ClosePrice = ClosePrice;            
            QCommodity.Close.CloseDate = CloseDate;           
            QCommodity.Close.MatchTotalCnt = MatchTotalCnt;
            QCommodity.Close.MatchTotalQty = MatchTotalQty;
            QCommodity.Close.MatchTotalAmt = MatchTotalAmt;
            QCommodity.Close.ComBuyCnt = ComBuyCnt;
            QCommodity.Close.ComBuyQty = ComBuyQty;
            QCommodity.Close.ComSellCnt = ComSellCnt;
            QCommodity.Close.ComSellQty = ComSellQty;
            QCommodity.Close.ComTotalQty = ComTotalQty;
            QCommodity.Close.SettlementPrice = SettlementPrice;
            QCommodity.Close.OpenInterest = OpenInterest;

            if (QCommodity.Match != null && QCommodity.Match.MatchPrices == 0.0) { QCommodity.Match.MatchPrices = ClosePrice; }
            if (QCommodity.Match != null && QCommodity.Match.MatchPrices == 0.0) { QCommodity.Match.MatchPrices = QCommodity.Close.LastSettlementPrice; }
            if (QCommodity.Best5 != null && QCommodity.Best5.BuyPriceBest1s == 0.0) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Match.MatchPrices; }
            if (QCommodity.Best5 != null && QCommodity.Best5.SellPriceBest1s == 0.0) { QCommodity.Best5.SellPriceBest1s = QCommodity.Match.MatchPrices; }            

            //return QCommodity.Close.Copy();
        }
        public void SetClose(string InformationTime, string InformationSeq, double DayHighPrice, double DayLowPrice, double OpenPrice, double BuyPrice, double SellPrice, double ClosePrice, DateTime CloseDate
                             , int MatchTotalCnt, int MatchTotalQty, double MatchTotalAmt, double SettlementPrice)
        {
            if (QCommodity.Close == null){QCommodity.Close = new QClose(this.QCommodity);}                

            QCommodity.Close.CommodityId = CommodityId;
            QCommodity.Close.InformationTime = InformationTime;
            QCommodity.Close.InformationSeq = InformationSeq;
            QCommodity.Close.DayHighPrice = DayHighPrice;
            QCommodity.Close.DayLowPrice = DayLowPrice;
            QCommodity.Close.OpenPrice = OpenPrice;
            QCommodity.Close.BuyPrice = BuyPrice;
            QCommodity.Close.SellPrice = SellPrice;
            QCommodity.Close.ClosePrice = ClosePrice;
            QCommodity.Close.CloseDate = CloseDate;
            QCommodity.Close.MatchTotalQty = MatchTotalQty;
            QCommodity.Close.MatchTotalAmt = MatchTotalAmt;            
            QCommodity.Close.MatchTotalCnt = MatchTotalCnt;            
            QCommodity.Close.SettlementPrice = SettlementPrice;

            if (QCommodity.Match != null && QCommodity.Match.MatchPrices == 0.0) { QCommodity.Match.MatchPrices = ClosePrice; }
            if (QCommodity.Match != null && QCommodity.Match.MatchPrices == 0.0) { QCommodity.Match.MatchPrices = QCommodity.Close.LastSettlementPrice; }
            if (QCommodity.Best5 != null && QCommodity.Best5.BuyPriceBest1s == 0.0) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Match.MatchPrices; }
            if (QCommodity.Best5 != null && QCommodity.Best5.SellPriceBest1s == 0.0) { QCommodity.Best5.SellPriceBest1s = QCommodity.Match.MatchPrices; }            

            //return QCommodity.Close.Copy();
        }
        public void SetClose(string InformationTime, string InformationSeq, double DayHighPrice, double DayLowPrice, double OpenPrice, double BuyPrice, double SellPrice, double ClosePrice, DateTime CloseDate
                             , int MatchTotalCnt, int MatchTotalQty, double MatchTotalAmt, int ComBuyCnt, int ComBuyQty, int ComSellCnt, int ComSellQty, int ComTotalQty, double SettlementPrice, int OpenInterest, DateTime LastCloseDate, double LastSettlementPrice, int LastOpenInterest)
        {
            if (QCommodity.Close == null) { QCommodity.Close = new QClose(this.QCommodity); }

            QCommodity.Close.CommodityId = CommodityId;
            QCommodity.Close.InformationTime = InformationTime;
            QCommodity.Close.InformationSeq = InformationSeq;
            QCommodity.Close.DayHighPrice = DayHighPrice;
            QCommodity.Close.DayLowPrice = DayLowPrice;
            QCommodity.Close.OpenPrice = OpenPrice;
            QCommodity.Close.BuyPrice = BuyPrice;
            QCommodity.Close.SellPrice = SellPrice;
            QCommodity.Close.ClosePrice = ClosePrice;
            QCommodity.Close.CloseDate = CloseDate;
            QCommodity.Close.MatchTotalCnt = MatchTotalCnt;
            QCommodity.Close.MatchTotalQty = MatchTotalQty;
            QCommodity.Close.MatchTotalAmt = MatchTotalAmt;
            QCommodity.Close.ComBuyCnt = ComBuyCnt;
            QCommodity.Close.ComBuyQty = ComBuyQty;
            QCommodity.Close.ComSellCnt = ComSellCnt;
            QCommodity.Close.ComSellQty = ComSellQty;
            QCommodity.Close.ComTotalQty = ComTotalQty;
            QCommodity.Close.SettlementPrice = SettlementPrice;
            QCommodity.Close.OpenInterest = OpenInterest;
            QCommodity.Close.LastCloseDate = LastCloseDate;
            QCommodity.Close.LastSettlementPrice = LastSettlementPrice;
            QCommodity.Close.LastOpenInterest = LastOpenInterest;

            if (QCommodity.Match != null && QCommodity.Match.MatchPrices == 0.0) { QCommodity.Match.MatchPrices = ClosePrice; }
            if (QCommodity.Match != null && QCommodity.Match.MatchPrices == 0.0) { QCommodity.Match.MatchPrices = QCommodity.Close.LastSettlementPrice; }
            if (QCommodity.Best5 != null && QCommodity.Best5.BuyPriceBest1s == 0.0) { QCommodity.Best5.BuyPriceBest1s = QCommodity.Match.MatchPrices; }
            if (QCommodity.Best5 != null && QCommodity.Best5.SellPriceBest1s == 0.0) { QCommodity.Best5.SellPriceBest1s = QCommodity.Match.MatchPrices; }            
            
            //return QCommodity.Close.Copy();
        }
        /*public void SetGreeks(string InformationTime, double LastIV, double Bid1IV, double Bid2IV, double Bid3IV, double Bid4IV, double Bid5IV, double Ask1IV
                             , double Ask2IV, double Ask3IV, double Ask4IV, double Ask5IV, double Delta, double Gamma, double Vega, double Theta, double Rho, double TPrice)
        {
            if (QCommodity.Greeks == null) { QCommodity.Greeks = new QGreeks(this.QCommodity); }

            QCommodity.Greeks.CommodityId = CommodityId;
            QCommodity.Greeks.InformationTime = InformationTime;
            QCommodity.Greeks.LastIV = LastIV;
            QCommodity.Greeks.Bid1IV = Bid1IV;
            QCommodity.Greeks.Bid2IV = Bid2IV;
            QCommodity.Greeks.Bid3IV = Bid3IV;
            QCommodity.Greeks.Bid4IV = Bid4IV;
            QCommodity.Greeks.Bid5IV = Bid5IV;
            QCommodity.Greeks.Ask1IV = Ask1IV;
            QCommodity.Greeks.Ask2IV = Ask2IV;
            QCommodity.Greeks.Ask3IV = Ask3IV;
            QCommodity.Greeks.Ask4IV = Ask4IV;
            QCommodity.Greeks.Ask5IV = Ask5IV;
            QCommodity.Greeks.Delta = Delta;
            QCommodity.Greeks.Gamma = Gamma;
            QCommodity.Greeks.Vega = Vega;
            QCommodity.Greeks.Theta = Theta;
            QCommodity.Greeks.Rho = Rho;
            QCommodity.Greeks.TPrice = TPrice;
        }*/
        public void SetExtra(string CommodityId, string UnderlyingId, PCommodity Underlying, DateTime Maturity, double Strike, double BarrierPrice, double ExecRatio, double HisVol, DateTime LastTradeDate, int IssueQty, int CancelQty, int Duration)
        {
            if (QCommodity.Extra == null) { QCommodity.Extra = new QCommodityExtra(this.QCommodity); }

            QCommodity.Extra.CommodityId = CommodityId;
            QCommodity.Extra.UnderlyingId = UnderlyingId;
            QCommodity.Extra.Underlying = Underlying;            
            QCommodity.Extra.Maturity = Maturity;
            QCommodity.Extra.Strike = Strike;
            QCommodity.Extra.BarrierPrice = BarrierPrice;
            QCommodity.Extra.ExecRatio = ExecRatio;
            QCommodity.Extra.HisVol = HisVol;
            QCommodity.Extra.LastTradeDate = LastTradeDate;
            QCommodity.Extra.IssueQty = IssueQty;
            QCommodity.Extra.CancelQty = CancelQty;
            QCommodity.Extra.Duration = Duration;

            //if (CodeMap != null) { CodeMap.SetCommodity(this); }
        }
        public void SetExtra(string CommodityId, double Strike, double ExecRatio)
        {
            if (QCommodity.Extra == null) { return; }

            QCommodity.Extra.CommodityId = CommodityId;
            QCommodity.Extra.Strike = Strike;
            QCommodity.Extra.ExecRatio = ExecRatio;         
        }
        public void SetHIV(string CommodityId, double HIV1M, double HIV3M, double HIV6M, double HIV12M)
        {
            if (QCommodity.HisVol == null) { QCommodity.HisVol = new QHistoricalVol(this.QCommodity); }

            QCommodity.HisVol.CommodityId = CommodityId;
            QCommodity.HisVol.HIV1M = HIV1M;
            QCommodity.HisVol.HIV3M = HIV3M;
            QCommodity.HisVol.HIV6M = HIV6M;
            QCommodity.HisVol.HIV12M = HIV12M;            
        }

        public void Set(ClientState ClientState)
        {
            lock (LockObj)
            {
                if (!m_Subscribes.Contains(ClientState))
                    m_Subscribes.Add(ClientState);
            }
        }
        public List<ClientState> Subscribes
        {
            get
            {
                List<ClientState> L = null;

                lock (LockObj)
                {
                    L = m_Subscribes.ToList<ClientState>();
                }

                return L;
            }
        }
        /*public int GetSubscribeNum
        {
            get
            {
                return Subscribes.Count;
            }
        }*/
        public void Remove(ClientState ClientState)
        {
            lock (LockObj)
            {
                if (m_Subscribes.Contains(ClientState))
                    m_Subscribes.Remove(ClientState);
            }
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_Subscribes.Clear();
                //m_RelationCommoditys.Clear();
            }
        }
        public void Close()
        {
            try
            {
                foreach (ClientState ClientState in Subscribes)
                    ClientState.Remove(this);

                Clear();
                        
                QCommodity = null;

                CodeMap = null;
                CMarket = null;
            }
            catch (Exception ex)
            {
            }
        }
        /*public void AddRelation(PCommodity rPCommodity)
        {
            lock(LockObj)
            {
                if (!m_RelationCommoditys.ContainsKey(rPCommodity.CommodityId))
                    m_RelationCommoditys.Add(rPCommodity.CommodityId, rPCommodity);
                else
                    m_RelationCommoditys[rPCommodity.CommodityId] = rPCommodity;
            }
        }
        public void RemoveRelation(string CommodityId)
        {
            lock (LockObj)
            {
                if (m_RelationCommoditys.ContainsKey(CommodityId))
                    m_RelationCommoditys.Remove(CommodityId);
            }
        }*/
        /*public List<PCommodity> RelationCommoditys
        {
            get
            {
                List<PCommodity> L = new List<PCommodity>();

                lock (LockObj)
                {
                    L = m_RelationCommoditys.Values.ToList<PCommodity>();
                }

                return L;
            }
        }*/
        public void Send(object obj)
        {   
            List<ClientState> ClientStateRemoveList = new List<ClientState>();

            if (QuoteUpdateEvent != null) { QuoteUpdateEvent(this, obj); }

            foreach (ClientState ClientState in Subscribes)
            {
                try
                {
                    ClientState.AddData(obj);
                }
                catch
                {
                    ClientStateRemoveList.Add(ClientState);
                }
            }

            foreach (ClientState clientstate in ClientStateRemoveList)
                clientstate.Close();
        }
        public void ClearCommodity()
        {
            lock (LockObj)
            {
                double matchs = 0.0;
                double buyprice = 0.0;
                double sellprice = 0.0;
                //QCommodityExtra = null;
                //QCommodity.Extra = null;

                matchs = QCommodity.Match.MatchPrices;
                buyprice = QCommodity.Best5.BuyPriceBest1s;
                sellprice = QCommodity.Best5.SellPriceBest1s;

                QCommodity.Open = new QOpen(this.QCommodity);                
                QCommodity.Best5 = new QBest5(this.QCommodity);
                QCommodity.Match = new QMatch(this.QCommodity);
                QCommodity.HighLow = new QHighLow(this.QCommodity);
                //QCommodity.Close = new QClose(this.QCommodity);
                //QCommodity.Greeks = new QGreeks(this.QCommodity);

                QCommodity.Open.CommodityId = CommodityId;
                QCommodity.Best5.CommodityId = CommodityId;
                QCommodity.Match.CommodityId = CommodityId;
                QCommodity.HighLow.CommodityId = CommodityId;
                //QCommodity.Close.CommodityId = CommodityId;
                //QCommodity.Greeks.CommodityId = CommodityId;

                QCommodity.Close.SettlementPrice = 0.0;
                QCommodity.Close.OpenInterest = 0;

                QCommodity.Match.MatchPrices = matchs;
                QCommodity.Best5.BuyPriceBest1s = buyprice;
                QCommodity.Best5.SellPriceBest1s = sellprice;

                if (QCommodity.Ticks != null)
                    QCommodity.Ticks.Clear();
            }
        }
        public void ClearHIVExtra()
        {
            lock (LockObj)
            {                
                QCommodity.HisVol = null;                
                QCommodity.Extra = null;
            }
        }
        public void TransLastClosePrice()
        {
            lock (LockObj)
            {
                QCommodity.Close.LastCloseDate = QCommodity.Close.CloseDate;
                QCommodity.Close.LastSettlementPrice = QCommodity.Close.SettlementPrice;
                QCommodity.Close.LastOpenInterest = QCommodity.Close.OpenInterest;
            }
        }
    }
    public class PCommodityList
    {
        private Dictionary<string, PCommodity> m_Commoditys = new Dictionary<string, PCommodity>();        
        private CMarketList CMarketList = null;
        private object LockObj = new object();
        private QuoteSetting Setting = null;
        public PCommodity FQuery = new PCommodity("FQuery");
        public PCommodity OQuery = new PCommodity("OQuery");
        //private Dictionary<string, string> SYSMonths = new Dictionary<string, string>();
        //private Dictionary<string, string> TFEMonths = new Dictionary<string, string>();

        public PCommodityList(QuoteSetting Setting, CMarketList CMarketList)
        {
            /*SYSMonths.Add("F", "A");
            SYSMonths.Add("G", "B");
            SYSMonths.Add("H", "C");
            SYSMonths.Add("J", "D");
            SYSMonths.Add("K", "E");
            SYSMonths.Add("M", "F");
            SYSMonths.Add("N", "G");
            SYSMonths.Add("Q", "H");
            SYSMonths.Add("U", "I");
            SYSMonths.Add("V", "J");
            SYSMonths.Add("X", "K");
            SYSMonths.Add("Z", "L");

            TFEMonths.Add("A", "F");
            TFEMonths.Add("B", "G");
            TFEMonths.Add("C", "H");
            TFEMonths.Add("D", "J");
            TFEMonths.Add("E", "K");
            TFEMonths.Add("F", "M");
            TFEMonths.Add("G", "N");
            TFEMonths.Add("H", "Q");
            TFEMonths.Add("I", "U");
            TFEMonths.Add("J", "V");
            TFEMonths.Add("K", "X");
            TFEMonths.Add("L", "Z");*/

            this.Setting = Setting;
            this.CMarketList = CMarketList;
        }
        public PCommodity Set(string CommodityId)
        {
            try
            {
                PCommodity mPCommodity = null;
                bool GetCommodity_Flag = false;

                //if (CommodityId.IndexOf("HK") > -1)
                //    Console.WriteLine(CommodityId);

                lock (LockObj)
                {
                    if (!m_Commoditys.ContainsKey(CommodityId))
                    {
                        PCommodity PCommodity = new PCommodity(CommodityId);
                        m_Commoditys.Add(CommodityId, PCommodity);
                        GetCommodity_Flag = true;
                    }

                    mPCommodity = m_Commoditys[CommodityId];
                }

                if (GetCommodity_Flag)
                    GetCommodity(mPCommodity);

                if (mPCommodity.QCommodity.Base.CommodityKind == CommodityKind.Warrant || mPCommodity.QCommodity.Base.CommodityKind == CommodityKind.Option || mPCommodity.QCommodity.Base.CommodityKind == CommodityKind.Future)
                    if (Setting.LoadCommodityExtra && mPCommodity.QCommodity.Extra == null) { GetCommodityExtra(mPCommodity); }

                if (mPCommodity.QCommodity.Base.CommodityKind == CommodityKind.Stock || mPCommodity.QCommodity.Base.CommodityKind == CommodityKind.Index || mPCommodity.QCommodity.Base.CommodityKind == CommodityKind.ETF)
                    if (Setting.LoadCommodityExtra && mPCommodity.QCommodity.HisVol == null) { GetCommodityHIV(mPCommodity); }

                if (mPCommodity.CMarket != null) { mPCommodity.CMarket.SetCommodity(mPCommodity); }
                //if (mPCommodity.QCommodity.Base != null && mPCommodity.QCommodity.Base.InnerCode != string.Empty && mPCommodity.QCommodity.Base.InnerCode != null) { mPCommodity.CMarket.SetInnerCode(mPCommodity.QCommodity.Base.InnerCode, mPCommodity); }

                return mPCommodity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public PCommodity Set(string Code, string CommodityId, Market Market, CommodityKind CommodityKind)
        {
            PCommodity mPCommodity = null;
            bool GetCommodity_Flag = false;

            lock (LockObj)
            {
                if (!m_Commoditys.ContainsKey(CommodityId))
                {
                    mPCommodity = new PCommodity(CommodityId);
                    m_Commoditys.Add(CommodityId, mPCommodity);
                    GetCommodity_Flag = true;
                }

                mPCommodity = m_Commoditys[CommodityId];
            }

            if (GetCommodity_Flag)
                GetCommodity(mPCommodity);

            if (CommodityKind == CommodityKind.Warrant || CommodityKind == CommodityKind.Option || CommodityKind == CommodityKind.Future)
                if (Setting.LoadCommodityExtra && mPCommodity.QCommodity.Extra == null) { GetCommodityExtra(mPCommodity); }

            if (CommodityKind == CommodityKind.Stock || CommodityKind == CommodityKind.Index || CommodityKind == CommodityKind.ETF)
                if (Setting.LoadCommodityExtra && mPCommodity.QCommodity.HisVol == null) { GetCommodityHIV(mPCommodity); }
                        
            mPCommodity.CMarket = CMarketList.Get(Market);            
            
            if (mPCommodity.CMarket != null) 
            {
                mPCommodity.CodeMap = mPCommodity.CMarket.GetCodeMap(CommodityKind, Code);
                mPCommodity.CMarket.SetCommodity(mPCommodity); 
            }
            //if (mPCommodity.QCommodity.Base != null && mPCommodity.QCommodity.Base.InnerCode != string.Empty && mPCommodity.QCommodity.Base.InnerCode != null) { mPCommodity.CMarket.SetInnerCode(mPCommodity.QCommodity.Base.InnerCode, mPCommodity); }

            return mPCommodity;  
        }
        public PCommodity SetNotGetFromDB(string Code, string CommodityId, Market Market, CommodityKind CommodityKind)
        {
            PCommodity mPCommodity = null;

            //if (CommodityId.IndexOf("HK") > -1)
            //    Console.WriteLine(CommodityId);

            lock (LockObj)
            {
                if (!m_Commoditys.ContainsKey(CommodityId))
                {
                    mPCommodity = new PCommodity(CommodityId);
                    m_Commoditys.Add(CommodityId, mPCommodity);                    
                }

                mPCommodity = m_Commoditys[CommodityId];
            }

            mPCommodity.CMarket = CMarketList.Get(Market);

            if (mPCommodity.CMarket != null)
            {
                mPCommodity.CodeMap = mPCommodity.CMarket.GetCodeMap(CommodityKind, Code);
                mPCommodity.CMarket.SetCommodity(mPCommodity);
            }
            //if (mPCommodity.QCommodity.Base != null && mPCommodity.QCommodity.Base.InnerCode != string.Empty && mPCommodity.QCommodity.Base.InnerCode != null) { mPCommodity.CMarket.SetInnerCode(mPCommodity.QCommodity.Base.InnerCode, mPCommodity); }

            return mPCommodity;
        }      
        public PCommodity Get(string CommodityId)
        {
            lock (LockObj)
            {
                if (m_Commoditys.ContainsKey(CommodityId))
                    return m_Commoditys[CommodityId];
                else
                    return null;
            }
        }
        /*public string GetSYSMonth(string TFEMonth)
        {
            try
            {
                if (TFEMonths.ContainsKey(TFEMonth)) { return TFEMonths[TFEMonth].ToString(); }
                else return "";
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        public string GetTFEMonth(string SYSMonth)
        {
            try
            {
                if (SYSMonths.ContainsKey(SYSMonth)) { return SYSMonths[SYSMonth].ToString(); }
                else return "";
            }
            catch (Exception ex)
            {
                return "";
            }
        }*/
        public List<PCommodity> Commoditys
        {
            get
            {
                List<PCommodity> L = null;

                lock (LockObj)
                {
                    L = m_Commoditys.Values.ToList<PCommodity>();
                }

                return L;
            }
        }
        public void Remove(string CommodityId)
        {
            PCommodity PCommodity = null;

            lock (LockObj)
            {
                if (m_Commoditys.ContainsKey(CommodityId))
                    PCommodity = m_Commoditys[CommodityId];
                else
                    return;
            }

            //if (PCommodity.RelationCommoditys != null && PCommodity.RelationCommoditys.Count > 0) { return; }

            //if (PCommodity.QCommodity.Extra != null && PCommodity.QCommodity.Extra.Underlying != null)
            //    PCommodity.QCommodity.Extra.Underlying.RemoveRelation(CommodityId);

            if (PCommodity.CMarket != null) { PCommodity.CMarket.RemoveCommodity(CommodityId); }

            if (PCommodity != null)
                PCommodity.Close();

            
            lock (LockObj)
            {
                if (m_Commoditys.ContainsKey(CommodityId))
                    m_Commoditys.Remove(CommodityId);
            }
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_Commoditys.Clear();
            }
        }
        public void Close()
        {
            try
            {
                foreach (PCommodity PCommodity in Commoditys)
                    PCommodity.Close();

                FQuery.Close();
                OQuery.Close();

                Clear();
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }
        public void ReloadData(Market Market)
        {
            int i = 0;

            DataView dv = Util.ExecSqlQry("select * from vwPrice where market = " + ((int)Market).ToString(), Setting.DBConnectString);
            DataView dv1;
            PCommodity PCommodity = null;

            foreach (DataRowView dr in dv)
            {
                string CommodityId = dr["CommodityId"].ToString().Trim();

                lock (LockObj)
                {
                    if (!m_Commoditys.ContainsKey(CommodityId))
                        m_Commoditys.Add(CommodityId, new PCommodity(CommodityId));

                    PCommodity = m_Commoditys[CommodityId];
                    PCommodity.IsLocalCommodity = true;
                }
                SetCommodityDr(dr, PCommodity);

                if (PCommodity.CMarket != null) { PCommodity.CMarket.SetCommodity(PCommodity); }
                //if (PCommodity.QCommodity.Base != null && PCommodity.QCommodity.Base.InnerCode != string.Empty && PCommodity.QCommodity.Base.InnerCode != null) { PCommodity.CMarket.SetInnerCode(PCommodity.QCommodity.Base.InnerCode, PCommodity); }
            }

            //dv = Util.ExecSqlQry("select a.*,b.commoditynm from hclose a,commodity b where a.commodityid=b.commodityid and b.market='" + Market + "' and a.closedate in (select max(closedate) from hclose d where d.commodityid=a.commodityid)", Setting.DBConnectString);
            dv = Util.ExecSqlQry("select a.commodityid,a.closedate,isnull(a.SettlementPrice,0) SettlementPrice,isnull(a.OpenInterest,0) OpenInterest from lclose a,commodity b,pbase c where a.commodityid=b.commodityid and b.commodityid=c.commodityid and b.market='" + Market + "'", Setting.DBConnectString);
            
            foreach (DataRowView dr in dv)
            {
                //i++;
                //Console.WriteLine(i.ToString());

                string CommodityId = dr["CommodityId"].ToString().Trim();

                lock (LockObj)
                {
                    if (!m_Commoditys.ContainsKey(CommodityId))
                        continue;

                    PCommodity = m_Commoditys[CommodityId];                    
                }
                SetCommodityLastCloseDr(dr, PCommodity);

                if (PCommodity.QCommodity.Base.CommodityKind == CommodityKind.Warrant || PCommodity.QCommodity.Base.CommodityKind == CommodityKind.Option || PCommodity.QCommodity.Base.CommodityKind == CommodityKind.Future)
                    if (Setting.LoadCommodityExtra && PCommodity.QCommodity.Extra == null) { GetCommodityExtra(PCommodity); }

                if (PCommodity.QCommodity.Base.CommodityKind == CommodityKind.Stock || PCommodity.QCommodity.Base.CommodityKind == CommodityKind.Index || PCommodity.QCommodity.Base.CommodityKind == CommodityKind.ETF)
                    if (Setting.LoadCommodityExtra && PCommodity.QCommodity.HisVol == null) { GetCommodityHIV(PCommodity); }
            }            
        }
        public void ClearExpireCommodity()
        {
            List<PCommodity> L;
            List<ClientState> C;
            
            lock (LockObj)
            {
                L = m_Commoditys.Values.ToList<PCommodity>();
            }

            foreach (PCommodity PCommodity in L)
            {   

                if (PCommodity.QCommodity.Base != null && PCommodity.QCommodity.Base.TradeDate.Subtract(DateTime.Today).Days < -10)
                {
                    foreach (ClientState ClientState in PCommodity.Subscribes)
                        ClientState.Remove(PCommodity);

                    this.Remove(PCommodity.CommodityId);
                }
                
            }
        }
        /*public void MarketSend(CMarket CMarket, object obj)
        {
            lock (LockObj)
            {
                foreach (PCommodity PCommodity in Commoditys.Values)
                {
                    if (PCommodity.QCommodity.Base.Market == CMarket.Market)
                        PCommodity.Send(obj);
                }
            }
        }*/
        /*public void MarketClear(CMarket CMarket)
        {
            lock (LockObj)
            {
                foreach (PCommodity PCommodity in Commoditys.Values)
                {
                    if (PCommodity.QCommodity.Base.Market == CMarket.Market)
                    {
                        if (PCommodity.QCommodity.Base.TradeDate == CMarket.TradeDate)
                        {
                            PCommodity.ClearCommodity();
                            PCommodity.Send(PCommodity.QCommodity);
                        }
                        else if (PCommodity.QCommodity.Base.TradeDate.Subtract(CMarket.TradeDate).Days < -2)
                            PCommodity.Close();
                    }
                }
            }
        }*/
        /*public void SetAllCommodity()
        {
            DataView dv = Util.ExecSqlQry("select * from vwPrice", DBConnectString);

            foreach (DataRowView dr in dv)
            {
                string CommodityId = dr["CommodityId"].ToString();

                PCommodity PCommodity = new PCommodity(CommodityId);
                SetCommodityDr(dr, PCommodity);
                Commoditys.Add(CommodityId, PCommodity);
            }
        }*/
        
        private void GetCommodity(PCommodity PCommodity)
        {
            DataView dv = Util.ExecSqlQry("select * from vwPrice where CommodityId='" + PCommodity.CommodityId + "'", Setting.DBConnectString);

            if (dv.Count > 0)
                SetCommodityDr(dv[0], PCommodity);

            //dv = Util.ExecSqlQry("select top 2 a.*,b.commoditynm,isnull(c.SettlementPrice,0) SettlementPrice2,isnull(c.OpenInterest,0) OpenInterest2 from hclose a left join commodity b on a.commodityid=b.commodityid left join pclose c on a.commodityid=c.commodityid where a.commodityid='" + PCommodity.CommodityId + "' order by a.closedate desc", Setting.DBConnectString);
            dv = Util.ExecSqlQry("select a.commodityid,a.closedate,isnull(a.SettlementPrice,0) SettlementPrice,isnull(a.OpenInterest,0) OpenInterest from lclose a,pbase b where a.commodityid=b.commodityid and a.commodityid='" + PCommodity.CommodityId + "'", Setting.DBConnectString);
            if (dv.Count > 0)
                SetCommodityLastCloseDr(dv[0], PCommodity);            
        }
        private void SetCommodityDr(DataRowView dr, PCommodity iPCommodity)
        {            
            string commodityid = dr["commodityid"].ToString();            
            string commoditynm = dr["commoditynm"].ToString();
            string commoditycode = dr["commoditycode"].ToString();
            Market market = (Market)dr["market"];
            CommodityKind commoditykind = (CommodityKind)dr["commoditykind"];
            CommodityType commoditytype = (CommodityType)dr["commoditytype"];
            string commodityproperty = dr["commodityproperty"].ToString();
            string settlementmonth = dr["settlementmonth"].ToString();
            double strike = (double)dr["strike"];
            string prodkind = dr["prodkind"].ToString();
            double decimallocate = (double)dr["decimallocate"];
            double strikedecimallocate = (double)dr["strikedecimallocate"];
            int unit = (int)dr["unit"];
            string innercode = dr["innercode"].ToString();
            DateTime tradedate = (DateTime)dr["tradedate"];
            string baseinformationtime = dr["baseinformationtime"].ToString();
            string baseinformationseq = dr["baseinformationseq"].ToString();
            double referenceprice = (double)dr["referenceprice"];
            double riselimitprice = (double)dr["riselimitprice"];
            double falllimitprice = (double)dr["falllimitprice"];
            double riselimitprice2 = (double)dr["riselimitprice2"];
            double falllimitprice2 = (double)dr["falllimitprice2"];
            double riselimitprice3 = (double)dr["riselimitprice3"];
            double falllimitprice3 = (double)dr["falllimitprice3"];
            string opentime = dr["opentime"].ToString();
            double openprice = (double)dr["openprice"];
            string matchinformationtime = dr["matchinformationtime"].ToString();
            string matchinformationseq = dr["matchinformationseq"].ToString();
            int matchseq = (int)dr["matchseq"];
            string matchtime = dr["matchtime"].ToString();
            double matchprice = (double)dr["matchprice"];
            int matchqty = (int)dr["matchqty"];
            double matchamt = (double)dr["matchamt"];
            double matchtotalamt = (double)dr["matchtotalamt"];
            int matchtotalqty = (int)dr["matchtotalqty"];
            int matchtotalcnt = (int)dr["matchtotalcnt"];
            int matchbuytotalcnt = (int)dr["matchbuytotalcnt"];
            int matchselltotalcnt = (int)dr["matchselltotalcnt"];
            string best5informationtime = dr["best5informationtime"].ToString();
            string best5informationseq = dr["best5informationseq"].ToString();
            double buypricebest1 = (double)dr["buypricebest1"];
            int buyqtybest1 = (int)dr["buyqtybest1"];
            double buypricebest2 = (double)dr["buypricebest2"];
            int buyqtybest2 = (int)dr["buyqtybest2"];
            double buypricebest3 = (double)dr["buypricebest3"];
            int buyqtybest3 = (int)dr["buyqtybest3"];
            double buypricebest4 = (double)dr["buypricebest4"];
            int buyqtybest4 = (int)dr["buyqtybest4"];
            double buypricebest5 = (double)dr["buypricebest5"];
            int buyqtybest5 = (int)dr["buyqtybest5"];
            double sellpricebest1 = (double)dr["sellpricebest1"];
            int sellqtybest1 = (int)dr["sellqtybest1"];
            double sellpricebest2 = (double)dr["sellpricebest2"];
            int sellqtybest2 = (int)dr["sellqtybest2"];
            double sellpricebest3 = (double)dr["sellpricebest3"];
            int sellqtybest3 = (int)dr["sellqtybest3"];
            double sellpricebest4 = (double)dr["sellpricebest4"];
            int sellqtybest4 = (int)dr["sellqtybest4"];
            double sellpricebest5 = (double)dr["sellpricebest5"];
            int sellqtybest5 = (int)dr["sellqtybest5"];
            double buypricederived = (double)dr["buypricederived"];
            int buyqtyderived = (int)dr["buyqtyderived"];
            double sellpricederived = (double)dr["sellpricederived"];
            int sellqtyderived = (int)dr["sellqtyderived"];
            string highlowinformationtime = dr["highlowinformationtime"].ToString();
            string highlowinformationseq = dr["highlowinformationseq"].ToString();
            double dayhighprice = (double)dr["dayhighprice"];
            double daylowprice = (double)dr["daylowprice"];
            string showtime = dr["showtime"].ToString();
            string closeinformationtime = dr["closeinformationtime"].ToString();
            string closeinformationseq = dr["closeinformationseq"].ToString();
            DateTime closedate = (DateTime)dr["closedate"];
            double closedayhighprice = (double)dr["closedayhighprice"];
            double closedaylowprice = (double)dr["closedaylowprice"];
            double closeopenprice = (double)dr["closeopenprice"];
            double buyprice = (double)dr["buyprice"];
            double sellprice = (double)dr["sellprice"];
            double closeprice = (double)dr["closeprice"];
            int closematchtotalcnt = (int)dr["closematchtotalcnt"];
            int closematchtotalqty = (int)dr["closematchtotalqty"];
            double closematchtotalamt = (double)dr["closematchtotalamt"];
            int combuycnt = (int)dr["combuycnt"];
            int combuyqty = (int)dr["combuyqty"];
            int comsellcnt = (int)dr["comsellcnt"];
            int comsellqty = (int)dr["comsellqty"];
            int comtotalqty = (int)dr["comtotalqty"];
            double settlementprice = (double)dr["settlementprice"];
            int openinterest = (int)dr["openinterest"];
            //string syscode = "";

            iPCommodity.CMarket = CMarketList.Get(market);
            if (iPCommodity.CMarket != null)
                iPCommodity.CodeMap = iPCommodity.CMarket.GetCodeMap(commoditykind,commoditycode);
            /*if (iPCommodity.CodeMap != null) { syscode = iPCommodity.CodeMap.SYSCode; }

            if (syscode != "" && iPCommodity.CMarket.Market == Market.TFE) 
            {
                string month = GetSYSMonth(commodityid.Substring(commodityid.Length-2,1));
                if (month != "")
                    syscode += month + commodityid.Substring(commodityid.Length - 1, 1); 
            }*/
            iPCommodity.SetBase(market, commoditykind, commoditytype, commoditycode, commoditynm, tradedate, baseinformationtime, baseinformationseq, settlementmonth, strike, referenceprice, riselimitprice, falllimitprice, riselimitprice2, falllimitprice2, riselimitprice3, falllimitprice3, unit, prodkind, decimallocate, strikedecimallocate, innercode,commodityproperty);
            iPCommodity.SetOpen(opentime, openprice);
            iPCommodity.SetBest5(best5informationtime, best5informationseq, buypricebest1, buyqtybest1, buypricebest2, buyqtybest2, buypricebest3, buyqtybest3, buypricebest4, buyqtybest4, buypricebest5, buyqtybest5, sellpricebest1, sellqtybest1, sellpricebest2, sellqtybest2, sellpricebest3, sellqtybest3, sellpricebest4, sellqtybest4, sellpricebest5, sellqtybest5, buypricederived, buyqtyderived, sellpricederived, sellqtyderived);
            iPCommodity.SetMatch(matchinformationtime, matchinformationseq, matchseq, matchtime, matchprice, matchqty, matchamt, matchtotalamt, matchtotalqty, matchtotalcnt, matchbuytotalcnt, matchselltotalcnt);
            iPCommodity.SetHighLow(highlowinformationtime, highlowinformationseq, dayhighprice, daylowprice, showtime);
            iPCommodity.SetClose(closeinformationtime, closeinformationseq, closedayhighprice, closedaylowprice, closeopenprice, buyprice, sellprice, closeprice, closedate, closematchtotalcnt, closematchtotalqty, closematchtotalamt, combuycnt, combuyqty, comsellcnt, comsellqty, comtotalqty, settlementprice, openinterest);
        }
        private void SetCommodityLastCloseDr(DataRowView dr, PCommodity iPCommodity)
        {
            string commodityid = dr["commodityid"].ToString();
            DateTime closedate = (DateTime)dr["closedate"];            
            double settlementprice = (double)dr["settlementprice"];
            int openinterest = (int)dr["openinterest"];
            
            iPCommodity.QCommodity.Base.CommodityId = commodityid;
            iPCommodity.QCommodity.Best5.CommodityId = commodityid;
            iPCommodity.QCommodity.Match.CommodityId = commodityid;
            iPCommodity.QCommodity.Close.CommodityId = commodityid;

            if (iPCommodity.QCommodity.Match.MatchPrices == 0.0) { iPCommodity.QCommodity.Match.MatchPrices = settlementprice; }
            if (iPCommodity.QCommodity.Best5.BuyPriceBest1s == 0.0) { iPCommodity.QCommodity.Best5.BuyPriceBest1s = iPCommodity.QCommodity.Match.MatchPrices; }
            if (iPCommodity.QCommodity.Best5.SellPriceBest1s == 0.0) { iPCommodity.QCommodity.Best5.SellPriceBest1s = iPCommodity.QCommodity.Match.MatchPrices; }            
            
            iPCommodity.QCommodity.Close.LastCloseDate = closedate;
            iPCommodity.QCommodity.Close.LastSettlementPrice = settlementprice;
            iPCommodity.QCommodity.Close.LastOpenInterest = openinterest;            
        }
        private void GetCommodityExtra(PCommodity PCommodity)
        {
            DataView dv = Util.ExecSqlQry("select CommodityId,isnull(Underlying,'') Underlying,Maturity,isnull(Strike,0) Strike,isnull(BarrierPrice,0) BarrierPrice,isnull(ExecRatio,1) ExecRatio,(isnull(HisVol,0) / 100.0) HisVol,LastTradeDate,isnull(IssueQty,0) IssueQty,isnull(CancelQty,0) CancelQty,IssueDate,isnull(Duration,0) Duration from commodityextra where CommodityId='" + PCommodity.CommodityId + "'", Setting.DBConnectString);
            
            if (dv.Count > 0)
                SetCommodityExtraDr(dv[0], PCommodity);
        }
        private void SetCommodityExtraDr(DataRowView dr, PCommodity iPCommodity)
        {
            string commodityid = dr["commodityid"].ToString();
            if (dr["Underlying"].ToString() == "") { return; }
            PCommodity Underlying = Set(dr["Underlying"].ToString());
            /*Underlying.AddRelation(iPCommodity); */           
            DateTime Maturity = (DateTime)dr["Maturity"];
            double Strike = (double)dr["Strike"];            
            double BarrierPrice = (double)dr["BarrierPrice"];            
            double ExecRatio = (double)dr["ExecRatio"];
            double HisVol = (double)dr["HisVol"];
            DateTime LastTradeDate = (DateTime)dr["LastTradeDate"];
            int IssueQty = (int)dr["IssueQty"];
            int CancelQty = (int)dr["CancelQty"];
            int Duration = (int)dr["Duration"];

            iPCommodity.SetExtra(iPCommodity.CommodityId, dr["Underlying"].ToString(),Underlying,Maturity,Strike,BarrierPrice,ExecRatio,HisVol,LastTradeDate,IssueQty,CancelQty,Duration);

            
            //CalculateGreeks(iPCommodity);
        }
        private void GetCommodityHIV(PCommodity PCommodity)
        {
            DataView dv = Util.ExecSqlQry("select CommodityId,(isnull(HIV1M,0) / 100.0) HIV1M,(isnull(HIV3M,0) / 100.0) HIV3M,(isnull(HIV6M,0) / 100.0) HIV6M,(isnull(HIV12M,0) / 100.0) HIV12M from commodityhiv where CommodityId='" + PCommodity.CommodityId + "'", Setting.DBConnectString);

            if (dv.Count > 0)
                SetCommodityHIVDr(dv[0], PCommodity);
        }
        private void SetCommodityHIVDr(DataRowView dr, PCommodity iPCommodity)
        {
            string commodityid = dr["commodityid"].ToString();
            double HIV1M = (double)dr["HIV1M"];
            double HIV3M = (double)dr["HIV3M"];
            double HIV6M = (double)dr["HIV6M"];
            double HIV12M = (double)dr["HIV12M"];

            iPCommodity.SetHIV(iPCommodity.CommodityId, HIV1M, HIV3M, HIV6M, HIV12M);
        }
        /*private void CalculateGreeks(PCommodity mPCommodity)
        {                   
            double lastiv = 0.0;
            double bidiv1 = 0.0;
            double bidiv2 = 0.0;
            double bidiv3 = 0.0;
            double bidiv4 = 0.0;
            double bidiv5 = 0.0;
            double askiv1 = 0.0;
            double askiv2 = 0.0;
            double askiv3 = 0.0;
            double askiv4 = 0.0;
            double askiv5 = 0.0;
            double delta = 0.0;
            double gamma = 0.0;
            double vega = 0.0;
            double theta = 0.0;
            double rho = 0.0;
            double tprice = 0.0;

            try
            {

                if (mPCommodity.QCommodity.Best5 != null && mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match != null)
                {
                    bidiv1 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest1s / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv2 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest2 / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv3 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest3 / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv4 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest4 / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv5 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest5 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv1 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest1s / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv2 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest2 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv3 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest3 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv4 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest4 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv5 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest5 / mPCommodity.QCommodity.Extra.ExecRatio);
                }
                if (mPCommodity.QCommodity.Match != null && mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match != null)
                {
                    lastiv = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Base.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Match.MatchPrices / mPCommodity.QCommodity.Extra.ExecRatio);
                    delta = Greeks.CalcDelta((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    gamma = Greeks.CalcGamma((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    vega = Greeks.CalcVega((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    theta = Greeks.CalcTheta((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    rho = Greeks.CalcRho((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    tprice = Greeks.CalcTPrice((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                }

                if (double.IsNaN(bidiv1) && double.IsInfinity(bidiv1)) { bidiv1 = 0.0; }
                if (double.IsNaN(bidiv2) && double.IsInfinity(bidiv2)) { bidiv2 = 0.0; }
                if (double.IsNaN(bidiv3) && double.IsInfinity(bidiv3)) { bidiv3 = 0.0; }
                if (double.IsNaN(bidiv4) && double.IsInfinity(bidiv4)) { bidiv4 = 0.0; }
                if (double.IsNaN(bidiv5) && double.IsInfinity(bidiv5)) { bidiv5 = 0.0; }
                if (double.IsNaN(askiv1) && double.IsInfinity(askiv1)) { askiv1 = 0.0; }
                if (double.IsNaN(askiv2) && double.IsInfinity(askiv2)) { askiv2 = 0.0; }
                if (double.IsNaN(askiv3) && double.IsInfinity(askiv3)) { askiv3 = 0.0; }
                if (double.IsNaN(askiv4) && double.IsInfinity(askiv4)) { askiv4 = 0.0; }
                if (double.IsNaN(askiv5) && double.IsInfinity(askiv5)) { askiv5 = 0.0; }
                if (double.IsNaN(lastiv) && double.IsInfinity(lastiv)) { lastiv = 0.0; }
                if (double.IsNaN(delta) && double.IsInfinity(delta)) { delta = 0.0; }
                if (double.IsNaN(gamma) && double.IsInfinity(gamma)) { gamma = 0.0; }
                if (double.IsNaN(vega) && double.IsInfinity(vega)) { vega = 0.0; }
                if (double.IsNaN(theta) && double.IsInfinity(theta)) { theta = 0.0; }
                if (double.IsNaN(rho) && double.IsInfinity(rho)) { rho = 0.0; }
                if (double.IsNaN(tprice) && double.IsInfinity(tprice)) { tprice = 0.0; }

                mPCommodity.SetGreeks(DateTime.Now.ToString("HHmmssff"), lastiv, bidiv1, bidiv2, bidiv3, bidiv4, bidiv5, askiv1, askiv2, askiv3, askiv4, askiv5, delta, gamma, vega, theta, rho,tprice);
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }*/
    }

    public class ClientState : IClientState
    {
        private HashSet<PCommodity> m_Commoditys = new HashSet<PCommodity>();
        private HashSet<CMarket> m_Markets = new HashSet<CMarket>();        
        public IQuoteCallBacks Callback;        
        public string IP = "";
        public int Port = 0;
        public DateTime LoginTime = DateTime.Now;
        private Queue DataQueue = new Queue();
        private object LockObj = new object();
        private Thread RoutineThread;
        public DateTime AliveTime = DateTime.Now;
        public bool IsSubFutureQuery = false;
        public bool IsSubOptionQuery = false;

        public ClientState(OperationContext O)
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            this.Callback = O.GetCallbackChannel<IQuoteCallBacks>();
            if (!O.IncomingMessageProperties.ContainsKey(RemoteEndpointMessageProperty.Name)) { IP = "127.0.0.1"; }
            else 
            {
                RemoteEndpointMessageProperty r = (RemoteEndpointMessageProperty)O.IncomingMessageProperties[System.ServiceModel.Channels.RemoteEndpointMessageProperty.Name];
                IP = r.Address;
                Port = r.Port;
            }
        }

        public void Set(PCommodity PCommodity)
        {
            lock (LockObj)
            {
                if (!m_Commoditys.Contains(PCommodity))
                    m_Commoditys.Add(PCommodity);
            }
        }
        public void Set(CMarket CMarket)
        {
            lock (LockObj)
            {
                if (!m_Markets.Contains(CMarket))
                    m_Markets.Add(CMarket);
            }
        }
        public List<PCommodity> Commoditys
        {
            get
            {
                List<PCommodity> L = null;

                lock (LockObj)
                {
                    L = m_Commoditys.ToList<PCommodity>();
                }

                return L;
            }
        }
        public List<CMarket> Markets
        {
            get
            {
                List<CMarket> L = null;

                lock (LockObj)
                {
                    L = m_Markets.ToList<CMarket>();
                }

                return L;
            }
        }
        public void Remove(PCommodity PCommodity)
        {
            lock (LockObj)
            {
                if (m_Commoditys.Contains(PCommodity))
                    m_Commoditys.Remove(PCommodity);
            }
        }
        public void Remove(CMarket CMarket)
        {
            lock (LockObj)
            {
                if (m_Markets.Contains(CMarket))
                    m_Markets.Remove(CMarket);
            }
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_Commoditys.Clear();
                m_Markets.Clear();
            }
        }
        public void Close()
        {
            try
            {
                try
                {
                    if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                }
                catch
                {
                }

                foreach (PCommodity PCommodity in Commoditys)
                    if (PCommodity != null) { PCommodity.Remove(this); }

                foreach (CMarket CMarket in Markets)
                    if (CMarket != null) { CMarket.RemoveSubscribe(this); }

                Clear();

                ICommunicationObject g = (ICommunicationObject)Callback;
                if (g.State == CommunicationState.Opened) { g.Close(); }
            }
            catch (Exception ex)
            {
                string f = "";
            }
        }
        public List<string> SubList
        {
            get
            {
                List<string> L = new List<string>();

                lock (LockObj)
                {
                    foreach (PCommodity s in m_Commoditys)
                        L.Add(s.CommodityId);

                    foreach (CMarket s in m_Markets)
                        L.Add(s.MarketId);
                }

                return L;
            }
        }

        public void AddData(object obj)
        {
            lock (LockObj)
            {
                DataQueue.Enqueue(obj);
            }
        }
        public void SendData()
        {
            while (DataQueue.Count > 0)
            {
                object obj = null;

                lock (LockObj)
                {
                    obj = DataQueue.Dequeue();
                }

                if (obj.GetType() == typeof(QCommodity))
                    Callback.QCommodityArrived((QCommodity)obj);
                else if (obj.GetType() == typeof(QBase))
                    Callback.QBaseArrived((QBase)obj);
                else if (obj.GetType() == typeof(QOpen))
                    Callback.QOpenArrived((QOpen)obj);
                else if (obj.GetType() == typeof(QBest5))
                    Callback.QBest5Arrived((QBest5)obj);
                else if (obj.GetType() == typeof(QMatch))
                    Callback.QMatchArrived((QMatch)obj);
                else if (obj.GetType() == typeof(QHighLow))
                    Callback.QHighLowArrived((QHighLow)obj);
                else if (obj.GetType() == typeof(QClose))
                    Callback.QCloseArrived((QClose)obj);
                else if (obj.GetType() == typeof(QCommodityExtra))
                    Callback.QExtraArrived((QCommodityExtra)obj);
                else if (obj.GetType() == typeof(QueryCls))
                    Callback.QQueryArrived((QueryCls)obj);
            }
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    while (DataQueue.Count > 0)
                    {
                        object obj = null;

                        lock (LockObj)
                        {
                            obj = DataQueue.Dequeue();
                        }

                        if (obj.GetType() == typeof(QCommodity))
                            Callback.QCommodityArrived((QCommodity)obj);
                        else if (obj.GetType() == typeof(QBase))
                            Callback.QBaseArrived((QBase)obj);
                        else if (obj.GetType() == typeof(QOpen))
                            Callback.QOpenArrived((QOpen)obj);
                        else if (obj.GetType() == typeof(QBest5))
                            Callback.QBest5Arrived((QBest5)obj);
                        else if (obj.GetType() == typeof(QMatch))
                            Callback.QMatchArrived((QMatch)obj);                        
                        else if (obj.GetType() == typeof(QHighLow))
                            Callback.QHighLowArrived((QHighLow)obj);
                        else if (obj.GetType() == typeof(QClose))
                            Callback.QCloseArrived((QClose)obj);
                        else if (obj.GetType() == typeof(QueryCls))
                            Callback.QQueryArrived((QueryCls)obj);         
                        else if (obj.GetType() == typeof(QCommodityExtra))
                            Callback.QExtraArrived((QCommodityExtra)obj);                        
                    }

                    Thread.Sleep(1);
                }
            }
            catch (Exception ex)
            {
                
            }
        }
        #region IClientState 成員

        string IClientState.IP
        {
            get { return this.IP; }
        }

        int IClientState.Port
        {
            get { return this.Port; }
        }
        
        DateTime IClientState.LoginTime
        {
            get { return this.LoginTime; }
        }
        List<string> IClientState.SubList
        {
            get { return this.SubList; }
        }
        void IClientState.Close()
        {
            this.Close();
        }

        #endregion
    }
    public class ClientStateList
    {
        private Dictionary<IQuoteCallBacks, ClientState> m_ClientStates = new Dictionary<IQuoteCallBacks, ClientState>();
        private object LockObj = new object();

        public ClientState Set(OperationContext O)
        {
            lock (LockObj)
            {
                IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                if (!m_ClientStates.ContainsKey(Callback))
                    m_ClientStates.Add(Callback, new ClientState(O));

                return m_ClientStates[Callback];
            }
        }
        public ClientState Get(IQuoteCallBacks Callback)
        {
            lock (LockObj)
            {
                if (m_ClientStates.ContainsKey(Callback))
                    return m_ClientStates[Callback];
                else
                    return null;
            }
        }
        public List<ClientState> ClientStates
        {
            get
            {
                List<ClientState> L = null;

                lock (LockObj)
                {
                    L = m_ClientStates.Values.ToList<ClientState>();
                }

                return L;
            }
        }
        public void Remove(IQuoteCallBacks Callback)
        {
            ClientState ClientState = null;

            lock (LockObj)
            {
                if (m_ClientStates.ContainsKey(Callback))
                    ClientState = m_ClientStates[Callback];
            }

            if (ClientState != null)
                ClientState.Close();

            lock (LockObj)
            {
                if (m_ClientStates.ContainsKey(Callback))
                    m_ClientStates.Remove(Callback);
            }
        }
        public void Remove(String IP,int Port)
        {
            foreach (ClientState C in ClientStates)
            {
                if (C.IP == IP && C.Port == Port)
                {
                    lock (LockObj)
                    {
                        m_ClientStates.Remove(C.Callback);
                    }

                    if (C != null)
                        C.Close();
                }
            }            
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_ClientStates.Clear();
            }
        }
        public void Close()
        {
            try
            {
                foreach (ClientState ClientState in ClientStates)
                    ClientState.Close();

                Clear();
            }
            catch (Exception ex)
            {
                string g = "";
            }
        }
    }

    public class CMarket
    {
        public Market Market;
        public string MarketId;
        public bool OpenWorkFlag;
        public bool OpenWorkFlag2;
        public bool OpenWorkFlag3;
        public string OpenTime;
        public bool CloseWorkFlag;
        public bool CloseWorkFlag2;
        public string CloseTime;
        public string TimeZone;
        public DateTime TradeDate;
        public bool IsTrade = true;
        private Dictionary<CommodityKind, Dictionary<string, CodeMap>> m_CodeMaps = new Dictionary<CommodityKind, Dictionary<string, CodeMap>>();
        //private Dictionary<string, string> m_SYSCodes = new Dictionary<string, string>();
        private Dictionary<string, PCommodity> m_Commoditys = new Dictionary<string, PCommodity>();
        private Dictionary<string, PCommodity> m_InnerCodes = new Dictionary<string, PCommodity>();
        private HashSet<ClientState> m_Subscribes = new HashSet<ClientState>();
        private HashSet<QuoteSource> m_QuoteSources = new HashSet<QuoteSource>();
        private object LockObj = new object();

        public CMarket()
        {
        }
        public CMarket(Market Market, string MarketId, string OpenTime, string CloseTime, string TimeZone)
        {
            this.Market = Market;
            this.MarketId = MarketId;
            this.OpenTime = OpenTime;
            this.CloseTime = CloseTime;
            this.TimeZone = TimeZone;
        }
        public void SetCodeMap(CodeMap CodeMap)
        {
            lock (LockObj)
            {
                if (!(m_CodeMaps.ContainsKey(CodeMap.CommodityKind) && m_CodeMaps[CodeMap.CommodityKind].ContainsKey(CodeMap.Code)))
                {
                    if (!m_CodeMaps.ContainsKey(CodeMap.CommodityKind))
                        m_CodeMaps.Add(CodeMap.CommodityKind, new Dictionary<string, CodeMap>());

                    if (!m_CodeMaps[CodeMap.CommodityKind].ContainsKey(CodeMap.Code))
                    {
                        m_CodeMaps[CodeMap.CommodityKind].Add(CodeMap.Code, CodeMap);
                        //if (!m_SYSCodes.ContainsKey(CodeMap.SYSCode)) { m_SYSCodes.Add(CodeMap.SYSCode, CodeMap.Code); }
                    }
                }
                else
                    m_CodeMaps[CodeMap.CommodityKind][CodeMap.Code] = CodeMap;
            }
        }
        public CodeMap GetCodeMap(CommodityKind CommodityKind, string Code)
        {
            lock (LockObj)
            {
                if (m_CodeMaps.ContainsKey(CommodityKind) && m_CodeMaps[CommodityKind].ContainsKey(Code))
                    return m_CodeMaps[CommodityKind][Code];
                else
                    return null;
            }
        }
        /*public string GetCode(string SYSCode)
        {
            lock (LockObj)
            {
                if (m_SYSCodes.ContainsKey(SYSCode))
                    return m_SYSCodes[SYSCode].ToString();
                else
                    return "";
            }
        }*/
        public List<CodeMap> CodeMaps
        {
            get
            {
                List<Dictionary<string, CodeMap>> L1 = null;
                List<CodeMap> L2 = null;

                lock (LockObj)
                {
                    L1 = m_CodeMaps.Values.ToList<Dictionary<string, CodeMap>>();

                    foreach (Dictionary<string, CodeMap> de in L1)
                        L2.AddRange(de.Values.ToList<CodeMap>());
                }

                return L2;
            }
        }
        public void SetCommodity(PCommodity PCommodity)
        {
            lock (LockObj)
            {
                /*if (Market == Market.TFE && PCommodity.CodeMap != null)
                {
                    if (!PCommodity.CodeMap.PCommoditys.ContainsKey(PCommodity.CommodityId))
                        PCommodity.CodeMap.PCommoditys.Add(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM"), PCommodity);
                    else
                        PCommodity.CodeMap.PCommoditys[PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM")] = PCommodity;
                }*/

                if (!m_Commoditys.ContainsKey(PCommodity.CommodityId))
                    m_Commoditys.Add(PCommodity.CommodityId, PCommodity);
                else
                {
                    m_Commoditys[PCommodity.CommodityId] = PCommodity;
                    return;
                }
            }

            List<ClientState> L;

            lock (LockObj)
            {
                L = m_Subscribes.ToList<ClientState>();
            }

            foreach(ClientState ClientState in L)
                PCommodity.Set(ClientState);
        }
        public PCommodity GetCommodity(string CommodityId)
        {
            lock (LockObj)
            {
                if (m_Commoditys.ContainsKey(CommodityId))
                    return m_Commoditys[CommodityId];
                else
                    return null;
            }
        }
        public void RemoveCommodity(string CommodityId)
        {
            PCommodity PCommodity = GetCommodity(CommodityId);

            lock (LockObj)
            {
                /*if (Market == Market.TFE && PCommodity.CodeMap != null && PCommodity.QCommodity.Extra != null)
                {
                    if (PCommodity.CodeMap.PCommoditys.ContainsKey(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM")))
                        PCommodity.CodeMap.PCommoditys.Remove(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM"));
                }*/

                if (PCommodity.QCommodity.Base != null && PCommodity.QCommodity.Base.InnerCode != null && m_InnerCodes.ContainsKey(PCommodity.QCommodity.Base.InnerCode))
                    m_InnerCodes.Remove(PCommodity.QCommodity.Base.InnerCode);
                if (m_Commoditys.ContainsKey(CommodityId))
                    m_Commoditys.Remove(CommodityId);                
            }
        }
        public List<PCommodity> Commoditys
        {
            get
            {
                List<PCommodity> L = null;

                lock (LockObj)
                {
                    L = m_Commoditys.Values.ToList<PCommodity>();
                }

                return L;
            }
        }
        public void CommoditysClear()
        {
            lock (LockObj)
            {
                foreach (PCommodity mPCommodity in m_Commoditys.Values)
                    mPCommodity.CMarket = null;
                m_Commoditys.Clear();
            }
        }
        /*public void SetInnerCode(string InnerCode, PCommodity PCommodity)
        {
            lock (LockObj)
            {
                if (!m_InnerCodes.ContainsKey(InnerCode))
                    m_InnerCodes.Add(InnerCode, PCommodity);
                else
                    m_InnerCodes[InnerCode] = PCommodity;
            }
        }*/
        /*public PCommodity GetInnerCode(string InnerCode)
        {
            lock (LockObj)
            {
                if (m_InnerCodes.ContainsKey(InnerCode))
                    return m_InnerCodes[InnerCode];
                else
                    return null;
            }
        }*/
        public void RemoveInnerCode(string InnerCode)
        {
            lock (LockObj)
            {
                if (m_InnerCodes.ContainsKey(InnerCode))
                    m_InnerCodes.Remove(InnerCode);
            }
        }
        public List<PCommodity> InnerCodes
        {
            get
            {
                List<PCommodity> L = null;

                lock (LockObj)
                {
                    L = m_InnerCodes.Values.ToList<PCommodity>();
                }

                return L;
            }
        }
        public void InnerCodeClear()
        {
            lock (LockObj)
            {
                foreach (PCommodity mPCommodity in m_InnerCodes.Values)
                    if (mPCommodity.QCommodity.Base != null) { mPCommodity.QCommodity.Base.InnerCode = string.Empty; }
                m_InnerCodes.Clear();
            }
        }
                
        public void SetSubscribe(ClientState ClientState)
        {
            List<PCommodity> L;

            lock (LockObj)
            {
                if (m_Subscribes.Contains(ClientState))
                    return;

                m_Subscribes.Add(ClientState);

                L = m_Commoditys.Values.ToList<PCommodity>();                
            }

            foreach (PCommodity PCommodity in L)
                PCommodity.Set(ClientState);
        }
        public void RemoveSubscribe(ClientState ClientState)
        {
            List<PCommodity> L;

            lock (LockObj)
            {
                if (m_Subscribes.Contains(ClientState))
                    m_Subscribes.Remove(ClientState);

                L = m_Commoditys.Values.ToList<PCommodity>();                
            }

            foreach (PCommodity PCommodity in L)
                PCommodity.Remove(ClientState);
        }
        public List<ClientState> Subscribes
        {
            get
            {
                List<ClientState> L = null;

                lock (LockObj)
                {
                    L = m_Subscribes.ToList<ClientState>();
                }

                return L;
            }
        }
        public void SetQuoteSource(QuoteSource QuoteSource)
        {
            lock (LockObj)
            {
                if (!m_QuoteSources.Contains(QuoteSource))
                    m_QuoteSources.Add(QuoteSource);
            }
        }
        public void RemoveQuoteSource(QuoteSource QuoteSource)
        {
            lock (LockObj)
            {
                if (m_QuoteSources.Contains(QuoteSource))
                    m_QuoteSources.Remove(QuoteSource);
            }
        }
        public List<QuoteSource> QuoteSources
        {
            get
            {
                List<QuoteSource> L = null;

                lock (LockObj)
                {
                    L = m_QuoteSources.ToList<QuoteSource>();
                }

                return L;
            }
        }

        public void MarketClear()
        {
            List<PCommodity> L;

            lock (LockObj)
            {
                L = m_Commoditys.Values.ToList<PCommodity>();
            }

            foreach (PCommodity PCommodity in L)
            {
                if (IsTrade)
                {
                    PCommodity.ClearCommodity();
                    PCommodity.Send(PCommodity.QCommodity);
                }
            }
        }
        public void TransLastClosePrice()
        {
            List<PCommodity> L;

            lock (LockObj)
            {
                L = m_Commoditys.Values.ToList<PCommodity>();
            }

            foreach (PCommodity PCommodity in L)
            {
                if (IsTrade)
                {
                    PCommodity.TransLastClosePrice();             
                }
            }
        }
        public void InitialQuoteSourcePacketNum()
        {
            lock (LockObj)
            {
                foreach (QuoteSource QuoteSource in m_QuoteSources)
                    QuoteSource.SetReceivePacket(0);
            }
        }
        public void ClearHIVExtra()
        {
            List<PCommodity> L;

            lock (LockObj)
            {
                L = m_Commoditys.Values.ToList<PCommodity>();
            }

            foreach (PCommodity PCommodity in L)
                PCommodity.ClearHIVExtra();
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_CodeMaps.Clear();
                m_Commoditys.Clear();
                m_InnerCodes.Clear();
                m_Subscribes.Clear();
                m_QuoteSources.Clear();
            }
        }
        public void Close()
        {
            try
            {
                foreach (PCommodity PCommodity in Commoditys)
                    PCommodity.Close();
                foreach (ClientState ClientState in Subscribes)
                    ClientState.Close();
                foreach (QuoteSource QuoteSource in QuoteSources)
                    QuoteSource.Close();

                Clear();
            }
            catch (Exception ex)
            {
                string ff = "";
            }
        }
    }
    public class CMarketList
    {
        private Dictionary<Market, CMarket> m_Markets = new Dictionary<Market, CMarket>();
        private Dictionary<string, CMarket> m_MarketsStr = new Dictionary<string, CMarket>();
        private object LockObj = new object();
        
        public CMarketList(string DBConnectString)
        {

            lock (LockObj)
            {
                Markets.Clear();
            }

            DataView dv = Util.ExecSqlQry("select ProgramNo,Market,isnull(OpenTime,'') OpenTime,isnull(CloseTime,'') CloseTime,isnull(TimeZone,'') TimeZone from market order by programno", DBConnectString);
            
            foreach (DataRowView dr in dv)
            {
                CMarket CMarket = new CMarket((Market)dr["ProgramNo"], dr["Market"].ToString(), dr["OpenTime"].ToString(), dr["CloseTime"].ToString(), dr["TimeZone"].ToString());

                DataView dv1 = Util.ExecSqlQry("select b.programno commoditykind,code,codenm,isnull(syscode,'') syscode from codemap a,commoditykind b where a.commoditykind=b.commoditykind and a.market='" + CMarket.MarketId + "'", DBConnectString);

                foreach (DataRowView dr1 in dv1)
                {
                    CMarket.SetCodeMap(new CodeMap(CMarket.Market, (CommodityKind)dr1["CommodityKind"], dr1["Code"].ToString(), dr1["CodeNm"].ToString()));

                    /*if (!CMarket.CodeMaps.ContainsKey((CommodityKind)dr1["CommodityKind"]))
                        CMarket.CodeMaps.Add((CommodityKind)dr1["CommodityKind"],new Dictionary<string,CodeMap>());

                    if (!CMarket.CodeMaps[(CommodityKind)dr1["CommodityKind"]].ContainsKey(dr1["Code"].ToString()))
                        CMarket.CodeMaps[(CommodityKind)dr1["CommodityKind"]].Add(dr1["Code"].ToString(), new CodeMap(CMarket.Market, (CommodityKind)dr1["CommodityKind"], dr1["Code"].ToString(), dr1["CodeNm"].ToString()));                    */
                }

                lock (LockObj)
                {
                    m_Markets.Add(CMarket.Market, CMarket);
                    m_MarketsStr.Add(CMarket.MarketId, CMarket);
                }
            }
        }

        public CMarket Get(Market Market)
        {
            lock (LockObj)
            {
                if (m_Markets.ContainsKey(Market))
                    return m_Markets[Market];
                else
                    return null;
            }
        }
        public CMarket Get(string MarketId)
        {
            lock (LockObj)
            {
                if (m_MarketsStr.ContainsKey(MarketId))
                    return m_MarketsStr[MarketId];
                else
                    return null;
            }
        }
        public List<CMarket> Markets
        {
            get
            {
                List<CMarket> L = null;

                lock (LockObj)
                {
                    L = m_Markets.Values.ToList<CMarket>();
                }

                return L;
            }
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_Markets.Clear();
                m_MarketsStr.Clear();
            }
        }
        public void Close()
        {
            try
            {
                foreach (CMarket CMarket in Markets)
                    CMarket.Close();

                Clear();
            }
            catch (Exception ex)
            {
            }
        }        
    }

    public class CodeMap
    {
        public Market Market;
        public CommodityKind CommodityKind;
        public string Code;
        public string CodeNm;
        //public string SYSCode;
        //private SortedDictionary<string, PCommodity> PCommoditys = new SortedDictionary<string,PCommodity>();
        //private object LockObj = new object();

        public CodeMap(Market Market, CommodityKind CommodityKind, string Code, string CodeNm)
        {
            this.Market = Market;
            this.CommodityKind = CommodityKind;
            this.Code = Code;
            this.CodeNm = CodeNm;
            //this.SYSCode = SYSCode;
        }
        /*public void SetCommodity(PCommodity PCommodity)
        {
            lock (LockObj)
            {
                if (PCommodity.QCommodity.Extra != null && PCommodity.QCommodity.Base.CommodityKind == CommodityKind.Future)
                {
                    if (!PCommoditys.ContainsKey(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM")))
                        PCommoditys.Add(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM"), PCommodity);
                    else
                        PCommoditys[PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM")] = PCommodity;
                                        
                    for(int i=0;i<PCommoditys.Count; i++)
                    {
                        if (i == 0)
                            PCommoditys.Values.ToList<PCommodity>()[i].QCommodity.Base.LastCode = Code + "F" + "AA";
                        else if (i == 1)
                            PCommoditys.Values.ToList<PCommodity>()[i].QCommodity.Base.LastCode = Code + "F" + "AB";
                        else
                            PCommoditys.Values.ToList<PCommodity>()[i].QCommodity.Base.LastCode = "";
                    }
                }
            }
        }
        public PCommodity GetCommodity(string Tag)
        {
            lock (LockObj)
            {
                PCommodity PCommodity = null;;
                                
                if (PCommoditys.Count > 0 && Tag == "AA")
                    PCommodity = PCommoditys.Values.ToList<PCommodity>()[0];
                else if (PCommoditys.Count > 1 && Tag == "AB")
                    PCommodity = PCommoditys.Values.ToList<PCommodity>()[1];
                return PCommodity;
            }
        }
        public void RemoveCommodity(PCommodity PCommodity)
        {            

            lock (LockObj)
            {
                if (PCommodity.QCommodity.Extra != null)
                {
                    if (PCommoditys.ContainsKey(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM")))
                        PCommoditys.Remove(PCommodity.QCommodity.Extra.Maturity.ToString("yyyyMM"));
                }
            }
        }*/
    }

    public class EstimateCommodity
    {
        public string EstimateLabel = "";
        public PCommodity Parent;
        public HashSet<EstimateElement> Elements = new HashSet<EstimateElement>();
        public double BasePrice = 0.0;
        public double CashDiff = 0.0;
        public double RefCapitalization = 0.0;
        public string RefCommodity = "";
        public EstimateCalculateKind CalculateKind;
        public double YestodayCapitalization = 0.0;
        private object LockObj = new object();

        public void Add(EstimateElement mEstimateElement)
        {
            lock (LockObj)
            {
                if (!Elements.Contains(mEstimateElement))
                    Elements.Add(mEstimateElement);
            }
        }

        public void Close()
        {
            lock (LockObj)
            {
                Elements.Clear();
            }
        }
    }
    public class EstimateElement
    {
        public PCommodity mPCommodity;
        public double Weight = 0.0;
        public int Shares = 0;
        public int YestodayShares = 0;
        public bool InsteadFlag = false;

        public EstimateElement(PCommodity mPCommodity, double Weight, int Shares, bool InsteadFlag)
        {
            this.mPCommodity = mPCommodity;
            this.Weight = Weight;
            this.Shares = Shares;
            this.InsteadFlag = InsteadFlag;
        }
    }
        
    public class QueryList
    {
        private Dictionary<string, QueryCls> m_QueryList = new Dictionary<string, QueryCls>();        
        private object LockObj = new object();

        public void LoadData(string DBConnectString,string FOFlag)
        {
            DataView dv = Util.ExecSqlQry("select * from PQuery where FOFlag='" + FOFlag + "' and convert(varchar,TradeDate,112)=convert(varchar,getdate(),112)", DBConnectString);

            foreach (DataRowView dr in dv)
            {                
                string CommodityId = dr["CommodityId"].ToString();
                string InformationTime = dr["InformationTime"].ToString();
                string InformationSeq = dr["InformationSeq"].ToString();
                string DisClosureTime = dr["DisClosureTime"].ToString();
                int DurationTime = Convert.ToInt32(dr["DurationTime"]);

                Add(FOFlag, CommodityId, InformationTime, InformationSeq, DisClosureTime, DurationTime);
            }
        }
        public QueryCls Add(string FOFlag, string CommodityId, string InformationTime, string InformationSeq, string DisClosureTime, int DurationTime)
        {
            lock (LockObj)
            {
                if (!m_QueryList.ContainsKey(InformationSeq)) 
                {
                    QueryCls Q = new QueryCls(FOFlag, CommodityId, InformationTime, InformationSeq, DisClosureTime, DurationTime);
                    m_QueryList.Add(InformationSeq, Q); 
                    return Q;
                }
                else
                    return null;
            }
        }
        public QueryCls Add(QueryCls QueryCls)
        {
            lock (LockObj)
            {
                if (!m_QueryList.ContainsKey(QueryCls.InformationSeq)) { m_QueryList.Add(QueryCls.InformationSeq, QueryCls); return QueryCls; }
                else { return null; }
            }
        }
        public void Clear()
        {
            lock (LockObj)
            {
                m_QueryList.Clear();                
            }
        }
        public List<QueryCls> QueryClss
        {
            get
            {
                List<QueryCls> L = null;

                lock (LockObj)
                {
                    L = m_QueryList.Values.ToList<QueryCls>();
                }

                return L;
            }
        }
    }

    public class SafeQueue
    {
        private Queue Q = new Queue();
        private object LockObj = new object();

        public void Enqueue(object item)
        {
            lock (LockObj)
            {
                if (!Q.Contains(item))
                    Q.Enqueue(item);
            }
        }
        public object Dequeue()
        {
            lock (LockObj)
            {
                return Q.Dequeue();
            }
        }
        public int Count
        {
            get
            {
                lock (LockObj)
                {
                    return Q.Count;
                }
            }
        }
        public bool Contains(object item)
        {
            lock (LockObj)
            {
                return Q.Contains(item);
            }
        }
        public void Clear()
        {
            lock (LockObj)
            {
                Q.Clear();
            }
        }
    }

    #endregion
    #region QuoteSource
    public class QuoteSourceList
    {
        private Dictionary<string, QuoteSource> m_QuoteSources = new Dictionary<string, QuoteSource>();
        private object LockObj = new object();
        private Queue<string> m_ErrorPool = new Queue<string>();

        public QuoteSourceList()
        {
            
        }

        public QuoteSource Set(QuoteSource QuoteSource)
        {
            lock (LockObj)
            {
                if (!m_QuoteSources.ContainsKey(QuoteSource.QuoteSetting.DataSource))
                    m_QuoteSources.Add(QuoteSource.QuoteSetting.DataSource, QuoteSource);
            }

            if (QuoteSource.CMarket != null) { QuoteSource.CMarket.SetQuoteSource(QuoteSource); }

            return m_QuoteSources[QuoteSource.QuoteSetting.DataSource];
         
        }
        public QuoteSource Get(string DataSource)
        {
            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(DataSource))
                    return m_QuoteSources[DataSource];
                else
                    return null;
            }
        }
        public List<QuoteSource> QuoteSources
        {
            get
            {
                List<QuoteSource> L = null;

                lock (LockObj)
                {
                    L = m_QuoteSources.Values.ToList<QuoteSource>();
                }

                return L;
            }
        }
        public void Remove(string DataSource)
        {
            QuoteSource QuoteSource = null;

            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(DataSource))
                    QuoteSource = m_QuoteSources[DataSource];
            }

            if (QuoteSource != null)
                QuoteSource.Close();

            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(DataSource))
                    m_QuoteSources.Remove(DataSource);
            }
        }
        public Queue<string> ErrPool
        {
            get
            {
                lock (LockObj)
                {
                    foreach (QuoteSource QuoteSource in m_QuoteSources.Values)
                    {
                        while (QuoteSource.ErrorQueue.Count > 0)
                            m_ErrorPool.Enqueue(QuoteSource.ErrorQueue.Dequeue().ToString());
                    }
                }
                return m_ErrorPool;
            }
        }
        public bool ContainKey(string Key)
        {
            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(Key))
                    return true;
                else
                    return false;
            }
        }
        private void Clear()
        {
            lock (LockObj)
            {
                m_QuoteSources.Clear();                
            }
        }
        public void Close()
        {
            try
            {
                foreach (QuoteSource QuoteSource in QuoteSources)
                    QuoteSource.Close();

                Clear();
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }
        public QuoteSource GetWCFQuoteSource()
        {
            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey("WCF_QuoteReceived"))
                    return m_QuoteSources["WCF_QuoteReceived"];
                else
                    return null;
            }
        }
        public bool MarketExit(CMarket iCMarket)
        {
            if (iCMarket == null) { return false; }

            lock (LockObj)
            {
                foreach (QuoteSource iQuoteSource in m_QuoteSources.Values)
                {
                    if (iQuoteSource.CMarket != null && iQuoteSource.CMarket.Market == iCMarket.Market)
                        return true;
                }

                return false;
            }
        }
    }    
    public abstract class QuoteSource : DeriLib.TSModel.ITSFactory
    {
        protected QuoteFactorySetting m_QuoteSetting;
        protected PCommodityList m_PCommodityList;
        protected CMarket m_CMarket;
        protected Queue m_ErrorPool = Queue.Synchronized(new Queue());
        protected SafeQueue m_WriteDBPool = new SafeQueue();//商品寫資料庫 Queue
        protected Queue m_WriteFilePool = Queue.Synchronized(new Queue());//接收行情byte寫檔Queue
        protected Queue m_PackagePool = Queue.Synchronized(new Queue());//接收行情待處理Queue                
        public Queue TicksPool = Queue.Synchronized(new Queue());//Ticks待處理Queue  
        //protected Queue m_CalculateGreeksPool = Queue.Synchronized(new Queue());//處理計算GreeksQueue                
        protected int m_PacketNum;        
        protected bool InitialOK = true;
        protected TimeSpan IniTime;
        private bool notFinishInitial = false;
        protected bool IsTibcoOpen = false;
        SqlConnection conn;
        private SqlCommand cmdBase;
        private SqlCommand cmdOpen;
        private SqlCommand cmdBest5;
        private SqlCommand cmdMatch;
        private SqlCommand cmdHighLow;
        private SqlCommand cmdClose;
        private SqlCommand cmdWarrantExtra;
        private SqlCommand cmdHTicks;
        private SqlCommand cmdQuery;
        private SqlCommand cmdUpdateCurrency;
        private Thread WriteToDBThread;
        private Thread WriteToLogThread;
        //private Thread CalculateGreeksThread;
        private FileStream fsIn;//報價寫檔
        
        public QuoteSource(QuoteFactorySetting QuoteSetting)
        {
            this.m_QuoteSetting = QuoteSetting;            
        }
        public QuoteFactorySetting QuoteSetting
        {
            get { return m_QuoteSetting; }
        }
        public PCommodityList PCommodityList
        {
            get { return m_PCommodityList; }
            set { m_PCommodityList = value; }
        }
        public CMarket CMarket
        {
            get { return m_CMarket; }
            set { m_CMarket = value; }
        }
        public void SetReceivePacket(int i)
        {
            m_PacketNum = i;
        }
        /*private void ReloadWork(object state)
        {
            PCommodityList.ReloadData(m_CMarket.Market);
            InitialOK = true;
        }*/
        private void ReloadWork()
        {
            PCommodityList.ReloadData(m_CMarket.Market);
            InitialOK = true;
        }
        /*public virtual void Start()
        {
            if (m_IsReloadData)
            {
                InitialOK = false;
                ThreadPool.QueueUserWorkItem(ReloadWork);
            }
        }
        public virtual void Close()
        {
            try
            {
                if (m_CMarket != null) { m_CMarket.RemoveQuoteSource(this); }
                if (WriteToDBThread != null && WriteToDBThread.IsAlive) { WriteToDBThread.Abort(); }
                if (WriteToLogThread != null && WriteToLogThread.IsAlive) { WriteToLogThread.Abort(); }
                if (fsIn != null) { fsIn.Close(); }
                if (conn.State == ConnectionState.Open) { conn.Close(); }
            }
            catch (Exception ex)
            {
            }
        }*/
        private void IniLog()
        {
            if (fsIn != null) { fsIn.Close(); }

            string sFileName = m_QuoteSetting.LogFileFolder + "\\" + DateTime.Today.ToString("yyyyMMdd") + "_" + m_QuoteSetting.DataSource + "_" + "Log.txt";
            fsIn = new FileStream(sFileName, FileMode.Append);
        }        
        /*public Queue ErrorPool
        {
            get { return m_ErrorPool; }
        }
        public Queue WriteDBPool
        {
            get { return m_WriteDBPool; }
        }
        public Queue WriteFilePool
        {
            get { return m_WriteFilePool; }
        }
        public Queue PackagePool
        {
            get { return m_PackagePool; }
        }
        public int PacketNum
        {
            get { return m_PacketNum; }
            set { m_PacketNum = value; }
        }        */
        private void WriteToDBWork()
        {
            try
            {
                while (true)
                {
                    int i = 0;

                    while (m_WriteDBPool.Count > 0)
                    {
                        //if (i == 10) { i = 0; Thread.Sleep(1); }

                        WriteSP(m_WriteDBPool.Dequeue());
                        //Thread.Sleep(1);
                        i++;
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WriteToDBWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void WriteSP(object obj)
        {
            string commodityid = "";

            try
            {
                if (conn.State == ConnectionState.Closed) { conn.Open(); }
                                
                Type iType = obj.GetType();

                if (iType == typeof(QBase))
                {
                    QBase QBase = (QBase)obj;
                    commodityid = QBase.CommodityId;
                    if (QBase.TradeDate == DateTime.MinValue) { return; }

                    cmdBase.Parameters["@CommodityId"].Value = QBase.CommodityId;
                    cmdBase.Parameters["@Market"].Value = (int)QBase.Market;
                    cmdBase.Parameters["@CommodityKind"].Value = QBase.CommodityKind;
                    cmdBase.Parameters["@CommodityType"].Value = QBase.CommodityType;
                    cmdBase.Parameters["@CommodityNm"].Value = QBase.CommodityNm;
                    cmdBase.Parameters["@CommodityCode"].Value = QBase.CommodityCode;                                        
                    cmdBase.Parameters["@TradeDate"].Value = QBase.TradeDate.ToString("yyyy/MM/dd");
                    cmdBase.Parameters["@InformationTime"].Value = QBase.InformationTime;
                    cmdBase.Parameters["@InformationSeq"].Value = QBase.InformationSeq;
                    cmdBase.Parameters["@SettleMentMonth"].Value = QBase.SettleMentMonth;
                    cmdBase.Parameters["@Strike"].Value = QBase.Strike;
                    cmdBase.Parameters["@ReferencePrice"].Value = QBase.ReferencePrice;
                    cmdBase.Parameters["@RiseLimitPrice"].Value = QBase.RiseLimitPrice;
                    cmdBase.Parameters["@FallLimitPrice"].Value = QBase.FallLimitPrice;
                    cmdBase.Parameters["@RiseLimitPrice2"].Value = QBase.RiseLimitPrice2;
                    cmdBase.Parameters["@FallLimitPrice2"].Value = QBase.FallLimitPrice2;
                    cmdBase.Parameters["@RiseLimitPrice3"].Value = QBase.RiseLimitPrice3;
                    cmdBase.Parameters["@FallLimitPrice3"].Value = QBase.FallLimitPrice3;
                    cmdBase.Parameters["@Unit"].Value = QBase.Unit;
                    cmdBase.Parameters["@ProdKind"].Value = QBase.ProdKind;
                    cmdBase.Parameters["@DecimalLocate"].Value = QBase.DecimalLocate;
                    cmdBase.Parameters["@StrikeDecimalLocate"].Value = QBase.StrikeDecimalLocate;
                    cmdBase.Parameters["@InnerCode"].Value = QBase.InnerCode;
                    cmdBase.Parameters["@CommodityProperty"].Value = QBase.CommodityProperty;

                    cmdBase.ExecuteNonQuery();                    
                }
                else if (iType == typeof(QOpen))
                {
                    QOpen QOpen = (QOpen)obj;
                    commodityid = QOpen.CommodityId;

                    cmdOpen.Parameters["@CommodityId"].Value = QOpen.CommodityId;
                    cmdOpen.Parameters["@OpenTime"].Value = QOpen.OpenTime;
                    cmdOpen.Parameters["@OpenPrice"].Value = QOpen.OpenPrice;

                    cmdOpen.ExecuteNonQuery();
                }
                else if (iType == typeof(QBest5))
                {
                    /*QBest5 QBest5 = (QBest5)obj;
                    commodityid = QBest5.CommodityId;

                    cmdBest5.Parameters["@CommodityId"].Value = QBest5.CommodityId;
                    cmdBest5.Parameters["@InformationTime"].Value = QBest5.InformationTime;
                    cmdBest5.Parameters["@InformationSeq"].Value = QBest5.InformationSeq;
                    cmdBest5.Parameters["@BuyPriceBest1"].Value = QBest5.BuyPriceBest1;
                    cmdBest5.Parameters["@BuyQtyBest1"].Value = QBest5.BuyQtyBest1;
                    cmdBest5.Parameters["@BuyPriceBest2"].Value = QBest5.BuyPriceBest2;
                    cmdBest5.Parameters["@BuyQtyBest2"].Value = QBest5.BuyQtyBest2;
                    cmdBest5.Parameters["@BuyPriceBest3"].Value = QBest5.BuyPriceBest3;
                    cmdBest5.Parameters["@BuyQtyBest3"].Value = QBest5.BuyQtyBest3;
                    cmdBest5.Parameters["@BuyPriceBest4"].Value = QBest5.BuyPriceBest4;
                    cmdBest5.Parameters["@BuyQtyBest4"].Value = QBest5.BuyQtyBest4;
                    cmdBest5.Parameters["@BuyPriceBest5"].Value = QBest5.BuyPriceBest5;
                    cmdBest5.Parameters["@BuyQtyBest5"].Value = QBest5.BuyQtyBest5;
                    cmdBest5.Parameters["@SellPriceBest1"].Value = QBest5.SellPriceBest1;
                    cmdBest5.Parameters["@SellQtyBest1"].Value = QBest5.SellQtyBest1;
                    cmdBest5.Parameters["@SellPriceBest2"].Value = QBest5.SellPriceBest2;
                    cmdBest5.Parameters["@SellQtyBest2"].Value = QBest5.SellQtyBest2;
                    cmdBest5.Parameters["@SellPriceBest3"].Value = QBest5.SellPriceBest3;
                    cmdBest5.Parameters["@SellQtyBest3"].Value = QBest5.SellQtyBest3;
                    cmdBest5.Parameters["@SellPriceBest4"].Value = QBest5.SellPriceBest4;
                    cmdBest5.Parameters["@SellQtyBest4"].Value = QBest5.SellQtyBest4;
                    cmdBest5.Parameters["@SellPriceBest5"].Value = QBest5.SellPriceBest5;
                    cmdBest5.Parameters["@SellQtyBest5"].Value = QBest5.SellQtyBest5;
                    cmdBest5.Parameters["@BuyPriceDerived"].Value = QBest5.BuyPriceDerived;
                    cmdBest5.Parameters["@BuyQtyDerived"].Value = QBest5.BuyQtyDerived;
                    cmdBest5.Parameters["@SellPriceDerived"].Value = QBest5.SellPriceDerived;
                    cmdBest5.Parameters["@SellQtyDerived"].Value = QBest5.SellQtyDerived;

                    cmdBest5.ExecuteNonQuery();*/
                }
                else if (iType == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;
                    commodityid = QMatch.CommodityId;

                    cmdMatch.Parameters["@CommodityId"].Value = QMatch.CommodityId;
                    cmdMatch.Parameters["@InformationTime"].Value = QMatch.InformationTime;
                    cmdMatch.Parameters["@InformationSeq"].Value = QMatch.InformationSeq;
                    cmdMatch.Parameters["@MatchSeq"].Value = QMatch.MatchSeq;
                    cmdMatch.Parameters["@MatchTime"].Value = QMatch.MatchTime;
                    cmdMatch.Parameters["@MatchPrice"].Value = QMatch.MatchPrice;
                    cmdMatch.Parameters["@MatchQty"].Value = QMatch.MatchQty;
                    cmdMatch.Parameters["@MatchAmt"].Value = QMatch.MatchAmt;
                    cmdMatch.Parameters["@MatchTotalAmt"].Value = QMatch.MatchTotalAmt;
                    cmdMatch.Parameters["@MatchTotalQty"].Value = QMatch.MatchTotalQty;
                    cmdMatch.Parameters["@MatchTotalCnt"].Value = QMatch.MatchTotalCnt;
                    cmdMatch.Parameters["@MatchBuyTotalCnt"].Value = QMatch.MatchBuyTotalCnt;
                    cmdMatch.Parameters["@MatchSellTotalCnt"].Value = QMatch.MatchSellTotalCnt;
                    cmdMatch.Parameters["@IsWriteTicks"].Value = m_QuoteSetting.IsWriteTicks ? "Y" : "N";
                    
                    cmdMatch.ExecuteNonQuery();
                }
                else if (iType == typeof(QHighLow))
                {
                    QHighLow QHighLow = (QHighLow)obj;
                    commodityid = QHighLow.CommodityId;

                    cmdHighLow.Parameters["@CommodityId"].Value = QHighLow.CommodityId;
                    cmdHighLow.Parameters["@InformationTime"].Value = QHighLow.InformationTime;
                    cmdHighLow.Parameters["@InformationSeq"].Value = QHighLow.InformationSeq;
                    cmdHighLow.Parameters["@DayHighPrice"].Value = QHighLow.DayHighPrice;
                    cmdHighLow.Parameters["@DayLowPrice"].Value = QHighLow.DayLowPrice;
                    cmdHighLow.Parameters["@ShowTime"].Value = QHighLow.ShowTime;

                    cmdHighLow.ExecuteNonQuery();
                }
                else if (iType == typeof(QClose))
                {
                    QClose QClose = (QClose)obj;
                    commodityid = QClose.CommodityId;

                    cmdClose.Parameters["@CommodityId"].Value = QClose.CommodityId;
                    cmdClose.Parameters["@InformationTime"].Value = QClose.InformationTime;
                    cmdClose.Parameters["@InformationSeq"].Value = QClose.InformationSeq;
                    cmdClose.Parameters["@DayHighPrice"].Value = QClose.DayHighPrice;
                    cmdClose.Parameters["@DayLowPrice"].Value = QClose.DayLowPrice;
                    cmdClose.Parameters["@OpenPrice"].Value = QClose.OpenPrice;
                    cmdClose.Parameters["@BuyPrice"].Value = QClose.BuyPrice;
                    cmdClose.Parameters["@SellPrice"].Value = QClose.SellPrice;
                    cmdClose.Parameters["@ClosePrice"].Value = QClose.ClosePrice;
                    cmdClose.Parameters["@CloseDate"].Value = QClose.CloseDate.ToString("yyyy/MM/dd");
                    cmdClose.Parameters["@MatchTotalCnt"].Value = QClose.MatchTotalCnt;
                    cmdClose.Parameters["@MatchTotalQty"].Value = QClose.MatchTotalQty;
                    cmdClose.Parameters["@MatchTotalAmt"].Value = QClose.MatchTotalAmt;
                    cmdClose.Parameters["@ComBuyCnt"].Value = QClose.ComBuyCnt;
                    cmdClose.Parameters["@ComBuyQty"].Value = QClose.ComBuyQty;
                    cmdClose.Parameters["@ComSellCnt"].Value = QClose.ComSellCnt;
                    cmdClose.Parameters["@ComSellQty"].Value = QClose.ComSellQty;
                    cmdClose.Parameters["@ComTotalQty"].Value = QClose.ComTotalQty;
                    cmdClose.Parameters["@SettlementPrice"].Value = QClose.SettlementPrice;
                    cmdClose.Parameters["@OpenInterest"].Value = QClose.OpenInterest;

                    cmdClose.ExecuteNonQuery();
                }
                else if (iType == typeof(QCommodityExtra))
                {
                    QCommodityExtra QCommodityExtra = (QCommodityExtra)obj;
                    commodityid = QCommodityExtra.CommodityId;

                    cmdWarrantExtra.Parameters["@CommodityId"].Value = QCommodityExtra.CommodityId;
                    cmdWarrantExtra.Parameters["@Strike"].Value = QCommodityExtra.Strike;
                    cmdWarrantExtra.Parameters["@ExecRatio"].Value = QCommodityExtra.ExecRatio;

                    cmdWarrantExtra.ExecuteNonQuery();
                }
                else if (iType == typeof(HTicks))
                {
                    /*HTicks HTicks = (HTicks)obj;

                    cmdHTicks.Parameters["@TradeDate"].Value = HTicks.TradeDate;
                    cmdHTicks.Parameters["@CommodityId"].Value = HTicks.CommodityId;
                    cmdHTicks.Parameters["@InformationTime"].Value = HTicks.InformationTime;
                    cmdHTicks.Parameters["@InformationSeq"].Value = HTicks.InformationSeq;
                    cmdHTicks.Parameters["@MatchSeq"].Value = HTicks.MatchSeq;
                    cmdHTicks.Parameters["@MatchTime"].Value = HTicks.MatchTime;
                    cmdHTicks.Parameters["@MatchPrice"].Value = HTicks.MatchPrice;
                    cmdHTicks.Parameters["@MatchQty"].Value = HTicks.MatchQty;
                    cmdHTicks.Parameters["@MatchTotalQty"].Value = HTicks.MatchTotalQty;
                    cmdHTicks.Parameters["@BuyPriceBest1"].Value = HTicks.BuyPriceBest1;
                    cmdHTicks.Parameters["@BuyQtyBest1"].Value = HTicks.BuyQtyBest1;
                    cmdHTicks.Parameters["@SellPriceBest1"].Value = HTicks.SellPriceBest1;
                    cmdHTicks.Parameters["@SellQtyBest1"].Value = HTicks.SellQtyBest1;

                    cmdHTicks.ExecuteNonQuery();*/
                }
                else if (iType == typeof(QueryCls))
                {
                    QueryCls QueryCls = (QueryCls)obj;

                    cmdQuery.Parameters["@FOFlag"].Value = QueryCls.FOFlag;
                    cmdQuery.Parameters["@TradeDate"].Value = DateTime.Today.ToString("yyyy/MM/dd");
                    cmdQuery.Parameters["@CommodityId"].Value = QueryCls.CommodityId;
                    cmdQuery.Parameters["@InformationTime"].Value = QueryCls.InformationTime;
                    cmdQuery.Parameters["@InformationSeq"].Value = QueryCls.InformationSeq;
                    cmdQuery.Parameters["@DisclosureTime"].Value = QueryCls.DisClosureTime;
                    cmdQuery.Parameters["@DurationTime"].Value = QueryCls.DurationTime;
                    
                    cmdQuery.ExecuteNonQuery();
                }
                else
                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WriteSP_Error] " + "[obj is null]");
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WriteSP_Error][" + commodityid + "]" + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void WriteToLogWork()
        {
            try
            {
                byte[] tByte;

                for (; ; )
                {
                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.05)
                    {
                        notFinishInitial = true;
                    }

                    if (Math.Abs(DateTime.Now.TimeOfDay.Subtract(IniTime).TotalSeconds) < 10 && notFinishInitial)
                    {
                        IniLog();
                                                
                        notFinishInitial = false;
                    }

                    while (m_WriteFilePool.Count > 0)
                    {
                        tByte = (byte[])m_WriteFilePool.Dequeue();

                        if (tByte != null)
                            fsIn.Write(tByte, 0, tByte.Length);
                    }

                    fsIn.Flush();

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WriteToLogWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        /*private void CalculateGreeksWork()
        {
            try
            {
                while (true)
                {
                    while (m_CalculateGreeksPool.Count > 0)                    
                        CalculateGreeks(m_CalculateGreeksPool.Dequeue());

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][CalculateGreeksWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void CalculateGreeks(object obj)
        {
            try
            {
                PCommodity mPCommodity = null;
                double lastiv = 0.0;
                double bidiv1 = 0.0;
                double bidiv2 = 0.0;
                double bidiv3 = 0.0;
                double bidiv4 = 0.0;
                double bidiv5 = 0.0;
                double askiv1 = 0.0;
                double askiv2 = 0.0;
                double askiv3 = 0.0;
                double askiv4 = 0.0;
                double askiv5 = 0.0;
                double delta = 0.0;
                double gamma = 0.0;
                double vega = 0.0;
                double theta = 0.0;
                double rho = 0.0;
                double tprice = 0.0;

                Type iType = obj.GetType();

                if (iType == typeof(QBest5))
                {
                    QBest5 QBest5 = (QBest5)obj;

                    mPCommodity = m_PCommodityList.Get(QBest5.CommodityId);

                    if (mPCommodity == null) { return; }
                    if (mPCommodity.QCommodity.Extra == null) { return; }

                    lastiv = mPCommodity.QCommodity.Greeks.LastIV;                    
                    delta = mPCommodity.QCommodity.Greeks.Delta;
                    gamma = mPCommodity.QCommodity.Greeks.Gamma;
                    vega = mPCommodity.QCommodity.Greeks.Vega;
                    theta = mPCommodity.QCommodity.Greeks.Theta;
                    rho = mPCommodity.QCommodity.Greeks.Rho;
                    tprice = mPCommodity.QCommodity.Greeks.TPrice;
                    
                    bidiv1 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest1s / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv2 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest2 / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv3 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest3 / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv4 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest4 / mPCommodity.QCommodity.Extra.ExecRatio);
                    bidiv5 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.BuyPriceBest5 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv1 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest1s / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv2 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest2 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv3 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest3 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv4 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest4 / mPCommodity.QCommodity.Extra.ExecRatio);
                    askiv5 = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Best5.SellPriceBest5 / mPCommodity.QCommodity.Extra.ExecRatio);

                    if (double.IsNaN(bidiv1) && double.IsInfinity(bidiv1)){ bidiv1 = 0.0;}
                    if (double.IsNaN(bidiv2) && double.IsInfinity(bidiv2)){ bidiv2 = 0.0;}
                    if (double.IsNaN(bidiv3) && double.IsInfinity(bidiv3)){ bidiv3 = 0.0;}
                    if (double.IsNaN(bidiv4) && double.IsInfinity(bidiv4)){ bidiv4 = 0.0;}
                    if (double.IsNaN(bidiv5) && double.IsInfinity(bidiv5)){ bidiv5 = 0.0;}
                    if (double.IsNaN(askiv1) && double.IsInfinity(askiv1)){ askiv1 = 0.0;}    
                    if (double.IsNaN(askiv2) && double.IsInfinity(askiv2)){ askiv2 = 0.0;}    
                    if (double.IsNaN(askiv3) && double.IsInfinity(askiv3)){ askiv3 = 0.0;}    
                    if (double.IsNaN(askiv4) && double.IsInfinity(askiv4)){ askiv4 = 0.0;}    
                    if (double.IsNaN(askiv5) && double.IsInfinity(askiv5)){ askiv5 = 0.0;}    

                    mPCommodity.SetGreeks(DateTime.Now.ToString("HHmmssff"), lastiv, bidiv1, bidiv2, bidiv3, bidiv4, bidiv5, askiv1, askiv2, askiv3, askiv4, askiv5,delta,gamma,vega,theta,rho,tprice);
                    mPCommodity.Send(mPCommodity.QCommodity.Greeks);
                }
                else if (iType == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;

                    mPCommodity = m_PCommodityList.Get(QMatch.CommodityId);

                    if (mPCommodity == null) { return; }

                    foreach (PCommodity P in mPCommodity.RelationCommoditys)
                    {
                        if (P != null) 
                        { 
                            CalculateGreeks(P.QCommodity.Match);
                            CalculateGreeks(P.QCommodity.Best5); 
                        }
                    }

                    if (mPCommodity.QCommodity.Extra == null) { return; }

                    bidiv1 = mPCommodity.QCommodity.Greeks.Bid1IV;
                    bidiv2 = mPCommodity.QCommodity.Greeks.Bid2IV;
                    bidiv3 = mPCommodity.QCommodity.Greeks.Bid3IV;
                    bidiv4 = mPCommodity.QCommodity.Greeks.Bid4IV;
                    bidiv5 = mPCommodity.QCommodity.Greeks.Bid5IV;
                    askiv1 = mPCommodity.QCommodity.Greeks.Ask1IV;
                    askiv2 = mPCommodity.QCommodity.Greeks.Ask2IV;
                    askiv3 = mPCommodity.QCommodity.Greeks.Ask3IV;
                    askiv4 = mPCommodity.QCommodity.Greeks.Ask4IV;
                    askiv5 = mPCommodity.QCommodity.Greeks.Ask5IV;
                    
                    lastiv = Greeks.CalcIV((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Match.MatchPrices / mPCommodity.QCommodity.Extra.ExecRatio);
                    delta = Greeks.CalcDelta((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    gamma = Greeks.CalcGamma((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    vega = Greeks.CalcVega((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    theta = Greeks.CalcTheta((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    rho = Greeks.CalcRho((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;
                    tprice = Greeks.CalcTPrice((enumOption)mPCommodity.QCommodity.Base.CommodityType, mPCommodity.QCommodity.Extra.Underlying.QCommodity.Match.MatchPrices, mPCommodity.QCommodity.Extra.Strike, mPCommodity.QCommodity.Extra.BarrierPrice, Math.Abs(mPCommodity.QCommodity.Extra.Strike - mPCommodity.QCommodity.Extra.BarrierPrice), mPCommodity.QCommodity.Extra.Maturity.Subtract(DateTime.Today).Days / 365.0, 0.03, 0.0, mPCommodity.QCommodity.Extra.HisVol) * mPCommodity.QCommodity.Extra.ExecRatio;

                    if (double.IsNaN(lastiv) && double.IsInfinity(lastiv)){ lastiv = 0.0;}    
                    if (double.IsNaN(delta) && double.IsInfinity(delta)){ delta = 0.0;}    
                    if (double.IsNaN(gamma) && double.IsInfinity(gamma)){ gamma = 0.0;}    
                    if (double.IsNaN(vega) && double.IsInfinity(vega)){ vega = 0.0;}    
                    if (double.IsNaN(theta) && double.IsInfinity(theta)){ theta = 0.0;}    
                    if (double.IsNaN(rho) && double.IsInfinity(rho)){ rho = 0.0;}
                    if (double.IsNaN(tprice) && double.IsInfinity(tprice)) { tprice = 0.0; }

                    mPCommodity.SetGreeks(DateTime.Now.ToString("HHmmssff"), lastiv, bidiv1, bidiv2, bidiv3, bidiv4, bidiv5, askiv1, askiv2, askiv3, askiv4, askiv5, delta, gamma, vega, theta, rho, tprice);
                    mPCommodity.Send(mPCommodity.QCommodity.Greeks);
                }                
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][CalculateGreeks_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }*/
        private void CmdStore()
        {
            cmdBase = new SqlCommand("spBase");
            cmdBase.CommandType = CommandType.StoredProcedure;
            cmdOpen = new SqlCommand("spOpen");
            cmdOpen.CommandType = CommandType.StoredProcedure;
            cmdBest5 = new SqlCommand("spBest5");
            cmdBest5.CommandType = CommandType.StoredProcedure;
            cmdMatch = new SqlCommand("spMatch");
            cmdMatch.CommandType = CommandType.StoredProcedure;
            cmdHighLow = new SqlCommand("spHighLow");
            cmdHighLow.CommandType = CommandType.StoredProcedure;
            cmdClose = new SqlCommand("spClose");
            cmdClose.CommandType = CommandType.StoredProcedure;
            cmdWarrantExtra = new SqlCommand("spWarrantExtra");
            cmdWarrantExtra.CommandType = CommandType.StoredProcedure;
            cmdHTicks = new SqlCommand("spHTicks");
            cmdHTicks.CommandType = CommandType.StoredProcedure;
            cmdQuery = new SqlCommand("spQuery");
            cmdQuery.CommandType = CommandType.StoredProcedure;
            cmdUpdateCurrency = new SqlCommand("spUpdateCurrency");
            cmdUpdateCurrency.CommandType = CommandType.StoredProcedure;

            conn = new SqlConnection(m_QuoteSetting.DBConnectString);
            cmdBase.Connection = conn;
            cmdOpen.Connection = conn;
            cmdBest5.Connection = conn;
            cmdMatch.Connection = conn;
            cmdHighLow.Connection = conn;
            cmdClose.Connection = conn;
            cmdWarrantExtra.Connection = conn;
            cmdHTicks.Connection = conn;
            cmdQuery.Connection = conn;
            cmdUpdateCurrency.Connection = conn;

            cmdBase.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdBase.Parameters.Add("@Market", SqlDbType.Int);
            cmdBase.Parameters.Add("@CommodityKind", SqlDbType.Int);
            cmdBase.Parameters.Add("@CommodityType", SqlDbType.Int);
            cmdBase.Parameters.Add("@CommodityNm", SqlDbType.VarChar, 50);
            cmdBase.Parameters.Add("@CommodityCode", SqlDbType.VarChar, 20);
            cmdBase.Parameters.Add("@TradeDate", SqlDbType.VarChar, 10);
            cmdBase.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdBase.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdBase.Parameters.Add("@SettleMentMonth", SqlDbType.VarChar, 6);
            cmdBase.Parameters.Add("@Strike", SqlDbType.Float);
            cmdBase.Parameters.Add("@ReferencePrice", SqlDbType.Float);
            cmdBase.Parameters.Add("@RiseLimitPrice", SqlDbType.Float);
            cmdBase.Parameters.Add("@FallLimitPrice", SqlDbType.Float);
            cmdBase.Parameters.Add("@RiseLimitPrice2", SqlDbType.Float);
            cmdBase.Parameters.Add("@FallLimitPrice2", SqlDbType.Float);
            cmdBase.Parameters.Add("@RiseLimitPrice3", SqlDbType.Float);
            cmdBase.Parameters.Add("@FallLimitPrice3", SqlDbType.Float);
            cmdBase.Parameters.Add("@Unit", SqlDbType.Int);
            cmdBase.Parameters.Add("@ProdKind", SqlDbType.VarChar, 1);
            cmdBase.Parameters.Add("@DecimalLocate", SqlDbType.Float);
            cmdBase.Parameters.Add("@StrikeDecimalLocate", SqlDbType.Float);
            cmdBase.Parameters.Add("@InnerCode", SqlDbType.VarChar,20);
            cmdBase.Parameters.Add("@CommodityProperty", SqlDbType.VarChar, 2);

            cmdOpen.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdOpen.Parameters.Add("@OpenTime", SqlDbType.VarChar, 8);
            cmdOpen.Parameters.Add("@OpenPrice", SqlDbType.Float);

            cmdBest5.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdBest5.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdBest5.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdBest5.Parameters.Add("@BuyPriceBest1", SqlDbType.Float);
            cmdBest5.Parameters.Add("@BuyQtyBest1", SqlDbType.Int);
            cmdBest5.Parameters.Add("@BuyPriceBest2", SqlDbType.Float);
            cmdBest5.Parameters.Add("@BuyQtyBest2", SqlDbType.Int);
            cmdBest5.Parameters.Add("@BuyPriceBest3", SqlDbType.Float);
            cmdBest5.Parameters.Add("@BuyQtyBest3", SqlDbType.Int);
            cmdBest5.Parameters.Add("@BuyPriceBest4", SqlDbType.Float);
            cmdBest5.Parameters.Add("@BuyQtyBest4", SqlDbType.Int);
            cmdBest5.Parameters.Add("@BuyPriceBest5", SqlDbType.Float);
            cmdBest5.Parameters.Add("@BuyQtyBest5", SqlDbType.Int);
            cmdBest5.Parameters.Add("@SellPriceBest1", SqlDbType.Float);
            cmdBest5.Parameters.Add("@SellQtyBest1", SqlDbType.Int);
            cmdBest5.Parameters.Add("@SellPriceBest2", SqlDbType.Float);
            cmdBest5.Parameters.Add("@SellQtyBest2", SqlDbType.Int);
            cmdBest5.Parameters.Add("@SellPriceBest3", SqlDbType.Float);
            cmdBest5.Parameters.Add("@SellQtyBest3", SqlDbType.Int);
            cmdBest5.Parameters.Add("@SellPriceBest4", SqlDbType.Float);
            cmdBest5.Parameters.Add("@SellQtyBest4", SqlDbType.Int);
            cmdBest5.Parameters.Add("@SellPriceBest5", SqlDbType.Float);
            cmdBest5.Parameters.Add("@SellQtyBest5", SqlDbType.Int);
            cmdBest5.Parameters.Add("@BuyPriceDerived", SqlDbType.Float);
            cmdBest5.Parameters.Add("@BuyQtyDerived", SqlDbType.Int);
            cmdBest5.Parameters.Add("@SellPriceDerived", SqlDbType.Float);
            cmdBest5.Parameters.Add("@SellQtyDerived", SqlDbType.Int);

            cmdMatch.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdMatch.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdMatch.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdMatch.Parameters.Add("@MatchSeq", SqlDbType.Int);
            cmdMatch.Parameters.Add("@MatchTime", SqlDbType.VarChar, 8);
            cmdMatch.Parameters.Add("@MatchPrice", SqlDbType.Float);
            cmdMatch.Parameters.Add("@MatchQty", SqlDbType.Int);
            cmdMatch.Parameters.Add("@MatchAmt", SqlDbType.Float);
            cmdMatch.Parameters.Add("@MatchTotalAmt", SqlDbType.Float);
            cmdMatch.Parameters.Add("@MatchTotalQty", SqlDbType.Int);
            cmdMatch.Parameters.Add("@MatchTotalCnt", SqlDbType.Int);
            cmdMatch.Parameters.Add("@MatchBuyTotalCnt", SqlDbType.Int);
            cmdMatch.Parameters.Add("@MatchSellTotalCnt", SqlDbType.Int);
            cmdMatch.Parameters.Add("@IsWriteTicks", SqlDbType.Char, 1);

            cmdHighLow.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdHighLow.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdHighLow.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdHighLow.Parameters.Add("@DayHighPrice", SqlDbType.Float);
            cmdHighLow.Parameters.Add("@DayLowPrice", SqlDbType.Float);
            cmdHighLow.Parameters.Add("@ShowTime", SqlDbType.VarChar, 8);

            cmdClose.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdClose.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdClose.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdClose.Parameters.Add("@DayHighPrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@DayLowPrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@OpenPrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@BuyPrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@SellPrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@ClosePrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@CloseDate", SqlDbType.VarChar, 10);
            cmdClose.Parameters.Add("@MatchTotalCnt", SqlDbType.Int);
            cmdClose.Parameters.Add("@MatchTotalQty", SqlDbType.Int);
            cmdClose.Parameters.Add("@MatchTotalAmt", SqlDbType.Float);
            cmdClose.Parameters.Add("@ComBuyCnt", SqlDbType.Int);
            cmdClose.Parameters.Add("@ComBuyQty", SqlDbType.Int);
            cmdClose.Parameters.Add("@ComSellCnt", SqlDbType.Int);
            cmdClose.Parameters.Add("@ComSellQty", SqlDbType.Int);
            cmdClose.Parameters.Add("@ComTotalQty", SqlDbType.Int);
            cmdClose.Parameters.Add("@SettlementPrice", SqlDbType.Float);
            cmdClose.Parameters.Add("@OpenInterest", SqlDbType.Int);

            cmdWarrantExtra.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdWarrantExtra.Parameters.Add("@Strike", SqlDbType.Float);
            cmdWarrantExtra.Parameters.Add("@ExecRatio", SqlDbType.Float);

            cmdHTicks.Parameters.Add("@TradeDate", SqlDbType.VarChar, 10);
            cmdHTicks.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdHTicks.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdHTicks.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdHTicks.Parameters.Add("@MatchSeq", SqlDbType.Int);
            cmdHTicks.Parameters.Add("@MatchTime", SqlDbType.VarChar, 8);
            cmdHTicks.Parameters.Add("@MatchPrice", SqlDbType.Float);
            cmdHTicks.Parameters.Add("@MatchQty", SqlDbType.Int);
            cmdHTicks.Parameters.Add("@MatchTotalQty", SqlDbType.Int);
            cmdHTicks.Parameters.Add("@BuyPriceBest1", SqlDbType.Float);
            cmdHTicks.Parameters.Add("@BuyQtyBest1", SqlDbType.Int);
            cmdHTicks.Parameters.Add("@SellPriceBest1", SqlDbType.Float);
            cmdHTicks.Parameters.Add("@SellQtyBest1", SqlDbType.Int);

            cmdQuery.Parameters.Add("@FOFlag", SqlDbType.Char, 1);
            cmdQuery.Parameters.Add("@TradeDate", SqlDbType.VarChar, 10);
            cmdQuery.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdQuery.Parameters.Add("@InformationTime", SqlDbType.VarChar, 8);
            cmdQuery.Parameters.Add("@InformationSeq", SqlDbType.VarChar, 8);
            cmdQuery.Parameters.Add("@DisclosureTime", SqlDbType.VarChar, 8);
            cmdQuery.Parameters.Add("@DurationTime", SqlDbType.Int);

            cmdUpdateCurrency.Parameters.Add("@CommodityId", SqlDbType.VarChar, 20);
            cmdUpdateCurrency.Parameters.Add("@CurrencyId", SqlDbType.VarChar, 20);
            
        }
        protected void ErrorProcess(string str)
        {
            m_ErrorPool.Enqueue(str);
            //if (ErrorFire != null)
            //    ErrorFire(QuoteSetting.DataSource, str);
        }

        #region ITSFactory 成員

        public int SendPacketNum
        {
            get { return 0; }            
        }

        public int ReceivePacketNum
        {
            get { return m_PacketNum; }
        }

        public int ReadDBNum
        {
            get { return 0; }
        }

        public int WriteDBNum
        {
            get { return m_WriteDBPool.Count; }
        }

        public string DataSource
        {
            get { return QuoteSetting.DataSource; }
        }

        public string Note
        {
            get { return QuoteSetting.DataSource; }
        }
        public Queue ErrorQueue
        {
            get { return m_ErrorPool; }
        }
        public virtual bool Start()
        {
            try
            {
                if (QuoteSetting.IsWriteToDb)
                {
                    CmdStore();
                    WriteToDBThread = new Thread(new ThreadStart(WriteToDBWork));
                    WriteToDBThread.Start();
                }
                if (QuoteSetting.IsWriteToLog)
                {
                    IniLog();
                    WriteToLogThread = new Thread(new ThreadStart(WriteToLogWork));
                    WriteToLogThread.Start();
                }
                /*if (QuoteSetting.IsCalculateGreeks)
                {
                    CalculateGreeksThread = new Thread(new ThreadStart(CalculateGreeksWork));
                    CalculateGreeksThread.Start();
                }*/ 
                if (m_QuoteSetting.IsReloadData)
                {
                    InitialOK = false;
                    //ThreadPool.QueueUserWorkItem(ReloadWork);
                    ReloadWork();
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public virtual bool Close()
        {
            try
            {
                if (m_CMarket != null) 
                { 
                    m_CMarket.RemoveQuoteSource(this); 
                }
                if (WriteToDBThread != null && WriteToDBThread.IsAlive) 
                { 
                    WriteToDBThread.Abort(); 
                }
                if (WriteToLogThread != null && WriteToLogThread.IsAlive) 
                {
                    WriteToLogThread.Abort(); 
                }
                /*if (CalculateGreeksThread != null && CalculateGreeksThread.IsAlive) 
                {
                    CalculateGreeksThread.Abort(); 
                }*/
                
                if (fsIn != null) 
                { 
                    fsIn.Close(); 
                }
                if (conn.State == ConnectionState.Open) 
                { 
                    conn.Close(); 
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public event DeriLib.TSModel.ErrorHandler ErrorFire;

        #endregion
    }
    public class WCFQuoteSource : QuoteSource
    {
        private Thread DoThread;
        private QuotePush Q = null;
        private string SubCommodity = "";
        private HashSet<string> m_ClientSubCommodity = new HashSet<string>();
        private string RemotIp = "";
        private System.Timers.Timer tr = new System.Timers.Timer(10000);
        private object LockObj = new object();
        
        public WCFQuoteSource(WCFQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {          
            SubCommodity = QuoteSetting.SubCommodity;
            RemotIp = QuoteSetting.RemotIp;
        } 
        public override bool Start()
        {
            try
            {
                DoThread = new Thread(new ThreadStart(DealWithQuote));
                DoThread.Start();

                tr.Elapsed += new ElapsedEventHandler(tr_Elapsed);
                tr.AutoReset = false;

                Q = new QuotePush(Communication.TCP, RemotIp);
                Q.QuoteArrived += new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                Q.MsgArrived += new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                Q.Start();

                if (SubCommodity != "")
                {
                    List<string> L = SubCommodity.Split(',').ToList<string>();
                    Q.SubCommodity(L);
                }

                return base.Start();
            }
            catch (Exception ex)
            {
                try
                {
                    tr.Start();
                    Q.Close();
                }
                catch (Exception ex2)
                {
                }
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return false;
                //throw ex;
            }
        }
        public override bool Close()
        {
            try
            {
                if (DoThread != null && DoThread.IsAlive) { DoThread.Abort(); }                
                base.Close();
                Q.Close();
                tr.Elapsed -= new ElapsedEventHandler(tr_Elapsed);
                tr.Stop();
                tr.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public void AddClientSubCommodity(string CommodityId)
        {
            lock (LockObj)
            {
                if (!m_ClientSubCommodity.Contains(CommodityId))
                    m_ClientSubCommodity.Add(CommodityId);
            }
        }
        public void RemoveClientSubCommodity(string CommodityId)
        {
            lock (LockObj)
            {
                if (m_ClientSubCommodity.Contains(CommodityId))
                    m_ClientSubCommodity.Remove(CommodityId);
            }
        }
        public bool IsPermanentCommodity(PCommodity PCommodity)
        {
            try
            {
                lock (LockObj)
                {
                    List<string> L = SubCommodity.Split(',').ToList<string>();

                    if (L.Contains(PCommodity.CommodityId)) { return true; }
                    if (PCommodity.CMarket != null && L.Contains(Enum.GetName(typeof(Market), PCommodity.CMarket.Market))) { return true; }

                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        public List<string> ClientSubCommoditys
        {
            get
            {
                List<string> L = null;

                lock (LockObj)
                {
                    L = m_ClientSubCommodity.ToList<string>();
                }

                return L;
            }
        }
        public void ReSubCommodity(List<string> L)
        {
            try
            {                
                if (!Q.IsDisConnect)
                    Q.SubCommodity(L);
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ReSubCommodity_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        public void UnSubCommodity(List<string> L)
        {
            try
            {
                if (!Q.IsDisConnect)
                    Q.UnSubCommodity(L);
            }
            catch(Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][UnSubCommodity_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");                
            }
        }
        public void tr_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                if (Q != null)
                {
                    Q.QuoteArrived -= new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                    Q.MsgArrived -= new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                    Q.Close();
                }

                Q = new QuotePush(Communication.TCP, RemotIp);
                Q.QuoteArrived += new QuotePush.QuoteArrivedHandler(Q_QuoteArrived);
                Q.MsgArrived += new QuotePush.MsgArrivedHandler(Q_MsgArrived);
                Q.Start();

                List<string> L = SubCommodity.Split(',').ToList<string>();
                L.AddRange(ClientSubCommoditys);
                Q.SubCommodity(L);
            }
            catch (Exception ex)
            {
                try
                {
                    tr.Start();
                    Q.Close();
                }
                catch (Exception ex2)
                {
                }
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");                
            }
        }
        private void Q_MsgArrived(object obj)
        {
            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WCFQuoteSource Connection Is Lost]");
            tr.Start();
        }
        private void Q_QuoteArrived(object obj)
        {
            m_PacketNum++;
            m_PackagePool.Enqueue(obj); 
        }
        private void DealWithQuote()
        {
            try
            {   
                int j = 0;
                PCommodity mPCommodity = null;

                for (; ; )
                {

                    while (m_PackagePool.Count > 0)
                    {                       
                        object obj = (object)m_PackagePool.Dequeue();

                        try
                        {
                            Type iType = obj.GetType();

                            if (iType == typeof(QCommodity))
                            {
                                QCommodity QCommodity = (QCommodity)obj;
                                
                                mPCommodity = m_PCommodityList.SetNotGetFromDB(QCommodity.Base.CommodityCode, QCommodity.Base.CommodityId, QCommodity.Base.Market, QCommodity.Base.CommodityKind);

                                mPCommodity.SetBase(QCommodity.Base.Market, QCommodity.Base.CommodityKind, QCommodity.Base.CommodityType, QCommodity.Base.CommodityCode, QCommodity.Base.CommodityNm, QCommodity.Base.TradeDate, QCommodity.Base.InformationTime, QCommodity.Base.InformationSeq, QCommodity.Base.SettleMentMonth, QCommodity.Base.Strike, QCommodity.Base.ReferencePrice, QCommodity.Base.RiseLimitPrice, QCommodity.Base.FallLimitPrice, QCommodity.Base.RiseLimitPrice2, QCommodity.Base.FallLimitPrice2, QCommodity.Base.RiseLimitPrice3, QCommodity.Base.FallLimitPrice3, QCommodity.Base.Unit, QCommodity.Base.ProdKind, QCommodity.Base.DecimalLocate, QCommodity.Base.StrikeDecimalLocate, QCommodity.Base.InnerCode, QCommodity.Base.CommodityProperty);
                                if (m_QuoteSetting.IsWriteToDb)                                
                                    m_WriteDBPool.Enqueue(QCommodity.Base);
                                
                                if (QCommodity.Extra != null)
                                {
                                    PCommodity Underlying = m_PCommodityList.Get(QCommodity.Extra.UnderlyingId);
                                    /*Underlying.AddRelation(mPCommodity);*/

                                    mPCommodity.SetExtra(QCommodity.Extra.CommodityId, QCommodity.Extra.UnderlyingId, Underlying, QCommodity.Extra.Maturity, QCommodity.Extra.Strike, QCommodity.Extra.BarrierPrice, QCommodity.Extra.ExecRatio, QCommodity.Extra.HisVol, QCommodity.Extra.LastTradeDate, QCommodity.Extra.IssueQty, QCommodity.Extra.CancelQty, QCommodity.Extra.Duration);                                    
                                }
                                if (QCommodity.HisVol != null)
                                    mPCommodity.SetHIV(QCommodity.HisVol.CommodityId, QCommodity.HisVol.HIV1M, QCommodity.HisVol.HIV3M, QCommodity.HisVol.HIV6M, QCommodity.HisVol.HIV12M);

                                if (mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenTime == string.Empty || mPCommodity.QCommodity.Open.OpenTime == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0)
                                {
                                    if (QCommodity.Open.OpenPrice != 0.0)
                                    {                                        
                                        if (m_QuoteSetting.IsWriteToDb)
                                            m_WriteDBPool.Enqueue(QCommodity.Open);                                     
                                    }
                                }

                                if (QCommodity.Best5.InformationSeq != string.Empty && QCommodity.Best5.InformationSeq != null)
                                {
                                    if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || mPCommodity.QCommodity.Best5.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(QCommodity.Best5.InformationSeq))
                                    {
                                        if (QCommodity.Best5.BuyPriceBest1 != 0.0 || QCommodity.Best5.SellPriceBest1 != 0.0)
                                        {
                                            if (m_QuoteSetting.IsWriteToDb)
                                                m_WriteDBPool.Enqueue(QCommodity.Best5);
                                        }
                                    }
                                }
                                
                                if (QCommodity.Match.InformationSeq != string.Empty && QCommodity.Match.InformationSeq != null)
                                {
                                    if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || mPCommodity.QCommodity.Match.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(QCommodity.Match.InformationSeq) || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) == int.Parse(QCommodity.Match.InformationSeq) && mPCommodity.QCommodity.Match.MatchSeq < QCommodity.Match.MatchSeq) || mPCommodity.QCommodity.Match.MatchTotalAmt < QCommodity.Match.MatchTotalAmt || mPCommodity.QCommodity.Match.MatchTotalQty < QCommodity.Match.MatchTotalQty)
                                    {                                            
                                        if (m_QuoteSetting.IsWriteToDb)
                                            m_WriteDBPool.Enqueue(QCommodity.Match);                                        
                                    }
                                }
                                if (QCommodity.HighLow.ShowTime != string.Empty && QCommodity.HighLow.ShowTime != null)
                                {
                                    if (mPCommodity.QCommodity.HighLow == null || mPCommodity.QCommodity.HighLow.ShowTime == string.Empty || mPCommodity.QCommodity.HighLow.ShowTime == null || int.Parse(mPCommodity.QCommodity.HighLow.ShowTime) < int.Parse(QCommodity.HighLow.ShowTime))
                                    {
                                        if (QCommodity.HighLow.DayHighPrice != 0.0 || QCommodity.HighLow.DayLowPrice != 0.0)
                                        {                                            
                                            if (m_QuoteSetting.IsWriteToDb)
                                                m_WriteDBPool.Enqueue(QCommodity.HighLow);
                                        }
                                    }
                                }

                                if (QCommodity.Close.InformationTime != string.Empty && QCommodity.Close.InformationTime != null)
                                {
                                    if (m_QuoteSetting.IsWriteToDb)
                                        m_WriteDBPool.Enqueue(QCommodity.Close);                            
                                }
                                /*if (QCommodity.Greeks.InformationTime != string.Empty && QCommodity.Greeks.InformationTime != null)
                                {                                    
                                    if (m_QuoteSetting.IsWriteToDb)
                                        m_WriteDBPool.Enqueue(mPCommodity.QCommodity.HighLow);                            
                                }*/

                                mPCommodity.SetOpen(QCommodity.Open.OpenTime, QCommodity.Open.OpenPrice);
                                mPCommodity.SetBest5(QCommodity.Best5.InformationTime, QCommodity.Best5.InformationSeq, QCommodity.Best5.BuyPriceBest1, QCommodity.Best5.BuyQtyBest1, QCommodity.Best5.BuyPriceBest2, QCommodity.Best5.BuyQtyBest2, QCommodity.Best5.BuyPriceBest3, QCommodity.Best5.BuyQtyBest3, QCommodity.Best5.BuyPriceBest4, QCommodity.Best5.BuyQtyBest4, QCommodity.Best5.BuyPriceBest5, QCommodity.Best5.BuyQtyBest5, QCommodity.Best5.SellPriceBest1, QCommodity.Best5.SellQtyBest1, QCommodity.Best5.SellPriceBest2, QCommodity.Best5.SellQtyBest2, QCommodity.Best5.SellPriceBest3, QCommodity.Best5.SellQtyBest3, QCommodity.Best5.SellPriceBest4, QCommodity.Best5.SellQtyBest4, QCommodity.Best5.SellPriceBest5, QCommodity.Best5.SellQtyBest5, QCommodity.Best5.BuyPriceDerived, QCommodity.Best5.BuyQtyDerived, QCommodity.Best5.SellPriceDerived, QCommodity.Best5.SellQtyDerived);
                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                    m_CalculateGreeksPool.Enqueue(QCommodity.Best5);*/
                                mPCommodity.SetMatch(QCommodity.Match.InformationTime, QCommodity.Match.InformationSeq, QCommodity.Match.MatchSeq, QCommodity.Match.MatchTime, QCommodity.Match.MatchPrice, QCommodity.Match.MatchQty, QCommodity.Match.MatchAmt, QCommodity.Match.MatchTotalAmt, QCommodity.Match.MatchTotalQty, QCommodity.Match.MatchTotalCnt, QCommodity.Match.MatchBuyTotalCnt, QCommodity.Match.MatchSellTotalCnt);
                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                    m_CalculateGreeksPool.Enqueue(QCommodity.Match);*/
                                mPCommodity.SetHighLow(QCommodity.HighLow.InformationTime, QCommodity.HighLow.InformationSeq, QCommodity.HighLow.DayHighPrice, QCommodity.HighLow.DayLowPrice, QCommodity.HighLow.ShowTime);
                                mPCommodity.SetClose(QCommodity.Close.InformationTime, QCommodity.Close.InformationSeq, QCommodity.Close.DayHighPrice, QCommodity.Close.DayLowPrice, QCommodity.Close.OpenPrice, QCommodity.Close.BuyPrice, QCommodity.Close.SellPrice, QCommodity.Close.ClosePrice, QCommodity.Close.CloseDate, QCommodity.Close.MatchTotalCnt, QCommodity.Close.MatchTotalQty, QCommodity.Close.MatchTotalAmt, QCommodity.Close.ComBuyCnt, QCommodity.Close.ComBuyQty, QCommodity.Close.ComSellCnt, QCommodity.Close.ComSellQty, QCommodity.Close.ComTotalQty, QCommodity.Close.SettlementPrice, QCommodity.Close.OpenInterest, QCommodity.Close.LastCloseDate, QCommodity.Close.LastSettlementPrice, QCommodity.Close.LastOpenInterest);
                                //mPCommodity.SetGreeks(QCommodity.Greeks.InformationTime, QCommodity.Greeks.LastIV, QCommodity.Greeks.Bid1IV, QCommodity.Greeks.Bid2IV, QCommodity.Greeks.Bid3IV, QCommodity.Greeks.Bid4IV, QCommodity.Greeks.Bid5IV, QCommodity.Greeks.Ask1IV, QCommodity.Greeks.Ask2IV, QCommodity.Greeks.Ask3IV, QCommodity.Greeks.Ask4IV, QCommodity.Greeks.Ask5IV, QCommodity.Greeks.Delta, QCommodity.Greeks.Gamma, QCommodity.Greeks.Vega, QCommodity.Greeks.Theta, QCommodity.Greeks.Rho, QCommodity.Greeks.TPrice);

                                mPCommodity.Send(QCommodity);
                            }
                            else if (iType == typeof(QBase))
                            {
                                QBase QBase = (QBase)obj;

                                mPCommodity = m_PCommodityList.SetNotGetFromDB(QBase.CommodityCode, QBase.CommodityId, QBase.Market, QBase.CommodityKind);
                                
                                if (mPCommodity == null) { continue; }

                                mPCommodity.SetBase(QBase.Market, QBase.CommodityKind, QBase.CommodityType, QBase.CommodityCode, QBase.CommodityNm, QBase.TradeDate, QBase.InformationTime, QBase.InformationSeq, QBase.SettleMentMonth, QBase.Strike, QBase.ReferencePrice, QBase.RiseLimitPrice, QBase.FallLimitPrice, QBase.RiseLimitPrice2, QBase.FallLimitPrice2, QBase.RiseLimitPrice3, QBase.FallLimitPrice3, QBase.Unit, QBase.ProdKind, QBase.DecimalLocate, QBase.StrikeDecimalLocate, QBase.InnerCode, QBase.CommodityProperty);
                                mPCommodity.Send(QBase);

                                if (m_QuoteSetting.IsWriteToDb)
                                    m_WriteDBPool.Enqueue(QBase);                                                  
                            }
                            else if (iType == typeof(QOpen))
                            {
                                QOpen QOpen = (QOpen)obj;

                                mPCommodity = m_PCommodityList.Get(QOpen.CommodityId);

                                if (mPCommodity == null) { continue; }

                                if (mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenTime == string.Empty || mPCommodity.QCommodity.Open.OpenTime == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0)
                                {
                                    if (m_QuoteSetting.IsWriteToDb)
                                        m_WriteDBPool.Enqueue(QOpen);
                                }

                                mPCommodity.SetOpen(QOpen.OpenTime, QOpen.OpenPrice);
                                mPCommodity.Send(QOpen);
                            }
                            else if (iType == typeof(QBest5))
                            {
                                QBest5 QBest5 = (QBest5)obj;

                                mPCommodity = m_PCommodityList.Get(QBest5.CommodityId);

                                if (mPCommodity == null) { continue; }

                                if (QBest5.InformationSeq != string.Empty && QBest5.InformationSeq != null)
                                {
                                    if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || mPCommodity.QCommodity.Best5.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(QBest5.InformationSeq))
                                    {
                                        if (m_QuoteSetting.IsWriteToDb)
                                            m_WriteDBPool.Enqueue(QBest5);
                                    }
                                }

                                mPCommodity.SetBest5(QBest5.InformationTime, QBest5.InformationSeq, QBest5.BuyPriceBest1, QBest5.BuyQtyBest1, QBest5.BuyPriceBest2, QBest5.BuyQtyBest2, QBest5.BuyPriceBest3, QBest5.BuyQtyBest3, QBest5.BuyPriceBest4, QBest5.BuyQtyBest4, QBest5.BuyPriceBest5, QBest5.BuyQtyBest5, QBest5.SellPriceBest1, QBest5.SellQtyBest1, QBest5.SellPriceBest2, QBest5.SellQtyBest2, QBest5.SellPriceBest3, QBest5.SellQtyBest3, QBest5.SellPriceBest4, QBest5.SellQtyBest4, QBest5.SellPriceBest5, QBest5.SellQtyBest5, QBest5.BuyPriceDerived, QBest5.BuyQtyDerived, QBest5.SellPriceDerived, QBest5.SellQtyDerived);
                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                    m_CalculateGreeksPool.Enqueue(QBest5);*/
                                mPCommodity.Send(QBest5);
                            }
                            else if (iType == typeof(QMatch))
                            {
                                QMatch QMatch = (QMatch)obj;

                                mPCommodity = m_PCommodityList.Get(QMatch.CommodityId);

                                if (mPCommodity == null) { continue; }

                                if (QMatch.InformationSeq != string.Empty && QMatch.InformationSeq != null)
                                {
                                    if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || mPCommodity.QCommodity.Match.InformationSeq == null || int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(QMatch.InformationSeq)  || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) == int.Parse(QMatch.InformationSeq) && mPCommodity.QCommodity.Match.MatchSeq < QMatch.MatchSeq) || mPCommodity.QCommodity.Match.MatchTotalAmt < QMatch.MatchTotalAmt || mPCommodity.QCommodity.Match.MatchTotalQty < QMatch.MatchTotalQty)
                                    {
                                        if (m_QuoteSetting.IsWriteToDb)
                                            m_WriteDBPool.Enqueue(QMatch);
                                    }
                                }

                                mPCommodity.SetMatch(QMatch.InformationTime, QMatch.InformationSeq, QMatch.MatchSeq, QMatch.MatchTime, QMatch.MatchPrice, QMatch.MatchQty, QMatch.MatchAmt, QMatch.MatchTotalAmt, QMatch.MatchTotalQty, QMatch.MatchTotalCnt, QMatch.MatchBuyTotalCnt, QMatch.MatchSellTotalCnt);
                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                    m_CalculateGreeksPool.Enqueue(QMatch);*/
                                mPCommodity.Send(QMatch);
                            }
                            else if (iType == typeof(QHighLow))
                            {
                                QHighLow QHighLow = (QHighLow)obj;

                                mPCommodity = m_PCommodityList.Get(QHighLow.CommodityId);

                                if (mPCommodity == null) { continue; }

                                if (QHighLow.ShowTime != string.Empty && QHighLow.ShowTime != null)
                                {
                                    if (mPCommodity.QCommodity.HighLow == null || mPCommodity.QCommodity.HighLow.ShowTime == string.Empty || mPCommodity.QCommodity.HighLow.ShowTime == null || int.Parse(mPCommodity.QCommodity.HighLow.ShowTime) < int.Parse(QHighLow.ShowTime))
                                    {
                                        if (m_QuoteSetting.IsWriteToDb)
                                            m_WriteDBPool.Enqueue(QHighLow);
                                    }
                                }

                                mPCommodity.SetHighLow(QHighLow.InformationTime, QHighLow.InformationSeq, QHighLow.DayHighPrice, QHighLow.DayLowPrice, QHighLow.ShowTime);
                                mPCommodity.Send(QHighLow);
                            }
                            else if (iType == typeof(QClose))
                            {
                                QClose QClose = (QClose)obj;

                                mPCommodity = m_PCommodityList.Get(QClose.CommodityId);

                                if (mPCommodity == null) { continue; }

                                if (QClose.InformationTime != string.Empty && QClose.InformationTime != null)
                                {
                                    if (m_QuoteSetting.IsWriteToDb)
                                        m_WriteDBPool.Enqueue(QClose);        
                                }

                                mPCommodity.SetClose(QClose.InformationTime, QClose.InformationSeq, QClose.DayHighPrice, QClose.DayLowPrice, QClose.OpenPrice, QClose.BuyPrice, QClose.SellPrice, QClose.ClosePrice, QClose.CloseDate, QClose.MatchTotalCnt, QClose.MatchTotalQty, QClose.MatchTotalAmt, QClose.ComBuyCnt, QClose.ComBuyQty, QClose.ComSellCnt, QClose.ComSellQty, QClose.ComTotalQty, QClose.SettlementPrice, QClose.OpenInterest, QClose.LastCloseDate, QClose.LastSettlementPrice, QClose.LastOpenInterest);
                                mPCommodity.Send(QClose);
                            }
                            /*else if (iType == typeof(QGreeks))
                            {
                                QGreeks QGreeks = (QGreeks)obj;

                                mPCommodity = m_PCommodityList.Get(QGreeks.CommodityId);

                                if (mPCommodity == null) { continue; }

                                if (QGreeks.InformationTime != string.Empty && QGreeks.InformationTime != null)
                                {
                                    if (m_QuoteSetting.IsWriteToDb)
                                        m_WriteDBPool.Enqueue(mPCommodity.QCommodity.Greeks);        
                                }

                                mPCommodity.SetGreeks(QGreeks.InformationTime, QGreeks.LastIV, QGreeks.Bid1IV, QGreeks.Bid2IV, QGreeks.Bid3IV, QGreeks.Bid4IV, QGreeks.Bid5IV, QGreeks.Ask1IV, QGreeks.Ask2IV, QGreeks.Ask3IV, QGreeks.Ask4IV, QGreeks.Ask5IV, QGreeks.Delta, QGreeks.Gamma, QGreeks.Vega, QGreeks.Theta, QGreeks.Rho, QGreeks.TPrice);
                                mPCommodity.Send(QGreeks);
                            }*/

                            j++;

                            if (m_QuoteSetting.DataSendms != 0 && j % m_QuoteSetting.DataSendms == 0)
                            {
                                j = 0;
                                Thread.Sleep(1);
                            }
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }                        
                    }

                    Thread.Sleep(1);
                }                
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }

            if (m_QuoteSetting.IsSendTicks)
                TicksPool.Enqueue(obj2); 
        }
    }
    public class EstimateQuoteSource : QuoteSource
    {
        private Thread CalThread;
        private string DBConnectString = "";
        private TimeSpan STime;
        private TimeSpan ETime;
        private bool StartFlag = false;
        private bool EndFlag = false;
        //private int MatchSeq = 0;
        //private int Best5Seq = 0;
        private int Calculatems = 0;
        private string EstimateLabel = "";
        private List<EstimateCommodity> EstimateCommodityList = new List<EstimateCommodity>();
        
        public EstimateQuoteSource(EstimateQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            STime = new TimeSpan(int.Parse(QuoteSetting.STime.Substring(0, 2)), int.Parse(QuoteSetting.STime.Substring(3, 2)), 0);
            ETime = new TimeSpan(int.Parse(QuoteSetting.ETime.Substring(0, 2)), int.Parse(QuoteSetting.ETime.Substring(3, 2)), 0);

            Calculatems = QuoteSetting.Calculatems;    
            EstimateLabel = QuoteSetting.EstimateLabel;    
        }
        public override bool Start()
        {
            LoadData();

            CalThread = new Thread(new ThreadStart(CalQuote));
            CalThread.Start();

            return base.Start();
        }
        public override bool Close()
        {
            try
            {                
                if (CalThread != null && CalThread.IsAlive) { CalThread.Abort(); }                
                base.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
       
        private void CalQuote()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        StartFlag = false;
                        EndFlag = false;
                    }

                    if (Math.Abs(nowts.Subtract(STime).TotalMinutes) < 1 && !StartFlag)
                    {
                        LoadData();
                        StartFlag = true;
                    }

                    if (Math.Abs(nowts.Subtract(STime.Add(new TimeSpan(0,1,0))).TotalMinutes) < 1 )
                    {
                        foreach (EstimateCommodity E in EstimateCommodityList)
                        {
                            E.Parent.QCommodity.Match.InformationSeq = "";
                            E.Parent.QCommodity.Match.InformationTime = "";
                            E.Parent.QCommodity.Match.MatchTime = "";
                            E.Parent.QCommodity.Best5.InformationSeq = "";
                            E.Parent.QCommodity.Best5.InformationTime = "";
                        }
                    }

                    if (STime <= nowts && nowts <= ETime)
                    {
                        foreach (EstimateCommodity E in EstimateCommodityList)
                        {
                            if (!E.Parent.CMarket.IsTrade)
                                continue;

                            CalculateEstimate(E);
                        }
                    }

                    Thread.Sleep(Calculatems);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][CalQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void CalculateEstimate(EstimateCommodity E)
        {
            double LastCapitalization = 0.0;
            double Bid1Capitalization = 0.0;
            double Ask1Capitalization = 0.0;
            double lastprice = 0.0;
            double bid1price = 0.0;
            double ask1price = 0.0;
            double buyamt = 0.0;
            double sellamt = 0.0;
            string nowstr = DateTime.Now.ToString("HHmmss") + "00";
            string matchseqstr = DateTime.Now.ToString("HHmmssff");
            string best5seqstr = DateTime.Now.ToString("HHmmssff");

            m_PacketNum++;

            if (E.BasePrice == 0.0)
            {
                PCommodity gPCommodity = m_PCommodityList.Get(E.RefCommodity);

                if (gPCommodity != null) { E.BasePrice = gPCommodity.QCommodity.Base.ReferencePrice; }
            }

            CalBuySellAmt(E,ref buyamt,ref sellamt);

            if (E.CalculateKind == EstimateCalculateKind.IndexShares)
            {
                LastCapitalization = CalLastCapitalization(E,EstimateCalculateType.Last);
                Bid1Capitalization = CalLastCapitalization(E, EstimateCalculateType.Bid1);
                Ask1Capitalization = CalLastCapitalization(E, EstimateCalculateType.Ask1);

                double extranums = 0.0;

                if (E.YestodayCapitalization != 0.0) { extranums = ((E.YestodayCapitalization - E.RefCapitalization) / E.YestodayCapitalization * E.BasePrice); }

                lastprice = Math.Round(E.BasePrice * LastCapitalization / E.RefCapitalization - extranums, 3);
                bid1price = Math.Round(E.BasePrice * Bid1Capitalization / E.RefCapitalization - extranums, 3);
                ask1price = Math.Round(E.BasePrice * Ask1Capitalization / E.RefCapitalization - extranums, 3);

                if (Math.Round(E.Parent.QCommodity.Match.MatchPrice, 3) != Math.Round(lastprice, 3) || lastprice == 0.0)
                {
                    E.Parent.SetMatch(E.Parent.QCommodity.Match.InformationTime, E.Parent.QCommodity.Match.InformationSeq, E.Parent.QCommodity.Match.MatchTime, lastprice, 0, 0);
                    DoSendWrite(E.Parent.QCommodity.Match);
                }

                if (Math.Round(E.Parent.QCommodity.Best5.BuyPriceBest1, 3) != Math.Round(bid1price, 3) || Math.Round(E.Parent.QCommodity.Best5.SellPriceBest1, 3) != Math.Round(ask1price, 3) || bid1price == 0.0 || ask1price == 0.0 || E.Parent.QCommodity.Best5.BuyAmt != buyamt || E.Parent.QCommodity.Best5.SellAmt != sellamt)
                {
                    E.Parent.SetBest5(E.Parent.QCommodity.Best5.InformationTime, E.Parent.QCommodity.Best5.InformationSeq, bid1price, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, ask1price, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    E.Parent.QCommodity.Best5.BuyAmt = buyamt;
                    E.Parent.QCommodity.Best5.SellAmt = sellamt;
                    DoSendWrite(E.Parent.QCommodity.Best5);
                }
            }
            else if (E.CalculateKind == EstimateCalculateKind.IndexWeight)
            {
                lastprice = E.BasePrice * (1 + CalLastChangeByWeight(E, EstimateCalculateType.Last));
                lastprice = Math.Round(lastprice, 3);
                bid1price = E.BasePrice * (1 + CalLastChangeByWeight(E, EstimateCalculateType.Bid1));
                bid1price = Math.Round(bid1price, 3);
                ask1price = E.BasePrice * (1 + CalLastChangeByWeight(E, EstimateCalculateType.Ask1));
                ask1price = Math.Round(ask1price, 3);

                if (Math.Round(E.Parent.QCommodity.Match.MatchPrice, 3) != Math.Round(lastprice, 3) || lastprice == 0.0)
                {
                    E.Parent.SetMatch(E.Parent.QCommodity.Match.InformationTime, E.Parent.QCommodity.Match.InformationSeq, E.Parent.QCommodity.Match.MatchTime, lastprice, 0, 0);
                    DoSendWrite(E.Parent.QCommodity.Match);
                }

                if (Math.Round(E.Parent.QCommodity.Best5.BuyPriceBest1, 3) != Math.Round(bid1price, 3) || Math.Round(E.Parent.QCommodity.Best5.SellPriceBest1, 3) != Math.Round(ask1price, 3) || bid1price == 0.0 || ask1price == 0.0 || E.Parent.QCommodity.Best5.BuyAmt != buyamt || E.Parent.QCommodity.Best5.SellAmt != sellamt)
                {
                    E.Parent.SetBest5(E.Parent.QCommodity.Best5.InformationTime, E.Parent.QCommodity.Best5.InformationSeq, bid1price, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, ask1price, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    E.Parent.QCommodity.Best5.BuyAmt = buyamt;
                    E.Parent.QCommodity.Best5.SellAmt = sellamt;
                    DoSendWrite(E.Parent.QCommodity.Best5);
                }
            }
            else if (E.CalculateKind == EstimateCalculateKind.ETFShares)
            {
                LastCapitalization = CalLastCapitalization(E, EstimateCalculateType.Last) + E.CashDiff;
                Bid1Capitalization = CalLastCapitalization(E, EstimateCalculateType.Bid1) + E.CashDiff;
                Ask1Capitalization = CalLastCapitalization(E, EstimateCalculateType.Ask1) + E.CashDiff;

                lastprice = Math.Round(LastCapitalization / 500 / 1000, 3);
                bid1price = Math.Round(Bid1Capitalization / 500 / 1000, 3);
                ask1price = Math.Round(Ask1Capitalization / 500 / 1000, 3);

                if (Math.Round(E.Parent.QCommodity.Match.MatchPrice, 3) != Math.Round(lastprice, 3) || lastprice == 0.0)
                {
                    E.Parent.SetMatch(E.Parent.QCommodity.Match.InformationTime, E.Parent.QCommodity.Match.InformationSeq, E.Parent.QCommodity.Match.MatchTime, lastprice, 0, 0);
                    DoSendWrite(E.Parent.QCommodity.Match);

                    if (m_QuoteSetting.IsWriteTicks) { Util.ExecSqlCmd("insert into estimateticks(commodityid,LastPrice) values('" + E.Parent.QCommodity.Base.CommodityId  + "'," + lastprice.ToString() + ")", DBConnectString); }
                }

                if (Math.Round(E.Parent.QCommodity.Best5.BuyPriceBest1, 3) != Math.Round(bid1price, 3) || Math.Round(E.Parent.QCommodity.Best5.SellPriceBest1, 3) != Math.Round(ask1price, 3) || bid1price == 0.0 || ask1price == 0.0 || E.Parent.QCommodity.Best5.BuyAmt != buyamt || E.Parent.QCommodity.Best5.SellAmt != sellamt)
                {
                    E.Parent.SetBest5(E.Parent.QCommodity.Best5.InformationTime, E.Parent.QCommodity.Best5.InformationSeq, bid1price, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, ask1price, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    E.Parent.QCommodity.Best5.BuyAmt = buyamt;
                    E.Parent.QCommodity.Best5.SellAmt = sellamt;
                    DoSendWrite(E.Parent.QCommodity.Best5);

                    if (m_QuoteSetting.IsWriteTicks) { Util.ExecSqlCmd("insert into estimateticks(commodityid,Bid1Price,Ask1Price) values('" + E.Parent.QCommodity.Base.CommodityId + "'," + bid1price.ToString() + "," + ask1price.ToString() + ")", DBConnectString); }
                }
            }
        }
        private double CalLastCapitalization(EstimateCommodity E, EstimateCalculateType iEstimateCaculateType)
        {
            double shares = 0.0;           
            double lastprice = 0.0;
            double val = 0.0;

            int newseq = 0;
            int newtime = 0;
            int oldseq = 0;
            int oldtime = 0;

            DateTime dt = DateTime.Today;

            foreach (EstimateElement M in E.Elements)
            {
                if (iEstimateCaculateType == EstimateCalculateType.Reference)
                {
                    shares = M.Shares;

                    lastprice = M.mPCommodity.QCommodity.Base.ReferencePrice;
                }
                else if (iEstimateCaculateType == EstimateCalculateType.Yestoday)
                {
                    shares = M.YestodayShares;

                    lastprice = M.mPCommodity.QCommodity.Close.LastSettlementPrice;
                }
                else if (iEstimateCaculateType == EstimateCalculateType.Last)
                {
                    shares = M.Shares;

                    int.TryParse(M.mPCommodity.QCommodity.Match.InformationSeq, out newseq);
                    int.TryParse(M.mPCommodity.QCommodity.Match.InformationTime, out newtime);
                    int.TryParse(E.Parent.QCommodity.Match.InformationSeq, out oldseq);
                    int.TryParse(E.Parent.QCommodity.Match.InformationTime, out oldtime);

                    if (E.Parent.QCommodity.Base.TradeDate.Date == dt)
                    {
                        if (newseq > oldseq) { E.Parent.QCommodity.Match.InformationSeq = M.mPCommodity.QCommodity.Match.InformationSeq; }
                        if (newtime > oldtime) { E.Parent.QCommodity.Match.InformationTime = M.mPCommodity.QCommodity.Match.InformationTime; E.Parent.QCommodity.Match.MatchTime = M.mPCommodity.QCommodity.Match.InformationTime; }
                    }

                    lastprice = M.mPCommodity.QCommodity.Match.MatchPrice;
                }
                else if (iEstimateCaculateType == EstimateCalculateType.Bid1)
                {
                    shares = M.Shares;

                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationSeq, out newseq);
                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationTime, out newtime);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationSeq, out oldseq);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationTime, out oldtime);

                    if (E.Parent.QCommodity.Base.TradeDate.Date == dt)
                    {
                        if (newseq > oldseq) { E.Parent.QCommodity.Best5.InformationSeq = M.mPCommodity.QCommodity.Best5.InformationSeq; }
                        if (newtime > oldtime) { E.Parent.QCommodity.Best5.InformationTime = M.mPCommodity.QCommodity.Best5.InformationTime; }
                    }

                    lastprice = M.mPCommodity.QCommodity.Best5.BuyPriceBest1;
                }
                else if (iEstimateCaculateType == EstimateCalculateType.Ask1)
                {
                    shares = M.Shares;

                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationSeq, out newseq);
                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationTime, out newtime);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationSeq, out oldseq);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationTime, out oldtime);

                    if (E.Parent.QCommodity.Base.TradeDate.Date == dt)
                    {
                        if (newseq > oldseq) { E.Parent.QCommodity.Best5.InformationSeq = M.mPCommodity.QCommodity.Best5.InformationSeq; }
                        if (newtime > oldtime) { E.Parent.QCommodity.Best5.InformationTime = M.mPCommodity.QCommodity.Best5.InformationTime; }
                    }

                    lastprice = M.mPCommodity.QCommodity.Best5.SellPriceBest1;
                }

                if (lastprice == 0.0)
                {
                    if (M.mPCommodity.QCommodity.Match.MatchPrice > 0)
                        lastprice = M.mPCommodity.QCommodity.Match.MatchPrice;
                    else
                        lastprice = M.mPCommodity.QCommodity.Base.ReferencePrice;
                }

                val += lastprice * shares;
            }

            return val;
        }
        private double CalYestodayCapitalization(EstimateCommodity E)
        {
            double shares = 0.0;
            double lastprice = 0.0;
            double val = 0.0;
                        
            DateTime dt = DateTime.Today;

            try
            {
                string sql = "select a.commodityid,a.shares,isnull(b.settlementprice,0.0) settlementprice from YestodayEstimateLink a left join lclose b on a.commodityid=b.commodityid where  a.EstimateCode='" + E.Parent.CommodityId + "' and a.commodityid in (select commodityid from estimatelink where EstimateCode='" + E.Parent.CommodityId + "')";
                sql += "union select a.commodityid,a.shares,b.referenceprice settlementprice from EstimateLink a,pbase b where a.commodityid=b.commodityid and a.EstimateCode='" + E.Parent.CommodityId + "' and a.commodityid not in (select commodityid from YestodayEstimateLink where EstimateCode='" + E.Parent.CommodityId + "')";
                DataView dv = Util.ExecSqlQry(sql, DBConnectString);

                foreach (DataRowView dr in dv)
                {
                    try
                    {
                        shares = Convert.ToInt32(dr["Shares"]);

                        lastprice = Convert.ToDouble(dr["SettlementPrice"]);

                        val += lastprice * shares;
                    }
                    catch (Exception ex)
                    {
                        m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][CalYestodayCapitalization_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                    }

                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][CalYestodayCapitalization_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }

            return val;
        }
        private double CalLastChangeByWeight(EstimateCommodity E, EstimateCalculateType iEstimateCaculateType)
        {
            double weight = 0.0;
            double lastprice = 0.0;
            double val = 0.0;

            int newseq = 0;
            int newtime = 0;
            int oldseq = 0;
            int oldtime = 0;

            DateTime dt = DateTime.Today;

            foreach (EstimateElement M in E.Elements)
            {
                weight = M.Weight;

                if (iEstimateCaculateType == EstimateCalculateType.Last)
                {
                    int.TryParse(M.mPCommodity.QCommodity.Match.InformationSeq, out newseq);
                    int.TryParse(M.mPCommodity.QCommodity.Match.InformationTime, out newtime);
                    int.TryParse(E.Parent.QCommodity.Match.InformationSeq, out oldseq);
                    int.TryParse(E.Parent.QCommodity.Match.InformationTime, out oldtime);

                    if (E.Parent.QCommodity.Base.TradeDate.Date == dt)
                    {
                        if (newseq > oldseq) { E.Parent.QCommodity.Match.InformationSeq = M.mPCommodity.QCommodity.Match.InformationSeq; }
                        if (newtime > oldtime) { E.Parent.QCommodity.Match.InformationTime = M.mPCommodity.QCommodity.Match.InformationTime; E.Parent.QCommodity.Match.MatchTime = M.mPCommodity.QCommodity.Match.InformationTime; }
                    }

                    if (M.mPCommodity.QCommodity.Match.MatchPrice == 0.0)
                        lastprice = 0.0;
                    else
                        lastprice = (M.mPCommodity.QCommodity.Match.MatchPrice - M.mPCommodity.QCommodity.Base.ReferencePrice) / M.mPCommodity.QCommodity.Base.ReferencePrice;
                }
                else if (iEstimateCaculateType == EstimateCalculateType.Bid1)
                {
                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationSeq, out newseq);
                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationTime, out newtime);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationSeq, out oldseq);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationTime, out oldtime);

                    if (E.Parent.QCommodity.Base.TradeDate.Date == dt)
                    {
                        if (newseq > oldseq) { E.Parent.QCommodity.Best5.InformationSeq = M.mPCommodity.QCommodity.Best5.InformationSeq; }
                        if (newtime > oldtime) { E.Parent.QCommodity.Best5.InformationTime = M.mPCommodity.QCommodity.Best5.InformationTime; }
                    }

                    if (M.mPCommodity.QCommodity.Best5.BuyPriceBest1 == 0.0)
                    {
                        if (M.mPCommodity.QCommodity.Match.MatchPrice > 0.0)
                            lastprice = (M.mPCommodity.QCommodity.Match.MatchPrice - M.mPCommodity.QCommodity.Base.ReferencePrice) / M.mPCommodity.QCommodity.Base.ReferencePrice;
                        else
                            lastprice = 0.0;
                    }
                    else
                        lastprice = (M.mPCommodity.QCommodity.Best5.BuyPriceBest1 - M.mPCommodity.QCommodity.Base.ReferencePrice) / M.mPCommodity.QCommodity.Base.ReferencePrice;
                }
                else if (iEstimateCaculateType == EstimateCalculateType.Ask1)
                {
                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationSeq, out newseq);
                    int.TryParse(M.mPCommodity.QCommodity.Best5.InformationTime, out newtime);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationSeq, out oldseq);
                    int.TryParse(E.Parent.QCommodity.Best5.InformationTime, out oldtime);

                    if (E.Parent.QCommodity.Base.TradeDate.Date == dt)
                    {
                        if (newseq > oldseq) { E.Parent.QCommodity.Best5.InformationSeq = M.mPCommodity.QCommodity.Best5.InformationSeq; }
                        if (newtime > oldtime) { E.Parent.QCommodity.Best5.InformationTime = M.mPCommodity.QCommodity.Best5.InformationTime; }
                    }

                    if (M.mPCommodity.QCommodity.Best5.SellPriceBest1 == 0.0)
                    {
                        if (M.mPCommodity.QCommodity.Match.MatchPrice > 0.0)
                            lastprice = (M.mPCommodity.QCommodity.Match.MatchPrice - M.mPCommodity.QCommodity.Base.ReferencePrice) / M.mPCommodity.QCommodity.Base.ReferencePrice;
                        else
                            lastprice = 0.0;
                    }
                    else
                        lastprice = (M.mPCommodity.QCommodity.Best5.SellPriceBest1 - M.mPCommodity.QCommodity.Base.ReferencePrice) / M.mPCommodity.QCommodity.Base.ReferencePrice;
                }

                val += lastprice * weight;
            }

            return val;
        }
        private void CalBuySellAmt(EstimateCommodity E, ref double BuyAmt, ref double SellAmt)
        {
            foreach (EstimateElement M in E.Elements)
            {
                BuyAmt += M.mPCommodity.QCommodity.Best5.BuyPriceBest1 * M.mPCommodity.QCommodity.Best5.BuyQtyBest1;
                BuyAmt += M.mPCommodity.QCommodity.Best5.BuyPriceBest2 * M.mPCommodity.QCommodity.Best5.BuyQtyBest2;
                BuyAmt += M.mPCommodity.QCommodity.Best5.BuyPriceBest3 * M.mPCommodity.QCommodity.Best5.BuyQtyBest3;
                BuyAmt += M.mPCommodity.QCommodity.Best5.BuyPriceBest4 * M.mPCommodity.QCommodity.Best5.BuyQtyBest4;
                BuyAmt += M.mPCommodity.QCommodity.Best5.BuyPriceBest5 * M.mPCommodity.QCommodity.Best5.BuyQtyBest5;
                SellAmt += M.mPCommodity.QCommodity.Best5.SellPriceBest1 * M.mPCommodity.QCommodity.Best5.SellQtyBest1;
                SellAmt += M.mPCommodity.QCommodity.Best5.SellPriceBest2 * M.mPCommodity.QCommodity.Best5.SellQtyBest2;
                SellAmt += M.mPCommodity.QCommodity.Best5.SellPriceBest3 * M.mPCommodity.QCommodity.Best5.SellQtyBest3;
                SellAmt += M.mPCommodity.QCommodity.Best5.SellPriceBest4 * M.mPCommodity.QCommodity.Best5.SellQtyBest4;
                SellAmt += M.mPCommodity.QCommodity.Best5.SellPriceBest5 * M.mPCommodity.QCommodity.Best5.SellQtyBest5;
            }
        }
        private void LoadData()
        {
            try
            {
                foreach (EstimateCommodity E in EstimateCommodityList)
                    E.Close();

                EstimateCommodityList.Clear();
                int i = 0;

                foreach(string S in EstimateLabel.Split(','))
                {
                    i++;

                    string sql = "select * from Estimate where EstimateLabel='" + S + "'";
                    DataView dv = Util.ExecSqlQry(sql, DBConnectString);

                    foreach (DataRowView dr in dv)
                    {
                        string EstimateCode = dr["EstimateCode"].ToString();
                        string EstimateNm = dr["EstimateNm"].ToString();
                        string RefCommodity = dr["RefCommodity"].ToString();
                        double BasePrice = Convert.ToDouble(dr["BasePrice"]);
                        double CashDiff = Convert.ToDouble(dr["CashDiff"]);
                        double RiseLimitPrice = 0.0;
                        double FallLimitPrice = 0.0;
                        
                        EstimateCalculateKind sCalculateKind = (EstimateCalculateKind)Convert.ToInt32(dr["CalculateKind"].ToString());
                        Market sMarket = (Market)Enum.Parse(typeof(Market),dr["Market"].ToString());
                        CommodityKind sCommodityKind = (CommodityKind)Enum.Parse(typeof(CommodityKind),dr["CommodityKind"].ToString());

                        PCommodity mPCommodity = m_PCommodityList.Set("", EstimateCode, sMarket, sCommodityKind);

                        EstimateCommodity E = new EstimateCommodity();
                        E.EstimateLabel = S;
                        E.Parent = mPCommodity;
                        E.BasePrice = BasePrice;
                        E.CashDiff = CashDiff;
                        E.CalculateKind = sCalculateKind;
                        E.RefCommodity = RefCommodity;
                        
                        PCommodity kPCommodity = m_PCommodityList.Get(E.RefCommodity);

                        if (kPCommodity != null) 
                        {
                            if (E.BasePrice == 0.0){ E.BasePrice = kPCommodity.QCommodity.Base.ReferencePrice; }

                            RiseLimitPrice = kPCommodity.QCommodity.Base.RiseLimitPrice;
                            FallLimitPrice = kPCommodity.QCommodity.Base.FallLimitPrice;
                        }                        

                        EstimateCommodityList.Add(E);

                        sql = "select CommodityId,isnull(weight,0.0) weight,isnull(shares,0) shares,isnull(insteadflag,'N') insteadflag from EstimateLink where EstimateCode='" + EstimateCode + "'";
                        DataView dv1 = Util.ExecSqlQry(sql, DBConnectString);

                        foreach (DataRowView dr1 in dv1)
                        {
                            PCommodity gPCommodity = m_PCommodityList.Set(dr1["CommodityId"].ToString().Trim());
                            
                            bool InsteadFlag = dr1["InsteadFlag"].ToString() == "N" ? false : true;

                            E.Add(new EstimateElement(gPCommodity, Convert.ToDouble(dr1["Weight"]), Convert.ToInt32(dr1["Shares"]), InsteadFlag));
                        }

                        if (E.CalculateKind == EstimateCalculateKind.IndexShares)
                        {
                            E.RefCapitalization = CalLastCapitalization(E, EstimateCalculateType.Reference);
                            E.YestodayCapitalization = CalYestodayCapitalization(E);
                        }

                        mPCommodity.SetBase(sMarket, sCommodityKind, CommodityType.None, "", EstimateNm, DateTime.Today, "", i.ToString("00000000"), E.BasePrice,RiseLimitPrice, FallLimitPrice, 1, "","");
                        mPCommodity.IsLocalCommodity = true;
                        DoSendWrite(mPCommodity.QCommodity.Base);
                    }
                }

                foreach (EstimateCommodity E in EstimateCommodityList)
                {
                    E.Parent.QCommodity.Match.InformationSeq = "";
                    E.Parent.QCommodity.Match.InformationTime = "";
                    E.Parent.QCommodity.Match.MatchTime = "";
                    E.Parent.QCommodity.Best5.InformationSeq = "";
                    E.Parent.QCommodity.Best5.InformationTime = "";

                    CalculateEstimate(E);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }

    }
    public class TFETSEQuoteSource : QuoteSource
    {
        private Thread RoutineThread;
        private Thread ReceiveThread;
        private Thread DoThread;
        private Thread DoUDPThread;
        private Socket rvUdp = null;
        private List<string> CMonth = new List<string>(new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" });
        private List<string> PMonth = new List<string>(new string[] { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" });
        private Hashtable TFECurrencyMap = Hashtable.Synchronized(new Hashtable());
        private Hashtable TSECurrencyMap = Hashtable.Synchronized(new Hashtable());
        private Hashtable SettleDateHt = Hashtable.Synchronized(new Hashtable());
        private Hashtable TGSettleDateHt = Hashtable.Synchronized(new Hashtable());
        private Hashtable FlowGroupMap = Hashtable.Synchronized(new Hashtable());
        private QueryList QueryList = new QueryList();
        private object udpLockObj = new object();
        private List<byte> rBuffer = new List<byte>();

        public TFETSEQuoteSource(QuoteFactorySetting QuoteSetting)
            : base(QuoteSetting)
        {
            IniTime = new TimeSpan(2,0,0);
        }        
        public override bool Start()
        {
            InitialCurrencyMap();
            InitialFlowGroupMap();

            if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_File)
            {
                ReceiveThread = new Thread(new ThreadStart(ReadFile));
                ReceiveThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse2_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc2_Udp)
            {
                ReceiveThread = new Thread(new ThreadStart(ReadUdp));
                ReceiveThread.Start();

                DoUDPThread = new Thread(new ThreadStart(DoUDPWork));
                DoUDPThread.Start();                
            }

            if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_Udp)
            {
                QueryList.LoadData(m_QuoteSetting.DBConnectString, "F");

                RoutineThread = new Thread(new ThreadStart(RoutineWork));
                RoutineThread.Start();

                DoThread = new Thread(new ThreadStart(DealWithFx));
                DoThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_Udp)
            {
                QueryList.LoadData(m_QuoteSetting.DBConnectString, "O");

                RoutineThread = new Thread(new ThreadStart(RoutineWork));
                RoutineThread.Start();

                DoThread = new Thread(new ThreadStart(DealWithOp));
                DoThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse2_Udp)
            {
                DoThread = new Thread(new ThreadStart(DealWithTse));
                DoThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc2_Udp)
            {
                DoThread = new Thread(new ThreadStart(DealWithOtc));
                DoThread.Start();
            }

            return base.Start();
        }
        public override bool Close()
        {            
            try
            {
                
                base.Close();
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                if (DoThread != null && DoThread.IsAlive) { DoThread.Abort(); }
                if (ReceiveThread != null && ReceiveThread.IsAlive) { ReceiveThread.Abort(); }
                if (DoUDPThread != null && DoUDPThread.IsAlive) { DoUDPThread.Abort(); }
                if (rvUdp != null) { rvUdp.Close(); }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private void ReadFile()
        {            
            int oldInByte = 0;
            int InByte = 0;
            int i = 0;
            int j = 0;

            ArrayList sbuffer = new ArrayList();
            FileStream fsInto = null;

            try
            {
                //string sFileName = Application.StartupPath + "\\20041029FxLog.txt";
                string sFileName = m_QuoteSetting.LogFileFolder + "\\" + DateTime.Today.ToString("yyyyMMdd") + "_" + m_QuoteSetting.DataSource + "_" + "Log.txt";
                fsInto = new FileStream(sFileName, FileMode.Open);

                TradeTimeMapping TradeTimeMapping = new TradeTimeMapping(m_QuoteSetting.QuoteSourceKind, m_QuoteSetting.Speed, m_QuoteSetting.FileStartTime.Replace(":",""));

                while ((InByte = fsInto.ReadByte()) != -1)
                {
                    sbuffer.Add((byte)InByte);
                    i++;
                    if (oldInByte == 13 && InByte == 10)
                    {
                        byte[] ddbyte = new byte[i];
                        sbuffer.CopyTo(ddbyte);

                        TradeTimeMapping.DoTime(ddbyte);

                        if (m_QuoteSetting.IsWriteToLog)
                            m_WriteFilePool.Enqueue(ddbyte);

                        m_PackagePool.Enqueue(ddbyte);

                        sbuffer.Clear();
                        i = 0;
                        j++;

                        if (m_QuoteSetting.DataSendms != 0 && j % m_QuoteSetting.DataSendms == 0)
                        {
                            j = 0;
                            Thread.Sleep(1);
                        }
                    }
                    oldInByte = InByte;
                }

                fsInto.Close();
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                if (fsInto != null)
                    fsInto.Close();
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ReadFile_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
            
        }
        private void ReadUdp()
        {
            try
            {
                rvUdp = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                EndPoint localEP = (EndPoint)new IPEndPoint(IPAddress.Parse(m_QuoteSetting.LocalIp), m_QuoteSetting.LocalPort);
                rvUdp.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, 1);
                //rvUdp.ExclusiveAddressUse = false;
                rvUdp.Bind(localEP);
                rvUdp.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(IPAddress.Parse(m_QuoteSetting.MultiCastIp), IPAddress.Parse(m_QuoteSetting.LocalIp)));

                byte[] bte;
                byte[] sUdpByte;
                int pos = -1;
                int epos = 0;
                
                EndPoint remoteEP = (EndPoint)new IPEndPoint(IPAddress.Any, 0);
                byte[] byteData = new byte[8192];
                int bytelength = 0;

                while (true)
                {
                    bytelength = rvUdp.ReceiveFrom(byteData, byteData.Length, SocketFlags.None, ref remoteEP);                    
                    sUdpByte = new byte[bytelength];
                    Array.Copy(byteData, sUdpByte, bytelength);

                    /*lock (udpLockObj)
                    {
                        rBuffer.AddRange(sUdpByte);
                    }*/
                    rBuffer.AddRange(sUdpByte);
                  
                    for (; ; )
                    {
                        pos = rBuffer.IndexOf((byte)13, pos + 1);

                        if (pos == -1 || pos == rBuffer.Count - 1)
                            break;

                        if ((byte)rBuffer[pos + 1] != 10)
                            continue;

                        bte = new byte[pos + 2];
                        epos = rBuffer.IndexOf((byte)27);

                        if (epos > -1 && epos < pos + 2)
                            rBuffer.CopyTo(epos, bte, 0, pos + 2 - epos);
                        rBuffer.RemoveRange(0, pos + 2);
                        pos = -1;

                        if (m_QuoteSetting.IsWriteToLog)
                            m_WriteFilePool.Enqueue(bte);

                        m_PackagePool.Enqueue(bte);
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ReadUdp_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoUDPWork()
        {
            try
            {
                /*byte[] bte;
                byte[] sUdpByte;
                int pos = -1;
                int epos = 0;

                for (; ; )
                {
                    if (rBuffer.Count == 0) { Thread.Sleep(1); }

                    pos = rBuffer.IndexOf((byte)13, pos + 1);

                    if (pos == -1 || pos == rBuffer.Count - 1)
                    {
                        Thread.Sleep(1);
                        continue;
                    }

                    if ((byte)rBuffer[pos + 1] != 10)
                    {
                        Thread.Sleep(1);
                        continue;
                    }

                    bte = new byte[pos + 2];
                    epos = rBuffer.IndexOf((byte)27);

                    if (epos > -1 && epos < pos + 2)
                        rBuffer.CopyTo(epos, bte, 0, pos + 2 - epos);
                    
                    lock (udpLockObj)
                    {
                        rBuffer.RemoveRange(0, pos + 2);
                    }

                    pos = -1;

                    if (m_QuoteSetting.IsWriteToLog)
                        m_WriteFilePool.Enqueue(bte);

                    m_PackagePool.Enqueue(bte);
                }*/
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DoUDPWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void RoutineWork()
        {
            try
            {
                bool ClearQuery = false;

                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 8 && DateTime.Now.TimeOfDay.TotalHours < 8.1 && !ClearQuery)
                    {
                        QueryList.Clear();
                        ClearQuery = true;
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void InitialCurrencyMap()
        {
            TFECurrencyMap.Add("1","NTD");
            TFECurrencyMap.Add("2", "TWD.FX");
            TFECurrencyMap.Add("3", "EURTW.FX");
            TFECurrencyMap.Add("4", "JPYTW.FX");
            TFECurrencyMap.Add("5", "GBPTW.FX");
            TFECurrencyMap.Add("6", "AUDTW.FX");
            TFECurrencyMap.Add("7", "HKDTW.FX");
            TFECurrencyMap.Add("8", "CNYTW.FX");

            TSECurrencyMap.Add("", "NTD");
            TSECurrencyMap.Add("CNY", "CNYTW.FX");
            TSECurrencyMap.Add("JPY", "JPYTW.FX");
            TSECurrencyMap.Add("KRW", "KRWTW.FX");
            TSECurrencyMap.Add("USD", "TWD.FX");
            TSECurrencyMap.Add("CAD", "CADTW.FX");
            TSECurrencyMap.Add("GBP", "GBPTW.FX");
            TSECurrencyMap.Add("EUR", "EURTW.FX");
            TSECurrencyMap.Add("SEK", "SEKTW.FX");
            TSECurrencyMap.Add("AUD", "AUDTW.FX");
            TSECurrencyMap.Add("HKD", "HKDTW.FX");
            TSECurrencyMap.Add("SGD", "SGDTW.FX");
        }
        private void InitialFlowGroupMap()
        {
            FlowGroupMap.Add("1", "1345");
            FlowGroupMap.Add("2", "1200");
            FlowGroupMap.Add("3", "1330");
            FlowGroupMap.Add("4", "1100");
            FlowGroupMap.Add("5", "1615");            
        }
        private string GetTFEMonth(string CommodityId)
        {
            try
            {
                string year = "201" + CommodityId.Substring(CommodityId.Length-1, 1);
                int month = CMonth.IndexOf(CommodityId.Substring(CommodityId.Length-2, 1)) + 1;
                if (month == 0) { month = PMonth.IndexOf(CommodityId.Substring(CommodityId.Length - 2, 1)) + 1; }
                if (month != 0) { return year + month.ToString("00"); } else { return ""; }
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        private CommodityType GetCommodityType(string CommodityId)
        {
            try
            {
                int month = CMonth.IndexOf(CommodityId.Substring(CommodityId.Length - 2, 1));
                if (month == -1) { month = PMonth.IndexOf(CommodityId.Substring(CommodityId.Length - 2, 1)); } else { return CommodityType.Call; }
                if (month == -1) { return CommodityType.None; } else { return CommodityType.Put; }

            }
            catch (Exception ex)
            {
                return CommodityType.None;
            }
        }
        #region 報價處理
        private void DealWithFx()
        {
            int othercol = 17;
            string InformationTime;
            string InformationSeq;
            string VersionNo;

            int sBodyLength = 0;
            int Packetlength = 0;

            string sCommodityId;
            double sRiseLimitPrice = 0.0;
            double sReferencePrice = 0.0;
            double sFallLimitPrice = 0.0;
            double sRiseLimitPrice2 = 0.0;
            double sFallLimitPrice2 = 0.0;
            double sRiseLimitPrice3 = 0.0;
            double sFallLimitPrice3 = 0.0;

            string Prod_Kind;
            double Decimal_Locate = 0.0;
            double Strike_Decimal_Locate = 0.0;

            string MatchTime;
            double MatchPrice = 0.0;
            int MatchQuantity = 0;
            int MatchTOTALQty = 0;
            int MatchBuyCNT = 0;
            int MatchSellCNT = 0;

            double FirstMatchPrice = 0.0;
            int FirstMatchQuantity = 0;

            double OpenPrice = 0.0;

            double DayHighPrice = 0.0;
            double DayLowPrice = 0.0;
            string ShowTime;

            int BuyOrder = 0;
            int BuyQuantity = 0;
            int SellOrder = 0;
            int SellQuantity = 0;

            int BultinKey = 0;
            string BultinData;

            string IndexKind;
            int IndexTime = 0;
            double IndexValue = 0.0;

            double BuyPriceBest1 = 0.0;
            int BuyQtyBest1 = 0;
            double BuyPriceBest2 = 0.0;
            int BuyQtyBest2 = 0;
            double BuyPriceBest3 = 0.0;
            int BuyQtyBest3 = 0;
            double BuyPriceBest4 = 0.0;
            int BuyQtyBest4 = 0;
            double BuyPriceBest5 = 0.0;
            int BuyQtyBest5 = 0;
            double SellPriceBest1 = 0.0;
            int SellQtyBest1 = 0;
            double SellPriceBest2 = 0.0;
            int SellQtyBest2 = 0;
            double SellPriceBest3 = 0.0;
            int SellQtyBest3 = 0;
            double SellPriceBest4 = 0.0;
            int SellQtyBest4 = 0;
            double SellPriceBest5 = 0.0;
            int SellQtyBest5 = 0;

            double BuyPriceDerived = 0.0;
            int BuyQtyDerived = 0;
            double SellPriceDerived = 0.0;
            int SellQtyDerived = 0;

            double TermHighPrice = 0.0;
            double TermLowPrice = 0.0;
            double DayHighPriceT = 0.0;
            double DayLowPriceT = 0.0;

            double BuyPrice = 0.0;
            double SellPrice = 0.0;
            double ClosePrice = 0.0;
            int BuyOrderTal = 0;
            int BuyQuantityTal = 0;
            int SellOrderTal = 0;
            int SellQuantityTal = 0;
            int TotalMatch = 0;
            int TotalQty = 0;
            int ComBuyOrderTal = 0;
            int ComBuyQuantityTal = 0;
            int ComSellOrderTal = 0;
            int ComSellQuantityTal = 0;
            int ComTotalQty = 0;
            double SettlementPrice = 0.0;
            int OpenInterest = 0;

            string DisclosureTime;
            int DurationTime = 0;

            int Match_seq;
            int Fx_Match_seq = 0;
            int Fx_PacketLost_Qty = 0;

            int i = 0;
                        
            byte[] sCheckSum;
            byte[] bte;

            PCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            if (!CMarket.IsTrade)
                                continue;

                            InformationTime = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00") + int.Parse(bte[6].ToString("x")).ToString("00");
                            InformationSeq = int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00") + int.Parse(bte[10].ToString("x")).ToString("00");
                            VersionNo = int.Parse(bte[11].ToString("x")).ToString("00");
                            sBodyLength = int.Parse(int.Parse(bte[12].ToString("x")).ToString("00") + int.Parse(bte[13].ToString("x")).ToString("00"));
                            Packetlength = sBodyLength + othercol;
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 1, 1));
                            int mKind = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 2, 1));

                            if (!m_QuoteSetting.IsRegisterAll)
                            {
                                string gCommodityId = "";

                                if (tCode == 1)
                                {
                                    if (mKind == 1 || mKind == 2)
                                        gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                }
                                else if (tCode == 2)
                                {
                                    if (mKind == 1 || mKind == 2 || mKind == 5 || mKind == 6 || mKind == 7 || mKind == 8)
                                        gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                    else if (mKind == 4)
                                        gCommodityId = "query";
                                }
                                else if (tCode == 3)
                                {
                                    if (mKind == 1 || mKind == 2 || mKind == 3 || mKind == 4)
                                        gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                }

                                mPCommodity = m_PCommodityList.Get(gCommodityId);

                                if (mPCommodity == null)
                                    continue;
                            }

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                #region //TRANSMISSION_CODE_0
                                case 0:
                                    switch (mKind) //MESSAGE_KIND
                                    {                                     
                                        case 0:
                                            #region //I000 HeartBeat
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI000 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion                                     
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][mKind=" + mKind + "] " + "Fx0 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_1
                                case 1:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I010 單一商品漲停幅揭示
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {                                                    
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI010 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                Prod_Kind = System.Text.UnicodeEncoding.Default.GetString(bte, 59, 1).Trim();
                                                Decimal_Locate = double.Parse(bte[60].ToString("x"));

                                                if (Decimal_Locate == 0)
                                                    Decimal_Locate = 1.0;
                                                else
                                                    Decimal_Locate = 1 / Math.Pow(10, Decimal_Locate);

                                                Strike_Decimal_Locate = double.Parse(bte[61].ToString("x"));

                                                if (Strike_Decimal_Locate == 0)
                                                    Strike_Decimal_Locate = 1.0;
                                                else
                                                    Strike_Decimal_Locate = 1 / Math.Pow(10, Strike_Decimal_Locate);

                                                sRiseLimitPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sRiseLimitPrice2 = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice2 = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sRiseLimitPrice3 = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice3 = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * Decimal_Locate;

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                CodeMap cm = m_CMarket.GetCodeMap(CommodityKind.Future, sCommodityId.Substring(0, 2));

                                                string settlemonth = GetTFEMonth(sCommodityId);

                                                string tradedate = int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00") + "/" + int.Parse(bte[64].ToString("x")).ToString("00") + "/" + int.Parse(bte[65].ToString("x")).ToString("00");
                                                string settledate = int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + "/" + int.Parse(bte[68].ToString("x")).ToString("00") + "/" + int.Parse(bte[69].ToString("x")).ToString("00");
                                                string flowgroup = "";
                                                //2015/6/25預計上線新格式
                                                //flowgroup = int.Parse(bte[70].ToString("x")).ToString();

                                                if (FlowGroupMap.ContainsKey(flowgroup)) { flowgroup = FlowGroupMap[flowgroup].ToString(); }

                                                //modify by chiao 2012/9/18
                                                /*if (sCommodityId.Substring(0, 2) == "TG") { settledate = GetTGMaturity(settlemonth); }
                                                else { settledate = GetMaturity(settlemonth); }

                                                Util.ExecSqlCmd("EXEC spCommodityExtra '" + sCommodityId + "','TFE','Future','" + settledate + "',0.0", m_QuoteSetting.DBConnectString);
                                                */
                                                Util.ExecSqlCmd("EXEC spCommodityExtra2 '" + sCommodityId + "','TFE','Future','" + tradedate + "','" + settledate + "',0.0,'" + flowgroup + "'", m_QuoteSetting.DBConnectString);

                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                mPCommodity.IsLocalCommodity = true;
                                                /*string syscode = "";
                                                if (cm != null) { syscode = cm.SYSCode; }

                                                if (syscode != "" && m_CMarket.Market == Market.TFE)
                                                {
                                                    string month = m_PCommodityList.GetSYSMonth(sCommodityId.Substring(sCommodityId.Length - 2, 1));
                                                    if (month != "")
                                                        syscode += month + sCommodityId.Substring(sCommodityId.Length - 1, 1);
                                                }*/

                                                //if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone) || mPCommodity.QCommodity.Base.InformationSeq == null || mPCommodity.QCommodity.Base.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Base.InformationSeq) < int.Parse(InformationSeq)))
                                                //{   
                                                    mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Future, CommodityType.None,cm.Code, cm.CodeNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), InformationTime, InformationSeq, GetTFEMonth(mPCommodity.CommodityId), 0, sReferencePrice, sRiseLimitPrice, sFallLimitPrice, sRiseLimitPrice2, sFallLimitPrice2, sRiseLimitPrice3, sFallLimitPrice3, 1, Prod_Kind,Decimal_Locate,Strike_Decimal_Locate,"","");
                                                    DoSendWrite(mPCommodity.QCommodity.Base);
                                                    /*mPCommodity.Send(Base);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }                                                    */
                                                //}
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI010 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2: 
                                            #region //I030 商品委託量累計訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI030 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 3:
                                            #region //I011 契約基本資料
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI011 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                string KindId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 4).Trim();
                                                string CHName = System.Text.UnicodeEncoding.Default.GetString(bte, 18, 30).Trim();
                                                string STOCKID = System.Text.UnicodeEncoding.Default.GetString(bte, 48, 6).Trim();
                                                string SUBType = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim();
                                                //2015/6/25預計上線新格式
                                                double ContractSIZE = double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00")) * 0.0001;
                                                string StatusCode = System.Text.UnicodeEncoding.Default.GetString(bte, 61, 1).Trim();
                                                string CurrencyCode = System.Text.UnicodeEncoding.Default.GetString(bte, 62, 1).Trim();
                                                string CurrencyId = "";                                                
                                                string AcceptQuoteFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 65, 1).Trim();
                                                string BeginDate = System.Text.UnicodeEncoding.Default.GetString(bte, 66, 4).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 70, 2).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 72, 2).Trim();                                                
                                                string BlockTradeFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim();
                                                string ExpiryType = System.Text.UnicodeEncoding.Default.GetString(bte, 75, 1).Trim();
                                                string UnderlyingType = "";
                                                string MarketCloseGroup = "";

                                                UnderlyingType = System.Text.UnicodeEncoding.Default.GetString(bte, 76, 1).Trim();
                                                MarketCloseGroup = int.Parse(bte[77].ToString("x")).ToString();
                                                //2015/6/25舊格式
                                                /*double ContractSIZE = double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00")) * 0.0001;
                                                string StatusCode = System.Text.UnicodeEncoding.Default.GetString(bte, 60, 1).Trim();
                                                string CurrencyCode = System.Text.UnicodeEncoding.Default.GetString(bte, 61, 1).Trim();
                                                string CurrencyId = "";                                                
                                                string AcceptQuoteFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim();
                                                string BeginDate = System.Text.UnicodeEncoding.Default.GetString(bte, 65, 4).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 69, 2).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 71, 2).Trim();
                                                string BlockTradeFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 73, 1).Trim();
                                                string ExpiryType = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim();
                                                string UnderlyingType = "";
                                                string MarketCloseGroup = "";*/


                                                if (FlowGroupMap.ContainsKey(MarketCloseGroup)) { MarketCloseGroup = FlowGroupMap[MarketCloseGroup].ToString(); }

                                                //if (KindId.IndexOf("RT") > -1 || KindId.IndexOf("RH") > -1)
                                                //    KindId = KindId;

                                                if (TFECurrencyMap.ContainsKey(CurrencyCode)) { CurrencyId = TFECurrencyMap[CurrencyCode].ToString(); }

                                                if (BeginDate == "//") { BeginDate = "2000/1/1"; }
                                                //Util.ExecSqlCmd("EXEC spCommodityContract 'TFE','Future','" + SUBType + "','" + KindId + "','" + CHName + "','" + STOCKID + "'," + ContractSIZE.ToString("0.0000"), m_QuoteSetting.DBConnectString);
                                                Util.ExecSqlCmd("EXEC spCommodityContract2 'TFE','Future','" + SUBType + "','" + KindId + "','" + CHName + "','" + STOCKID + "'," + ContractSIZE.ToString("0.0000") + ",'" + CurrencyId + "','" + StatusCode + "','" + AcceptQuoteFlag + "','" + BeginDate + "','" + BlockTradeFlag + "','" + ExpiryType + "','" + UnderlyingType + "','" + MarketCloseGroup + "'", m_QuoteSetting.DBConnectString);
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI011 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 4: 
                                            #region //I050 公告訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI050 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 5:
                                            #region //I060 現貨標的指數資訊揭示
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI060 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 6:
                                            #region //I120 股票期貨與現貨標的對照表
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI120 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 7:
                                            #region //I130 契約調整檔
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI130 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                /*string adjbasedate = int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00");
                                                string adjbfid = sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 18, 4).Trim();
                                                string adjbfstockid = sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 22, 6).Trim();
                                                double adjbfqty = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                double adjbfcash2 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                double adjbfcash3 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                string adjbfstockid4 = sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 22, 6).Trim();
                                                double adjbfqty4 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                string adjafid = sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 18, 4).Trim();
                                                string adjafstockid = sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 22, 6).Trim();
                                                double adjafqty = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                double adjafcash2 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                double adjafprice3 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                double adjafqty3 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                string adjafdate3 = int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00");
                                                string adjafstockid4 = sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 22, 6).Trim();
                                                double adjafqty4 = double.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00")) / 10000.0;
                                                string adjafdividenddate = int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00");*/

                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI130 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 8:
                                            #region //I064 現貨標的詴撮與狀態資訊
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI064 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI064 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][mKind=" + mKind + "] " + "Fx1 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_2
                                case 2:                                    
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1: 
                                            #region //I020 成交價量揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI020 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");

                                                #region check seq start
                                                if (m_QuoteSetting.IsCheckLost && m_QuoteSetting.IsRegisterAll)
                                                {
                                                    Match_seq = Convert.ToInt32(InformationSeq);

                                                    if (Match_seq != 0 && Match_seq != 1)
                                                    {
                                                        if (Match_seq - Fx_Match_seq != 1 && Match_seq > Fx_Match_seq)
                                                        {
                                                            Fx_PacketLost_Qty += Match_seq - Fx_Match_seq - 1;
                                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][Lost Fx_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Fx_PacketLost_Qty + " Last:" + Fx_Match_seq + " Current:" + Match_seq);
                                                        }
                                                    }
                                                    else
                                                        Fx_PacketLost_Qty = 0;

                                                    if (Match_seq > Fx_Match_seq)
                                                        Fx_Match_seq = Match_seq;
                                                }
                                                #endregion check seq end

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();                                                
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                //if (sCommodityId.IndexOf("RT") > -1 || sCommodityId.IndexOf("RH") > -1)
                                                //    sCommodityId = sCommodityId;

                                                if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(InformationSeq)))
                                                {                                                    
                                                    MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    MatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));
                                                    MatchTOTALQty = int.Parse(int.Parse(bte[Packetlength - 16].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 15].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 14].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 13].ToString("x")).ToString("00"));
                                                    MatchBuyCNT = int.Parse(int.Parse(bte[Packetlength - 12].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 11].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 10].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 9].ToString("x")).ToString("00"));
                                                    MatchSellCNT = int.Parse(int.Parse(bte[Packetlength - 8].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 7].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 6].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 5].ToString("x")).ToString("00"));
                                                    
                                                    MatchPrice = MatchPrice * mPCommodity.QCommodity.Base.DecimalLocate;                                                    
                                                    if ((int)(bte[48] & 127) > 0) { MatchTOTALQty += MatchQuantity; }

                                                    mPCommodity.SetMatch(InformationTime, InformationSeq, 1, MatchTime, MatchPrice, MatchQuantity, 0, 0, MatchTOTALQty, 0, MatchBuyCNT, MatchSellCNT);
                                                    /*if (m_QuoteSetting.IsCalculateGreeks)
                                                        m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                    /*mPCommodity.Send(Match);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                                    for (i = 0; i < (int)(bte[48] & 127); i++)
                                                    {
                                                        MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 49 + 8 * i, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[50 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[51 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[52 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[53 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[54 + 8 * i].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                        MatchQuantity = int.Parse(int.Parse(bte[55 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[56 + 8 * i].ToString("x")).ToString("00"));
                                                        MatchTOTALQty += MatchQuantity;

                                                        mPCommodity.SetMatch(InformationTime, InformationSeq, i + 2, MatchTime, MatchPrice, MatchQuantity, 0, 0, MatchTOTALQty, 0, MatchBuyCNT, MatchSellCNT);
                                                        /*if (m_QuoteSetting.IsCalculateGreeks)
                                                            m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                        DoSendWrite(mPCommodity.QCommodity.Match);
                                                        /*mPCommodity.Send(Match);
                                                        if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Match); }*/
                                                    }
                                                }      
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI020 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2: 
                                            #region //I080 委託簿揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI080 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();                                                
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(InformationSeq)))
                                                {

                                                    BuyPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00"));
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    BuyPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 44, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00"));
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00"));
                                                    BuyPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00"));
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00"));
                                                    BuyPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00"));
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00"));
                                                    BuyPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[75].ToString("x")).ToString("00") + int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));

                                                    SellPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 84, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                                    SellPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 94, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                    SellPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 104, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00") + int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00"));
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00") + int.Parse(bte[113].ToString("x")).ToString("00"));
                                                    SellPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 114, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00") + int.Parse(bte[117].ToString("x")).ToString("00") + int.Parse(bte[118].ToString("x")).ToString("00") + int.Parse(bte[119].ToString("x")).ToString("00"));
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[120].ToString("x")).ToString("00") + int.Parse(bte[121].ToString("x")).ToString("00") + int.Parse(bte[122].ToString("x")).ToString("00") + int.Parse(bte[123].ToString("x")).ToString("00"));
                                                    SellPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 124, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[125].ToString("x")).ToString("00") + int.Parse(bte[126].ToString("x")).ToString("00") + int.Parse(bte[127].ToString("x")).ToString("00") + int.Parse(bte[128].ToString("x")).ToString("00") + int.Parse(bte[129].ToString("x")).ToString("00"));
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[130].ToString("x")).ToString("00") + int.Parse(bte[131].ToString("x")).ToString("00") + int.Parse(bte[132].ToString("x")).ToString("00") + int.Parse(bte[133].ToString("x")).ToString("00"));

                                                    BuyPriceDerived = 0.0;
                                                    BuyQtyDerived = 0;
                                                    SellPriceDerived = 0.0;
                                                    SellQtyDerived = 0;

                                                    if (int.Parse(bte[134].ToString("x")).ToString("00") == "01")
                                                    {
                                                        BuyPriceDerived = double.Parse(int.Parse(bte[135].ToString("x")).ToString("00") + int.Parse(bte[136].ToString("x")).ToString("00") + int.Parse(bte[137].ToString("x")).ToString("00") + int.Parse(bte[138].ToString("x")).ToString("00") + int.Parse(bte[139].ToString("x")).ToString("00"));
                                                        BuyQtyDerived = int.Parse(int.Parse(bte[140].ToString("x")).ToString("00") + int.Parse(bte[141].ToString("x")).ToString("00") + int.Parse(bte[142].ToString("x")).ToString("00") + int.Parse(bte[143].ToString("x")).ToString("00"));
                                                        SellPriceDerived = double.Parse(int.Parse(bte[144].ToString("x")).ToString("00") + int.Parse(bte[145].ToString("x")).ToString("00") + int.Parse(bte[146].ToString("x")).ToString("00") + int.Parse(bte[147].ToString("x")).ToString("00") + int.Parse(bte[148].ToString("x")).ToString("00"));
                                                        SellQtyDerived = int.Parse(int.Parse(bte[149].ToString("x")).ToString("00") + int.Parse(bte[150].ToString("x")).ToString("00") + int.Parse(bte[151].ToString("x")).ToString("00") + int.Parse(bte[152].ToString("x")).ToString("00"));

                                                        if (BuyQtyDerived > 0)
                                                        {
                                                            if (BuyPriceDerived > BuyPriceBest1 || BuyPriceBest1 == 0.0)
                                                            {
                                                                BuyPriceBest5 = BuyPriceBest4;
                                                                BuyQtyBest5 = BuyQtyBest4;
                                                                BuyPriceBest4 = BuyPriceBest3;
                                                                BuyQtyBest4 = BuyQtyBest3;
                                                                BuyPriceBest3 = BuyPriceBest2;
                                                                BuyQtyBest3 = BuyQtyBest2;
                                                                BuyPriceBest2 = BuyPriceBest1;
                                                                BuyQtyBest2 = BuyQtyBest1;
                                                                BuyPriceBest1 = BuyPriceDerived;
                                                                BuyQtyBest1 = BuyQtyDerived;
                                                            }
                                                            else if (BuyPriceDerived == BuyPriceBest1)
                                                            {
                                                                BuyQtyBest1 += BuyQtyDerived;
                                                            }
                                                        }

                                                        if (SellQtyDerived > 0)
                                                        {
                                                            if (SellPriceDerived < SellPriceBest1 || SellPriceBest1 == 0.0)
                                                            {
                                                                SellPriceBest5 = SellPriceBest4;
                                                                SellQtyBest5 = SellQtyBest4;
                                                                SellPriceBest4 = SellPriceBest3;
                                                                SellQtyBest4 = SellQtyBest3;
                                                                SellPriceBest3 = SellPriceBest2;
                                                                SellQtyBest3 = SellQtyBest2;
                                                                SellPriceBest2 = SellPriceBest1;
                                                                SellQtyBest2 = SellQtyBest1;
                                                                SellPriceBest1 = SellPriceDerived;
                                                                SellQtyBest1 = SellQtyDerived;
                                                            }
                                                            else if (SellPriceDerived == SellPriceBest1)
                                                            {
                                                                SellQtyBest1 += SellQtyDerived;
                                                            }
                                                        }
                                                    }
                                                
                                                    BuyPriceBest1 = BuyPriceBest1 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest2 = BuyPriceBest2 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest3 = BuyPriceBest3 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest4 = BuyPriceBest4 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest5 = BuyPriceBest5 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest1 = SellPriceBest1 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest2 = SellPriceBest2 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest3 = SellPriceBest3 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest4 = SellPriceBest4 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest5 = SellPriceBest5 * mPCommodity.QCommodity.Base.DecimalLocate;

                                                    BuyPriceDerived = BuyPriceDerived * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceDerived = SellPriceDerived * mPCommodity.QCommodity.Base.DecimalLocate;

                                                    mPCommodity.SetBest5(InformationTime, InformationSeq, BuyPriceBest1, BuyQtyBest1, BuyPriceBest2, BuyQtyBest2, BuyPriceBest3, BuyQtyBest3, BuyPriceBest4, BuyQtyBest4, BuyPriceBest5, BuyQtyBest5, SellPriceBest1, SellQtyBest1, SellPriceBest2, SellQtyBest2, SellPriceBest3, SellQtyBest3, SellPriceBest4, SellQtyBest4, SellPriceBest5, SellQtyBest5, BuyPriceDerived, BuyQtyDerived, SellPriceDerived, SellQtyDerived);
                                                    /*if (m_QuoteSetting.IsCalculateGreeks)
                                                        m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Best5);*/
                                                    DoSendWrite(mPCommodity.QCommodity.Best5);
                                                    /*mPCommodity.Send(Best5);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Best5); }*/
                                                }                                                 
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI080 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 3: 
                                            #region //I140 系統訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI140 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 4: 
                                            #region //I100 詢價揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI100 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                DisclosureTime = int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00");
                                                DurationTime = int.Parse(int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00"));

                                                QueryCls QQ = QueryList.Add("F", sCommodityId, InformationTime, InformationSeq, DisclosureTime, DurationTime);

                                                if (QQ != null) { DoSendWriteQuery(QQ); }         
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI100 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 5: 
                                            #region //I021 盤中最高低價揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI021 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.HighLow == null || mPCommodity.QCommodity.HighLow.InformationSeq == null || mPCommodity.QCommodity.HighLow.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.HighLow.InformationSeq) < int.Parse(InformationSeq)))
                                                {
                                                    DayHighPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    DayLowPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 40, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00") + int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    ShowTime = int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00");

                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, DayHighPrice, DayLowPrice, ShowTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI021 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 6: 
                                            #region //I023 定時開盤價量揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI023 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0)
                                                {
                                                    MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");
                                                    FirstMatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    FirstMatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));

                                                    mPCommodity.SetOpen(MatchTime, FirstMatchPrice);
                                                    DoSendWrite(mPCommodity.QCommodity.Open);
                                                    /*mPCommodity.Send(Open);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Open); }*/
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI023 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 7:
                                            #region //I022 試撮成交價量揭示
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI022 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 8:
                                            #region //I082 試撮後剩餘委託簿揭示訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI082 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][mKind=" + mKind + "] " + "Fx2 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_3
                                case 3:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1: 
                                            #region //I070 收盤行情資料訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI070 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                TermHighPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00") + int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00"));
                                                ComBuyOrderTal = int.Parse(int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00") + int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00"));
                                                ComBuyQuantityTal = int.Parse(int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00") + int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00"));
                                                ComSellOrderTal = int.Parse(int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                ComSellQuantityTal = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                ComTotalQty = int.Parse(int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00"));

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, ComBuyOrderTal, ComBuyQuantityTal, ComSellOrderTal, ComSellQuantityTal, ComTotalQty, 0.0, 0);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI070 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2: 
                                            #region //I071 收盤行情訊息含結算價
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI071 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                TermHighPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00") + int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00"));
                                                ComBuyOrderTal = int.Parse(int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00") + int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00"));
                                                ComBuyQuantityTal = int.Parse(int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00") + int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00"));
                                                ComSellOrderTal = int.Parse(int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                ComSellQuantityTal = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                ComTotalQty = int.Parse(int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00"));
                                                SettlementPrice = double.Parse(int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00") + int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, ComBuyOrderTal, ComBuyQuantityTal, ComSellOrderTal, ComSellQuantityTal, ComTotalQty, SettlementPrice, 0);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI071 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 3: 
                                            #region //I072 行情訊息含結算價及未平倉合約數
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI072 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                TermHighPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00") + int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00"));
                                                ComBuyOrderTal = int.Parse(int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00") + int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00"));
                                                ComBuyQuantityTal = int.Parse(int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00") + int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00"));
                                                ComSellOrderTal = int.Parse(int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                ComSellQuantityTal = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                ComTotalQty = int.Parse(int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00"));
                                                SettlementPrice = double.Parse(int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00") + int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenInterest = int.Parse(int.Parse(bte[113].ToString("x")).ToString("00") + int.Parse(bte[114].ToString("x")).ToString("00") + int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00"));

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, ComBuyOrderTal, ComBuyQuantityTal, ComSellOrderTal, ComSellQuantityTal, ComTotalQty, SettlementPrice, OpenInterest);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI072 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 4: 
                                            #region //I073 複式商品收盤行情資料訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][FxI073 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Future);
                                                SetCom(mPCommodity);

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                TermHighPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 40, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00") + int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = System.Text.UnicodeEncoding.Default.GetString(bte, 46, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = System.Text.UnicodeEncoding.Default.GetString(bte, 52, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[53].ToString("x")).ToString("00") + int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 58, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 70, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = System.Text.UnicodeEncoding.Default.GetString(bte, 76, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00") + int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00") + int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00") + int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00") + int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00"));

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, 0, 0, 0, 0, 0, 0.0, 0);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI073 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][mKind=" + mKind + "] " + "Fx3 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                default:
                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][tCode=" + tCode + "] " + "Fx TRANSMISSION_CODE ERROR");
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
            
        }
        private void DealWithOp()
        {
            int othercol = 17;
            string InformationTime;
            string InformationSeq;
            string VersionNo;

            int sBodyLength = 0;
            int Packetlength = 0;

            string sCommodityId;
            double sRiseLimitPrice = 0.0;
            double sReferencePrice = 0.0;
            double sFallLimitPrice = 0.0;
            double sRiseLimitPrice2 = 0.0;
            double sFallLimitPrice2 = 0.0;
            double sRiseLimitPrice3 = 0.0;
            double sFallLimitPrice3 = 0.0;

            string Prod_Kind;
            double Decimal_Locate = 0.0;
            double Strike_Decimal_Locate = 0.0;

            string MatchTime;
            double MatchPrice = 0.0;
            int MatchQuantity = 0;
            int MatchTOTALQty = 0;
            int MatchBuyCNT = 0;
            int MatchSellCNT = 0;

            double FirstMatchPrice = 0.0;
            int FirstMatchQuantity = 0;

            double DayHighPrice = 0.0;
            double DayLowPrice = 0.0;
            string ShowTime;

            int BuyOrder = 0;
            int BuyQuantity = 0;
            int SellOrder = 0;
            int SellQuantity = 0;

            int BultinKey = 0;
            string BultinData;

            string IndexKind;
            int IndexTime = 0;
            double IndexValue = 0.0;

            double BuyPriceBest1 = 0.0;
            int BuyQtyBest1 = 0;
            double BuyPriceBest2 = 0.0;
            int BuyQtyBest2 = 0;
            double BuyPriceBest3 = 0.0;
            int BuyQtyBest3 = 0;
            double BuyPriceBest4 = 0.0;
            int BuyQtyBest4 = 0;
            double BuyPriceBest5 = 0.0;
            int BuyQtyBest5 = 0;
            double SellPriceBest1 = 0.0;
            int SellQtyBest1 = 0;
            double SellPriceBest2 = 0.0;
            int SellQtyBest2 = 0;
            double SellPriceBest3 = 0.0;
            int SellQtyBest3 = 0;
            double SellPriceBest4 = 0.0;
            int SellQtyBest4 = 0;
            double SellPriceBest5 = 0.0;
            int SellQtyBest5 = 0;

            double BuyPriceDerived = 0.0;
            int BuyQtyDerived = 0;
            double SellPriceDerived = 0.0;
            int SellQtyDerived = 0;

            double TermHighPrice = 0.0;
            double TermLowPrice = 0.0;
            double DayHighPriceT = 0.0;
            double DayLowPriceT = 0.0;
            double OpenPrice = 0.0;
            double BuyPrice = 0.0;
            double SellPrice = 0.0;
            double ClosePrice = 0.0;
            int BuyOrderTal = 0;
            int BuyQuantityTal = 0;
            int SellOrderTal = 0;
            int SellQuantityTal = 0;
            int TotalMatch = 0;
            int TotalQty = 0;
            int ComBuyOrderTal = 0;
            int ComBuyQuantityTal = 0;
            int ComSellOrderTal = 0;
            int ComSellQuantityTal = 0;
            int ComTotalQty = 0;
            double SettlementPrice = 0.0;
            int OpenInterest = 0;

            string DisclosureTime;
            int DurationTime = 0;
            //CoQuery iCoQuery;

            int Match_seq;
            int Op_Match_seq = 0;
            int Op_PacketLost_Qty = 0;
            
            int i = 0;
            double strike;
            byte[] sCheckSum;
            byte[] bte;

            PCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            if (!CMarket.IsTrade)
                                continue;

                            InformationTime = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00") + int.Parse(bte[6].ToString("x")).ToString("00");
                            InformationSeq = int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00") + int.Parse(bte[10].ToString("x")).ToString("00");
                            VersionNo = int.Parse(bte[11].ToString("x")).ToString("00");
                            sBodyLength = int.Parse(int.Parse(bte[12].ToString("x")).ToString("00") + int.Parse(bte[13].ToString("x")).ToString("00"));
                            Packetlength = sBodyLength + othercol;
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 1, 1));
                            int mKind = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 2, 1));

                            if (!m_QuoteSetting.IsRegisterAll)
                            {
                                string gCommodityId = "";

                                if (tCode == 4)
                                {
                                    if (mKind == 1 || mKind == 2)
                                        gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                }
                                else if (tCode == 5)
                                {
                                    if (mKind == 1 || mKind == 2 || mKind == 5 || mKind == 6 || mKind == 7 || mKind == 8)
                                        gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                    else if (mKind == 4)
                                        gCommodityId = "query";
                                }
                                else if (tCode == 6)
                                {
                                    if (mKind == 1 || mKind == 2 || mKind == 3)
                                        gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                }

                                mPCommodity = m_PCommodityList.Get(gCommodityId);

                                if (mPCommodity == null)
                                    continue;
                            }

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                #region //TRANSMISSION_CODE_0
                                case 0:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 0:
                                            #region //I000 HeartBeat
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI000 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][mKind=" + mKind + "] " + "Op0 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_4
                                case 4:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I010 單一商品漲停幅揭示
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI010 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                Prod_Kind = System.Text.UnicodeEncoding.Default.GetString(bte, 59, 1).Trim();
                                                Decimal_Locate = double.Parse(bte[60].ToString("x"));

                                                if (Decimal_Locate == 0)
                                                    Decimal_Locate = 1.0;
                                                else
                                                    Decimal_Locate = 1 / Math.Pow(10, Decimal_Locate);

                                                Strike_Decimal_Locate = double.Parse(bte[61].ToString("x"));

                                                if (Strike_Decimal_Locate == 0)
                                                    Strike_Decimal_Locate = 1.0;
                                                else
                                                    Strike_Decimal_Locate = 1 / Math.Pow(10, Strike_Decimal_Locate);

                                                
                                                sRiseLimitPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sRiseLimitPrice2 = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice2 = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sRiseLimitPrice3 = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice3 = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * Decimal_Locate;

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                
                                                double.TryParse(sCommodityId.Substring(3,5),out strike);
                                                strike *= Strike_Decimal_Locate;
                                                CodeMap cm = m_CMarket.GetCodeMap(CommodityKind.Option,sCommodityId.Substring(0, 2));

                                                string settlemonth = GetTFEMonth(sCommodityId);
                                                
                                                string tradedate = int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00") + "/" + int.Parse(bte[64].ToString("x")).ToString("00") + "/" + int.Parse(bte[65].ToString("x")).ToString("00");
                                                string settledate = int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + "/" + int.Parse(bte[68].ToString("x")).ToString("00") + "/" + int.Parse(bte[69].ToString("x")).ToString("00");
                                                string flowgroup = "";
                                                //2015/6/25預計上線新格式
                                                //flowgroup = int.Parse(bte[70].ToString("x")).ToString();

                                                if (FlowGroupMap.ContainsKey(flowgroup)) { flowgroup = FlowGroupMap[flowgroup].ToString(); }

                                                CommodityType sCommodityType = GetCommodityType(sCommodityId);

                                                /*if (sCommodityId.Substring(0, 2) == "TG") { settledate = GetTGMaturity(settlemonth); }
                                                else { settledate = GetMaturity(settlemonth); }

                                                Util.ExecSqlCmd("EXEC spCommodityExtraTFEOp '" + sCommodityId + "','" + Enum.GetName(typeof(CommodityType),sCommodityType) + "','" + settledate + "'," + strike.ToString(), m_QuoteSetting.DBConnectString);
                                                */
                                                Util.ExecSqlCmd("EXEC spCommodityExtraTFEOp2 '" + sCommodityId + "','" + Enum.GetName(typeof(CommodityType), sCommodityType) + "','" + tradedate + "','" + settledate + "'," + strike.ToString() + ",'" + flowgroup + "'", m_QuoteSetting.DBConnectString);

                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                mPCommodity.IsLocalCommodity = true;
                                                //if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone) || mPCommodity.QCommodity.Base.InformationSeq == null || mPCommodity.QCommodity.Base.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Base.InformationSeq) < int.Parse(InformationSeq)))
                                                //{
                                                    mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Option, sCommodityType,cm.Code, cm.CodeNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), InformationTime, InformationSeq, settlemonth,strike, sReferencePrice, sRiseLimitPrice, sFallLimitPrice, sRiseLimitPrice2, sFallLimitPrice2, sRiseLimitPrice3, sFallLimitPrice3, 1, Prod_Kind, Decimal_Locate, Strike_Decimal_Locate, "","");
                                                    DoSendWrite(mPCommodity.QCommodity.Base);
                                                    /*mPCommodity.Send(Base);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Base); }*/
                                                //}
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI010 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2:
                                            #region //I030 商品委託量累計訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI030 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 3:
                                            #region //I011 契約基本資料
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI011 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                string KindId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 4).Trim();
                                                string CHName = System.Text.UnicodeEncoding.Default.GetString(bte, 18, 30).Trim();
                                                string STOCKID = System.Text.UnicodeEncoding.Default.GetString(bte, 48, 6).Trim();
                                                string SUBType = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim();
                                                //2015/6/25預計上線新格式
                                                double ContractSIZE = double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00")) * 0.0001;
                                                string CurrencyCode = System.Text.UnicodeEncoding.Default.GetString(bte, 62, 1).Trim();
                                                string CurrencyId = "";
                                                string StatusCode = System.Text.UnicodeEncoding.Default.GetString(bte, 61, 1).Trim();
                                                string AcceptQuoteFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 65, 1).Trim();
                                                string BeginDate = System.Text.UnicodeEncoding.Default.GetString(bte, 66, 4).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 70, 2).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 72, 2).Trim();
                                                string BlockTradeFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim();
                                                string ExpiryType = System.Text.UnicodeEncoding.Default.GetString(bte, 75, 1).Trim();
                                                string UnderlyingType = "";
                                                string MarketCloseGroup = "";

                                                UnderlyingType = System.Text.UnicodeEncoding.Default.GetString(bte, 76, 1).Trim();
                                                MarketCloseGroup = int.Parse(bte[77].ToString("x")).ToString();
                                                //2015/6/25舊格式
                                                /*double ContractSIZE = double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00")) * 0.0001;
                                                string StatusCode = System.Text.UnicodeEncoding.Default.GetString(bte, 60, 1).Trim();
                                                string CurrencyCode = System.Text.UnicodeEncoding.Default.GetString(bte, 61, 1).Trim();
                                                string CurrencyId = "";
                                                string AcceptQuoteFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim();
                                                string BeginDate = System.Text.UnicodeEncoding.Default.GetString(bte, 65, 4).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 69, 2).Trim() + "/" + System.Text.UnicodeEncoding.Default.GetString(bte, 71, 2).Trim();
                                                string BlockTradeFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 73, 1).Trim();
                                                string ExpiryType = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim();
                                                string UnderlyingType = "";
                                                string MarketCloseGroup = "";*/

                                                if (FlowGroupMap.ContainsKey(MarketCloseGroup)) { MarketCloseGroup = FlowGroupMap[MarketCloseGroup].ToString(); }
                                                if (TFECurrencyMap.ContainsKey(CurrencyCode)) { CurrencyId = TFECurrencyMap[CurrencyCode].ToString(); }
                                                if (BeginDate == "//") { BeginDate = "2000/1/1"; }
                                                //Util.ExecSqlCmd("EXEC spCommodityContract 'TFE','Option','" + SUBType + "','" + KindId + "','" + CHName + "','" + STOCKID + "'," + ContractSIZE.ToString("0.0000"), m_QuoteSetting.DBConnectString);                                                
                                                Util.ExecSqlCmd("EXEC spCommodityContract2 'TFE','Option','" + SUBType + "','" + KindId + "','" + CHName + "','" + STOCKID + "'," + ContractSIZE.ToString("0.0000") + ",'" + CurrencyId + "','" + StatusCode + "','" + AcceptQuoteFlag + "','" + BeginDate + "','" + BlockTradeFlag + "','" + ExpiryType + "','" + UnderlyingType + "','" + MarketCloseGroup + "'", m_QuoteSetting.DBConnectString);
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI011 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 4:
                                            #region //I050 公告訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI050 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 5:
                                            #region //I060 現貨標的指數資訊揭示
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI060 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 6:
                                            #region //I120 股票選擇權與現貨標的對照表
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI120 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 7:
                                            #region //I130 契約調整檔
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI130 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 8:
                                            #region //I064 現貨標的詴撮與狀態資訊
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI064 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI064 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][mKind=" + mKind + "] " + "Op1 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_5
                                case 5:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I020 成交價量揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI020 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");

                                                #region check seq start
                                                if (m_QuoteSetting.IsCheckLost && m_QuoteSetting.IsRegisterAll)
                                                {
                                                    Match_seq = Convert.ToInt32(InformationSeq);

                                                    if (Match_seq != 0 && Match_seq != 1)
                                                    {
                                                        if (Match_seq - Op_Match_seq != 1 && Match_seq > Op_Match_seq)
                                                        {
                                                            Op_PacketLost_Qty += Match_seq - Op_Match_seq - 1;
                                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][Lost Op_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Op_PacketLost_Qty + " Last:" + Op_Match_seq + " Current:" + Match_seq);
                                                        }
                                                    }
                                                    else
                                                        Op_PacketLost_Qty = 0;

                                                    if (Match_seq > Op_Match_seq)
                                                        Op_Match_seq = Match_seq;
                                                }
                                                #endregion check seq end

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(InformationSeq)))
                                                {   
                                                    MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    MatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));
                                                    MatchTOTALQty = int.Parse(int.Parse(bte[Packetlength - 16].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 15].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 14].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 13].ToString("x")).ToString("00"));
                                                    MatchBuyCNT = int.Parse(int.Parse(bte[Packetlength - 12].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 11].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 10].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 9].ToString("x")).ToString("00"));
                                                    MatchSellCNT = int.Parse(int.Parse(bte[Packetlength - 8].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 7].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 6].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 5].ToString("x")).ToString("00"));

                                                    MatchPrice = MatchPrice * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    if ((int)(bte[48] & 127) > 0) { MatchTOTALQty += MatchQuantity; }

                                                    mPCommodity.SetMatch(InformationTime, InformationSeq, 1, MatchTime, MatchPrice, MatchQuantity, 0, 0, MatchTOTALQty, 0, MatchBuyCNT, MatchSellCNT);
                                                    /*if (m_QuoteSetting.IsCalculateGreeks)
                                                        m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                    /*mPCommodity.Send(Match);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Match); }*/

                                                    for (i = 0; i < (int)(bte[48] & 127); i++)
                                                    {
                                                        MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 49 + 8 * i, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[50 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[51 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[52 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[53 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[54 + 8 * i].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                        MatchQuantity = int.Parse(int.Parse(bte[55 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[56 + 8 * i].ToString("x")).ToString("00"));
                                                        MatchTOTALQty += MatchQuantity;

                                                        mPCommodity.SetMatch(InformationTime, InformationSeq, i + 2, MatchTime, MatchPrice, MatchQuantity, 0, 0, MatchTOTALQty, 0, MatchBuyCNT, MatchSellCNT);
                                                        /*if (m_QuoteSetting.IsCalculateGreeks)
                                                            m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                        DoSendWrite(mPCommodity.QCommodity.Match);
                                                        /*mPCommodity.Send(Match);
                                                        if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Match); }*/
                                                    }
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI020 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2:
                                            #region //I080 委託簿揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI080 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(InformationSeq)))
                                                {

                                                    BuyPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00"));
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    BuyPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 44, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00"));
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00"));
                                                    BuyPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00"));
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00"));
                                                    BuyPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00"));
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00"));
                                                    BuyPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[75].ToString("x")).ToString("00") + int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));

                                                    SellPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 84, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                                    SellPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 94, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                    SellPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 104, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00") + int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00"));
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00") + int.Parse(bte[113].ToString("x")).ToString("00"));
                                                    SellPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 114, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00") + int.Parse(bte[117].ToString("x")).ToString("00") + int.Parse(bte[118].ToString("x")).ToString("00") + int.Parse(bte[119].ToString("x")).ToString("00"));
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[120].ToString("x")).ToString("00") + int.Parse(bte[121].ToString("x")).ToString("00") + int.Parse(bte[122].ToString("x")).ToString("00") + int.Parse(bte[123].ToString("x")).ToString("00"));
                                                    SellPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 124, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[125].ToString("x")).ToString("00") + int.Parse(bte[126].ToString("x")).ToString("00") + int.Parse(bte[127].ToString("x")).ToString("00") + int.Parse(bte[128].ToString("x")).ToString("00") + int.Parse(bte[129].ToString("x")).ToString("00"));
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[130].ToString("x")).ToString("00") + int.Parse(bte[131].ToString("x")).ToString("00") + int.Parse(bte[132].ToString("x")).ToString("00") + int.Parse(bte[133].ToString("x")).ToString("00"));

                                                    BuyPriceDerived = 0.0;
                                                    BuyQtyDerived = 0;
                                                    SellPriceDerived = 0.0;
                                                    SellQtyDerived = 0;

                                                    if (int.Parse(bte[134].ToString("x")).ToString("00") == "01")
                                                    {
                                                        BuyPriceDerived = double.Parse(int.Parse(bte[135].ToString("x")).ToString("00") + int.Parse(bte[136].ToString("x")).ToString("00") + int.Parse(bte[137].ToString("x")).ToString("00") + int.Parse(bte[138].ToString("x")).ToString("00") + int.Parse(bte[139].ToString("x")).ToString("00"));
                                                        BuyQtyDerived = int.Parse(int.Parse(bte[140].ToString("x")).ToString("00") + int.Parse(bte[141].ToString("x")).ToString("00") + int.Parse(bte[142].ToString("x")).ToString("00") + int.Parse(bte[143].ToString("x")).ToString("00"));
                                                        SellPriceDerived = double.Parse(int.Parse(bte[144].ToString("x")).ToString("00") + int.Parse(bte[145].ToString("x")).ToString("00") + int.Parse(bte[146].ToString("x")).ToString("00") + int.Parse(bte[147].ToString("x")).ToString("00") + int.Parse(bte[148].ToString("x")).ToString("00"));
                                                        SellQtyDerived = int.Parse(int.Parse(bte[149].ToString("x")).ToString("00") + int.Parse(bte[150].ToString("x")).ToString("00") + int.Parse(bte[151].ToString("x")).ToString("00") + int.Parse(bte[152].ToString("x")).ToString("00"));

                                                        if (BuyQtyDerived > 0)
                                                        {
                                                            if (BuyPriceDerived > BuyPriceBest1 || BuyPriceBest1 == 0.0)
                                                            {
                                                                BuyPriceBest5 = BuyPriceBest4;
                                                                BuyQtyBest5 = BuyQtyBest4;
                                                                BuyPriceBest4 = BuyPriceBest3;
                                                                BuyQtyBest4 = BuyQtyBest3;
                                                                BuyPriceBest3 = BuyPriceBest2;
                                                                BuyQtyBest3 = BuyQtyBest2;
                                                                BuyPriceBest2 = BuyPriceBest1;
                                                                BuyQtyBest2 = BuyQtyBest1;
                                                                BuyPriceBest1 = BuyPriceDerived;
                                                                BuyQtyBest1 = BuyQtyDerived;
                                                            }
                                                            else if (BuyPriceDerived == BuyPriceBest1)
                                                            {
                                                                BuyQtyBest1 += BuyQtyDerived;
                                                            }
                                                        }

                                                        if (SellQtyDerived > 0)
                                                        {
                                                            if (SellPriceDerived < SellPriceBest1 || SellPriceBest1 == 0.0)
                                                            {
                                                                SellPriceBest5 = SellPriceBest4;
                                                                SellQtyBest5 = SellQtyBest4;
                                                                SellPriceBest4 = SellPriceBest3;
                                                                SellQtyBest4 = SellQtyBest3;
                                                                SellPriceBest3 = SellPriceBest2;
                                                                SellQtyBest3 = SellQtyBest2;
                                                                SellPriceBest2 = SellPriceBest1;
                                                                SellQtyBest2 = SellQtyBest1;
                                                                SellPriceBest1 = SellPriceDerived;
                                                                SellQtyBest1 = SellQtyDerived;
                                                            }
                                                            else if (SellPriceDerived == SellPriceBest1)
                                                            {
                                                                SellQtyBest1 += SellQtyDerived;
                                                            }
                                                        }
                                                    }

                                                    BuyPriceBest1 = BuyPriceBest1 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest2 = BuyPriceBest2 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest3 = BuyPriceBest3 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest4 = BuyPriceBest4 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    BuyPriceBest5 = BuyPriceBest5 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest1 = SellPriceBest1 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest2 = SellPriceBest2 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest3 = SellPriceBest3 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest4 = SellPriceBest4 * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceBest5 = SellPriceBest5 * mPCommodity.QCommodity.Base.DecimalLocate;

                                                    BuyPriceDerived = BuyPriceDerived * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    SellPriceDerived = SellPriceDerived * mPCommodity.QCommodity.Base.DecimalLocate;

                                                    mPCommodity.SetBest5(InformationTime, InformationSeq, BuyPriceBest1, BuyQtyBest1, BuyPriceBest2, BuyQtyBest2, BuyPriceBest3, BuyQtyBest3, BuyPriceBest4, BuyQtyBest4, BuyPriceBest5, BuyQtyBest5, SellPriceBest1, SellQtyBest1, SellPriceBest2, SellQtyBest2, SellPriceBest3, SellQtyBest3, SellPriceBest4, SellQtyBest4, SellPriceBest5, SellQtyBest5, BuyPriceDerived, BuyQtyDerived, SellPriceDerived, SellQtyDerived);
                                                    /*if (m_QuoteSetting.IsCalculateGreeks)
                                                        m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Best5);*/
                                                    DoSendWrite(mPCommodity.QCommodity.Best5);
                                                    /*mPCommodity.Send(Best5);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Best5); }*/
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI080 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 3:
                                            #region //I140 系統訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI140 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 4:
                                            #region //I100 詢價揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI100 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                DisclosureTime = int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00");
                                                DurationTime = int.Parse(int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00"));

                                                QueryCls QQ = QueryList.Add("O", sCommodityId, InformationTime, InformationSeq, DisclosureTime, DurationTime);

                                                if (QQ != null) { DoSendWriteQuery(QQ); }                                                    
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI100 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 5:
                                            #region //I021 盤中最高低價揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI021 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.HighLow == null || mPCommodity.QCommodity.HighLow.InformationSeq == null || mPCommodity.QCommodity.HighLow.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.HighLow.InformationSeq) < int.Parse(InformationSeq)))
                                                {
                                                    DayHighPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    DayLowPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 40, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00") + int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    ShowTime = int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00");

                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, DayHighPrice, DayLowPrice, ShowTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI021 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 6:
                                            #region //I023 定時開盤價量揭示訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI023 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                if (mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0)
                                                {
                                                    MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");
                                                    FirstMatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                    FirstMatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));

                                                    mPCommodity.SetOpen(MatchTime, FirstMatchPrice);
                                                    DoSendWrite(mPCommodity.QCommodity.Open);
                                                    /*mPCommodity.Send(Open);
                                                    if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Open); }*/
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI023 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 7:
                                            #region //I022 試撮成交價量揭示
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "FxI022 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 8:
                                            #region //I082 試撮後剩餘委託簿揭示訊息
                                            try
                                            {
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "FxI082 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][mKind=" + mKind + "] " + "Op2 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_6
                                case 6:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I070 收盤行情資料訊息
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI070 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                TermHighPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00") + int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00"));
                                                ComBuyOrderTal = int.Parse(int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00") + int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00"));
                                                ComBuyQuantityTal = int.Parse(int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00") + int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00"));
                                                ComSellOrderTal = int.Parse(int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                ComSellQuantityTal = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                ComTotalQty = int.Parse(int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00"));

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, ComBuyOrderTal, ComBuyQuantityTal, ComSellOrderTal, ComSellQuantityTal, ComTotalQty, 0.0, 0);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI070 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2:
                                            #region //I071 收盤行情訊息含結算價
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI071 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                TermHighPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00") + int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00"));
                                                ComBuyOrderTal = int.Parse(int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00") + int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00"));
                                                ComBuyQuantityTal = int.Parse(int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00") + int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00"));
                                                ComSellOrderTal = int.Parse(int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                ComSellQuantityTal = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                ComTotalQty = int.Parse(int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00"));
                                                SettlementPrice = int.Parse(int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00") + int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, ComBuyOrderTal, ComBuyQuantityTal, ComSellOrderTal, ComSellQuantityTal, ComTotalQty, SettlementPrice, 0);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI071 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 3:
                                            #region //I072 行情訊息含結算價及未平倉合約數
                                            try
                                            {
                                                Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);
                                                if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                                {
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][OpI072 ERROR CHECKSUM ERROR]");
                                                    break;
                                                }

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                mPCommodity = m_PCommodityList.Set(sCommodityId.Substring(0, 2), sCommodityId, m_CMarket.Market, CommodityKind.Option);
                                                SetCom(mPCommodity);

                                                TermHighPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                TermLowPrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayHighPriceT = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                DayLowPriceT = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenPrice = double.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyPrice = double.Parse(int.Parse(bte[49].ToString("x")).ToString("00") + int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                SellPrice = double.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                ClosePrice = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                BuyOrderTal = int.Parse(int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00"));
                                                BuyQuantityTal = int.Parse(int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00") + int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00"));
                                                SellOrderTal = int.Parse(int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00") + int.Parse(bte[74].ToString("x")).ToString("00") + int.Parse(bte[75].ToString("x")).ToString("00"));
                                                SellQuantityTal = int.Parse(int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                TotalMatch = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));
                                                TotalQty = int.Parse(int.Parse(bte[84].ToString("x")).ToString("00") + int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00"));
                                                ComBuyOrderTal = int.Parse(int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00") + int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00"));
                                                ComBuyQuantityTal = int.Parse(int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00") + int.Parse(bte[94].ToString("x")).ToString("00") + int.Parse(bte[95].ToString("x")).ToString("00"));
                                                ComSellOrderTal = int.Parse(int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                ComSellQuantityTal = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                ComTotalQty = int.Parse(int.Parse(bte[104].ToString("x")).ToString("00") + int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00"));
                                                SettlementPrice = double.Parse(int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00") + int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00")) * mPCommodity.QCommodity.Base.DecimalLocate;
                                                OpenInterest = int.Parse(int.Parse(bte[113].ToString("x")).ToString("00") + int.Parse(bte[114].ToString("x")).ToString("00") + int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00"));

                                                mPCommodity.SetClose(InformationTime, InformationSeq, DayHighPriceT, DayLowPriceT, OpenPrice, BuyPrice, SellPrice, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), TotalMatch, TotalQty, 0, ComBuyOrderTal, ComBuyQuantityTal, ComSellOrderTal, ComSellQuantityTal, ComTotalQty, SettlementPrice, OpenInterest);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI072 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion                                                                                    
                                        default:
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][mKind=" + mKind + "] " + "Op3 MESSAGE_KIND ERROR");
                                            break;
                                    }
                                    break;
                                #endregion
                                default:
                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][tCode=" + tCode + "] " + "Op TRANSMISSION_CODE ERROR");
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithTse()
        {
            string InformationSeq;
            string InformationTime;
            int Packetlength = 0;
            int StkCnt = 0;

            string sCommodityId;
            string sCommodityNm;
            string stkProperty;
            string stkState;
            //int sCommodityCode = 0;
            int sUnusualCode = 0;
            double sRiseLimitPrice = 0.0;
            double sReferencePrice = 0.0;
            double sFallLimitPrice = 0.0;

            int sDisPlayTag = 0;
            int sFallRiseTag = 0;
            int nResult = 0;
            int nPos = 0;

            string MatchTime;
            double MatchPrice = 0.0;
            int MatchQuantity = 0;
            int MatchTOTALQty = 0;
            int oldMatchTOTALQty = 0;

            double HighPrice = 0.0;
            double LowPrice = 0.0;
            double OpenPrice = 0.0;
            double ClosePrice = 0.0;
            double SettlePrice = 0.0;
            string ShowTime;

            double AccountSum = 0;
            int AccountQuantity = 0;
            int AccountOrder = 0;
            double AccountSumTotal = 0;
            int AccountQuantityTotal = 0;
            int AccountOrderTotal = 0;

            int BuyOrder = 0;
            int BuyQuantity = 0;
            int SellOrder = 0;
            int SellQuantity = 0;

            string BultinKey;
            string BultinData;

            string IndexCode = "";
            int IndexItems = 0;
            double IndexValue = 0.0;

            double BuyPriceBest1 = 0.0;
            int BuyQtyBest1 = 0;
            double BuyPriceBest2 = 0.0;
            int BuyQtyBest2 = 0;
            double BuyPriceBest3 = 0.0;
            int BuyQtyBest3 = 0;
            double BuyPriceBest4 = 0.0;
            int BuyQtyBest4 = 0;
            double BuyPriceBest5 = 0.0;
            int BuyQtyBest5 = 0;
            double SellPriceBest1 = 0.0;
            int SellQtyBest1 = 0;
            double SellPriceBest2 = 0.0;
            int SellQtyBest2 = 0;
            double SellPriceBest3 = 0.0;
            int SellQtyBest3 = 0;
            double SellPriceBest4 = 0.0;
            int SellQtyBest4 = 0;
            double SellPriceBest5 = 0.0;
            int SellQtyBest5 = 0;

            int sLeftQty = 0;
            double sStrikePrice = 0.0;
            double sExecRatio = 0.0;

            int Unit = 0;
            int Match_seq;
            int Tse_Match_seq = 0;
            int Tse_PacketLost_Qty = 0;

            string CurrencyId = "";

            byte[] sCheckSum;
            byte[] bte;

            PCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            if (!CMarket.IsTrade)
                                continue;

                            Packetlength = int.Parse(int.Parse(bte[1].ToString("x")).ToString("00") + int.Parse(bte[2].ToString("x")).ToString("00"));
                            InformationSeq = int.Parse(bte[6].ToString("x")).ToString("00") + int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00");
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(bte[4].ToString("x"));

                            if (!m_QuoteSetting.IsRegisterAll)
                            {
                                string gCommodityId = "";
                                int gCommodityCode = 0;

                                /*if (tCode == 1)
                                {
                                    gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                                    mPCommodity = m_PCommodityList.Get(gCommodityId);
                                    if (mPCommodity == null)
                                        continue;
                                }
                                else if (tCode == 1 || tCode == 6 || tCode == 9)
                                {
                                    gCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));

                                    mPCommodity = m_CMarket.GetInnerCode(gCommodityCode.ToString());
                                    if (mPCommodity == null)
                                        continue;
                                }*/

                                if (tCode == 1 || tCode == 6 || tCode == 9)
                                {
                                    gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                    mPCommodity = m_PCommodityList.Get(gCommodityId);

                                    if (mPCommodity == null)
                                        continue;
                                }    
                            }

                            m_PacketNum++;

                            /*if (tCode == 1 || tCode == 6 || tCode == 9)
                            {
                                if (System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim() != "2515")
                                    continue;
                            }*/
                            //if (!(tCode == 1 || tCode == 6 || tCode == 17)) { continue; }

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {  
                                case 1:
                                    #region //集中市場個股基本資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse01 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                                        if (sCommodityId == "000000") { break; }
                                        
                                        sCommodityNm = System.Text.UnicodeEncoding.Default.GetString(bte, 16, 6).Trim();
                                        stkProperty = System.Text.UnicodeEncoding.Default.GetString(bte, 22, 2).Trim();
                                        stkState = System.Text.UnicodeEncoding.Default.GetString(bte, 24, 2).Trim();
                                        //sCommodityCode = int.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00"));
                                        sUnusualCode = int.Parse(bte[28].ToString("x"));
                                        sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00")) / 100;
                                        sRiseLimitPrice = double.Parse(int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00") + int.Parse(bte[34].ToString("x")).ToString("00")) / 100;
                                        sFallLimitPrice = double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00")) / 100;

                                        /*string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim();                                        
                                        sStrikePrice = double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00")) / 100;
                                        sLeftQty = int.Parse(int.Parse(bte[53].ToString("x")).ToString("00") + int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00"));
                                        sExecRatio = double.Parse(int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00")) / 100 / 1000;
                                        Unit = int.Parse(int.Parse(bte[63].ToString("x")).ToString("00") + int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00"));
                                        */

                                        string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 41, 1).Trim();
                                        sStrikePrice = double.Parse(int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00") + int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00")) / 100;
                                        sLeftQty = int.Parse(int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00"));
                                        sExecRatio = double.Parse(int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00") + int.Parse(bte[64].ToString("x")).ToString("00")) / 100 / 1000;
                                        Unit = int.Parse(int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00"));
                                        CurrencyId = System.Text.UnicodeEncoding.Default.GetString(bte, 69, 3).Trim();

                                        if (TSECurrencyMap.ContainsKey(CurrencyId)) { CurrencyId = TSECurrencyMap[CurrencyId].ToString(); }

                                        if (CurrencyId == "") { CurrencyId = "NTD"; }

                                        if (m_QuoteSetting.IsWriteToDb)
                                            Util.ExecSqlCmd("EXEC spUpdateCurrency '" + sCommodityId + "','" + CurrencyId + "'", m_QuoteSetting.DBConnectString);

                                        //mPCommodity.CMarket.SetCommodity(sCommodityCode, mPCommodity);

                                        //if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone) || mPCommodity.QCommodity.Base.InformationSeq == null || mPCommodity.QCommodity.Base.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Base.InformationSeq) <= int.Parse(InformationSeq)))
                                        //{
                                            CommodityKind sCommodityKind = CommodityKind.Stock;
                                            CommodityType sCommodityType = CommodityType.None;
                                        
                                            GetCommodityKind(sCommodityId, ref sCommodityKind, ref sCommodityType);
                                            mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, sCommodityKind);
                                            mPCommodity.IsLocalCommodity = true;    
                                            mPCommodity.SetBase(m_CMarket.Market, sCommodityKind, sCommodityType, "", sCommodityNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), "", InformationSeq, sReferencePrice, sRiseLimitPrice, sFallLimitPrice, Unit, "", stkProperty);
                                            DoSendWrite(mPCommodity.QCommodity.Base);

                                            if (IsWarrantFlag == "Y")
                                            {
                                                mPCommodity.SetExtra(sCommodityId, sStrikePrice, sExecRatio);
                                                if (m_QuoteSetting.IsWriteToDb)
                                                    Util.ExecSqlCmd("EXEC spWarrantExtra '" + sCommodityId + "'," + sStrikePrice + "," + sExecRatio + "," + sLeftQty, m_QuoteSetting.DBConnectString);
                                            }                                      
                                            /*mPCommodity.Send(Base);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }*/                                            
                                        //}
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse01 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 2:
                                    #region //集中市場競價交易成交統計資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse02 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                                        mPCommodity = m_PCommodityList.Set("1000", "1000", m_CMarket.Market, CommodityKind.Index);

                                        if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None,"", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), "", "", 0.0, 0.0, 0.0, 1, "",""); }

                                        if (InformationSeq == "00000000") { break; }

                                        if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) <= int.Parse(InformationSeq)))
                                        {                                            
                                            AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));                                            
                                            AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));
                                            AccountOrderTotal = int.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00"));

                                            if (mPCommodity.QCommodity.Match != null)
                                            {
                                                AccountSum = AccountSumTotal - mPCommodity.QCommodity.Match.MatchTotalAmt;
                                                AccountQuantity = (int)(AccountQuantityTotal - mPCommodity.QCommodity.Match.MatchTotalQty);
                                                AccountOrder = (int)(AccountOrderTotal - mPCommodity.QCommodity.Match.MatchTotalCnt);
                                                MatchPrice = mPCommodity.QCommodity.Match.MatchPrice;
                                            }
                                            else
                                            {
                                                AccountSum = AccountSumTotal;
                                                AccountQuantity = AccountQuantityTotal;
                                                AccountOrder = AccountOrderTotal ;
                                                MatchPrice = 0.0;
                                            }

                                            if (!(AccountSum == 0.0 && AccountQuantity == 0 && AccountOrder == 0))
                                            {
                                                mPCommodity.SetMatch(InformationTime, InformationSeq, 2, InformationTime, MatchPrice, AccountQuantity, AccountSum, AccountSumTotal, AccountQuantityTotal, AccountOrderTotal, 0, 0);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                if (InformationTime != "999999")
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                else
                                                    mPCommodity.QCommodity.Match.MatchSeq = 1;

                                                //Console.WriteLine("4 ---- " + mPCommodity.QCommodity.Match.MatchPrice + " ----- " + mPCommodity.QCommodity.Match.MatchTotalAmt / 100000000.0 + " ----- " + mPCommodity.QCommodity.Match.InformationSeq + " ----- " + mPCommodity.QCommodity.Match.InformationTime);
                                            }
                                            /*mPCommodity.Send(Match);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/
                                        }   
                                     
                                        //if (InformationTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.MatchTotalAmt == 0.0))
                                        if (InformationTime == "999999")
                                        {
                                            HighPrice = 0.0;
                                            LowPrice = 0.0;
                                            OpenPrice = 0.0;
                                            ClosePrice = 0.0;

                                            if (mPCommodity.QCommodity.Open != null)
                                                OpenPrice = mPCommodity.QCommodity.Open.OpenPrice;
                                            if (mPCommodity.QCommodity.HighLow != null)
                                            {
                                                HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;                                                    
                                            }
                                            if (mPCommodity.QCommodity.Close != null)
                                                ClosePrice = mPCommodity.QCommodity.Close.ClosePrice;
                                            
                                            mPCommodity.SetClose(InformationTime,InformationSeq,HighPrice,LowPrice,OpenPrice,0.0,0.0,ClosePrice,TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone),AccountOrderTotal,AccountQuantityTotal,AccountSumTotal,ClosePrice);
                                            DoSendWrite(mPCommodity.QCommodity.Close);
                                            /*mPCommodity.Send(Close);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse02 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 3:
                                    #region //集中市場競價交易指數統計資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse03 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                                        IndexItems = int.Parse(int.Parse(bte[13].ToString("x")).ToString("00"));
                                        
                                        for (int k = 0; k < IndexItems; k++)
                                        {
                                            switch (k)
                                            {
                                                case 0:
                                                    IndexCode = "1000";//加　權 
                                                    break;
                                                case 1:
                                                    IndexCode = "1010";//無金融
                                                    break;
                                                case 2:
                                                    IndexCode = "1011";//無電子
                                                    break;
                                                case 3:
                                                    IndexCode = "1012";//化學工業類
                                                    break;
                                                case 4:
                                                    IndexCode = "1013";//生技醫療類
                                                    break;
                                                case 5:
                                                    IndexCode = "1001";//水泥類(原分類)
                                                    break;
                                                case 6:
                                                    IndexCode = "1002";//食品類(原分類)
                                                    break;
                                                case 7:
                                                    IndexCode = "1003";//塑化類(原分類)
                                                    break;
                                                case 8:
                                                    IndexCode = "1004";//紡纖類(原分類)
                                                    break;
                                                case 9:
                                                    IndexCode = "1005";//機電類(原分類)
                                                    break;
                                                case 10:
                                                    IndexCode = "1006";//造紙類(原分類)
                                                    break;
                                                case 11:
                                                    IndexCode = "1007";//營建類(原分類)
                                                    break;
                                                case 12:
                                                    IndexCode = "1008";//雜項類(原分類)
                                                    break;
                                                case 13:
                                                    IndexCode = "1009";//金融類(原分類)
                                                    break;
                                                case 14:
                                                    IndexCode = "1100";//水泥類
                                                    break;
                                                case 15:
                                                    IndexCode = "1200";//食品類
                                                    break;
                                                case 16:
                                                    IndexCode = "1300";//塑膠類
                                                    break;
                                                case 17:
                                                    IndexCode = "1400";//紡纖類
                                                    break;
                                                case 18:
                                                    IndexCode = "1500";//電機類
                                                    break;
                                                case 19:
                                                    IndexCode = "1600";//電器類
                                                    break;
                                                case 20:
                                                    IndexCode = "1700";//化工類
                                                    break;
                                                case 21:
                                                    IndexCode = "1800";//玻璃類
                                                    break;
                                                case 22:
                                                    IndexCode = "1900";//造紙類
                                                    break;
                                                case 23:
                                                    IndexCode = "2000";//鋼鐵類
                                                    break;
                                                case 24:
                                                    IndexCode = "2100";//橡膠類
                                                    break;
                                                case 25:
                                                    IndexCode = "2200";//汽車類
                                                    break;
                                                case 26:
                                                    IndexCode = "2300";//電子類
                                                    break;
                                                case 27:
                                                    IndexCode = "2500";//營建類
                                                    break;
                                                case 28:
                                                    IndexCode = "2600";//運輸類
                                                    break;
                                                case 29:
                                                    IndexCode = "2700";//觀光類
                                                    break;
                                                case 30:
                                                    IndexCode = "2800";//金融類
                                                    break;
                                                case 31:
                                                    IndexCode = "2900";//百貨類
                                                    break;
                                                case 32:
                                                    IndexCode = "9900";//其它類
                                                    break;
                                                case 33:
                                                    IndexCode = "1014";//無金融電子
                                                    break;
                                                case 34:
                                                    IndexCode = "1015";//油電燃氣類
                                                    break;
                                                case 35:
                                                    IndexCode = "1016";//半導體類
                                                    break;
                                                case 36:
                                                    IndexCode = "1017";//電腦週邊設備類
                                                    break;
                                                case 37:
                                                    IndexCode = "1018";//光電類
                                                    break;
                                                case 38:
                                                    IndexCode = "1019";//通信網路類
                                                    break;
                                                case 39:
                                                    IndexCode = "1020";//電子零組件類
                                                    break;
                                                case 40:
                                                    IndexCode = "1021";//電子通路類
                                                    break;
                                                case 41:
                                                    IndexCode = "1022";//資訊服務類
                                                    break;
                                                case 42:
                                                    IndexCode = "1023";//其他電子類
                                                    break;
                                                default:
                                                    break;
                                            }

                                            IndexValue = double.Parse(int.Parse(bte[14 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[15 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[16 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[17 + 4 * k].ToString("x")).ToString("00")) / 100;

                                            //if (IndexCode == "1000")
                                            //    Console.WriteLine("1 ---- " + IndexValue + " ----- " + InformationSeq + " ----- " + InformationTime);

                                            mPCommodity = m_PCommodityList.Set(IndexCode, IndexCode, m_CMarket.Market, CommodityKind.Index);
                                            mPCommodity.IsLocalCommodity = true;
                                            //mPCommodity.CMarket.SetCommodity(IndexCode, mPCommodity);
                                            CodeMap cm = m_CMarket.GetCodeMap(CommodityKind.Index,IndexCode);

                                            if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None,"", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), "", "", 0.0, 0.0, 0.0, 1, "",""); }

                                            if (InformationSeq == "00000000")
                                            {
                                                mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, cm.Code, cm.CodeNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), InformationTime, InformationSeq, IndexValue, 0, 0, 1, "","");
                                                DoSendWrite(mPCommodity.QCommodity.Base);
                                                /*mPCommodity.Send(Base);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }*/
                                                continue;
                                            }
                                            if (InformationSeq == "00000002")
                                            {
                                                mPCommodity.SetOpen(InformationTime, IndexValue);
                                                DoSendWrite(mPCommodity.QCommodity.Open);
                                                /*mPCommodity.Send(Open);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/

                                                mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, IndexValue, InformationTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                /*mPCommodity.Send(HighLow);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                            }
                                            //if (InformationTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.ClosePrice == 0.0))
                                            if (InformationTime == "999999")
                                            {
                                                HighPrice = 0.0;
                                                LowPrice = 0.0;
                                                OpenPrice = 0.0;
                                                AccountSumTotal = 0;
                                                AccountQuantityTotal = 0;
                                                AccountOrderTotal = 0;

                                                if (mPCommodity.QCommodity.Open != null)
                                                    OpenPrice = mPCommodity.QCommodity.Open.OpenPrice;
                                                if (mPCommodity.QCommodity.HighLow != null)
                                                {
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;                                                    
                                                }
                                                if(mPCommodity.QCommodity.Close != null)
                                                {
                                                    AccountSumTotal = mPCommodity.QCommodity.Close.MatchTotalAmt;
                                                    AccountQuantityTotal = mPCommodity.QCommodity.Close.MatchTotalQty;
                                                    AccountOrderTotal = mPCommodity.QCommodity.Close.MatchTotalCnt;
                                                }

                                                mPCommodity.SetClose(InformationTime, InformationSeq, HighPrice, LowPrice, OpenPrice, 0.0, 0.0, IndexValue, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), AccountOrderTotal, AccountQuantityTotal, AccountSumTotal, IndexValue);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                                
                                            }

                                            //if (IndexCode == "1000")
                                            //    Console.WriteLine("2 ---- " + IndexValue + " ----- " + InformationSeq + " ----- " + InformationTime);

                                            //if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999")
                                            //{
                                                AccountSumTotal = 0;
                                                AccountQuantityTotal = 0;
                                                AccountOrderTotal = 0;
                                                AccountSum = 0; 
                                                AccountQuantity = 0;
 
                                                if (mPCommodity.QCommodity.Match != null)
                                                {
                                                    AccountSum = mPCommodity.QCommodity.Match.MatchAmt;
                                                    AccountQuantity = mPCommodity.QCommodity.Match.MatchQty;
                                                    AccountSumTotal = mPCommodity.QCommodity.Match.MatchTotalAmt;
                                                    AccountQuantityTotal = mPCommodity.QCommodity.Match.MatchTotalQty;
                                                    AccountOrderTotal = mPCommodity.QCommodity.Match.MatchTotalCnt;
                                                }
                                                
                                                mPCommodity.SetMatch(InformationTime, InformationSeq, 1, InformationTime, IndexValue, AccountQuantity, AccountSum, AccountSumTotal, AccountQuantityTotal, AccountOrderTotal, 0, 0);

                                                /*if (IndexCode == "1000")
                                                {
                                                    ErrorProcess("[" + DateTime.Now.ToString() + "][" + IndexValue + "][" + InformationTime + "][" + InformationSeq + "]");
                                                }*/

                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                //mPCommodity.SetMatch(InformationTime, InformationSeq, 1, InformationTime, IndexValue,0,0);

                                                /*if (IndexCode == "1000")
                                                {
                                                    //Console.WriteLine("3 ---- " + mPCommodity.QCommodity.Match.MatchPrice + " ----- " + mPCommodity.QCommodity.Match.MatchTotalAmt / 100000000.0 + " ----- " + mPCommodity.QCommodity.Match.InformationSeq);
                                                    //if (IndexCode == "1000")
                                                    //    Console.WriteLine("2 ---- " + IndexValue + " ----- " + InformationSeq + " ----- " + InformationTime);

                                                    if (InformationTime == "999999")
                                                    {
                                                        mPCommodity.QCommodity.Match.MatchSeq = 2;
                                                        DoSendWrite(mPCommodity.QCommodity.Match);
                                                    }
                                                    else
                                                    {
                                                        if (m_QuoteSetting.IsSendTicks)
                                                            mPCommodity.Send(mPCommodity.QCommodity.Match.Copy());
                                                        else
                                                            mPCommodity.Send(mPCommodity.QCommodity.Match);
                                                    }
                                                }
                                                else
                                                {
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                }*/
                                                DoSendWrite(mPCommodity.QCommodity.Match);

                                                HighPrice = 0.0;
                                                LowPrice = 0.0;
                                                if (mPCommodity.QCommodity.HighLow != null)
                                                {
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                                }

                                                //最高最低
                                                if (int.Parse(InformationSeq) > 1 && (HighPrice < IndexValue || HighPrice == 0.0))
                                                {
                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, LowPrice, InformationTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                                if (int.Parse(InformationSeq) > 1 && (LowPrice > IndexValue || LowPrice == 0.0))
                                                {
                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, HighPrice, IndexValue, InformationTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }                                                
                                            //}
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse03 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 4:
                                    #region //集中市場競價交易委託統計資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse04 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 5:
                                    #region //集中市場公告資訊
                                    try
                                    {
                                        string astr = "";

                                        //astr = int.Parse(bte[10].ToString("x")).ToString("00") + " ";
                                        //astr += "[集中市場]" + System.Text.UnicodeEncoding.Default.GetString(bte, 11, Packetlength - 14);
                                        
                                        //ErrorProcess(astr);
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse05 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 6:
                                    #region //集中市場競價交易即時行情資訊
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse06 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        //modify 20150610
                                        nPos = 29;

                                        MatchPrice = 0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;
                                        oldMatchTOTALQty = 0;
                                        OpenPrice = 0;
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        //if (sCommodityCode == 0) { break; }

                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        //modify 20150610
                                        sDisPlayTag = (int)bte[22];
                                        sFallRiseTag = (int)(bte[23] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost && m_QuoteSetting.IsRegisterAll)
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Tse_Match_seq != 1 && Match_seq > Tse_Match_seq)
                                                {
                                                    Tse_PacketLost_Qty += Match_seq - Tse_Match_seq - 1;
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Lost Tse_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Tse_PacketLost_Qty + " Last:" + Tse_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Tse_PacketLost_Qty = 0;

                                            if (Match_seq > Tse_Match_seq)
                                                Tse_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end
                                        
                                        nResult = sDisPlayTag >> 7;

                                        //modify 20150610
                                        MatchTOTALQty = int.Parse(int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            //modify 20150610
                                            MatchQuantity = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        //if (mPCommodity == null){mPCommodity = m_CMarket.GetInnerCode(sCommodityCode.ToString());}
                                        /*if (mPCommodity == null) { mPCommodity = m_PCommodityList.Get(sCommodityId); }
                                        if (mPCommodity == null)
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse06 ERROR " + "][No Mapping Code-" + sCommodityId + "]");
                                            break;
                                        }*/
                                        if (mPCommodity == null) { mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); }

                                        //if (mPCommodity.CommodityId == "2325") 
                                        //    mPCommodity = mPCommodity;
                                        
                                        #region 寫HTicks
                                        
                                        /*if (MatchTime.Length >= 6 && int.Parse(MatchTime.Substring(0, 6)) >= 90000)
                                        {
                                            HTicks HTicks = new HTicks();
                                            HTicks.TradeDate = DateTime.Now.ToString("yyyy/MM/dd");
                                            HTicks.CommodityId = mPCommodity.CommodityId;
                                            HTicks.InformationTime = MatchTime;
                                            HTicks.InformationSeq = InformationSeq;
                                            HTicks.MatchSeq = 1;
                                            HTicks.MatchTime = MatchTime;
                                            HTicks.MatchPrice = MatchPrice;
                                            HTicks.MatchTotalQty = MatchTOTALQty;
                                            HTicks.BuyPriceBest1 = BuyPriceBest1;
                                            HTicks.BuyQtyBest1 = BuyQtyBest1;
                                            HTicks.SellPriceBest1 = SellPriceBest1;
                                            HTicks.SellQtyBest1 = SellQtyBest1;

                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || int.Parse(mPCommodity.QCommodity.Match.MatchTime.Substring(0, 6)) < 90000 || MatchTOTALQty == 0)
                                                HTicks.MatchQty = MatchTOTALQty;
                                            else
                                                HTicks.MatchQty = MatchTOTALQty - mPCommodity.QCommodity.Match.MatchTotalQty;

                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HTicks); }
                                        }*/
                                        
                                        #endregion

                                        //if (int.Parse(MatchTime) > 132600)
                                        //    IsHasBidAsk = IsHasBidAsk;

                                        //if (BuyQtyBest1 != 0 || SellQtyBest1 != 0)
                                        if (IsHasBidAsk)
                                        {
                                            if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(InformationSeq)))
                                            {
                                                mPCommodity.SetBest5(MatchTime, InformationSeq, BuyPriceBest1, BuyQtyBest1, BuyPriceBest2, BuyQtyBest2, BuyPriceBest3, BuyQtyBest3, BuyPriceBest4, BuyQtyBest4, BuyPriceBest5, BuyQtyBest5, SellPriceBest1, SellQtyBest1, SellPriceBest2, SellQtyBest2, SellPriceBest3, SellQtyBest3, SellPriceBest4, SellQtyBest4, SellPriceBest5, SellQtyBest5);
                                                //Util.ExecSqlCmd("insert into pbest5ticks(CommodityId,InformationTime,InformationSeq,BuyPriceBest1,BuyQtyBest1,SellPriceBest1,SellQtyBest1) values('" + mPCommodity.CommodityId + "','" + MatchTime + "','" + InformationSeq + "'," + BuyPriceBest1 + "," + BuyQtyBest1 + "," + SellPriceBest1 + "," + SellQtyBest1 + ")", m_QuoteSetting.DBConnectString);

                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Best5);*/
                                                DoSendWrite(mPCommodity.QCommodity.Best5);
                                                /*mPCommodity.Send(Best5);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Best5); }*/
                                            }
                                        }

                                        
                                        if (MatchPrice != 0.0)
                                        {
                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.MatchTime) <= int.Parse(MatchTime)))
                                            {
                                                if (mPCommodity.QCommodity.Match != null)
                                                    oldMatchTOTALQty = mPCommodity.QCommodity.Match.MatchTotalQty;

                                                if (mPCommodity.QCommodity.Match != null && MatchTOTALQty <= oldMatchTOTALQty)
                                                    break;

                                                if (MatchTOTALQty == 0)
                                                    break;

                                                mPCommodity.SetMatch(MatchTime, InformationSeq, MatchTime, MatchPrice, MatchTOTALQty - oldMatchTOTALQty, MatchTOTALQty);
                                                mPCommodity.QCommodity.Match.FallRiseTag = sFallRiseTag;
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                DoSendWrite(mPCommodity.QCommodity.Match);
                                                /*mPCommodity.Send(Match);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                                if(mPCommodity.QCommodity.HighLow == null)
                                                {
                                                    mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, MatchPrice, MatchTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                }
                                                else
                                                {                                                
                                                    if (mPCommodity.QCommodity.HighLow.DayHighPrice < MatchPrice || (mPCommodity.QCommodity.HighLow.DayHighPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, mPCommodity.QCommodity.HighLow.DayLowPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    }
                                                    if (mPCommodity.QCommodity.HighLow.DayLowPrice > MatchPrice || (mPCommodity.QCommodity.HighLow.DayLowPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, mPCommodity.QCommodity.HighLow.DayHighPrice, MatchPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    }
                                                }                                                
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse06 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 7:
                                    #region //集中市場定價交易成交統計資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse07 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                                        if (InformationTime == "999999")
                                            break;

                                        mPCommodity = m_PCommodityList.Set("1000", "1000", m_CMarket.Market, CommodityKind.Index);

                                        if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None,"", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), "", "", 0.0, 0.0, 0.0, 1, "",""); }

                                        if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq != InformationSeq)
                                        {
                                            AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));                                            
                                            AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));
                                            AccountOrderTotal = int.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00"));

                                            //InformationSeq = "1" + InformationSeq.Substring(1);

                                            mPCommodity.SetMatch(mPCommodity.QCommodity.Match.InformationTime, mPCommodity.QCommodity.Match.InformationSeq, 3, InformationTime, mPCommodity.QCommodity.Match.MatchPrice, AccountQuantityTotal, AccountSumTotal, AccountSumTotal + mPCommodity.QCommodity.Match.MatchTotalAmt, AccountQuantityTotal + mPCommodity.QCommodity.Match.MatchTotalQty, AccountOrderTotal + mPCommodity.QCommodity.Match.MatchTotalCnt, 0, 0);
                                            
                                            //DoSendWrite(mPCommodity.QCommodity.Match);
                                            
                                        }           
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse07 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 8:
                                    #region //集中市場定價交易委託統計資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse08 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 9:
                                    #region //集中市場定價交易個股成交資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse09 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        MatchPrice = 0.0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        //if (sCommodityCode == 0) { break; }
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        MatchPrice = double.Parse(int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00") + int.Parse(bte[21].ToString("x")).ToString("00")) / 100;
                                        MatchQuantity = int.Parse(int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00"));

                                        //if (mPCommodity == null){mPCommodity = m_CMarket.GetInnerCode(sCommodityCode.ToString());}
                                        /*if (mPCommodity == null) { mPCommodity = m_PCommodityList.Get(sCommodityId); }
                                        if (mPCommodity == null)
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse09 ERROR " + "][No Mapping Code-" + sCommodityId + "]");
                                            break;
                                        }*/
                                        if (mPCommodity == null) { mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); }

                                        if ((mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq != InformationSeq) && MatchQuantity != 0)
                                        {
                                            if (mPCommodity.QCommodity.Match != null)
                                                MatchTOTALQty = mPCommodity.QCommodity.Match.MatchTotalQty;

                                            mPCommodity.SetMatch(MatchTime, InformationSeq, MatchTime, MatchPrice, MatchQuantity, MatchQuantity + MatchTOTALQty);
                                            /*if (m_QuoteSetting.IsCalculateGreeks)
                                                m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                            DoSendWrite(mPCommodity.QCommodity.Match);

                                            if (mPCommodity.QCommodity.Close != null)
                                            {
                                                mPCommodity.SetClose(mPCommodity.QCommodity.Close.InformationTime, mPCommodity.QCommodity.Close.InformationSeq, mPCommodity.QCommodity.Close.DayHighPrice, mPCommodity.QCommodity.Close.DayLowPrice, mPCommodity.QCommodity.Close.OpenPrice, mPCommodity.QCommodity.Close.BuyPrice, mPCommodity.QCommodity.Close.SellPrice, mPCommodity.QCommodity.Close.ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), 0, mPCommodity.QCommodity.Match.MatchTotalQty, 0.0, mPCommodity.QCommodity.Close.SettlementPrice);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse09 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 10:
                                    #region //新編台灣指數資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse10 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        IndexCode = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim(); ;
                                        IndexValue = double.Parse(int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00") + int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00")) / 100;

                                        //Console.WriteLine(IndexCode);

                                        mPCommodity = m_PCommodityList.Set(IndexCode, IndexCode, m_CMarket.Market, CommodityKind.Index);
                                        //mPCommodity.CMarket.SetCommodity(IndexCode, mPCommodity);
                                        CodeMap cm = m_CMarket.GetCodeMap(CommodityKind.Index,IndexCode);
                                      
                                        if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None,"", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), "", "", 0.0, 0.0, 0.0, 1, "",""); }
                                        
                                        if (InformationSeq == "00000000")
                                        {
                                            mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, cm.Code, cm.CodeNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), InformationTime, InformationSeq, IndexValue, 0.0, 0.0, 1, "","");
                                            DoSendWrite(mPCommodity.QCommodity.Base);
                                            /*mPCommodity.Send(Base);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }*/
                                            break;
                                        }
                                        if (InformationSeq == "00000002")
                                        {
                                            mPCommodity.SetOpen(InformationTime, IndexValue);
                                            DoSendWrite(mPCommodity.QCommodity.Open);
                                            /*mPCommodity.Send(Open);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/

                                            mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, IndexValue, InformationTime);
                                            DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            /*mPCommodity.Send(HighLow);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                        }
                                        if (InformationTime == "999999")
                                        {
                                            HighPrice = 0.0;
                                            LowPrice = 0.0;
                                            OpenPrice = 0.0;
                                            AccountSumTotal = 0;
                                            AccountQuantityTotal = 0;
                                            AccountOrderTotal = 0;

                                            if (mPCommodity.QCommodity.Open != null)
                                                OpenPrice = mPCommodity.QCommodity.Open.OpenPrice;
                                            if (mPCommodity.QCommodity.HighLow != null)
                                            {
                                                HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;                                                    
                                            }
                                            if(mPCommodity.QCommodity.Close != null)
                                            {
                                                AccountSumTotal = mPCommodity.QCommodity.Close.MatchTotalAmt;
                                                AccountQuantityTotal = mPCommodity.QCommodity.Close.MatchTotalQty;
                                                AccountOrderTotal = mPCommodity.QCommodity.Close.MatchTotalCnt;
                                            }

                                            mPCommodity.SetClose(InformationTime, InformationSeq, HighPrice, LowPrice, OpenPrice, 0.0, 0.0, IndexValue, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), AccountOrderTotal, AccountQuantityTotal, AccountSumTotal, IndexValue);
                                            DoSendWrite(mPCommodity.QCommodity.Close);
                                            /*mPCommodity.Send(Close);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            
                                        }
                                        if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(InformationSeq)))
                                        {
                                            mPCommodity.SetMatch(InformationTime, InformationSeq, InformationTime, IndexValue, 0, 0);
                                            /*if (m_QuoteSetting.IsCalculateGreeks)
                                                m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                            DoSendWrite(mPCommodity.QCommodity.Match);
                                            /*mPCommodity.Send(Match);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                            HighPrice = 0.0;
                                            LowPrice = 0.0;
                                            if (mPCommodity.QCommodity.HighLow != null)
                                            {
                                                HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                            }

                                            //最高最低
                                            if (int.Parse(InformationSeq) > 1 && (HighPrice < IndexValue || HighPrice == 0.0))
                                            {
                                                mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, LowPrice, InformationTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                /*mPCommodity.Send(HighLow);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                            }
                                            if (int.Parse(InformationSeq) > 1 && (LowPrice > IndexValue || LowPrice == 0.0))
                                            {
                                                mPCommodity.SetHighLow(InformationTime, InformationSeq, HighPrice, IndexValue, InformationTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                /*mPCommodity.Send(HighLow);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                            }                                                
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse10 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                
                                case 12:
                                    #region //集中市場競價交易開(收)盤資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse12 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                                        for (int i = 0; i < StkCnt; i++)
                                        {
                                            //modify 20150610
                                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 28, 6).Trim();
                                            OpenPrice = double.Parse(int.Parse(bte[17 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 28].ToString("x")).ToString("00")) / 100;
                                            HighPrice = double.Parse(int.Parse(bte[20 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 28].ToString("x")).ToString("00")) / 100;
                                            LowPrice = double.Parse(int.Parse(bte[23 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[24 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[25 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchPrice = double.Parse(int.Parse(bte[26 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[27 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[28 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[29 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[30 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[31 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[32 + i * 28].ToString("x")).ToString("00"));
                                            ShowTime = int.Parse(bte[33 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[34 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[35 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[36 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[37 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[38 + i * 28].ToString("x")).ToString("00");
                                            ShowTime = ShowTime.Substring(0, 6);

                                            mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); 

                                            if ((mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0) && OpenPrice != 0.0)
                                            {
                                                mPCommodity.SetOpen(ShowTime, OpenPrice);
                                                DoSendWrite(mPCommodity.QCommodity.Open);
                                                /*mPCommodity.Send(Open);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/
                                            }

                                            if (mPCommodity.QCommodity.HighLow == null)
                                            {
                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }
                                            else
                                            {
                                                if (mPCommodity.QCommodity.HighLow.DayHighPrice > HighPrice)
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                if (mPCommodity.QCommodity.HighLow.DayLowPrice < LowPrice)
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;

                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }

                                            //if (ShowTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.ClosePrice == 0.0))
                                            if (ShowTime == "999999")
                                            {
                                                BuyPriceBest1 = 0.0;
                                                SellPriceBest1 = 0.0;

                                                if(mPCommodity.QCommodity.Best5 != null)
                                                {
                                                    BuyPriceBest1 = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                                                    SellPriceBest1 = mPCommodity.QCommodity.Best5.SellPriceBest1;
                                                }

                                                ClosePrice = MatchPrice;
                                                SettlePrice = MatchPrice;
                                                if (SettlePrice == 0.0) { SettlePrice = mPCommodity.QCommodity.Base.ReferencePrice; }

                                                mPCommodity.SetClose(ShowTime, InformationSeq, HighPrice, LowPrice, OpenPrice, BuyPriceBest1, SellPriceBest1, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), 0, MatchTOTALQty, 0.0, SettlePrice);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse12 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 13:
                                    #region //集中市場零股交易即時揭示資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse13 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 14:
                                    #region //集中市場認購(售)權證全稱資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse14 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 15:
                                    #region //集中市場當日停止交易股票資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse15 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 16:
                                    #region //集中市場行情傳輸系統HeartBeat資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse16 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 17:
                                    #region //第二IP集中市場競價交易即時行情資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse17 ERROR CHECKSUM ERROR]");
                                            break;
                                        }
                                        //modify 20150610
                                        nPos = 29;

                                        MatchPrice = 0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;
                                        OpenPrice = 0;
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        //modify 20150610
                                        sDisPlayTag = (int)bte[22];                                        
                                        sFallRiseTag = (int)(bte[23] & 3);
                                                                                
                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost && m_QuoteSetting.IsRegisterAll)
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Tse_Match_seq != 1 && Match_seq > Tse_Match_seq)
                                                {
                                                    Tse_PacketLost_Qty += Match_seq - Tse_Match_seq - 1;
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse2_Error][Lost Tse_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Tse_PacketLost_Qty + " Last:" + Tse_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Tse_PacketLost_Qty = 0;

                                            if (Match_seq > Tse_Match_seq)
                                                Tse_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        //modify 20150610
                                        MatchTOTALQty = int.Parse(int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            //modify 20150610
                                            MatchQuantity = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        //if (mPCommodity == null) { mPCommodity = m_CMarket.GetInnerCode(sCommodityCode.ToString()); }
                                        /*if (mPCommodity == null) { mPCommodity = m_PCommodityList.Get(sCommodityId); }

                                        if (mPCommodity == null)
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse17 ERROR " + "][No Mapping Code-" + sCommodityId + "]");
                                            break;
                                        }*/
                                        if (mPCommodity == null) { mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); }

                                        //if (!(mPCommodity.CommodityId == "032701" || mPCommodity.CommodityId == "2823")) { continue; }

                                        #region 寫HTicks

                                        /*if (MatchTime.Length >= 6 && int.Parse(MatchTime.Substring(0, 6)) >= 90000)
                                        {
                                            HTicks HTicks = new HTicks();
                                            HTicks.TradeDate = DateTime.Now.ToString("yyyy/MM/dd");
                                            HTicks.CommodityId = mPCommodity.CommodityId;
                                            HTicks.InformationTime = MatchTime;
                                            HTicks.InformationSeq = InformationSeq;
                                            HTicks.MatchSeq = 1;
                                            HTicks.MatchTime = MatchTime;
                                            HTicks.MatchPrice = MatchPrice;
                                            HTicks.MatchTotalQty = MatchTOTALQty;
                                            HTicks.BuyPriceBest1 = BuyPriceBest1;
                                            HTicks.BuyQtyBest1 = BuyQtyBest1;
                                            HTicks.SellPriceBest1 = SellPriceBest1;
                                            HTicks.SellQtyBest1 = SellQtyBest1;

                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || int.Parse(mPCommodity.QCommodity.Match.MatchTime.Substring(0, 6)) < 90000 || MatchTOTALQty == 0)
                                                HTicks.MatchQty = MatchTOTALQty;
                                            else
                                                HTicks.MatchQty = MatchTOTALQty - mPCommodity.QCommodity.Match.MatchTotalQty;

                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HTicks); }
                                        }*/

                                        #endregion

                                        //if (BuyQtyBest1 != 0 || SellQtyBest1 != 0)
                                        if (IsHasBidAsk)
                                        {   

                                            if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(InformationSeq)))
                                            {
                                                mPCommodity.SetBest5(MatchTime, InformationSeq, BuyPriceBest1, BuyQtyBest1, BuyPriceBest2, BuyQtyBest2, BuyPriceBest3, BuyQtyBest3, BuyPriceBest4, BuyQtyBest4, BuyPriceBest5, BuyQtyBest5, SellPriceBest1, SellQtyBest1, SellPriceBest2, SellQtyBest2, SellPriceBest3, SellQtyBest3, SellPriceBest4, SellQtyBest4, SellPriceBest5, SellQtyBest5);
                                                //Util.ExecSqlCmd("insert into pbest5ticks(CommodityId,InformationTime,InformationSeq,BuyPriceBest1,BuyQtyBest1,SellPriceBest1,SellQtyBest1) values('" + mPCommodity.CommodityId + "','" + MatchTime + "','" + InformationSeq + "'," + BuyPriceBest1 + "," + BuyQtyBest1 + "," + SellPriceBest1 + "," + SellQtyBest1 + ")", m_QuoteSetting.DBConnectString);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Best5);*/
                                                DoSendWrite(mPCommodity.QCommodity.Best5);
                                                /*mPCommodity.Send(Best5);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Best5); }*/
                                            }
                                        }

                                        if (MatchPrice != 0.0)
                                        {
                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.MatchTime) <= int.Parse(MatchTime)))
                                            {
                                                if (mPCommodity.QCommodity.Match != null)
                                                    oldMatchTOTALQty = mPCommodity.QCommodity.Match.MatchTotalQty;

                                                if (mPCommodity.QCommodity.Match != null && MatchTOTALQty <= oldMatchTOTALQty)
                                                    break;

                                                if (MatchTOTALQty == 0)
                                                    break;

                                                mPCommodity.SetMatch(MatchTime, InformationSeq, MatchTime, MatchPrice, MatchTOTALQty - oldMatchTOTALQty, MatchTOTALQty);
                                                
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                DoSendWrite(mPCommodity.QCommodity.Match);
                                                /*mPCommodity.Send(Match);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                                if(mPCommodity.QCommodity.HighLow == null)
                                                {
                                                    mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, MatchPrice, MatchTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                                else
                                                {                                                
                                                    if (mPCommodity.QCommodity.HighLow.DayHighPrice < MatchPrice || (mPCommodity.QCommodity.HighLow.DayHighPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, mPCommodity.QCommodity.HighLow.DayLowPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                    if (mPCommodity.QCommodity.HighLow.DayLowPrice > MatchPrice || (mPCommodity.QCommodity.HighLow.DayLowPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, mPCommodity.QCommodity.HighLow.DayHighPrice, MatchPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                }
                                                
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse17 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 18:
                                    #region //第二IP集中市場競價交易開(收)盤資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Tse18 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                                        for (int i = 0; i < StkCnt; i++)
                                        {
                                            //modify 20150610
                                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 28, 6).Trim();
                                            OpenPrice = double.Parse(int.Parse(bte[17 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 28].ToString("x")).ToString("00")) / 100;
                                            HighPrice = double.Parse(int.Parse(bte[20 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 28].ToString("x")).ToString("00")) / 100;
                                            LowPrice = double.Parse(int.Parse(bte[23 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[24 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[25 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchPrice = double.Parse(int.Parse(bte[26 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[27 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[28 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[29 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[30 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[31 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[32 + i * 28].ToString("x")).ToString("00"));
                                            ShowTime = int.Parse(bte[33 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[34 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[35 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[36 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[37 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[38 + i * 28].ToString("x")).ToString("00");
                                            ShowTime = ShowTime.Substring(0, 6);

                                            mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None);
                                            
                                            if (mPCommodity.QCommodity.Open == null && OpenPrice != 0.0)
                                            {
                                                mPCommodity.SetOpen(ShowTime, OpenPrice);
                                                DoSendWrite(mPCommodity.QCommodity.Open);
                                                /*mPCommodity.Send(Open);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/
                                            }

                                            if (mPCommodity.QCommodity.HighLow == null)
                                            {
                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }
                                            else
                                            {
                                                if (mPCommodity.QCommodity.HighLow.DayHighPrice > HighPrice)
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                if (mPCommodity.QCommodity.HighLow.DayLowPrice < LowPrice)
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;

                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }

                                            //if (ShowTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.ClosePrice == 0.0))
                                            if (ShowTime == "999999")
                                            {
                                                BuyPriceBest1 = 0.0;
                                                SellPriceBest1 = 0.0;

                                                if(mPCommodity.QCommodity.Best5 != null)
                                                {
                                                    BuyPriceBest1 = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                                                    SellPriceBest1 = mPCommodity.QCommodity.Best5.SellPriceBest1;
                                                }

                                                ClosePrice = MatchPrice;
                                                SettlePrice = MatchPrice;
                                                if (SettlePrice == 0.0) { SettlePrice = mPCommodity.QCommodity.Base.ReferencePrice; }

                                                mPCommodity.SetClose(ShowTime, InformationSeq, HighPrice, LowPrice, OpenPrice, BuyPriceBest1, SellPriceBest1, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), 0, MatchTOTALQty, 0.0, SettlePrice);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse18 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 19:
                                    #region //集中市場當日暫停/恢復交易股票資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse14 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                default:
                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][tCode=" + tCode + "] " + "Tse TRANSMISSION_CODE ERROR");
                                    break;                               
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }               
        }
        private void DealWithOtc()
        {
            string InformationSeq;
            string InformationTime;
            int Packetlength = 0;
            int StkCnt = 0;

            string sCommodityId;
            string sCommodityNm;
            string stkProperty;
            string stkState;
            //int sCommodityCode = 0;
            int sUnusualCode = 0;
            double sRiseLimitPrice = 0.0;
            double sReferencePrice = 0.0;
            double sFallLimitPrice = 0.0;

            int sDisPlayTag = 0;
            int sFallRiseTag = 0;
            int nResult = 0;
            int nPos = 21;

            string MatchTime;
            double MatchPrice = 0.0;
            int MatchQuantity = 0;
            int MatchTOTALQty = 0;
            int oldMatchTOTALQty = 0;

            double HighPrice = 0.0;
            double LowPrice = 0.0;
            double OpenPrice = 0.0;
            double ClosePrice = 0.0;
            double SettlePrice = 0.0;
            string ShowTime;

            double AccountSum = 0;
            int AccountQuantity = 0;
            int AccountOrder = 0;
            double AccountSumTotal = 0;
            int AccountQuantityTotal = 0;
            int AccountOrderTotal = 0;

            int BuyOrder = 0;
            int BuyQuantity = 0;
            int SellOrder = 0;
            int SellQuantity = 0;

            string BultinKey;
            string BultinData;

            string IndexCode = "";
            int IndexItems = 0;
            double IndexValue = 0.0;

            double BuyPriceBest1 = 0.0;
            int BuyQtyBest1 = 0;
            double BuyPriceBest2 = 0.0;
            int BuyQtyBest2 = 0;
            double BuyPriceBest3 = 0.0;
            int BuyQtyBest3 = 0;
            double BuyPriceBest4 = 0.0;
            int BuyQtyBest4 = 0;
            double BuyPriceBest5 = 0.0;
            int BuyQtyBest5 = 0;
            double SellPriceBest1 = 0.0;
            int SellQtyBest1 = 0;
            double SellPriceBest2 = 0.0;
            int SellQtyBest2 = 0;
            double SellPriceBest3 = 0.0;
            int SellQtyBest3 = 0;
            double SellPriceBest4 = 0.0;
            int SellQtyBest4 = 0;
            double SellPriceBest5 = 0.0;
            int SellQtyBest5 = 0;

            int sLeftQty = 0;
            double sStrikePrice = 0.0;
            double sExecRatio = 0.0;

            int Unit = 0;
            int Match_seq;
            int Otc_Match_seq = 0;
            int Otc_PacketLost_Qty = 0;

            string CurrencyId = "";

            byte[] sCheckSum;
            byte[] bte;

            PCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            if (!CMarket.IsTrade)
                                continue;

                            Packetlength = int.Parse(int.Parse(bte[1].ToString("x")).ToString("00") + int.Parse(bte[2].ToString("x")).ToString("00"));
                            InformationSeq = int.Parse(bte[6].ToString("x")).ToString("00") + int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00");
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(bte[4].ToString("x"));

                            if (!m_QuoteSetting.IsRegisterAll)
                            {
                                string gCommodityId = "";
                                //int gCommodityCode = 0;

                                /*if (tCode == 1)
                                {
                                    gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                    mPCommodity = m_PCommodityList.Get(gCommodityId);

                                    if (mPCommodity == null)
                                        continue;
                                }
                                else if (tCode == 6 || tCode == 9)
                                {
                                    gCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                    mPCommodity = m_CMarket.GetInnerCode(gCommodityCode.ToString());

                                    if (mPCommodity == null)
                                        continue;
                                }*/
                                if (tCode == 1 || tCode == 6 || tCode == 9)
                                {
                                    gCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                    mPCommodity = m_PCommodityList.Get(gCommodityId);

                                    if (mPCommodity == null)
                                        continue;
                                }                                
                            }

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                case 1:
                                    #region //上櫃個股基本資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc01 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                                        if (sCommodityId == "000000") { break; }

                                        sCommodityNm = System.Text.UnicodeEncoding.Default.GetString(bte, 16, 6).Trim();
                                        stkProperty = System.Text.UnicodeEncoding.Default.GetString(bte, 22, 2).Trim();
                                        stkState = System.Text.UnicodeEncoding.Default.GetString(bte, 24, 2).Trim();
                                        //sCommodityCode = int.Parse(int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00"));
                                        sUnusualCode = int.Parse(bte[28].ToString("x"));
                                        sReferencePrice = double.Parse(int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00")) / 100;
                                        sRiseLimitPrice = double.Parse(int.Parse(bte[33].ToString("x")).ToString("00") + int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00")) / 100;
                                        sFallLimitPrice = double.Parse(int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) / 100;
                                        //Unit = int.Parse(int.Parse(bte[63].ToString("x")).ToString("00") + int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00"));
                                        /*string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 39, 1).Trim();
                                        sStrikePrice = double.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00")) / 100;
                                        sLeftQty = int.Parse(int.Parse(bte[54].ToString("x")).ToString("00") + int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00"));
                                        sExecRatio = double.Parse(int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00")) / 100 / 1000;                                        
                                        Unit = 1000;*/

                                        string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 42, 1).Trim();
                                        sStrikePrice = double.Parse(int.Parse(bte[43].ToString("x")).ToString("00") + int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00")) / 100;
                                        sLeftQty = int.Parse(int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00") + int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00"));
                                        sExecRatio = double.Parse(int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00") + int.Parse(bte[64].ToString("x")).ToString("00") + int.Parse(bte[65].ToString("x")).ToString("00")) / 100 / 1000;                                        
                                        Unit = int.Parse(int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00"));
                                        CurrencyId = System.Text.UnicodeEncoding.Default.GetString(bte, 69, 3).Trim();

                                        if (TSECurrencyMap.ContainsKey(CurrencyId)) { CurrencyId = TSECurrencyMap[CurrencyId].ToString(); }

                                        if (CurrencyId == "") { CurrencyId = "NTD"; }

                                        if (m_QuoteSetting.IsWriteToDb)
                                            Util.ExecSqlCmd("EXEC spUpdateCurrency '" + sCommodityId + "','" + CurrencyId + "'", m_QuoteSetting.DBConnectString);

                                        //mPCommodity.CMarket.SetCommodity(sCommodityCode, mPCommodity);

                                        //if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone) || mPCommodity.QCommodity.Base.InformationSeq == null || mPCommodity.QCommodity.Base.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Base.InformationSeq) <= int.Parse(InformationSeq)))
                                        //{
                                            CommodityKind sCommodityKind = CommodityKind.Stock;
                                            CommodityType sCommodityType = CommodityType.None;

                                            GetCommodityKind(sCommodityId, ref sCommodityKind, ref sCommodityType);
                                            mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, sCommodityKind);
                                            mPCommodity.IsLocalCommodity = true;    
                                            mPCommodity.SetBase(m_CMarket.Market, sCommodityKind, sCommodityType, "", sCommodityNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), "", InformationSeq, sReferencePrice, sRiseLimitPrice, sFallLimitPrice, Unit, "", stkProperty);
                                            DoSendWrite(mPCommodity.QCommodity.Base);

                                            if (IsWarrantFlag == "Y")
                                            {
                                                mPCommodity.SetExtra(sCommodityId, sStrikePrice, sExecRatio);
                                                if (m_QuoteSetting.IsWriteToDb)
                                                    Util.ExecSqlCmd("EXEC spWarrantExtra '" + sCommodityId + "'," + sStrikePrice + "," + sExecRatio + "," + sLeftQty, m_QuoteSetting.DBConnectString);                                                
                                            }        
                                            
                                            /*mPCommodity.Send(Base);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }*/
                                        //}
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc01 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 2:
                                    #region //上櫃等價交易成交統計資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc02 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                                        mPCommodity = m_PCommodityList.Set("4000", "4000", m_CMarket.Market, CommodityKind.Index);

                                        if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None,"", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today,m_CMarket.TimeZone), "", "", 0, 0, 0, 1, "",""); }

                                        if (InformationSeq == "00000000") { break; }

                                        if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) <= int.Parse(InformationSeq)))
                                        {
                                            AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));
                                            AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));
                                            AccountOrderTotal = int.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00"));

                                            if (mPCommodity.QCommodity.Match != null)
                                            {
                                                AccountSum = AccountSumTotal - mPCommodity.QCommodity.Match.MatchTotalAmt;
                                                AccountQuantity = (int)(AccountQuantityTotal - mPCommodity.QCommodity.Match.MatchTotalQty);
                                                AccountOrder = (int)(AccountOrderTotal - mPCommodity.QCommodity.Match.MatchTotalCnt);
                                                MatchPrice = mPCommodity.QCommodity.Match.MatchPrice;
                                            }
                                            else
                                            {
                                                AccountSum = AccountSumTotal;
                                                AccountQuantity = AccountQuantityTotal;
                                                AccountOrder = AccountOrderTotal;
                                                MatchPrice = 0.0;
                                            }

                                            if (!(AccountSum == 0.0 && AccountQuantity == 0 && AccountOrder == 0))
                                            {
                                                mPCommodity.SetMatch(InformationTime, InformationSeq, 2, InformationTime, MatchPrice, AccountQuantity, AccountSum, AccountSumTotal, AccountQuantityTotal, AccountOrderTotal, 0, 0);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                if (InformationTime != "999999")
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                else
                                                    mPCommodity.QCommodity.Match.MatchSeq = 1;
                                            }
                                            /*mPCommodity.Send(Match);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/
                                        }

                                        //if (InformationTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.MatchTotalAmt == 0.0))
                                        if (InformationTime == "999999")
                                        {
                                            HighPrice = 0.0;
                                            LowPrice = 0.0;
                                            OpenPrice = 0.0;
                                            ClosePrice = 0.0;

                                            if (mPCommodity.QCommodity.Open != null)
                                                OpenPrice = mPCommodity.QCommodity.Open.OpenPrice;
                                            if (mPCommodity.QCommodity.HighLow != null)
                                            {
                                                HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                            }
                                            if (mPCommodity.QCommodity.Close != null)
                                                ClosePrice = mPCommodity.QCommodity.Close.ClosePrice;

                                            mPCommodity.SetClose(InformationTime, InformationSeq, HighPrice, LowPrice, OpenPrice, 0.0, 0.0, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), AccountOrderTotal, AccountQuantityTotal, AccountSumTotal, ClosePrice);
                                            DoSendWrite(mPCommodity.QCommodity.Close);
                                            /*mPCommodity.Send(Close);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc02 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 3:
                                    #region //上櫃等價交易指數統計資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc03 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                                        IndexItems = int.Parse(int.Parse(bte[13].ToString("x")).ToString("00"));

                                        for (int k = 0; k < IndexItems; k++)
                                        {
                                            switch (k)
                                            {
                                                case 0:
                                                    IndexCode = "4000";//上　櫃
                                                    break;
                                                case 1:
                                                    IndexCode = "4001";//電子類
                                                    break;
                                                case 2:
                                                    IndexCode = "4002";//食品類
                                                    break;
                                                case 3:
                                                    IndexCode = "4003";//塑膠類
                                                    break;
                                                case 4:
                                                    IndexCode = "4004";//紡纖類
                                                    break;
                                                case 5:
                                                    IndexCode = "4005";//電機類
                                                    break;
                                                case 6:
                                                    IndexCode = "4006";//電器類
                                                    break;
                                                case 7:
                                                    IndexCode = "4007";//玻璃類
                                                    break;
                                                case 8:
                                                    IndexCode = "4008";//鋼鐵類
                                                    break;
                                                case 9:
                                                    IndexCode = "4009";//橡膠類
                                                    break;
                                                case 10:
                                                    IndexCode = "4010";//營建類
                                                    break;
                                                case 11:
                                                    IndexCode = "4011";//航運類
                                                    break;
                                                case 12:
                                                    IndexCode = "4012";//觀光類
                                                    break;
                                                case 13:
                                                    IndexCode = "4013";//金融類
                                                    break;
                                                case 14:
                                                    IndexCode = "4014";//百貨類
                                                    break;
                                                case 15:
                                                    IndexCode = "4015";//化工類
                                                    break;
                                                case 16:
                                                    IndexCode = "4016";//生技醫療類
                                                    break;
                                                case 17:
                                                    IndexCode = "4017";//油電燃氣類
                                                    break;
                                                case 18:
                                                    IndexCode = "4018";//半導體類
                                                    break;
                                                case 19:
                                                    IndexCode = "4019";//電腦週邊設備類
                                                    break;
                                                case 20:
                                                    IndexCode = "4020";//光電類
                                                    break;
                                                case 21:
                                                    IndexCode = "4021";//通信網路類
                                                    break;
                                                case 22:
                                                    IndexCode = "4022";//電子零組件類
                                                    break;
                                                case 23:
                                                    IndexCode = "4023";//電子通路類
                                                    break;
                                                case 24:
                                                    IndexCode = "4024";//資訊服務類
                                                    break;
                                                default:
                                                    break;
                                            }

                                            IndexValue = double.Parse(int.Parse(bte[14 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[15 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[16 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[17 + 4 * k].ToString("x")).ToString("00")) / 100;

                                            mPCommodity = m_PCommodityList.Set(IndexCode, IndexCode, m_CMarket.Market, CommodityKind.Index);
                                            mPCommodity.IsLocalCommodity = true;
                                            //mPCommodity.CMarket.SetCommodity(IndexCode, mPCommodity);
                                            CodeMap cm = m_CMarket.GetCodeMap(CommodityKind.Index,IndexCode);

                                            if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, "", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), "", "", 0, 0, 0, 1, "", ""); }

                                            if (InformationSeq == "00000000")
                                            {
                                                mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, cm.Code, cm.CodeNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), InformationTime, InformationSeq, IndexValue, 0, 0, 1, "", "");
                                                DoSendWrite(mPCommodity.QCommodity.Base);
                                                /*mPCommodity.Send(Base);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }*/
                                                continue;
                                            }
                                            if (InformationSeq == "00000002")
                                            {
                                                mPCommodity.SetOpen(InformationTime, IndexValue);
                                                DoSendWrite(mPCommodity.QCommodity.Open);
                                                /*mPCommodity.Send(Open);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/
                                                mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, IndexValue, InformationTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                /*mPCommodity.Send(HighLow);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                            }
                                            //if (InformationTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.ClosePrice == 0.0))
                                            if (InformationTime == "999999")
                                            {
                                                HighPrice = 0.0;
                                                LowPrice = 0.0;
                                                OpenPrice = 0.0;
                                                AccountSumTotal = 0;
                                                AccountQuantityTotal = 0;
                                                AccountOrderTotal = 0;

                                                if (mPCommodity.QCommodity.Open != null)
                                                    OpenPrice = mPCommodity.QCommodity.Open.OpenPrice;
                                                if (mPCommodity.QCommodity.HighLow != null)
                                                {
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                                }
                                                if (mPCommodity.QCommodity.Close != null)
                                                {
                                                    AccountSumTotal = mPCommodity.QCommodity.Close.MatchTotalAmt;
                                                    AccountQuantityTotal = mPCommodity.QCommodity.Close.MatchTotalQty;
                                                    AccountOrderTotal = mPCommodity.QCommodity.Close.MatchTotalCnt;
                                                }

                                                mPCommodity.SetClose(InformationTime, InformationSeq, HighPrice, LowPrice, OpenPrice, 0.0, 0.0, IndexValue, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), AccountOrderTotal, AccountQuantityTotal, AccountSumTotal, IndexValue);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }

                                            //if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(InformationSeq)) || InformationTime=="999999")
                                            //{
                                                AccountSumTotal = 0;
                                                AccountQuantityTotal = 0;
                                                AccountOrderTotal = 0;
                                                AccountSum = 0;
                                                AccountQuantity = 0;

                                                if (mPCommodity.QCommodity.Match != null)
                                                {
                                                    AccountSum = mPCommodity.QCommodity.Match.MatchAmt;
                                                    AccountQuantity = mPCommodity.QCommodity.Match.MatchQty;
                                                    AccountSumTotal = mPCommodity.QCommodity.Match.MatchTotalAmt;
                                                    AccountQuantityTotal = mPCommodity.QCommodity.Match.MatchTotalQty;
                                                    AccountOrderTotal = mPCommodity.QCommodity.Match.MatchTotalCnt;
                                                }

                                                mPCommodity.SetMatch(InformationTime, InformationSeq, 1, InformationTime, IndexValue, AccountQuantity, AccountSum, AccountSumTotal, AccountQuantityTotal, AccountOrderTotal, 0, 0);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                //mPCommodity.SetMatch(InformationTime, InformationSeq, InformationTime, IndexValue, 0, 0);

                                                if (IndexCode == "4000")
                                                {
                                                    if (InformationTime == "999999")
                                                    {
                                                        mPCommodity.QCommodity.Match.MatchSeq = 2;
                                                        DoSendWrite(mPCommodity.QCommodity.Match);
                                                    }
                                                    else
                                                    {
                                                        if (m_QuoteSetting.IsSendTicks)
                                                            mPCommodity.Send(mPCommodity.QCommodity.Match.Copy());
                                                        else
                                                            mPCommodity.Send(mPCommodity.QCommodity.Match);
                                                    }
                                                }
                                                else
                                                {
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                }
                                                     
                                                HighPrice = 0.0;
                                                LowPrice = 0.0;
                                                if (mPCommodity.QCommodity.HighLow != null)
                                                {
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                                }

                                                //最高最低
                                                if (int.Parse(InformationSeq) > 1 && (HighPrice < IndexValue || HighPrice == 0.0))
                                                {
                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, LowPrice, InformationTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                                if (int.Parse(InformationSeq) > 1 && (LowPrice > IndexValue || LowPrice == 0.0))
                                                {
                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, HighPrice, IndexValue, InformationTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                            //}
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc03 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 4:
                                    #region //上櫃等價交易委託統計資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc04 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 5:
                                    #region //上櫃公告資訊
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc05 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 6:
                                    #region //上櫃等價交易即時行情資訊
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc06 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        //modify 20150610
                                        nPos = 29;

                                        MatchPrice = 0.0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;
                                        oldMatchTOTALQty = 0;
                                        OpenPrice = 0;
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        //if (sCommodityCode == 0) { break; }

                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        //modify 20150610
                                        sDisPlayTag = (int)bte[22];
                                        sFallRiseTag = (int)(bte[23] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost && m_QuoteSetting.IsRegisterAll)
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Otc_Match_seq != 1 && Match_seq > Otc_Match_seq)
                                                {
                                                    Otc_PacketLost_Qty += Match_seq - Otc_Match_seq - 1;
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Lost Otc_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Otc_PacketLost_Qty + " Last:" + Otc_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Otc_PacketLost_Qty = 0;

                                            if (Match_seq > Otc_Match_seq)
                                                Otc_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        //modify 20150610
                                        MatchTOTALQty = int.Parse(int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            //modify 20150610
                                            MatchQuantity = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        //if (mPCommodity == null) { mPCommodity = m_CMarket.GetInnerCode(sCommodityCode.ToString()); }
                                        /*if (mPCommodity == null) { mPCommodity = m_PCommodityList.Get(sCommodityId); }
                                        if (mPCommodity == null)
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc06 ERROR " + "][No Mapping Code-" + sCommodityId + "]");
                                            break;
                                        }*/
                                        if (mPCommodity == null) { mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); }

                                        #region 寫HTicks

                                        /*if (MatchTime.Length >= 6 && int.Parse(MatchTime.Substring(0, 6)) >= 90000)
                                        {
                                            HTicks HTicks = new HTicks();
                                            HTicks.TradeDate = DateTime.Now.ToString("yyyy/MM/dd");
                                            HTicks.CommodityId = mPCommodity.CommodityId;
                                            HTicks.InformationTime = MatchTime;
                                            HTicks.InformationSeq = InformationSeq;
                                            HTicks.MatchSeq = 1;
                                            HTicks.MatchTime = MatchTime;
                                            HTicks.MatchPrice = MatchPrice;
                                            HTicks.MatchTotalQty = MatchTOTALQty;
                                            HTicks.BuyPriceBest1 = BuyPriceBest1;
                                            HTicks.BuyQtyBest1 = BuyQtyBest1;
                                            HTicks.SellPriceBest1 = SellPriceBest1;
                                            HTicks.SellQtyBest1 = SellQtyBest1;

                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || int.Parse(mPCommodity.QCommodity.Match.MatchTime.Substring(0, 6)) < 90000 || MatchTOTALQty == 0)
                                                HTicks.MatchQty = MatchTOTALQty;
                                            else
                                                HTicks.MatchQty = MatchTOTALQty - mPCommodity.QCommodity.Match.MatchTotalQty;

                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HTicks); }
                                        }*/

                                        #endregion

                                        //if (BuyQtyBest1 != 0 || SellQtyBest1 != 0)
                                        if (IsHasBidAsk)
                                        {
                                            if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(InformationSeq)))
                                            {
                                                mPCommodity.SetBest5(MatchTime, InformationSeq, BuyPriceBest1, BuyQtyBest1, BuyPriceBest2, BuyQtyBest2, BuyPriceBest3, BuyQtyBest3, BuyPriceBest4, BuyQtyBest4, BuyPriceBest5, BuyQtyBest5, SellPriceBest1, SellQtyBest1, SellPriceBest2, SellQtyBest2, SellPriceBest3, SellQtyBest3, SellPriceBest4, SellQtyBest4, SellPriceBest5, SellQtyBest5);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Best5);*/
                                                DoSendWrite(mPCommodity.QCommodity.Best5);
                                                /*mPCommodity.Send(Best5);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Best5); }*/
                                            }
                                        }

                                        if (MatchPrice != 0.0)
                                        {
                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.MatchTime) <= int.Parse(MatchTime)))
                                            {
                                                if (mPCommodity.QCommodity.Match != null)
                                                    oldMatchTOTALQty = mPCommodity.QCommodity.Match.MatchTotalQty;

                                                if (mPCommodity.QCommodity.Match != null && MatchTOTALQty <= oldMatchTOTALQty)
                                                    break;

                                                if (MatchTOTALQty == 0)
                                                    break;

                                                mPCommodity.SetMatch(MatchTime, InformationSeq, MatchTime, MatchPrice, MatchTOTALQty - oldMatchTOTALQty, MatchTOTALQty);
                                                mPCommodity.QCommodity.Match.FallRiseTag = sFallRiseTag;
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                DoSendWrite(mPCommodity.QCommodity.Match);
                                                                                                
                                                /*mPCommodity.Send(Match);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                                if (mPCommodity.QCommodity.HighLow == null)
                                                {
                                                    mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, MatchPrice, MatchTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                                else
                                                {
                                                    if (mPCommodity.QCommodity.HighLow.DayHighPrice < MatchPrice || (mPCommodity.QCommodity.HighLow.DayHighPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, mPCommodity.QCommodity.HighLow.DayLowPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                    if (mPCommodity.QCommodity.HighLow.DayLowPrice > MatchPrice || (mPCommodity.QCommodity.HighLow.DayLowPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, mPCommodity.QCommodity.HighLow.DayHighPrice, MatchPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                }                                                
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc06 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 7:
                                    #region //上櫃定價交易成交統計資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc07 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                                        if (InformationTime == "999999")
                                            break;

                                        mPCommodity = m_PCommodityList.Set("4000", "4000", m_CMarket.Market, CommodityKind.Index);

                                        if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, "", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), "", "", 0, 0, 0, 1, "", ""); }

                                        if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq != InformationSeq)
                                        {
                                            AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));
                                            AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));
                                            AccountOrderTotal = int.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00"));

                                            //InformationSeq = "1" + InformationSeq.Substring(1);
                                            /*if (m_QuoteSetting.IsCalculateGreeks)
                                                m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                            mPCommodity.SetMatch(InformationTime, InformationSeq, 3, InformationTime, mPCommodity.QCommodity.Match.MatchPrice, AccountQuantityTotal, AccountSumTotal, AccountSumTotal + mPCommodity.QCommodity.Match.MatchTotalAmt, AccountQuantityTotal + mPCommodity.QCommodity.Match.MatchTotalQty, AccountOrderTotal + mPCommodity.QCommodity.Match.MatchTotalCnt, 0, 0);
                                            //DoSendWrite(mPCommodity.QCommodity.Match);
                                            /*mPCommodity.Send(Match);
                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc07 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 8:
                                    #region //上櫃定價交易委託統計資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc08 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 9:
                                    #region //上櫃定價交易個股成交資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc09 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        MatchPrice = 0.0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        //if (sCommodityCode == 0) { break; }
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        MatchPrice = double.Parse(int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00") + int.Parse(bte[21].ToString("x")).ToString("00")) / 100;
                                        MatchQuantity = int.Parse(int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00"));

                                        //if (mPCommodity == null) { mPCommodity = m_CMarket.GetInnerCode(sCommodityCode.ToString()); }
                                        /*if (mPCommodity == null) { mPCommodity = m_PCommodityList.Get(sCommodityId); }
                                        if (mPCommodity == null)
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc09 ERROR " + "][No Mapping Code-" + sCommodityId + "]");
                                            break;
                                        }*/
                                        if (mPCommodity == null) { mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); }

                                        if ((mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq != InformationSeq) && MatchQuantity != 0)
                                        {
                                            if (mPCommodity.QCommodity.Match != null)
                                                MatchTOTALQty = mPCommodity.QCommodity.Match.MatchTotalQty;

                                            mPCommodity.SetMatch(MatchTime, InformationSeq, MatchTime, MatchPrice, MatchQuantity, MatchTOTALQty + MatchQuantity);
                                            /*if (m_QuoteSetting.IsCalculateGreeks)
                                                m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                            DoSendWrite(mPCommodity.QCommodity.Match);

                                            if (mPCommodity.QCommodity.Close != null)
                                            {
                                                mPCommodity.SetClose(mPCommodity.QCommodity.Close.InformationTime, mPCommodity.QCommodity.Close.InformationSeq, mPCommodity.QCommodity.Close.DayHighPrice, mPCommodity.QCommodity.Close.DayLowPrice, mPCommodity.QCommodity.Close.OpenPrice, mPCommodity.QCommodity.Close.BuyPrice, mPCommodity.QCommodity.Close.SellPrice, mPCommodity.QCommodity.Close.ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), 0, mPCommodity.QCommodity.Match.MatchTotalQty, 0.0, mPCommodity.QCommodity.Close.SettlementPrice);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc09 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 10:
                                    #region //上櫃定價交易個股委託資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc10 ERROR CHECKSUM ERROR]");
                                            break;
                                        }
                                        
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc10 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 11:
                                    #region //上櫃等價交易開(收)盤資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc11 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                                        for (int i = 0; i < StkCnt; i++)
                                        {
                                            //modify 20150610
                                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 28, 6).Trim();
                                            OpenPrice = double.Parse(int.Parse(bte[17 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 28].ToString("x")).ToString("00")) / 100;
                                            HighPrice = double.Parse(int.Parse(bte[20 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 28].ToString("x")).ToString("00")) / 100;
                                            LowPrice = double.Parse(int.Parse(bte[23 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[24 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[25 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchPrice = double.Parse(int.Parse(bte[26 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[27 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[28 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[29 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[30 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[31 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[32 + i * 28].ToString("x")).ToString("00"));
                                            ShowTime = int.Parse(bte[33 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[34 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[35 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[36 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[37 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[38 + i * 28].ToString("x")).ToString("00");
                                            ShowTime = ShowTime.Substring(0, 6);

                                            mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None);
                                                                                        
                                            if ((mPCommodity.QCommodity.Open == null || mPCommodity.QCommodity.Open.OpenPrice == 0.0) && OpenPrice != 0.0)
                                            {
                                                mPCommodity.SetOpen(ShowTime, OpenPrice);
                                                DoSendWrite(mPCommodity.QCommodity.Open);
                                                /*mPCommodity.Send(Open);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/
                                            }

                                            if (mPCommodity.QCommodity.HighLow == null)
                                            {
                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }
                                            else
                                            {
                                                if (mPCommodity.QCommodity.HighLow.DayHighPrice > HighPrice)
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                if (mPCommodity.QCommodity.HighLow.DayLowPrice < LowPrice)
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;

                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }

                                            //if (ShowTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.ClosePrice == 0.0))
                                            if (ShowTime == "999999")
                                            {
                                                BuyPriceBest1 = 0.0;
                                                SellPriceBest1 = 0.0;
                                                
                                                if (mPCommodity.QCommodity.Best5 != null)
                                                {
                                                    BuyPriceBest1 = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                                                    SellPriceBest1 = mPCommodity.QCommodity.Best5.SellPriceBest1;
                                                }

                                                ClosePrice = MatchPrice;
                                                SettlePrice = MatchPrice;
                                                if (SettlePrice == 0.0) { SettlePrice = mPCommodity.QCommodity.Base.ReferencePrice; }

                                                mPCommodity.SetClose(ShowTime, InformationSeq, HighPrice, LowPrice, OpenPrice, BuyPriceBest1, SellPriceBest1, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), 0, MatchTOTALQty, 0.0, SettlePrice);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc11 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 12:
                                    #region //新編櫃買指數資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc12 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                                        for (int i = 0; i < StkCnt; i++)
                                        {
                                            try
                                            {
                                                InformationTime = int.Parse(bte[17 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 13].ToString("x")).ToString("00");
                                                IndexCode = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 13, 6).Trim(); ;
                                                IndexValue = double.Parse(int.Parse(bte[20 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[23 + i * 13].ToString("x")).ToString("00")) / 100;

                                                mPCommodity = m_PCommodityList.Set(IndexCode, IndexCode, m_CMarket.Market, CommodityKind.Index);
                                                //mPCommodity.CMarket.SetCommodity(IndexCode, mPCommodity);
                                                CodeMap cm = m_CMarket.GetCodeMap(CommodityKind.Index, IndexCode);

                                                if (mPCommodity.QCommodity.Base == null || mPCommodity.QCommodity.Base.TradeDate < TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone)) { mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, "", "", TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), "", "", 0.0, 0.0, 0.0, 1, "", ""); }

                                                if (InformationSeq == "00000000")
                                                {
                                                    mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Index, CommodityType.None, cm.Code, cm.CodeNm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), InformationTime, InformationSeq, IndexValue, 0.0, 0.0, 1, "", "");
                                                    DoSendWrite(mPCommodity.QCommodity.Base);
                                                    /*mPCommodity.Send(Base);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Base); }*/
                                                    continue;
                                                }
                                                if (InformationSeq == "00000002")
                                                {
                                                    mPCommodity.SetOpen(InformationTime, IndexValue);
                                                    DoSendWrite(mPCommodity.QCommodity.Open);
                                                    /*mPCommodity.Send(Open);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/

                                                    mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, IndexValue, InformationTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                                if (InformationTime == "999999")
                                                {
                                                    HighPrice = 0.0;
                                                    LowPrice = 0.0;
                                                    OpenPrice = 0.0;
                                                    AccountSumTotal = 0;
                                                    AccountQuantityTotal = 0;
                                                    AccountOrderTotal = 0;

                                                    if (mPCommodity.QCommodity.Open != null)
                                                        OpenPrice = mPCommodity.QCommodity.Open.OpenPrice;
                                                    if (mPCommodity.QCommodity.HighLow != null)
                                                    {
                                                        HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                        LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                                    }
                                                    if (mPCommodity.QCommodity.Close != null)
                                                    {
                                                        AccountSumTotal = mPCommodity.QCommodity.Close.MatchTotalAmt;
                                                        AccountQuantityTotal = mPCommodity.QCommodity.Close.MatchTotalQty;
                                                        AccountOrderTotal = mPCommodity.QCommodity.Close.MatchTotalCnt;
                                                    }

                                                    mPCommodity.SetClose(InformationTime, InformationSeq, HighPrice, LowPrice, OpenPrice, 0.0, 0.0, IndexValue, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), AccountOrderTotal, AccountQuantityTotal, AccountSumTotal, IndexValue);
                                                    DoSendWrite(mPCommodity.QCommodity.Close);
                                                    /*mPCommodity.Send(Close);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/

                                                }
                                                if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.InformationSeq == null || mPCommodity.QCommodity.Match.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.InformationSeq) < int.Parse(InformationSeq)))
                                                {
                                                    mPCommodity.SetMatch(InformationTime, InformationSeq, InformationTime, IndexValue, 0, 0);
                                                    /*if (m_QuoteSetting.IsCalculateGreeks)
                                                        m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                    DoSendWrite(mPCommodity.QCommodity.Match);
                                                    /*mPCommodity.Send(Match);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                                    HighPrice = 0.0;
                                                    LowPrice = 0.0;
                                                    if (mPCommodity.QCommodity.HighLow != null)
                                                    {
                                                        HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                        LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;
                                                    }

                                                    //最高最低
                                                    if (int.Parse(InformationSeq) > 1 && (HighPrice < IndexValue || HighPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(InformationTime, InformationSeq, IndexValue, LowPrice, InformationTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                    if (int.Parse(InformationSeq) > 1 && (LowPrice > IndexValue || LowPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(InformationTime, InformationSeq, HighPrice, IndexValue, InformationTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                }
                                            }
                                            catch (Exception eg)
                                            {
                                                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc12 ERROR " + "][" + eg.Message + "][" + eg.StackTrace + "]");
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc12 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                
                                case 13:
                                    #region //上櫃零股交易即時揭示資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc13 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 14:
                                    #region //上櫃認購(售)權證全稱資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc14 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 15:
                                    #region //上櫃當日停止交易股票資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc15 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 16:
                                    #region //上櫃行情傳輸系統HeartBeat資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc16 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                
                                case 17:
                                    #region //第二IP上櫃股票等價交易即時行情資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc17 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        //modify 20150610
                                        nPos = 29;

                                        MatchPrice = 0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;
                                        OpenPrice = 0;
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        //modify 20150610
                                        sDisPlayTag = (int)bte[22];
                                        sFallRiseTag = (int)(bte[23] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost && m_QuoteSetting.IsRegisterAll)
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Otc_Match_seq != 1 && Match_seq > Otc_Match_seq)
                                                {
                                                    Otc_PacketLost_Qty += Match_seq - Otc_Match_seq - 1;
                                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc2_Error][Lost Otc_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Otc_PacketLost_Qty + " Last:" + Otc_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Otc_PacketLost_Qty = 0;

                                            if (Match_seq > Otc_Match_seq)
                                                Otc_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        //modify 20150610
                                        MatchTOTALQty = int.Parse(int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));
                                        
                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;                                            
                                            //modify 20150610
                                            MatchQuantity = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        //if (mPCommodity == null) { mPCommodity = m_CMarket.GetInnerCode(sCommodityCode.ToString()); }
                                        /*if (mPCommodity == null) { mPCommodity = m_PCommodityList.Get(sCommodityId); }
                                        if (mPCommodity == null)
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc17 ERROR " + "][No Mapping Code-" + sCommodityId + "]");
                                            break;
                                        }*/
                                        if (mPCommodity == null) { mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None); }

                                        #region 寫HTicks

                                        /*if (MatchTime.Length >= 6 && int.Parse(MatchTime.Substring(0, 6)) >= 90000)
                                        {
                                            HTicks HTicks = new HTicks();
                                            HTicks.TradeDate = DateTime.Now.ToString("yyyy/MM/dd");
                                            HTicks.CommodityId = mPCommodity.CommodityId;
                                            HTicks.InformationTime = MatchTime;
                                            HTicks.InformationSeq = InformationSeq;
                                            HTicks.MatchSeq = 1;
                                            HTicks.MatchTime = MatchTime;
                                            HTicks.MatchPrice = MatchPrice;
                                            HTicks.MatchTotalQty = MatchTOTALQty;
                                            HTicks.BuyPriceBest1 = BuyPriceBest1;
                                            HTicks.BuyQtyBest1 = BuyQtyBest1;
                                            HTicks.SellPriceBest1 = SellPriceBest1;
                                            HTicks.SellQtyBest1 = SellQtyBest1;

                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || int.Parse(mPCommodity.QCommodity.Match.MatchTime.Substring(0, 6)) < 90000 || MatchTOTALQty == 0)
                                                HTicks.MatchQty = MatchTOTALQty;
                                            else
                                                HTicks.MatchQty = MatchTOTALQty - mPCommodity.QCommodity.Match.MatchTotalQty;

                                            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HTicks); }
                                        }*/

                                        #endregion

                                        //if (BuyQtyBest1 != 0 || SellQtyBest1 != 0)
                                        if (IsHasBidAsk)
                                        {
                                            if (mPCommodity.QCommodity.Best5 == null || mPCommodity.QCommodity.Best5.InformationSeq == null || mPCommodity.QCommodity.Best5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QCommodity.Best5.InformationSeq) < int.Parse(InformationSeq)))
                                            {
                                                mPCommodity.SetBest5(MatchTime, InformationSeq, BuyPriceBest1, BuyQtyBest1, BuyPriceBest2, BuyQtyBest2, BuyPriceBest3, BuyQtyBest3, BuyPriceBest4, BuyQtyBest4, BuyPriceBest5, BuyQtyBest5, SellPriceBest1, SellQtyBest1, SellPriceBest2, SellQtyBest2, SellPriceBest3, SellQtyBest3, SellPriceBest4, SellQtyBest4, SellPriceBest5, SellQtyBest5);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Best5);*/
                                                DoSendWrite(mPCommodity.QCommodity.Best5);
                                                /*mPCommodity.Send(Best5);
                                                if (m_QuoteSetting.IsWriteToDb) { WriteDBPool.Enqueue(Best5); }*/
                                            }
                                        }

                                        if (MatchPrice != 0.0)
                                        {
                                            if (mPCommodity.QCommodity.Match == null || mPCommodity.QCommodity.Match.MatchTime == null || mPCommodity.QCommodity.Match.MatchTime == string.Empty || (int.Parse(mPCommodity.QCommodity.Match.MatchTime) <= int.Parse(MatchTime)))
                                            {
                                                if (mPCommodity.QCommodity.Match != null)
                                                    oldMatchTOTALQty = mPCommodity.QCommodity.Match.MatchTotalQty;

                                                if (mPCommodity.QCommodity.Match != null && MatchTOTALQty <= oldMatchTOTALQty)
                                                    break;

                                                if (MatchTOTALQty == 0)
                                                    break;

                                                mPCommodity.SetMatch(MatchTime, InformationSeq, MatchTime, MatchPrice, MatchTOTALQty - oldMatchTOTALQty, MatchTOTALQty);
                                                /*if (m_QuoteSetting.IsCalculateGreeks)
                                                    m_CalculateGreeksPool.Enqueue(mPCommodity.QCommodity.Match);*/
                                                DoSendWrite(mPCommodity.QCommodity.Match);
                                                /*mPCommodity.Send(Match);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Match); }*/

                                                if (mPCommodity.QCommodity.HighLow == null)
                                                {
                                                    mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, MatchPrice, MatchTime);
                                                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                    /*mPCommodity.Send(HighLow);
                                                    if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                }
                                                else
                                                {
                                                    if (mPCommodity.QCommodity.HighLow.DayHighPrice < MatchPrice || (mPCommodity.QCommodity.HighLow.DayHighPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, MatchPrice, mPCommodity.QCommodity.HighLow.DayLowPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                    if (mPCommodity.QCommodity.HighLow.DayLowPrice > MatchPrice || (mPCommodity.QCommodity.HighLow.DayLowPrice == 0.0))
                                                    {
                                                        mPCommodity.SetHighLow(MatchTime, InformationSeq, mPCommodity.QCommodity.HighLow.DayHighPrice, MatchPrice, MatchTime);
                                                        DoSendWrite(mPCommodity.QCommodity.HighLow);
                                                        /*mPCommodity.Send(HighLow);
                                                        if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(HighLow); }*/
                                                    }
                                                }

                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc17 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 18:
                                    #region //第二IP上櫃股票等價交易開(收)盤資料
                                    try
                                    {
                                        Array.Copy(bte, 1, sCheckSum, 0, Packetlength - 4);

                                        if (!Util.FunChechSum(sCheckSum, bte[Packetlength - 3]))
                                        {
                                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Otc18 ERROR CHECKSUM ERROR]");
                                            break;
                                        }

                                        StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                                        for (int i = 0; i < StkCnt; i++)
                                        {
                                            //modify 20150610
                                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 28, 6).Trim();
                                            OpenPrice = double.Parse(int.Parse(bte[17 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 28].ToString("x")).ToString("00")) / 100;
                                            HighPrice = double.Parse(int.Parse(bte[20 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 28].ToString("x")).ToString("00")) / 100;
                                            LowPrice = double.Parse(int.Parse(bte[23 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[24 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[25 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchPrice = double.Parse(int.Parse(bte[26 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[27 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[28 + i * 28].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[29 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[30 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[31 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[32 + i * 28].ToString("x")).ToString("00"));
                                            ShowTime = int.Parse(bte[33 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[34 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[35 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[36 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[37 + i * 28].ToString("x")).ToString("00") + int.Parse(bte[38 + i * 28].ToString("x")).ToString("00");
                                            ShowTime = ShowTime.Substring(0, 6);

                                            mPCommodity = m_PCommodityList.Set("", sCommodityId, m_CMarket.Market, CommodityKind.None);

                                            if (mPCommodity.QCommodity.Open == null && OpenPrice != 0.0)
                                            {
                                                mPCommodity.SetOpen(ShowTime, OpenPrice);
                                                DoSendWrite(mPCommodity.QCommodity.Open);
                                                /*mPCommodity.Send(Open);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Open); }*/
                                            }

                                            if (mPCommodity.QCommodity.HighLow == null)
                                            {
                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }
                                            else
                                            {
                                                if (mPCommodity.QCommodity.HighLow.DayHighPrice > HighPrice)
                                                    HighPrice = mPCommodity.QCommodity.HighLow.DayHighPrice;
                                                if (mPCommodity.QCommodity.HighLow.DayLowPrice < LowPrice)
                                                    LowPrice = mPCommodity.QCommodity.HighLow.DayLowPrice;

                                                mPCommodity.SetHighLow(ShowTime, InformationSeq, HighPrice, LowPrice, ShowTime);
                                                DoSendWrite(mPCommodity.QCommodity.HighLow);
                                            }

                                            //if (ShowTime == "999999" && (mPCommodity.QCommodity.Close == null || mPCommodity.QCommodity.Close.ClosePrice == 0.0))
                                            if (ShowTime == "999999")
                                            {
                                                BuyPriceBest1 = 0.0;
                                                SellPriceBest1 = 0.0;

                                                if (mPCommodity.QCommodity.Best5 != null)
                                                {
                                                    BuyPriceBest1 = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                                                    SellPriceBest1 = mPCommodity.QCommodity.Best5.SellPriceBest1;
                                                }

                                                ClosePrice = MatchPrice;
                                                SettlePrice = MatchPrice;
                                                if (SettlePrice == 0.0) { SettlePrice = mPCommodity.QCommodity.Base.ReferencePrice; }

                                                mPCommodity.SetClose(ShowTime, InformationSeq, HighPrice, LowPrice, OpenPrice, BuyPriceBest1, SellPriceBest1, ClosePrice, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), 0, MatchTOTALQty, 0.0, SettlePrice);
                                                DoSendWrite(mPCommodity.QCommodity.Close);
                                                /*mPCommodity.Send(Close);
                                                if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(Close); }*/
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc18 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 19:
                                    #region //上櫃當日暫停/恢復交易股票資料
                                    try
                                    {
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse14 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                default:
                                    ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][tCode=" + tCode + "] " + "Otc TRANSMISSION_CODE ERROR");
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private string GetMaturity(string SettleMonth)
        {
            string settleday = "";            
            int j = 0;

            if (SettleDateHt.ContainsKey(SettleMonth))
                return SettleDateHt[SettleMonth].ToString();

            try
            {
                DateTime dt = DateTime.ParseExact(SettleMonth + "01", "yyyyMMdd", null);

                for(;;)
                {
                    if (dt.DayOfWeek == DayOfWeek.Wednesday)
                    {
                        j++;
                        if (j == 3) { break; }                            
                    }

                    dt = dt.AddDays(1);
                }

                settleday = dt.ToString("yyyy/MM/dd");

                DataView dv = Util.ExecSqlQry("select convert(varchar,min(tradedate),111) from tradedate where country='TWN' and istrade='Y' and tradedate>='" + settleday + "'", m_QuoteSetting.DBConnectString);

                if (dv.Count > 0)
                    settleday = dv[0][0].ToString();

                SettleDateHt.Add(SettleMonth, settleday);

                return settleday;
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][GetMaturity_Error] [" + ex.Message + "][" + ex.StackTrace + "]");
                return settleday;
            }
        }
        private string GetTGMaturity(string SettleMonth)
        {
            string settleday = "";

            if (TGSettleDateHt.ContainsKey(SettleMonth))
                return TGSettleDateHt[SettleMonth].ToString();

            try
            {
                settleday = SettleMonth.Substring(0, 4) + "/" + SettleMonth.Substring(4, 2) + "/" + "01";
                DataView dv = Util.ExecSqlQry("select min(tradedate) from (select  top 2 * from tradedate where country='TWN' and istrade='Y' and tradedate<dateadd(m,1,'"+settleday+"') order by tradedate desc) a", m_QuoteSetting.DBConnectString);

                if (dv.Count > 0)
                    settleday = dv[0][0].ToString();

                TGSettleDateHt.Add(SettleMonth, settleday);

                return settleday;
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][GetTGMaturity_Error] [" + ex.Message + "][" + ex.StackTrace + "]");
                return settleday;
            }
        }
        private void SetCom(PCommodity mPCommodity)
        {
            try
            {
                if (mPCommodity.CommodityId.Length == 8 && mPCommodity.CommodityId.Substring(5, 1) == "/")
                {
                    //if (mPCommodity.QCommodity.Base.CommodityId == "")
                    //{
                        PCommodity sPCommodity = m_PCommodityList.Get(mPCommodity.CommodityId.Substring(0, 5));
                        if (sPCommodity != null)
                        {
                            string cnm = "";
                            string ccode = "";
                            if (sPCommodity.QCommodity.Base != null) 
                            {
                                ccode = sPCommodity.QCommodity.Base.CommodityCode; 
                                cnm = sPCommodity.QCommodity.Base.CommodityNm; 
                            }
                            mPCommodity.SetBase(m_CMarket.Market, CommodityKind.Future, sPCommodity.QCommodity.Base.CommodityType, ccode, cnm, TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Today, m_CMarket.TimeZone), "", "", sPCommodity.QCommodity.Base.SettleMentMonth, 0, 0, 0, 0, 0, 0, 0, 0, 1, sPCommodity.QCommodity.Base.ProdKind, sPCommodity.QCommodity.Base.DecimalLocate, sPCommodity.QCommodity.Base.StrikeDecimalLocate, "", "");
                            DoSendWrite(mPCommodity.QCommodity.Base);
                            /*mPCommodity.Send(mPCommodity.QCommodity.Base);
                            m_WriteDBPool.Enqueue(mPCommodity.QCommodity.Base);*/
                        }
                    //}
                }
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][SetCom_Error] [" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void GetCommodityKind(string CommodityId, ref CommodityKind sCommodityKind, ref CommodityType sCommodityType)
        {
            try
            {
                sCommodityKind = CommodityKind.Stock;
                sCommodityType = CommodityType.None;

                if (char.IsNumber(CommodityId, 0))
                {
                    if (CommodityId.Substring(0, 2) == "00" && int.Parse(CommodityId.Substring(2, 2)) >= 50 && int.Parse(CommodityId.Substring(2, 2)) <= 99)
                        sCommodityKind = CommodityKind.ETF;
                    else if (CommodityId.Substring(0, 2) == "91" && int.Parse(CommodityId.Substring(2, 2)) >= 0 && int.Parse(CommodityId.Substring(2, 2)) <= 99)
                        sCommodityKind = CommodityKind.TDR;
                    else if (CommodityId.Substring(0, 2) == "01")
                        sCommodityKind = CommodityKind.REITs;
                    else if (CommodityId.Substring(0, 1) == "0" && int.Parse(CommodityId.Substring(1, 3)) >= 300 && int.Parse(CommodityId.Substring(1, 3)) <= 999 && (CommodityId.Length == 5 || CommodityId.Length == 6))
                    {
                        sCommodityKind = CommodityKind.Warrant;
                        if (CommodityId.Substring(CommodityId.Length - 1, 1) == "P" || CommodityId.Substring(CommodityId.Length - 1, 1) == "Q" || CommodityId.Substring(CommodityId.Length - 1, 1) == "B") { sCommodityType = CommodityType.Put; }
                        else { sCommodityType = CommodityType.Call; }
                    }
                    else if (CommodityId.Substring(0, 1) == "7" && int.Parse(CommodityId.Substring(1, 3)) >= 0 && int.Parse(CommodityId.Substring(1, 3)) <= 399 && (CommodityId.Length == 5 || CommodityId.Length == 6))
                    {
                        sCommodityKind = CommodityKind.Warrant;
                        if (CommodityId.Substring(CommodityId.Length - 1, 1) == "P" || CommodityId.Substring(CommodityId.Length - 1, 1) == "Q" || CommodityId.Substring(CommodityId.Length - 1, 1) == "B") { sCommodityType = CommodityType.Put; }
                        else { sCommodityType = CommodityType.Call; }
                    }
                    else if (CommodityId.Substring(0, 1) != "7" && CommodityId.Substring(0, 2) != "91" && CommodityId.Substring(0, 2) != "93" && CommodityId.Substring(0, 2) != "94" && int.Parse(CommodityId.Substring(0, 4)) >= 1000 && int.Parse(CommodityId.Substring(0, 4)) <= 9999 && (CommodityId.Length == 5 || CommodityId.Length == 6) && char.IsNumber(CommodityId, 4))
                        sCommodityKind = CommodityKind.CB;
                    else
                        sCommodityKind = CommodityKind.Stock;
                }
                else
                    sCommodityKind = CommodityKind.Bond;                
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }
        private void DoSendWrite(object obj)
        {         
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);
                        
            if (m_QuoteSetting.IsWriteToDb) 
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2); 
            }

            if (m_QuoteSetting.IsSendTicks && (obj is QMatch || obj is QBest5))
            {
                WriteTicks(mPCommodity,obj);
            }                
        }
        private void DoSendWriteQuery(QueryCls obj)
        {
            if (obj.FOFlag == "F") { m_PCommodityList.FQuery.Send(obj); }
            else { m_PCommodityList.OQuery.Send(obj); }            

            if (m_QuoteSetting.IsWriteToDb) { m_WriteDBPool.Enqueue(obj); }                
        }

        private void WriteTicks(PCommodity mPCommodity,object obj)
        {
            
            StringBuilder str = new StringBuilder();

            str.Append(mPCommodity.QCommodity.Base.CommodityId);

            string market = "";
            string commoditykind = "";

            if (mPCommodity.CMarket != null) { market = Enum.GetName(typeof(Market) ,mPCommodity.CMarket.Market); }
            if (mPCommodity.QCommodity != null && mPCommodity.QCommodity.Base != null) { commoditykind = Enum.GetName(typeof(CommodityKind), mPCommodity.QCommodity.Base.CommodityKind); }

            str.Append("," + market);
            str.Append("," + commoditykind);

            if (obj is QMatch)
                str.Append("," + mPCommodity.QCommodity.Match.MatchTime);
            else if (obj is QBest5)
                str.Append("," + mPCommodity.QCommodity.Best5.InformationTime);

            str.Append("," + mPCommodity.QCommodity.Match.MatchPrice);
            str.Append("," + mPCommodity.QCommodity.Match.MatchQty);
            str.Append("," + mPCommodity.QCommodity.Match.MatchTotalQty);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest1);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest1);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest2);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest2);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest3);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest3);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest4);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest4);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyPriceBest5);
            str.Append("," + mPCommodity.QCommodity.Best5.BuyQtyBest5);
            str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest1);
            str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest1);
            str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest2);
            str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest2);
            str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest3);
            str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest3);
            str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest4);
            str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest4);
            str.Append("," + mPCommodity.QCommodity.Best5.SellPriceBest5);
            str.Append("," + mPCommodity.QCommodity.Best5.SellQtyBest5);

            TicksPool.Enqueue(str.ToString()); 
        }
        #endregion
    }
    /*public class IPushQuoteSource : QuoteSource
    {
        private Thread RoutineThread;
        private string DBConnectString = "";
        private string SubCommodity = "";
        private TimeSpan RecoverTime;
        private bool RecoverFlag = false;
        private DeriLib.FrmIPush.FrmIPush IPush = new DeriLib.FrmIPush.FrmIPush();
        private Hashtable SettleDateHt = Hashtable.Synchronized(new Hashtable());

        public IPushQuoteSource(IPushQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            SubCommodity = QuoteSetting.SubCommodity;
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);            
        }        
        public override bool Start()
        {
            IPush.MsgArrived += new DeriLib.FrmIPush.FrmIPush.MsgArrivedHandler(IPush_MsgArrived);
            IPush.DataArrived += new DeriLib.FrmIPush.FrmIPush.DataArrivedHandler(IPush_DataArrived);
            IPush.Start(SubCommodity);
            
            IPush.RecoverData();

            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            return base.Start();
        }

        private void IPush_DataArrived(object sender, object obj)
        {
            try
            {
                PCommodity mPCommodity = null;

                m_PacketNum++;

                if (obj.GetType() == typeof(QBase))
                {
                    QBase QBase = (QBase)obj;

                    string settledate = GetMaturity(QBase.SettleMentMonth);

                    Util.ExecSqlCmd("EXEC spCommodityExtra '" + QBase.CommodityId + "','TFE','Future','" + settledate + "',0.0", m_QuoteSetting.DBConnectString);

                    mPCommodity = m_PCommodityList.Set(QBase.CommodityId.Substring(0, 3), QBase.CommodityId, Market.TFE, CommodityKind.Future);
                    mPCommodity.IsLocalCommodity = true;
                    mPCommodity.SetBase(Market.TFE, CommodityKind.Future, CommodityType.None, "TWS", "新加坡摩台期", DateTime.Today, QBase.InformationTime, QBase.InformationSeq, QBase.SettleMentMonth, 0, QBase.ReferencePrice, QBase.RiseLimitPrice, QBase.FallLimitPrice, 0.0, 0.0, 0.0, 0.0, 1, QBase.ProdKind, 1, 1, "", "");
                    DoSendWrite(mPCommodity.QCommodity.Base);
                }
                else if (obj.GetType() == typeof(QOpen))
                {
                    QOpen QOpen = (QOpen)obj;

                    mPCommodity = m_PCommodityList.Get(QOpen.CommodityId);

                    if (mPCommodity == null) { return; }

                    mPCommodity.SetOpen(QOpen.OpenTime, QOpen.OpenPrice);
                    DoSendWrite(mPCommodity.QCommodity.Open);
                }
                else if (obj.GetType() == typeof(QBest5))
                {
                    QBest5 QBest5 = (QBest5)obj;

                    mPCommodity = m_PCommodityList.Get(QBest5.CommodityId);

                    if (mPCommodity == null) { return; }

                    mPCommodity.SetBest5(QBest5.InformationTime, QBest5.InformationSeq, QBest5.BuyPriceBest1, QBest5.BuyQtyBest1, QBest5.BuyPriceBest2, QBest5.BuyQtyBest2, QBest5.BuyPriceBest3, QBest5.BuyQtyBest3, QBest5.BuyPriceBest4, QBest5.BuyQtyBest4, QBest5.BuyPriceBest5, QBest5.BuyQtyBest5, QBest5.SellPriceBest1, QBest5.SellQtyBest1, QBest5.SellPriceBest2, QBest5.SellQtyBest2, QBest5.SellPriceBest3, QBest5.SellQtyBest3, QBest5.SellPriceBest4, QBest5.SellQtyBest4, QBest5.SellPriceBest5, QBest5.SellQtyBest5, QBest5.BuyPriceDerived, QBest5.BuyQtyDerived, QBest5.SellPriceDerived, QBest5.SellQtyDerived);
                    DoSendWrite(mPCommodity.QCommodity.Best5);
                }
                else if (obj.GetType() == typeof(QMatch))
                {
                    QMatch QMatch = (QMatch)obj;

                    mPCommodity = m_PCommodityList.Get(QMatch.CommodityId);

                    if (mPCommodity == null) { return; }
                    if (mPCommodity.QCommodity.Match.MatchTime == QMatch.MatchTime && mPCommodity.QCommodity.Match.MatchQty == QMatch.MatchQty)
                        return;

                    mPCommodity.SetMatch(QMatch.InformationTime, QMatch.InformationSeq, QMatch.MatchSeq, QMatch.MatchTime, QMatch.MatchPrice, QMatch.MatchQty, QMatch.MatchAmt, QMatch.MatchTotalAmt, QMatch.MatchTotalQty, QMatch.MatchTotalCnt, QMatch.MatchBuyTotalCnt, QMatch.MatchSellTotalCnt);
                    DoSendWrite(mPCommodity.QCommodity.Match);
                }
                else if (obj.GetType() == typeof(QHighLow))
                {
                    QHighLow QHighLow = (QHighLow)obj;

                    mPCommodity = m_PCommodityList.Get(QHighLow.CommodityId);

                    if (mPCommodity == null) { return; }

                    mPCommodity.SetHighLow(QHighLow.InformationTime, QHighLow.InformationSeq, QHighLow.DayHighPrice, QHighLow.DayLowPrice, QHighLow.ShowTime);
                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                }
                else if (obj.GetType() == typeof(QClose))
                {
                    QClose QClose = (QClose)obj;

                    mPCommodity = m_PCommodityList.Get(QClose.CommodityId);

                    if (mPCommodity == null) { return; }

                    mPCommodity.SetClose(QClose.InformationTime, QClose.InformationSeq, QClose.DayHighPrice, QClose.DayLowPrice, QClose.OpenPrice, QClose.BuyPrice, QClose.SellPrice, QClose.ClosePrice, QClose.CloseDate, QClose.MatchTotalCnt, QClose.MatchTotalQty, QClose.MatchTotalAmt, QClose.ComBuyCnt, QClose.ComBuyQty, QClose.ComSellCnt, QClose.ComSellQty, QClose.ComTotalQty, QClose.SettlementPrice, QClose.OpenInterest, QClose.LastCloseDate, QClose.LastSettlementPrice, QClose.LastOpenInterest);
                    DoSendWrite(mPCommodity.QCommodity.Close);
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][IPush_DataArrived_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void IPush_MsgArrived(object sender, DeriLib.FrmIPush.IPushMsgArgs e)
        {
            if (e.IPushMsg == DeriLib.FrmIPush.IPushMsg.ConnectFail)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][IPush_MsgArrived_Error] " + "[連線失敗]");
                Close();
            }
            else if (e.IPushMsg == DeriLib.FrmIPush.IPushMsg.ConnectLost)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][IPush_MsgArrived_Error] " + "[連線斷線]");
                Close();
            }
        }
        private string GetMaturity(string SettleMonth)
        {
            string settleday = "";
            
            if (SettleDateHt.ContainsKey(SettleMonth))
                return SettleDateHt[SettleMonth].ToString();

            try
            {
                settleday = SettleMonth.Substring(0, 4) + "/" + SettleMonth.Substring(4, 2) + "/" + "01";
                DataView dv = Util.ExecSqlQry("select min(tradedate) from (select  top 2 * from tradedate where country='TWN' and istrade='Y' and tradedate<dateadd(m,1,'" + settleday + "') order by tradedate desc) a", m_QuoteSetting.DBConnectString);

                if (dv.Count > 0)
                    settleday = dv[0][0].ToString();

                SettleDateHt.Add(SettleMonth, settleday);

                return settleday;
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][GetMaturity_Error] [" + ex.Message + "][" + ex.StackTrace + "]");
                return settleday;
            }
        }
        public override bool Close()
        {
            try
            {
                IPush.Close();
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        IPush.RecoverData();
                        RecoverFlag = true;
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }

    }*/ 
    #endregion

    public class TradeTimeMapping
    {
        private QuoteSourceKind QuoteSourceKind = QuoteSourceKind.None;
        private Dictionary<string, string> InfoTimes = new Dictionary<string, string>();
        private TimeSpan FileStartTimeSpan = DateTime.Now.TimeOfDay;
        private DateTime startdt;

        public TradeTimeMapping(QuoteSourceKind QuoteSourceKind, int Div, string FileStartTime)
        {
            int cnt = 0;

            try
            {
                if (FileStartTime != "")
                    FileStartTimeSpan = new TimeSpan(int.Parse(FileStartTime.Substring(0, 2)), int.Parse(FileStartTime.Substring(2, 2)), int.Parse(FileStartTime.Substring(4, 2)));
                else
                    FileStartTimeSpan = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            }
            catch
            {
                FileStartTimeSpan = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            }

            if (Div == 0) { Div = 2000; }

            if (QuoteSourceKind == QuoteSourceKind.TfeFx_File || QuoteSourceKind == QuoteSourceKind.TfeOp_File)
            {
                DateTime dt = DateTime.Now;
                startdt = new DateTime(1900, 1, 1, 8, 45, 0);
                DateTime orderdt = startdt;
                cnt = 18000 / Div;

                for (int i = 0; i < cnt; i++)
                {
                    InfoTimes.Add(dt.ToString("HHmmss"), orderdt.ToString("HHmmss"));

                    dt = dt.AddSeconds(1);
                    orderdt = orderdt.AddSeconds(Div);
                }
            }
            else if (QuoteSourceKind == QuoteSourceKind.Tse_File || QuoteSourceKind == QuoteSourceKind.Otc_File)
            {
                DateTime dt = DateTime.Now;
                startdt = new DateTime(1900, 1, 1, 8, 45, 0);
                DateTime orderdt = startdt;
                cnt = 18000 / Div;

                for (int i = 0; i < cnt; i++)
                {
                    InfoTimes.Add(dt.ToString("HHmmss"), orderdt.ToString("HHmmss"));

                    dt = dt.AddSeconds(1);
                    orderdt = orderdt.AddSeconds(Div);
                }
            }

            this.QuoteSourceKind = QuoteSourceKind;
        }
        public void DoTime(byte[] btes)
        {
            for (; ; )
            {
                string nowtime = DateTime.Now.ToString("HHmmss");
                string time = GetOrderTime(btes);

                if (InfoTimes.ContainsKey(nowtime))
                {
                    string tradetime = InfoTimes[nowtime];
                                        
                    if (int.Parse(time) > int.Parse(tradetime))
                    {
                        Thread.Sleep(1);
                    }
                    else
                    {
                        if (DateTime.Now.TimeOfDay < FileStartTimeSpan && int.Parse(time) >= int.Parse(startdt.ToString("HHmmss")))
                        {
                            Thread.Sleep(1);
                        }
                        else
                            return;
                    }                    
                }
                else
                {
                    return;
                }                    
            }
        }
        private string GetOrderTime(byte[] bte)
        {
            string time = "0";

            if (QuoteSourceKind == QuoteSourceKind.TfeFx_File || QuoteSourceKind == QuoteSourceKind.TfeOp_File)
            {
                time = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00");
            }
            else if (QuoteSourceKind == QuoteSourceKind.Tse_File)
            {
                int tCode = int.Parse(bte[4].ToString("x"));

                switch (tCode)
                {
                    case 1:
                        break;
                    case 2:
                        time = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                        break;
                    case 3:
                        time = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                        break;                    
                    case 6:
                        time = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                        break;
                    case 7:
                        time = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                        break;                    
                    case 9:
                        time = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                        break;
                    case 10:
                        time = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                        break;                    
                    default:
                        break;
                }
            }
            else if (QuoteSourceKind == QuoteSourceKind.Otc_File)
            {
                int tCode = int.Parse(bte[4].ToString("x"));

                switch (tCode)
                {
                    case 1:
                        break;
                    case 2:
                        time = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                        break;
                    case 3:
                        time = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                        break;
                    case 6:
                        time = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                        break;
                    case 7:
                        time = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                        break;
                    case 9:
                        time = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                        break;
                    case 12:                        
                        time = int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00");
                        break;
                    default:
                        break;
                }
            }

            return time;
        }
    }
}
