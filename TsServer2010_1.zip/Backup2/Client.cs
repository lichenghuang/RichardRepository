﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;

namespace DeriLib.Client
{
    public enum Communication{NamedPipe,TCP,HTTP};

    public abstract class WCFClient
    {
        protected Binding m_Binding;
        protected EndpointAddress m_EndpointAddress;
        
        public WCFClient(Communication mCommunication,string IP,string Service)
        {
            if (IP == "") { IP = "localhost"; }

            if (mCommunication == Communication.NamedPipe)
            {
                NetNamedPipeBinding f = new NetNamedPipeBinding();

                f.MaxBufferPoolSize = 10048576;
                f.MaxReceivedMessageSize = 10048576;
                f.MaxBufferSize = 10048576;
                f.ReaderQuotas.MaxDepth = 32;
                f.ReaderQuotas.MaxStringContentLength = 10048576;
                f.ReaderQuotas.MaxArrayLength = 10048576;
                f.ReaderQuotas.MaxBytesPerRead = 10048576;                
                m_Binding = f;

                m_EndpointAddress = new EndpointAddress("net.pipe://localhost/"+ Service);
            }
            else if (mCommunication == Communication.TCP)
            {
                NetTcpBinding f = new NetTcpBinding();

                f.MaxBufferPoolSize = 10048576;
                f.MaxReceivedMessageSize = 10048576;
                f.MaxBufferSize = 10048576;
                f.ReaderQuotas.MaxDepth = 32;
                f.ReaderQuotas.MaxStringContentLength = 10048576;
                f.ReaderQuotas.MaxArrayLength = 10048576;
                f.ReaderQuotas.MaxBytesPerRead = 10048576;
                f.ReliableSession.InactivityTimeout = TimeSpan.MaxValue;

                f.Security.Mode = SecurityMode.None;
                f.Security.Transport.ClientCredentialType = TcpClientCredentialType.None;
                
                m_Binding = f;

                m_EndpointAddress = new EndpointAddress("net.tcp://" + IP + "/" + Service);
            }
            else if (mCommunication == Communication.HTTP)
            {
                WSDualHttpBinding f = new WSDualHttpBinding();
                m_Binding = f;

                m_EndpointAddress = new EndpointAddress("http://" + IP + "/" + Service);
            }
            
            m_Binding.OpenTimeout = new TimeSpan(0, 0, 30);
            //m_Binding.ReceiveTimeout = TimeSpan.MaxValue;
            //m_Binding.SendTimeout = TimeSpan.MaxValue;
            m_Binding.ReceiveTimeout = new TimeSpan(0, 0, 30);
            m_Binding.SendTimeout = new TimeSpan(0, 0, 30);
            m_Binding.CloseTimeout = new TimeSpan(0, 0, 30);
        }
        
        public abstract void Start();
        public abstract void Close();
    }
}
