﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading;
using System.Timers;
using DeriLib.Quote;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace DeriLib.Client.Quote
{
    [CallbackBehavior(UseSynchronizationContext = false)]
    public class QuotePush : WCFClient, IQuoteCallBacks
    {
        public delegate void QuoteArrivedHandler(object obj);
        public event QuoteArrivedHandler QuoteArrived;
        public delegate void MsgArrivedHandler(object obj);
        public event MsgArrivedHandler MsgArrived;
        private object LockObj = new object();
        private DuplexChannelFactory<IQuoteClient> WcfFactory = null;
        private IQuoteClient wcfProxy;
        private System.Timers.Timer tr;
        private Thread RoutineTh;
        private Queue DataList = new Queue();
        private int f = 0;
        public bool IsDisConnect = false;
        public QuotePush(Communication mCommunication,string IP)
            : base(mCommunication,IP,"Quote")
        {
        }
        public QuotePush(Communication mCommunication, string IP,string Service)
            : base(mCommunication, IP, Service)
        {
        }
        #region IQuoteCallBacks 成員
        public void QCommodityArrived(QCommodity QCommodity)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QCommodity);
            lock (LockObj)
            {
                DataList.Enqueue(QCommodity);
            }
        }
        public void QBaseArrived(QBase QBase)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QBase);
            lock (LockObj)
            {
                DataList.Enqueue(QBase);
            }
        }
        public void QOpenArrived(QOpen QOpen)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QOpen);
            lock (LockObj)
            {
                DataList.Enqueue(QOpen);
            }
        }
        public void QBest5Arrived(QBest5 QBest5)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QBest5);
            lock (LockObj)
            {
                DataList.Enqueue(QBest5);
            }
        }
        public void QMatchArrived(QMatch QMatch)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QMatch);            
            lock (LockObj)
            {
                DataList.Enqueue(QMatch);
            }
        }
        public void QHighLowArrived(QHighLow QHighLow)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QHighLow);
            lock (LockObj)
            {
                DataList.Enqueue(QHighLow);
            }
        }
        public void QCloseArrived(QClose QClose)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QClose);
            lock (LockObj)
            {
                DataList.Enqueue(QClose);
            }
        }
        public void QQueryArrived(QueryCls QueryCls)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QClose);
            lock (LockObj)
            {
                DataList.Enqueue(QueryCls);
            }
        }
        /*public void QGreeksArrived(QGreeks QGreeks)
        {
            if (QuoteArrived != null)
                QuoteArrived(QGreeks);
        }*/
        public void QExtraArrived(QCommodityExtra QCommodityExtra)
        {
            //if (QuoteArrived != null)
            //    QuoteArrived(QCommodityExtra);
            lock (LockObj)
            {
                DataList.Enqueue(QCommodityExtra);
            }
        }
        public void QSimpleCommodityArrived(QSimpleCommodity QSimpleCommodity)
        {         
            if (QuoteArrived != null)
                QuoteArrived(QSimpleCommodity);
            
            /*lock (LockObj)
            {
                DataList.Enqueue(QSimpleCommodity);
            }*/
        }
        public void QSimpleBaseArrived(QSimpleBase QSimpleBase)
        {
            if (QuoteArrived != null)
                QuoteArrived(QSimpleBase);

            /*lock (LockObj)
            {
                DataList.Enqueue(QSimpleBase);
            }*/
        }
        /*public void QMatchBest5Arrived(QMatchBest5 QMatchBest5)
        {
            lock (LockObj)
            {
                DataList.Enqueue(QMatchBest5);
            }
        }*/
        public void QSimpleMatchArrived(QSimpleMatch QSimpleMatch)
        {
            if (QuoteArrived != null)
                QuoteArrived(QSimpleMatch);

            /*lock (LockObj)
            {
                DataList.Enqueue(QSimpleMatch);
            }*/
        }
        public void QSimpleBest5Arrived(QSimpleBest5 QSimpleBest5)
        {
            if (QuoteArrived != null)
                QuoteArrived(QSimpleBest5);

            /*lock (LockObj)
            {
                DataList.Enqueue(QSimpleBest5);
            }*/
        }
        #endregion
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    while (DataList.Count > 0)
                    {
                        object obj = null;

                        lock (LockObj)
                        {
                            obj = DataList.Dequeue();
                        }

                        if (obj == null)
                        {
                            continue;
                        }

                        if (obj.ToString() == "DisConnect")
                        {
                            tr.Stop();
                        }
                        else
                        {
                            if (QuoteArrived != null)
                                QuoteArrived(obj);
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch
            {
            }
        }
        public override void Start()
        {
            try
            {
                IsDisConnect = true;
                WcfFactory = new DuplexChannelFactory<IQuoteClient>(this, m_Binding, m_EndpointAddress);
                SetMaxItemsInObjectGraph(WcfFactory);
                wcfProxy = WcfFactory.CreateChannel();

                RoutineTh = new Thread(new ThreadStart(RoutineWork));
                RoutineTh.Start();
                                
                bool b = wcfProxy.GetAlived();
                IsDisConnect = false;
                tr = new System.Timers.Timer(1000);
                tr.Elapsed += new ElapsedEventHandler(tr_Elapsed);
                tr.Start();
            }
            catch (Exception ex)
            {
                //ICommunicationObject g = (ICommunicationObject)wcfProxy;
                //g.Abort();
                //g.Close();
                throw ex;
            }
        }
        public void tr_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (IsDisConnect) { return; }

            try
            {
                if (!wcfProxy.GetAlived())
                {
                    IsDisConnect = true;

                    if (MsgArrived != null)
                    {
                        MsgArrived("Connection Is Lost");
                        //tr.Stop();
                        //tr.Dispose();
                        lock (LockObj)
                        {
                            DataList.Enqueue("DisConnect");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IsDisConnect = true;

                if (MsgArrived != null)
                {
                    MsgArrived("Connection Is Lost");
                    //tr.Stop();
                    //tr.Dispose();
                    lock (LockObj)
                    {
                        DataList.Enqueue("DisConnect");
                    }
                }
            }
        }
        private void SetMaxItemsInObjectGraph(ChannelFactory channelFactory)
        {
            foreach (OperationDescription op in channelFactory.Endpoint.Contract.Operations)
            {
                DataContractSerializerOperationBehavior dataContractBehavior = op.Behaviors[typeof(DataContractSerializerOperationBehavior)] as DataContractSerializerOperationBehavior;

                if (dataContractBehavior != null)
                    dataContractBehavior.MaxItemsInObjectGraph = int.MaxValue;
            }
        }
        #region IQuoteClient 成員

        public List<string> SubCommodity(List<string> CommodityList)
        {                        
            return wcfProxy.SubCommodity(CommodityList);
        }

        public List<string> UnSubCommodity(List<string> CommodityList)
        {
            return wcfProxy.UnSubCommodity(CommodityList);
        }

        public List<QCommodity> GetImage(List<string> CommodityList)
        {
            return wcfProxy.GetImage(CommodityList);
        }
        public List<QSimpleCommodity> GetSimpleImage(List<string> CommodityList)
        {
            return wcfProxy.GetSimpleImage(CommodityList);
        }

        public List<string> GetSubCommodityList()
        {
            return wcfProxy.GetSubCommodityList();
        }

        public List<QMatch> GetCommodityTicks(string CommodityId)
        {
            return wcfProxy.GetCommodityTicks(CommodityId);
        }

        public override void Close()
        {
            try
            {
                try
                {
                    if (RoutineTh != null && RoutineTh.IsAlive) { RoutineTh.Abort(); }
                }
                catch (Exception ex2)
                {
                }

                try
                {
                    if (!IsDisConnect)
                        wcfProxy.Close();
                }
                catch (Exception ex3)
                {
                }
                try
                {
                    WcfFactory.Close();
                }
                catch (Exception ex4)
                {
                }

                try
                {
                    if (tr != null)
                    {
                        tr.Elapsed -= new ElapsedEventHandler(tr_Elapsed);
                        tr.Stop();
                        tr.Dispose();
                    }
                }
                catch (Exception ex1)
                {
                }
            }
            catch (Exception ex)
            {
            }
        }

        #endregion
    }
}
