﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Derivative.PriceModel
{
    #region ..Enum Define..
    public enum enumOption
    {
        Call = 1,      //VanillaType
        Put,
        DIC,             //BarrierType
        UIC,
        DOC,
        UOC,
        DIP,
        UIP,
        DOP,
        UOP
    }
    #endregion ..Enum Define..



    public class Greeks
    {
        public static int loopCount;
        public static double CalcTPrice(enumOption OptionType, double spot, double strike,
                                            double maturity, double interest, double div, double vol)
        {
            //Vanilla Price
            div = interest - div; //cost of carry
            double d1, d2;
            d1 = (Math.Log(spot / strike) + (div + 0.5 * vol * vol) * maturity) / (vol * Math.Sqrt(maturity));
            d2 = d1 - vol * Math.Sqrt(maturity);

            if (OptionType == enumOption.Call)
                return spot * Math.Exp((div - interest) * maturity) * CND(d1) - strike * Math.Exp(-1.0 * interest * maturity) * CND(d2);
            else
                return strike * Math.Exp(-1 * interest * maturity) * CND(-1.0 * d2) - spot * Math.Exp((div - interest) * maturity) * CND(-1.0 * d1);
        }

        public static double CalcTPrice(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            double v = vol;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla Price
                return CalcTPrice(OptionType, S, X, T, r, r - b, v);
            }
            else
            {
                // Barrier Price
                if (((OptionType == enumOption.DOC || OptionType == enumOption.DOP) && S <= H) || ((OptionType == enumOption.UOC || OptionType == enumOption.UOP) && S >= H))
                {
                    return k;
                }
                else if (((OptionType == enumOption.DIC || OptionType == enumOption.DIP) && S <= H) || ((OptionType == enumOption.UIC || OptionType == enumOption.UIP) && S >= H))
                {
                    if (OptionType == enumOption.DIC || OptionType == enumOption.DOC || OptionType == enumOption.UIC || OptionType == enumOption.UOC)
                    {
                        return CalcTPrice(enumOption.Call, S, X, T, r, r - b, v);
                    }
                    else
                    {
                        return CalcTPrice(enumOption.Put, S, X, T, r, r - b, v);
                    }
                }

                return Standard(OptionType, S, X, H, k, T, r, b, v);
            }
        }

        public static double CalcDelta(enumOption OptionType, double spot, double strike,
                                            double maturity, double interest, double div, double vol)
        {
            //Vanilla Delta
            double d1;
            div = interest - div; //cost of carry

            d1 = (Math.Log(spot / strike) + (div + 0.5 * vol * vol) * maturity) / (vol * Math.Sqrt(maturity));

            if (OptionType == enumOption.Call)
                return Math.Exp((div - interest) * maturity) * CND(d1);
            else
                return Math.Exp((div - interest) * maturity) * (CND(d1) - 1);
        }

        public static double CalcDelta(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            double v = vol;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla Delta
                return CalcDelta(OptionType, S, X, T, r, r - b, v);
            }
            else
            {
                // Barrier Delta
                double dS = 0.0001, result = 0;
                if (((OptionType == enumOption.DOC || OptionType == enumOption.DOP) && S <= H) || ((OptionType == enumOption.UOC || OptionType == enumOption.UOP) && S >= H))
                {
                    return 0;
                }
                else if (((OptionType == enumOption.DIC || OptionType == enumOption.DIP) && S <= H) || ((OptionType == enumOption.UIC || OptionType == enumOption.UIP) && S >= H))
                {
                    if (OptionType == enumOption.DIC || OptionType == enumOption.DOC || OptionType == enumOption.UIC || OptionType == enumOption.UOC)
                    {
                        return CalcDelta(enumOption.Call, S, X, T, r, r - b, v);
                    }
                    else
                    {
                        return CalcDelta(enumOption.Put, S, X, T, r, r - b, v);
                    }
                }

                result = (Standard(OptionType, S + dS, X, H, k, T, r, b, v) - Standard(OptionType, S - dS, X, H, k, T, r, b, v)) / (2 * dS);
                return result;
            }

        }

        public static double CalcGamma(enumOption OptionType, double spot, double strike,
                                    double maturity, double interest, double div, double vol)
        {
            // Vanilla Gamma
            double d1, sigmat;
            div = interest - div; //cost of carry

            sigmat = 1.0 / (vol * Math.Sqrt(maturity));
            d1 = (Math.Log(spot / strike) + (div + 0.5 * vol * vol) * maturity) * sigmat;

            return Math.Exp((div - interest) * maturity) * dNorm(d1) * sigmat / spot;
        }

        public static double CalcGamma(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            double v = vol;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla Gamma
                return CalcGamma(OptionType, S, X, T, r, r - b, v);
            }
            else
            {
                // Barrier Gamma
                double dS = S * 0.0001, result = 0;
                if (((OptionType == enumOption.DOC || OptionType == enumOption.DOP) && S <= H) || ((OptionType == enumOption.UOC || OptionType == enumOption.UOP) && S >= H))
                {
                    return 0;
                }
                else if (((OptionType == enumOption.DIC || OptionType == enumOption.DIP) && S <= H) || ((OptionType == enumOption.UIC || OptionType == enumOption.UIP) && S >= H))
                {
                    if (OptionType == enumOption.DIC || OptionType == enumOption.DOC || OptionType == enumOption.UIC || OptionType == enumOption.UOC)
                    {
                        return CalcGamma(enumOption.Call, S, X, T, r, r - b, v);
                    }
                    else
                    {
                        return CalcGamma(enumOption.Put, S, X, T, r, r - b, v);
                    }
                }

                result = (Standard(OptionType, S + dS, X, H, k, T, r, b, v) - 2 * Standard(OptionType, S, X, H, k, T, r, b, v) + Standard(OptionType, S - dS, X, H, k, T, r, b, v)) / Math.Pow(dS, 2);
                return result;
            }
        }

        public static double CalcVega(enumOption OptionType, double spot, double strike,
                                    double maturity, double interest, double div, double vol)
        {
            //Vanilla Vega
            double d1, sigmat;
            div = interest - div; //cost of carry

            sigmat = 1.0 / (vol * Math.Sqrt(maturity));
            d1 = (Math.Log(spot / strike) + (div + 0.5 * vol * vol) * maturity) * sigmat;

            return spot * Math.Exp((div - interest) * maturity) * dNorm(d1) * Math.Sqrt(maturity);
        }

        public static double CalcVega(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            double v = vol;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla Vega
                return CalcVega(OptionType, S, X, T, r, r - b, v);
            }
            else
            {
                // Barrier Vega
                double dV = 0.01, result = 0;
                if (((OptionType == enumOption.DOC || OptionType == enumOption.DOP) && S <= H) || ((OptionType == enumOption.UOC || OptionType == enumOption.UOP) && S >= H))
                {
                    return 0;
                }
                else if (((OptionType == enumOption.DIC || OptionType == enumOption.DIP) && S <= H) || ((OptionType == enumOption.UIC || OptionType == enumOption.UIP) && S >= H))
                {
                    if (OptionType == enumOption.DIC || OptionType == enumOption.DOC || OptionType == enumOption.UIC || OptionType == enumOption.UOC)
                    {
                        return CalcVega(enumOption.Call, S, X, T, r, r - b, v);
                    }
                    else
                    {
                        return CalcVega(enumOption.Put, S, X, T, r, r - b, v);
                    }
                }

                result = (Standard(OptionType, S, X, H, k, T, r, b, v + dV) - Standard(OptionType, S, X, H, k, T, r, b, v - dV)) / (2 * dV);
                return result;
            }

        }

        public static double CalcTheta(enumOption OptionType, double spot, double strike,
                                    double maturity, double interest, double div, double vol)
        {
            //Vanilla Theta
            double d1, d2, sigmat;
            div = interest - div; //cost of carry

            sigmat = vol * Math.Sqrt(maturity);
            d1 = (Math.Log(spot / strike) + (div + 0.5 * vol * vol) * maturity) / sigmat;
            d2 = d1 - sigmat;

            if (OptionType == enumOption.Call)
                return -0.5 * spot * Math.Exp((div - interest) * maturity) * dNorm(d1) * vol / Math.Sqrt(maturity)
                        - (div - interest) * spot * Math.Exp((div - interest) * maturity) * CND(d1)
                        - interest * strike * Math.Exp(-1.0 * interest * maturity) * CND(d2);
            else
                return -0.5 * spot * Math.Exp((div - interest) * maturity) * dNorm(d1) * vol / Math.Sqrt(maturity)
                        + (div - interest) * spot * Math.Exp((div - interest) * maturity) * CND(-1.0 * d1)
                        + interest * strike * Math.Exp(-1.0 * interest * maturity) * CND(-1.0 * d2);
        }

        public static double CalcTheta(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            double v = vol;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla Theta
                return CalcTheta(OptionType, S, X, T, r, r - b, v);
            }
            else
            {
                // Barrier Theta
                double result = 0;
                if (((OptionType == enumOption.DOC || OptionType == enumOption.DOP) && S <= H) || ((OptionType == enumOption.UOC || OptionType == enumOption.UOP) && S >= H))
                {
                    return 0;
                }
                else if (((OptionType == enumOption.DIC || OptionType == enumOption.DIP) && S <= H) || ((OptionType == enumOption.UIC || OptionType == enumOption.UIP) && S >= H))
                {
                    if (OptionType == enumOption.DIC || OptionType == enumOption.DOC || OptionType == enumOption.UIC || OptionType == enumOption.UOC)
                    {
                        return CalcTheta(enumOption.Call, S, X, T, r, r - b, v);
                    }
                    else
                    {
                        return CalcTheta(enumOption.Put, S, X, T, r, r - b, v);
                    }
                }

                if (T <= 1.0 / 365.0)
                {
                    //result = Standard(OptionType, S, X, H, k, 0.00001, r, b, v) - Standard(OptionType, S, X, H, k, T, r, b, v) / (1.0 / 365.0 - 0.00001);
                    result = Standard(OptionType, S, X, H, k, 0.00001, r, b, v) - Standard(OptionType, S, X, H, k, T, r, b, v);
                }
                else
                {
                    //result = (Standard(OptionType, S, X, H, k, T - 1.0 / 365.0, r, b, v) - Standard(OptionType, S, X, H, k, T, r, b, v)) / (1.0 / 365.0);
                    result = (Standard(OptionType, S, X, H, k, T - 1.0 / 365.0, r, b, v) - Standard(OptionType, S, X, H, k, T, r, b, v));
                }
                return result;
            }
        }

        public static double CalcRho(enumOption OptionType, double spot, double strike,
                                    double maturity, double interest, double div, double vol)
        {
            //Vanilla Rho
            double d1, d2, sigmat;
            div = interest - div; //cost of carry

            sigmat = vol * Math.Sqrt(maturity);

            d1 = (Math.Log(spot / strike) + (div + 0.5 * vol * vol) * maturity) / sigmat;
            d2 = d1 - sigmat;

            if (OptionType == enumOption.Call)
            {
                if (div != 0)
                    return maturity * strike * Math.Exp(-1.0 * interest * maturity) * CND(d2);
                else
                    return -1.0 * maturity * CalcTPrice(OptionType, spot, strike, maturity, interest, div, vol);
            }
            else
            {
                if (div != 0)
                    return -1.0 * maturity * strike * Math.Exp(-1.0 * interest * maturity) * CND(-1.0 * d2);
                else
                    return -1.0 * maturity * CalcTPrice(OptionType, spot, strike, maturity, interest, div, vol);
            }
        }

        public static double CalcRho(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            double v = vol;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla Rho
                return CalcRho(OptionType, S, X, T, r, r - b, v);
            }
            else
            {
                // Barrier Rho
                double dR = 0.01, result = 0;
                if (((OptionType == enumOption.DOC || OptionType == enumOption.DOP) && S <= H) || ((OptionType == enumOption.UOC || OptionType == enumOption.UOP) && S >= H))
                {
                    return 0;
                }
                else if (((OptionType == enumOption.DIC || OptionType == enumOption.DIP) && S <= H) || ((OptionType == enumOption.UIC || OptionType == enumOption.UIP) && S >= H))
                {
                    if (OptionType == enumOption.DIC || OptionType == enumOption.DOC || OptionType == enumOption.UIC || OptionType == enumOption.UOC)
                    {
                        return CalcRho(enumOption.Call, S, X, T, r, r - b, v);
                    }
                    else
                    {
                        return CalcRho(enumOption.Put, S, X, T, r, r - b, v);
                    }
                }

                result = (Standard(OptionType, S, X, H, k, T, r + dR, b + dR, v) - Standard(OptionType, S, X, H, k, T, r - dR, b - dR, v)) / (2 * dR);
                return result;
            }
        }

        public static double CalcVanna(enumOption OptionType, double spot, double strike,
                                    double maturity, double interest, double div, double vol)
        {
            double d1, d2, sigmat;

            div = interest - div; //cost of carry
            sigmat = vol * Math.Sqrt(maturity);
            d1 = (Math.Log(spot / strike) + (interest + 0.5 * vol * vol) * maturity) / sigmat;
            d2 = d1 - sigmat;
            return -Math.Exp((div - interest) * maturity) * d2 / vol * dNorm(d1);
        }

        public static double CalcVanna(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double vol)
        {
            double dS = 0.0001, b = 0;
            b = interest - div;
            return 1 / (4 * dS * 0.01) * (Standard(OptionType, spot + dS, strike, barrier, rebat, maturity, interest, b, vol + 0.01) - Standard(OptionType, spot + dS, strike, barrier, rebat, maturity, interest, b, vol - 0.01) - Standard(OptionType, spot - dS, strike, barrier, rebat, maturity, interest, b, vol + 0.01) + Standard(OptionType, spot - dS, strike, barrier, rebat, maturity, interest, b, vol - 0.01));
        }

        public static double CalcIV(enumOption OptionType, double spot, double strike,
                                              double maturity, double interest, double div, double Price)
        {
            //Vanilla IV
            double iv = 0.8, dif = 1.0, vega;
            div = interest - div; //cost of carry
            loopCount = 0;
            if (spot <= 0.0) spot = 0.00000001;
            if (strike <= 0.0) strike = 0.00000001;
            if (maturity <= 0.0) maturity = 0.00000001;
            if (Price <= 0.0) return 0.00000001;

            //for (; Math.Abs(dif) > 0.008; )
            for (; Math.Abs(dif) > 0.00000000001; )
            {
                loopCount = loopCount + 1;
                if (loopCount >= 100) return 0.000488;

                vega = CalcVega(OptionType, spot, strike, maturity, interest, interest - div, iv);
                if (Math.Abs(vega) >= 0.001)
                {
                    dif = (CalcTPrice(OptionType, spot, strike, maturity, interest, interest - div, iv) - Price) / vega;
                    iv = iv - dif;
                    if (iv < 0.000001)
                    {
                        iv = giv2(OptionType, spot, strike, maturity, interest, div, Price);
                        return iv;
                    }
                }
                else
                {
                    iv = giv2(OptionType, spot, strike, maturity, interest, div, Price);
                    return iv;
                }
            }
            return iv;
        }

        public static double CalcIV(enumOption OptionType, double spot, double strike, double barrier, double rebat, double maturity, double interest, double div, double Price)
        {
            double S = spot;
            double X = strike;
            double H = barrier;
            double k = rebat;
            double T = maturity;
            double r = interest;
            double b = div;
            b = interest - div; //cost of carry

            if (OptionType == enumOption.Call || OptionType == enumOption.Put)
            {
                //Vanilla IV
                return CalcIV(OptionType, S, X, T, r, r - b, Price);
            }
            else
            {
                //Barrier IV, if price difference is larger than 10%, return 0.000488
                double result = 0, ResultPrice = 0;
                result = IV(OptionType, S, X, H, k, T, r, b, Price);
                if (Math.Round(result, 6) == 0.000488) return result;

                ResultPrice = CalcTPrice(OptionType, S, X, H, k, T, r, r - b, result);

                if (Math.Abs(ResultPrice - Price) / Price >= 0.1) //price difference is larger than 10%
                {
                    //Console.WriteLine("{0} , is NOT a Good IV", result);
                    return 0.000488;
                }
                else
                {
                    return result;
                }
            }
        }

        private static double IV(enumOption OptionType, double S, double X, double H, double k, double T, double r, double b, double Price)
        {
            //Barrier IV, called by CalcIV of Barrier
            double iv = 0.5, dif = 1.0, vega;
            loopCount = 0;

            if (S <= 0.0) S = 0.00000001;
            if (X <= 0.0) X = 0.00000001;
            if (T <= 0.0) T = 0.00000001;
            if (Price <= 0.0) return 0.00000001;

            //for (; Math.Abs(dif) > 0.008; )
            for (; Math.Abs(dif) > 0.00000000001; )            
            {
                loopCount = loopCount + 1;
                if (loopCount >= 100) return 0.000488;

                vega = CalcVega(OptionType, S, X, H, k, T, r, r - b, iv);
                if (Math.Abs(vega) >= 0.001)
                {
                    dif = (CalcTPrice(OptionType, S, X, H, k, T, r, r - b, iv) - Price) / vega;
                    iv = iv - dif;
                    if (iv < 0.000001)
                    {
                        iv = giv2(OptionType, S, X, H, k, T, r, b, Price);
                        return iv;
                    }
                }
                else
                {
                    iv = giv2(OptionType, S, X, H, k, T, r, b, Price);
                    return iv;
                }
            }
            return iv;
        }

        private static double Standard(enumOption OptionType, double S, double X, double H, double k, double T, double r, double b, double v)
        {
            // Barrier Option Collector
            double mu, lambda, X1, X2, y1, y2, z;
            int eta = 0, phi = 0;     //Binary variable , 1 or -1
            double f1, f2, f3, f4, f5, f6;       //Equal to formula "A", "B", "C","D", "E","F" in the book
            double result = 0;

            switch (OptionType)
            {
                case enumOption.DIC:
                case enumOption.DOC:
                    eta = 1;
                    phi = 1;
                    break;
                case enumOption.UIC:
                case enumOption.UOC:
                    eta = -1;
                    phi = 1;
                    break;
                case enumOption.DIP:
                case enumOption.DOP:
                    eta = 1;
                    phi = -1;
                    break;
                case enumOption.UIP:
                case enumOption.UOP:
                    eta = -1;
                    phi = -1;
                    break;
            }

            mu = (b - Math.Pow(v, 2) / 2) / Math.Pow(v, 2);
            lambda = Math.Sqrt(Math.Pow(mu, 2) + 2 * r / Math.Pow(v, 2));
            X1 = Math.Log(S / X) / (v * Math.Sqrt(T)) + (1 + mu) * v * Math.Sqrt(T);
            X2 = Math.Log(S / H) / (v * Math.Sqrt(T)) + (1 + mu) * v * Math.Sqrt(T);
            y1 = Math.Log(Math.Pow(H, 2) / (S * X)) / (v * Math.Sqrt(T)) + (1 + mu) * v * Math.Sqrt(T);
            y2 = Math.Log(H / S) / (v * Math.Sqrt(T)) + (1 + mu) * v * Math.Sqrt(T);
            z = Math.Log(H / S) / (v * Math.Sqrt(T)) + lambda * v * Math.Sqrt(T);

            f1 = phi * S * Math.Exp((b - r) * T) * CND(phi * X1) - phi * X * Math.Exp(-r * T) * CND(phi * X1 - phi * v * Math.Sqrt(T));
            f2 = phi * S * Math.Exp((b - r) * T) * CND(phi * X2) - phi * X * Math.Exp(-r * T) * CND(phi * X2 - phi * v * Math.Sqrt(T));
            f3 = phi * S * Math.Exp((b - r) * T) * Math.Pow(H / S, 2 * (mu + 1)) * CND(eta * y1) - phi * X * Math.Exp(-r * T) * Math.Pow(H / S, 2 * mu) * CND(eta * y1 - eta * v * Math.Sqrt(T));
            f4 = phi * S * Math.Exp((b - r) * T) * Math.Pow(H / S, 2 * (mu + 1)) * CND(eta * y2) - phi * X * Math.Exp(-r * T) * Math.Pow(H / S, 2 * mu) * CND(eta * y2 - eta * v * Math.Sqrt(T));
            f5 = k * Math.Exp(-r * T) * (CND(eta * X2 - eta * v * Math.Sqrt(T)) - Math.Pow(H / S, 2 * mu) * CND(eta * y2 - eta * v * Math.Sqrt(T)));
            f6 = k * (Math.Pow(H / S, mu + lambda) * CND(eta * z) + Math.Pow(H / S, mu - lambda) * CND(eta * z - 2 * eta * lambda * v * Math.Sqrt(T)));

            if (X > H)
            {
                switch (OptionType)
                {
                    case enumOption.DIC:      //1a) cdi
                        result = f3 + f5;
                        break;
                    case enumOption.UIC:    //2a) cui
                        result = f1 + f5;
                        break;
                    case enumOption.DIP:    //3a) pdi
                        result = f2 - f3 + f4 + f5;
                        break;
                    case enumOption.UIP:   //4a) pui
                        result = f1 - f2 + f4 + f5;
                        break;
                    case enumOption.DOC:    //5a) cdo
                        result = f1 - f3 + f6;
                        break;
                    case enumOption.UOC:   //6a) cuo
                        result = f6;
                        break;
                    case enumOption.DOP:   //7a) pdo
                        result = f1 - f2 + f3 - f4 + f6;
                        break;
                    case enumOption.UOP:  //8a) puo
                        result = f2 - f4 + f6;
                        break;
                }
            }
            else if (X < H)
            {
                switch (OptionType)
                {
                    case enumOption.DIC:     //1b) cdi
                        result = f1 - f2 + f4 + f5;
                        break;
                    case enumOption.UIC:    //2b) cui
                        result = f2 - f3 + f4 + f5;
                        break;
                    case enumOption.DIP:    //3b) pdi
                        result = f1 + f5;
                        break;
                    case enumOption.UIP:    //4b) pui
                        result = f3 + f5;
                        break;
                    case enumOption.DOC:   // 5b) cdo
                        result = f2 + f6 - f4;
                        break;
                    case enumOption.UOC:  //6b) cuo
                        result = f1 - f2 + f3 - f4 + f6;
                        break;
                    case enumOption.DOP:  //7b) pdo
                        result = f6;
                        break;
                    case enumOption.UOP:  //8b) puo
                        result = f1 - f3 + f6;
                        break;
                }
            }
            return result;
        }

        private static double giv2(enumOption OptionType, double spot, double strike, double maturity, double interest, double div, double Price)
        {
            // Auxiliary method for Vanilla IV
            double ivh = 1.0, ivl = 0, iv = 0.0;

            if (spot == 0.0) spot = 0.00000001;
            if (strike == 0.0) strike = 0.00000001;
            if (maturity == 0.0) maturity = 0.00000001;
            if (Price == 0.0) Price = 0.00000001;

            for (; ivh - ivl > 0.0008; )
            {
                iv = (ivh + ivl) * 0.5;
                if (CalcTPrice(OptionType, spot, strike, maturity, interest, interest - div, iv) > Price)
                    ivh = iv;
                else
                    ivl = iv;
            }
            return iv;
        }

        private static double giv2(enumOption OptionType, double S, double X, double H, double k, double T, double r, double b, double Price)
        {
            // Auxiliary method for Barrier IV
            double ivh = 1.0, ivl = 0, iv = 0.0;

            if (S == 0.0) S = 0.00000001;
            if (X == 0.0) X = 0.00000001;
            if (T == 0.0) T = 0.00000001;
            if (Price == 0.0) Price = 0.00000001;

            for (; ivh - ivl > 0.0008; )
            {
                iv = (ivh + ivl) * 0.5;
                if (CalcTPrice(OptionType, S, X, H, k, T, r, r - b, iv) > Price)
                    ivh = iv;
                else
                    ivl = iv;
            }
            return iv;
        }

        private static double dNorm(double x)
        {
            //Calculate normal distribution
            return Math.Exp(-0.5 * x * x) * 0.3989422804; //Math.Exp()/Math.Sqrt(2*pi)
        }

        private static double CND(double X)
        {
            // Cumulative Normal Distribution
            double y, Exponential, SumA, SumB, result;

            y = Math.Abs(X);
            result = 0;

            if (y <= 37)
            {
                Exponential = Math.Exp(-Math.Pow(y, 2) / 2);
                if (y < 7.07106781186547)
                {
                    SumA = 3.52624965998911E-02 * y + 0.700383064443688;
                    SumA = SumA * y + 6.37396220353165;
                    SumA = SumA * y + 33.912866078383;
                    SumA = SumA * y + 112.079291497871;
                    SumA = SumA * y + 221.213596169931;
                    SumA = SumA * y + 220.206867912376;
                    SumB = 8.83883476483184E-02 * y + 1.75566716318264;
                    SumB = SumB * y + 16.064177579207;
                    SumB = SumB * y + 86.7807322029461;
                    SumB = SumB * y + 296.564248779674;
                    SumB = SumB * y + 637.333633378831;
                    SumB = SumB * y + 793.826512519948;
                    SumB = SumB * y + 440.413735824752;
                    result = Exponential * SumA / SumB;
                }
                else
                {
                    SumA = y + 0.65;
                    SumA = y + 4 / SumA;
                    SumA = y + 3 / SumA;
                    SumA = y + 2 / SumA;
                    SumA = y + 1 / SumA;
                    result = Exponential / (SumA * 2.506628274631);
                }
            }

            if (X > 0) result = 1 - result;
            return result;
        }



        //--------------Quanto---------------------//
        public static double QuantoPrice(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            if (isIndex == 1)
                return Quanto(CP, sf, kf, T, rf, qf, sigmaSf, x) / x;
            else
                return Quanto(CP, sf, kf, T, rf, qf, sigmaSf, x);
        }


        private static double Quanto(int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            double d1 = 0, d2 = 0;
            d1 = (Math.Log(sf / kf) + (rf - qf + 0.5 * sigmaSf * sigmaSf) * T) / (sigmaSf * Math.Sqrt(T));
            d2 = d1 - sigmaSf * Math.Sqrt(T);

            if (CP == 1) //Call
                return x * sf * Math.Exp(-qf * T) * CND(d1) - kf * x * Math.Exp(-rf * T) * CND(d2);
            else
                return -x * sf * Math.Exp(-qf * T) * CND(-d1) + kf * x * Math.Exp(-rf * T) * CND(-d2);
        }


        public static double QuantoDelta(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            double ds = 0.0001;
            double pricePlusds = 0, priceMinusds = 0;

            pricePlusds = QuantoPrice(isIndex, CP, sf + ds, kf, T, rf, qf, sigmaSf, x);
            priceMinusds = QuantoPrice(isIndex, CP, sf - ds, kf, T, rf, qf, sigmaSf, x);

            if (isIndex == 1)
                return (pricePlusds - priceMinusds) / (2 * ds);
            else
                return (pricePlusds - priceMinusds) / (2 * ds * x);

        }


        public static double QuantoGamma(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            double ds = 0.0001;
            double price = 0, pricePlusds = 0, priceMinusds = 0;

            price = QuantoPrice(isIndex, CP, sf, kf, T, rf, qf, sigmaSf, x);
            pricePlusds = QuantoPrice(isIndex, CP, sf + ds, kf, T, rf, qf, sigmaSf, x);
            priceMinusds = QuantoPrice(isIndex, CP, sf - ds, kf, T, rf, qf, sigmaSf, x);

            if (isIndex == 1)
                return (pricePlusds - 2 * price + priceMinusds) / (ds * ds);
            else
                return (pricePlusds - 2 * price + priceMinusds) / (ds * ds * x);
        }


        public static double QuantoVega(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            double dv = 0.0001;
            double pricePlusdv = 0, priceMinusdv = 0;

            pricePlusdv = QuantoPrice(isIndex, CP, sf, kf, T, rf, qf, sigmaSf + dv, x);
            priceMinusdv = QuantoPrice(isIndex, CP, sf, kf, T, rf, qf, sigmaSf - dv, x);

            return (pricePlusdv - priceMinusdv) / (2 * dv);

        }


        public static double QuantoTheta(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            double price = 0, priceMinusdT = 0;

            price = QuantoPrice(isIndex, CP, sf, kf, T, rf, qf, sigmaSf, x);
            priceMinusdT = QuantoPrice(isIndex, CP, sf, kf, T - 1.0 / 365.0, rf, qf, sigmaSf, x);

            return (priceMinusdT - price) / (1.0 / 365.0);
        }


        public static double QuantoRho(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double sigmaSf, double x)
        {
            double pricePlusdr = 0, priceMinusdr = 0, dr = 0.01;

            pricePlusdr = QuantoPrice(isIndex, CP, sf, kf, T, rf + dr, qf, sigmaSf, x);
            priceMinusdr = QuantoPrice(isIndex, CP, sf, kf, T, rf - dr, qf, sigmaSf, x);

            return (pricePlusdr - priceMinusdr) / (2 * dr);
        }


        public static double QuantoIV(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double x, double Price)
        {
            double iv = 0.8, dif = 1.0, vega;

            if (sf <= 0.0) sf = 0.00000001;
            if (kf <= 0.0) kf = 0.00000001;
            if (T <= 0.0) T = 0.00000001;
            if (Price <= 0.0) return 0.00000001;

            for (; Math.Abs(dif) > 0.008; )
            {
                //vega = CalcVega(OptionType, spot, strike, maturity, interest, interest - div, iv);
                vega = QuantoVega(isIndex, CP, sf, kf, T, rf, qf, iv, x);
                if (Math.Abs(vega) >= 0.001)
                {
                    //dif = (CalcTPrice(OptionType, spot, strike, maturity, interest, interest - div, iv) - Price) / vega;
                    dif = (QuantoPrice(isIndex, CP, sf, kf, T, rf, qf, iv, x) - Price) / vega;
                    iv = iv - dif;
                    if (iv < 0.000001)
                    {
                        iv = giv(isIndex, CP, sf, kf, T, rf, qf, x, Price);
                        return iv;
                    }
                }
                else
                {
                    iv = giv(isIndex, CP, sf, kf, T, rf, qf, x, Price);
                    return iv;
                }
            }
            return iv;
        }


        private static double giv(int isIndex, int CP, double sf, double kf, double T, double rf, double qf, double x, double Price)
        {
            // Auxiliary method for IV
            double ivh = 1.0, ivl = 0, iv = 0.0;

            if (sf == 0.0) sf = 0.00000001;
            if (kf == 0.0) kf = 0.00000001;
            if (T == 0.0) T = 0.00000001;
            if (Price == 0.0) Price = 0.00000001;

            for (; ivh - ivl > 0.0008; )
            {
                iv = (ivh + ivl) * 0.5;
                if (QuantoPrice(isIndex, CP, sf, kf, T, rf, qf, iv, x) > Price)
                    ivh = iv;
                else
                    ivl = iv;
            }
            return iv;
        }


    }
}
