﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.IO.Pipes;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using DeriLib.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using System.Runtime.InteropServices;

namespace DeriLib.FastQuote
{
    [ServiceBehavior(
        InstanceContextMode = InstanceContextMode.Single,
        ConcurrencyMode = ConcurrencyMode.Multiple
        )]
    public class FastQuote : IQuoteClient, IDisposable, DeriLib.TSModel.ITSServer
    {
        #region 變數宣告        
        private FastQuoteSourceList m_QuoteSourceList = null;        
        private FastClientStateList m_ClientStateList = null;
        private FastPCommodityList m_PCommodityList = null;

        private QuoteSetting Setting = null;
        private Thread RoutineThread;    
        private StreamWriter gStateLog = null;//錯誤寫檔        
        private Queue m_ErrQueue = Queue.Synchronized(new Queue());
        private Queue m_ErrQueueOut = Queue.Synchronized(new Queue());
        #endregion

        public FastQuote(QuoteSetting Setting)
        {
            try
            {
                this.Setting = Setting;

                IniValue();
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][Quote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void IniValue()
        {
            try
            {
                IniStateLogLog();
                m_ClientStateList = new FastClientStateList();
                m_PCommodityList = new FastPCommodityList();
                m_QuoteSourceList = new FastQuoteSourceList();
                
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][IniValue_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void AddQuoteSource(FastQuoteSource QuoteSource)
        {
            if (!m_QuoteSourceList.ContainKey(QuoteSource.QuoteSetting.DataSource))
            {
                try
                {
                    QuoteSource.PCommodityList = m_PCommodityList;
                    m_QuoteSourceList.Set(QuoteSource);                    
                    QuoteSource.Start();
                }
                catch (Exception ex)
                {
                    m_QuoteSourceList.Remove(QuoteSource.DataSource);
                    QuoteSource.Close();
                    throw ex;
                }
            }
            else
            {
                QuoteSource.Close();
            }
        }
        private void RemoveQuoteSource(string DataSource)
        {
            m_QuoteSourceList.Remove(DataSource);
        }
                
        private FastQuoteSourceList QuoteSourceList
        {
            get { return m_QuoteSourceList; }
        }
        private FastClientStateList ClientStateList
        {
            get { return m_ClientStateList; }
        }
        private FastPCommodityList PCommodityList
        {
            get { return m_PCommodityList; }
        }
        private void IniStateLogLog()
        {
            try
            {
                if (gStateLog != null) { gStateLog.Close(); }

                gStateLog = File.AppendText(Setting.LogFileFolder + "\\" + DateTime.Today.ToString("yyyyMMdd") + "TsFastQuote_StateLog.txt");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][IniLog_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void RoutineWork()
        {
            try
            {
                int count = 0;
                TimeSpan alivediff = new TimeSpan(0, 1, 0);
                bool notFinishFirstWork = true;
                bool notFinishClearWork = true;

                for (; ; )
                {
                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        notFinishFirstWork = true;
                        notFinishClearWork = true;
                    }

                    if (DateTime.Now.TimeOfDay.TotalHours >= 1.11 && DateTime.Now.TimeOfDay.TotalHours < 1.2 && notFinishFirstWork)
                    {
                        try
                        {
                            IniStateLogLog();                            
                            
                            notFinishFirstWork = false;
                        }
                        catch (Exception ex3)
                        {
                            m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                        }
                    }

                    if (DateTime.Now.TimeOfDay.TotalHours >= 8.5 && DateTime.Now.TimeOfDay.TotalHours < 8.6 && notFinishClearWork)
                    {
                        try
                        {
                            m_PCommodityList.RemoveNoneTradeCommodity();

                            notFinishClearWork = false;
                        }
                        catch (Exception ex3)
                        {
                            m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex3.Message + "][" + ex3.StackTrace + "]");
                        }
                    }

                    while (m_QuoteSourceList.ErrPool.Count > 0)
                    {
                        m_ErrQueue.Enqueue(m_QuoteSourceList.ErrPool.Dequeue().ToString());

                        if (m_ErrQueue.Count > 100)
                            m_ErrQueue.Dequeue();
                    }

                    while (m_ErrQueue.Count > 0)
                    {
                        string errstr = m_ErrQueue.Dequeue().ToString();
                        m_ErrQueueOut.Enqueue(errstr);
                        WriteToStateLog(errstr);
                    }

                    count++;
                    if (count == 7200) { count = 0; }

                    if (count % 60 == 0)
                    {
                        foreach (FastClientState ClientState in m_ClientStateList.ClientStates)
                        {
                            try
                            {
                                ICommunicationObject commObj = ClientState.Callback as ICommunicationObject;

                                if (commObj != null && (commObj.State == CommunicationState.Closed))
                                    m_ClientStateList.Remove(ClientState.Callback);
                                else if (ClientState != null && DateTime.Now.Subtract(ClientState.AliveTime) > alivediff)
                                    m_ClientStateList.Remove(ClientState.Callback);
                            }
                            catch (Exception ex)
                            {
                                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                            }
                        }
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        
        #region Method

        public void Start()
        {
            try
            {
                LoadData();

                RoutineThread = new Thread(new ThreadStart(RoutineWork));
                RoutineThread.Start();

                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][TsFastQuote Started]");
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        public void Close()
        {
            try
            {
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                if (m_QuoteSourceList != null) { m_QuoteSourceList.Close(); }                
                if (m_ClientStateList != null) { m_ClientStateList.Close(); }

                WriteToStateLog("[FastQuote][" + DateTime.Now.ToString() + "][TsFastQuote Closed]");

                gStateLog.Close();
            }
            catch (Exception ex)
            {
                WriteToStateLog("[FastQuote][" + DateTime.Now.ToString() + "][Close_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void LoadData()
        {
            if (DateTime.Now.TimeOfDay.TotalHours < 8 && DateTime.Now.TimeOfDay.TotalHours > 1) { return; }

            string sql = "select (case market when'TSE' then (case commoditykind when 'Warrant' then 'TSEWRT' else 'TSE' end) when'OTC' then (case commoditykind when 'Warrant' then 'OTCWRT' else 'OTC' end)  else (case commoditykind when 'Future' then 'FUT' when 'Option' then 'OPT' else '' end) end) Source,";
            sql += " j.commodityid,a.InformationTime BaseInformationTime,a.InformationSeq BaseInformationSeq,j.DecimalLocate DecimalLocate,a.ReferencePrice,a.RiseLimitPrice,a.FallLimitPrice,";
            sql += " b.InformationTime MatchInformationTime,b.InformationSeq MatchInformationSeq,b.MatchTime,b.MatchSeq,b.MatchPrice,b.MatchQty,b.MatchTotalQty,b.MatchAmt,b.MatchTotalAmt,";
            sql += " c.InformationTime Best5InformationTime,c.InformationSeq Best5InformationSeq,c.BuyPriceBest1,c.BuyPriceBest2,c.BuyPriceBest3,c.BuyPriceBest4,c.BuyPriceBest5,c.BuyQtyBest1,c.BuyQtyBest2,c.BuyQtyBest3,c.BuyQtyBest4,c.BuyQtyBest5,c.SellPriceBest1,c.SellPriceBest2,c.SellPriceBest3,c.SellPriceBest4,c.SellPriceBest5,c.SellQtyBest1,c.SellQtyBest2,c.SellQtyBest3,c.SellQtyBest4,c.SellQtyBest5";
            sql += " from commodity j,pbase a left join pmatch b on a.commodityid=b.commodityid and  convert(varchar,a.tradedate,112)=convert(varchar,b.mdate,112) left join pbest5 c on a.commodityid=c.commodityid and  convert(varchar,a.tradedate,112)=convert(varchar,c.mdate,112)";
            sql += " where j.commodityid=a.commodityid and  convert(varchar,a.tradedate,112)=convert(varchar,getdate(),112) and ";
            sql += " j.market is not null and j.commoditynm<>'' ";
            sql += " order by a.commodityid";
            DataView dv = Util.ExecSqlQry(sql, Setting.DBConnectString);

            foreach (DataRowView dr in dv)
            {
                string Source = "";
                string CommodityId = "";
                string BaseInformationTime = "";
                string BaseInformationSeq = "";
                double DecimalLocate = 0.0;
                double ReferencePrice = 0.0;
                double RiseLimitPrice = 0.0;
                double FallLimitPrice = 0.0;
                string MatchInformationTime = "";
                string MatchInformationSeq = "";
                string MatchTime = "";
                int MatchSeq = 0;
                double MatchPrice = 0.0;
                int MatchQty = 0;
                int MatchTotalQty = 0;
                double MatchAmt = 0.0;
                double MatchTotalAmt = 0.0;
                string Best5InformationTime = "";
                string Best5InformationSeq = "";
                double BuyPriceBest1 = 0.0;
                double BuyPriceBest2 = 0.0;
                double BuyPriceBest3 = 0.0;
                double BuyPriceBest4 = 0.0;
                double BuyPriceBest5 = 0.0;
                int BuyQtyBest1 = 0;
                int BuyQtyBest2 = 0;
                int BuyQtyBest3 = 0;
                int BuyQtyBest4 = 0;
                int BuyQtyBest5 = 0;
                double SellPriceBest1 = 0.0;
                double SellPriceBest2 = 0.0;
                double SellPriceBest3 = 0.0;
                double SellPriceBest4 = 0.0;
                double SellPriceBest5 = 0.0;
                int SellQtyBest1 = 0;
                int SellQtyBest2 = 0;
                int SellQtyBest3 = 0;
                int SellQtyBest4 = 0;
                int SellQtyBest5 = 0;

                Source = dr["Source"].ToString().Trim();
                CommodityId = dr["CommodityId"].ToString().Trim();
                BaseInformationTime = dr["BaseInformationTime"].ToString().Trim();
                BaseInformationSeq = dr["BaseInformationSeq"].ToString().Trim();
                DecimalLocate = Convert.ToDouble(dr["DecimalLocate"]);
                ReferencePrice = Convert.ToDouble(dr["ReferencePrice"]);
                RiseLimitPrice = Convert.ToDouble(dr["RiseLimitPrice"]);
                FallLimitPrice = Convert.ToDouble(dr["FallLimitPrice"]);

                FastPCommodity P = m_PCommodityList.Set(Source, CommodityId);
                P.TradeDate = DateTime.Today;
                P.QSimpleCommodity.QSimpleBase.InformationTime = BaseInformationTime;
                P.QSimpleCommodity.QSimpleBase.InformationSeq = BaseInformationSeq;
                P.QSimpleCommodity.QSimpleBase.DecimalLocate = DecimalLocate;
                P.QSimpleCommodity.QSimpleBase.ReferencePrice = ReferencePrice;
                P.QSimpleCommodity.QSimpleBase.RiseLimitPrice = RiseLimitPrice;
                P.QSimpleCommodity.QSimpleBase.FallLimitPrice = FallLimitPrice;

                if (dr["MatchInformationTime"] != DBNull.Value)
                {
                    MatchInformationTime = dr["MatchInformationTime"].ToString().Trim();
                    MatchInformationSeq = dr["MatchInformationSeq"].ToString().Trim();
                    MatchTime = dr["MatchTime"].ToString().Trim();
                    MatchSeq = Convert.ToInt32(dr["MatchSeq"]);
                    MatchPrice = Convert.ToDouble(dr["MatchPrice"]);
                    MatchQty = Convert.ToInt32(dr["MatchQty"]);
                    MatchTotalQty = Convert.ToInt32(dr["MatchTotalQty"]);
                    MatchAmt = Convert.ToDouble(dr["MatchAmt"]);
                    MatchTotalAmt = Convert.ToDouble(dr["MatchTotalAmt"]);
                                        
                    P.QSimpleCommodity.QSimpleMatch.InformationTime = MatchInformationTime;
                    P.QSimpleCommodity.QSimpleMatch.InformationSeq = MatchInformationSeq;
                    P.QSimpleCommodity.QSimpleMatch.MatchSeq = MatchSeq;
                    P.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                    P.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQty;
                    P.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTotalQty;
                    P.QSimpleCommodity.QSimpleMatch.MatchAmt = MatchAmt;
                    P.QSimpleCommodity.QSimpleMatch.MatchTotalAmt = MatchTotalAmt;
                }
                if (dr["Best5InformationTime"] != DBNull.Value)
                {
                    Best5InformationTime = dr["Best5InformationTime"].ToString().Trim();
                    Best5InformationSeq = dr["Best5InformationSeq"].ToString().Trim();
                    BuyPriceBest1 = Convert.ToDouble(dr["BuyPriceBest1"]);
                    BuyPriceBest2 = Convert.ToDouble(dr["BuyPriceBest2"]);
                    BuyPriceBest3 = Convert.ToDouble(dr["BuyPriceBest3"]);
                    BuyPriceBest4 = Convert.ToDouble(dr["BuyPriceBest4"]);
                    BuyPriceBest5 = Convert.ToDouble(dr["BuyPriceBest5"]);
                    BuyQtyBest1 = Convert.ToInt32(dr["BuyQtyBest1"]);
                    BuyQtyBest2 = Convert.ToInt32(dr["BuyQtyBest2"]);
                    BuyQtyBest3 = Convert.ToInt32(dr["BuyQtyBest3"]);
                    BuyQtyBest4 = Convert.ToInt32(dr["BuyQtyBest4"]);
                    BuyQtyBest5 = Convert.ToInt32(dr["BuyQtyBest5"]);
                    SellPriceBest1 = Convert.ToDouble(dr["SellPriceBest1"]);
                    SellPriceBest2 = Convert.ToDouble(dr["SellPriceBest2"]);
                    SellPriceBest3 = Convert.ToDouble(dr["SellPriceBest3"]);
                    SellPriceBest4 = Convert.ToDouble(dr["SellPriceBest4"]);
                    SellPriceBest5 = Convert.ToDouble(dr["SellPriceBest5"]);
                    SellQtyBest1 = Convert.ToInt32(dr["SellQtyBest1"]);
                    SellQtyBest2 = Convert.ToInt32(dr["SellQtyBest2"]);
                    SellQtyBest3 = Convert.ToInt32(dr["SellQtyBest3"]);
                    SellQtyBest4 = Convert.ToInt32(dr["SellQtyBest4"]);
                    SellQtyBest5 = Convert.ToInt32(dr["SellQtyBest5"]);

                    P.QSimpleCommodity.QSimpleBest5.InformationTime = Best5InformationTime;
                    P.QSimpleCommodity.QSimpleBest5.InformationSeq = Best5InformationSeq;
                    P.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                    P.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                    P.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                    P.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                    P.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                    P.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                    P.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                    P.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                    P.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                    P.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;
                    P.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                    P.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                    P.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                    P.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                    P.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                    P.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                    P.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                    P.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                    P.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                    P.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;
                }                
            }
        }
        
        private void WriteToStateLog(string str)
        {
            try
            {                
                lock (gStateLog)
                {
                    gStateLog.WriteLine(str);
                    gStateLog.Flush();
                }
            }
            catch (Exception ex)
            {
            }
        }        
        #endregion

        #region IDisposable 成員

        public void Dispose()
        {
            Close();
        }

        #endregion

        #region IQuoteClient 成員

        List<string> IQuoteClient.SubCommodity(List<string> CommodityList)
        {
            try
            {
                FastClientState ClientState = m_ClientStateList.Set(OperationContext.Current);

                foreach (string CommodityId in CommodityList)
                {
                    string jCommodityId = "";

                    try
                    {
                        jCommodityId = CommodityId.ToUpper().Trim();
                        if (jCommodityId.IndexOf("/") > -1) { continue; }

                        if (ClientState.SubList.Contains(jCommodityId)) { continue; }


                        FastPCommodity FastPCommodity = m_PCommodityList.Get(jCommodityId);

                        if (FastPCommodity != null)
                        {
                            FastPCommodity.SetFastClientState(ClientState);
                            ClientState.SetFastPCommodity(FastPCommodity);

                            ClientState.AddData(FastPCommodity.QSimpleCommodity);
                        }                                                
                    }
                    catch (Exception ex)
                    {
                        m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][SubCommodity_Error][" + jCommodityId + "]" + "[" + ex.Message + "][" + ex.StackTrace + "]");
                    }
                }

                return ClientState.SubList;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][SubCommodity_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }
        }
        List<string> IQuoteClient.UnSubCommodity(List<string> CommodityList)
        {
            try
            {
                FastClientState ClientState = m_ClientStateList.Set(OperationContext.Current);

                foreach (string CommodityId in CommodityList)
                {
                    string jCommodityId = CommodityId.ToUpper().Trim();

                    if (jCommodityId.IndexOf("/") > -1) { continue; }

                    FastPCommodity FastPCommodity = m_PCommodityList.Get(jCommodityId);

                    if (FastPCommodity != null)
                    {
                        FastPCommodity.RemoveFastClientState(ClientState);
                        ClientState.RemoveFastPCommodity(FastPCommodity);
                    }                    
                }

                return ClientState.SubList;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][UnSubCommodity_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }
        }

        public List<QCommodity> GetImage(List<string> CommodityList)
        {
            return null;
        }
        List<QSimpleCommodity> IQuoteClient.GetSimpleImage(List<string> CommodityList)
        {
            try
            {
                List<QSimpleCommodity> L = new List<QSimpleCommodity>();

                foreach (string CommodityId in CommodityList)
                {
                    string jCommodityId = CommodityId.ToUpper().Trim();

                    if (jCommodityId.IndexOf("/") > -1) { continue; }
                               
                    string lCommodityId = jCommodityId;

                    FastPCommodity PCommodity = m_PCommodityList.Get(lCommodityId);

                    if (PCommodity != null)
                        L.Add(PCommodity.QSimpleCommodity);
                }

                return L;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][GetImage_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }
        }
        List<string> IQuoteClient.GetSubCommodityList()
        {
            IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

            FastClientState ClientState = m_ClientStateList.Get(Callback);

            if (ClientState != null)
                return ClientState.SubList;
            else
                return new List<string>();
        }
        List<QMatch> IQuoteClient.GetCommodityTicks(string CommodityId)
        {
            throw new NotImplementedException();
        }
        void IQuoteClient.Close()
        {
            try
            {
                IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                FastClientState ClientState = m_ClientStateList.Get(Callback);

                if (ClientState != null)
                    ClientStateList.Remove(Callback);
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][ClientClose_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        bool IQuoteClient.GetAlived()
        {
            try
            {
                IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                FastClientState ClientState = m_ClientStateList.Get(Callback);
                if (ClientState != null) { ClientState.AliveTime = DateTime.Now; }
                return true;
            }
            catch (Exception ex)
            {
                m_ErrQueue.Enqueue("[FastQuote][" + DateTime.Now.ToString() + "][GetAlived_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return false;
            }
        }

        #endregion

        #region ITSServer 成員

        int DeriLib.TSModel.ITSServer.Connections
        {
            get { throw new NotImplementedException(); }
        }

        string DeriLib.TSModel.ITSServer.Service
        {
            get { return Setting.Service; }
        }

        string DeriLib.TSModel.ITSServer.Note
        {
            get { return Setting.Note; }
        }

        bool DeriLib.TSModel.ITSServer.Start()
        {
            this.Start();
            return true;
        }

        bool DeriLib.TSModel.ITSServer.AddDataSource(DeriLib.TSModel.ITSFactory DataSource)
        {
            FastQuoteSource QuoteSource = DataSource as FastQuoteSource;

            if (QuoteSource != null)
            {
                AddQuoteSource(QuoteSource);
                return true;
            }
            else
                return false;
        }

        bool DeriLib.TSModel.ITSServer.RemoveDataSource(string DataSource)
        {
            RemoveQuoteSource(DataSource);
            return true;
        }

        bool DeriLib.TSModel.ITSServer.Close()
        {
            this.Close();
            return true;
        }

        List<IClientState> DeriLib.TSModel.ITSServer.ClientStates
        {
            get
            {
                List<IClientState> L = new List<IClientState>();

                foreach (FastClientState C in m_ClientStateList.ClientStates)
                    L.Add((IClientState)C);
                return L;
            }
        }

        void DeriLib.TSModel.ITSServer.RemoveClientState(string IP, int Port)
        {
            m_ClientStateList.Remove(IP, Port);
        }
        Queue DeriLib.TSModel.ITSServer.ErrorQueue
        {
            get { return m_ErrQueueOut; }
        }

        Dictionary<string, DeriLib.TSModel.ITSFactory> DeriLib.TSModel.ITSServer.DataSources
        {
            get
            {
                List<FastQuoteSource> L = m_QuoteSourceList.QuoteSources;
                Dictionary<string, DeriLib.TSModel.ITSFactory> I = new Dictionary<string, DeriLib.TSModel.ITSFactory>();

                foreach (FastQuoteSource d in L)
                {
                    I.Add(d.DataSource, (DeriLib.TSModel.ITSFactory)d);
                }

                return I;
            }
        }

        event DeriLib.TSModel.ErrorHandler DeriLib.TSModel.ITSServer.ErrorFire
        {
            add { throw new NotImplementedException(); }
            remove { throw new NotImplementedException(); }
        }

        #endregion

    }

    public class FastClientState : IClientState
    {
        private HashSet<FastPCommodity> m_Commoditys = new HashSet<FastPCommodity>();        
        public IQuoteCallBacks Callback;
        public string IP = "";
        public int Port = 0;
        public DateTime LoginTime = DateTime.Now;
        private Queue DataQueue = new Queue();
        private object LockObj = new object();
        private Thread RoutineThread;
        public DateTime AliveTime = DateTime.Now;
        
        public FastClientState(OperationContext O)
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            this.Callback = O.GetCallbackChannel<IQuoteCallBacks>();
            if (!O.IncomingMessageProperties.ContainsKey(RemoteEndpointMessageProperty.Name)) { IP = "127.0.0.1"; }
            else
            {
                RemoteEndpointMessageProperty r = (RemoteEndpointMessageProperty)O.IncomingMessageProperties[System.ServiceModel.Channels.RemoteEndpointMessageProperty.Name];
                IP = r.Address;
                Port = r.Port;
            }
        }

        public void SetFastPCommodity(FastPCommodity PCommodity)
        {
            lock (LockObj)
            {
                if (!m_Commoditys.Contains(PCommodity))
                    m_Commoditys.Add(PCommodity);
            }
        }
        public void RemoveFastPCommodity(FastPCommodity PCommodity)
        {
            lock (LockObj)
            {
                if (m_Commoditys.Contains(PCommodity))
                    m_Commoditys.Remove(PCommodity);
            }
        }
        public List<FastPCommodity> Commoditys
        {
            get
            {
                List<FastPCommodity> L = null;

                lock (LockObj)
                {
                    L = m_Commoditys.ToList<FastPCommodity>();
                }

                return L;
            }
        }        
        public void Close()
        {
            try
            {
                try
                {
                    if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                }
                catch
                {
                }

                foreach (FastPCommodity FastPCommodity in Commoditys)
                    if (FastPCommodity != null) { FastPCommodity.RemoveFastClientState(this); }

                lock (LockObj)
                {
                    m_Commoditys.Clear();
                }

                ICommunicationObject g = (ICommunicationObject)Callback;
                if (g.State == CommunicationState.Opened) { g.Close(); }
            }
            catch (Exception ex)
            {
                string f = "";
            }
        }
        public List<string> SubList
        {
            get
            {
                List<string> L = new List<string>();

                lock (LockObj)
                {
                    foreach (FastPCommodity s in m_Commoditys)
                        L.Add(s.CommodityId);
                }

                return L;
            }
        }

        public void AddData(object obj)
        {
            lock (LockObj)
            {
                DataQueue.Enqueue(obj);
            }
        }
        public void SendData(object obj)
        {
            if (obj.GetType() == typeof(QSimpleCommodity))
                Callback.QSimpleCommodityArrived((QSimpleCommodity)obj);
            else if (obj.GetType() == typeof(QSimpleBase))
                Callback.QSimpleBaseArrived((QSimpleBase)obj);
            /*else if (obj.GetType() == typeof(QMatchBest5))
                Callback.QMatchBest5Arrived((QMatchBest5)obj);*/
            else if (obj.GetType() == typeof(QSimpleMatch))
                Callback.QSimpleMatchArrived((QSimpleMatch)obj);
            else if (obj.GetType() == typeof(QSimpleBest5))
                Callback.QSimpleBest5Arrived((QSimpleBest5)obj);
            else if (obj.GetType() == typeof(QueryCls))
                Callback.QQueryArrived((QueryCls)obj);
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    while (DataQueue.Count > 0)
                    {
                        object obj = null;

                        lock (LockObj)
                        {
                            obj = DataQueue.Dequeue();
                        }

                        if (obj.GetType() == typeof(QSimpleCommodity))
                            Callback.QSimpleCommodityArrived((QSimpleCommodity)obj);
                        else if (obj.GetType() == typeof(QSimpleBase))
                            Callback.QSimpleBaseArrived((QSimpleBase)obj);
                        /*else if (obj.GetType() == typeof(QMatchBest5))
                            Callback.QMatchBest5Arrived((QMatchBest5)obj);*/
                        else if (obj.GetType() == typeof(QSimpleMatch))
                            Callback.QSimpleMatchArrived((QSimpleMatch)obj);
                        else if (obj.GetType() == typeof(QSimpleBest5))
                            Callback.QSimpleBest5Arrived((QSimpleBest5)obj);
                        else if (obj.GetType() == typeof(QueryCls))
                            Callback.QQueryArrived((QueryCls)obj);                 
                    }

                    Thread.Sleep(1);
                }
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }

        #region IClientState 成員

        string IClientState.IP
        {
            get { return this.IP; }
        }

        int IClientState.Port
        {
            get { return this.Port; }
        }

        DateTime IClientState.LoginTime
        {
            get { return this.LoginTime; }
        }
        List<string> IClientState.SubList
        {
            get { return this.SubList; }
        }
        void IClientState.Close()
        {
            this.Close();
        }

        #endregion
    }
    public class FastClientStateList
    {
        private Dictionary<IQuoteCallBacks, FastClientState> m_ClientStates = new Dictionary<IQuoteCallBacks, FastClientState>();
        private object LockObj = new object();

        public FastClientState Set(OperationContext O)
        {
            lock (LockObj)
            {
                IQuoteCallBacks Callback = OperationContext.Current.GetCallbackChannel<IQuoteCallBacks>();

                if (!m_ClientStates.ContainsKey(Callback))
                    m_ClientStates.Add(Callback, new FastClientState(O));

                return m_ClientStates[Callback];
            }
        }
        public FastClientState Get(IQuoteCallBacks Callback)
        {
            lock (LockObj)
            {
                if (m_ClientStates.ContainsKey(Callback))
                    return m_ClientStates[Callback];
                else
                    return null;
            }
        }
        public List<FastClientState> ClientStates
        {
            get
            {
                List<FastClientState> L = null;

                lock (LockObj)
                {
                    L = m_ClientStates.Values.ToList<FastClientState>();
                }

                return L;
            }
        }
        public void Remove(IQuoteCallBacks Callback)
        {
            FastClientState FastClientState = null;

            lock (LockObj)
            {
                if (m_ClientStates.ContainsKey(Callback))
                    FastClientState = m_ClientStates[Callback];
            }

            if (FastClientState != null)
                FastClientState.Close();

            lock (LockObj)
            {
                if (m_ClientStates.ContainsKey(Callback))
                    m_ClientStates.Remove(Callback);
            }
        }
        public void Remove(String IP, int Port)
        {
            foreach (FastClientState C in ClientStates)
            {
                if (C.IP == IP && C.Port == Port)
                {
                    lock (LockObj)
                    {
                        m_ClientStates.Remove(C.Callback);
                    }

                    if (C != null)
                        C.Close();
                }
            }
        }        
        public void Close()
        {
            try
            {
                foreach (FastClientState ClientState in ClientStates)
                    ClientState.Close();

                lock (LockObj)
                {
                    m_ClientStates.Clear();
                }
            }
            catch (Exception ex)
            {
                string g = "";
            }
        }
    }

    public class FastPCommodity
    {
        public string CommodityId;
        public QSimpleCommodity QSimpleCommodity = null;        
        private HashSet<FastClientState> m_Subscribes = new HashSet<FastClientState>();
        public DateTime TradeDate = DateTime.Today;
        private object LockObj = new object();
        
        public FastPCommodity(string CommodityId)
        {
            this.CommodityId = CommodityId;
            QSimpleCommodity = new QSimpleCommodity(CommodityId);
            QSimpleCommodity.QSimpleBase = new QSimpleBase(CommodityId);
            QSimpleCommodity.QSimpleMatch = new QSimpleMatch(CommodityId);
            QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(CommodityId);
        }

        public void SetFastClientState(FastClientState FastClientState)
        {
            lock (LockObj)
            {
                if (!m_Subscribes.Contains(FastClientState))
                    m_Subscribes.Add(FastClientState);
            }
        }
        public void RemoveFastClientState(FastClientState FastClientState)
        {
            lock (LockObj)
            {
                if (m_Subscribes.Contains(FastClientState))
                    m_Subscribes.Remove(FastClientState);
            }
        }
        public List<FastClientState> Subscribes
        {
            get
            {
                List<FastClientState> L = null;

                lock (LockObj)
                {
                    L = m_Subscribes.ToList<FastClientState>();
                }

                return L;
            }
        }
        public void Close()
        {
            try
            {
                foreach (FastClientState FastClientState in Subscribes)
                    FastClientState.RemoveFastPCommodity(this);

                lock (LockObj)
                {
                    m_Subscribes.Clear();
                }
            }
            catch (Exception ex)
            {
            }
        }
        public void Send(object obj)
        {
            List<FastClientState> ClientStateRemoveList = new List<FastClientState>();

            foreach (FastClientState FastClientState in Subscribes)
            {
                try
                {
                    //FastClientState.AddData(obj);
                    FastClientState.SendData(obj);
                }
                catch
                {
                    ClientStateRemoveList.Add(FastClientState);
                }
            }

            foreach (FastClientState FastClientState in ClientStateRemoveList)
            {
                m_Subscribes.Remove(FastClientState);
                FastClientState.Close();
            }
        }       
    }
    public class FastPCommodityList
    {
        private Dictionary<string, FastPCommodity> m_Commoditys = new Dictionary<string, FastPCommodity>();
        public FastPCommodity FQuery = new FastPCommodity("FQuery");
        public FastPCommodity OQuery = new FastPCommodity("OQuery");
        public FastPCommodity TSE = new FastPCommodity("TSE");
        public FastPCommodity OTC = new FastPCommodity("OTC");
        public FastPCommodity TSEWRT = new FastPCommodity("TSEWRT");
        public FastPCommodity OTCWRT = new FastPCommodity("OTCWRT");
        public FastPCommodity FUT = new FastPCommodity("FUT");
        public FastPCommodity OPT = new FastPCommodity("OPT");

        private Dictionary<string, FastPCommodity> TSECommoditys = new Dictionary<string, FastPCommodity>();
        private Dictionary<string, FastPCommodity> OTCCommoditys = new Dictionary<string, FastPCommodity>();
        private Dictionary<string, FastPCommodity> TSEWRTCommoditys = new Dictionary<string, FastPCommodity>();
        private Dictionary<string, FastPCommodity> OTCWRTCommoditys = new Dictionary<string, FastPCommodity>();
        private Dictionary<string, FastPCommodity> FUTCommoditys = new Dictionary<string, FastPCommodity>();
        private Dictionary<string, FastPCommodity> OPTCommoditys = new Dictionary<string, FastPCommodity>();
        private object LockObj = new object();        
        
        public FastPCommodityList()
        {
            m_Commoditys.Add("FQuery", FQuery);
            m_Commoditys.Add("OQuery", OQuery);
            m_Commoditys.Add("TSE", TSE);
            m_Commoditys.Add("OTC", OTC);
            m_Commoditys.Add("TSEWRT", TSEWRT);
            m_Commoditys.Add("OTCWRT", OTCWRT);
            m_Commoditys.Add("FUT", FUT);
            m_Commoditys.Add("OPT", OPT);
        }
        
        public FastPCommodity Set(string Source,string CommodityId)
        {
            try
            {
                FastPCommodity mPCommodity = null;

                lock (LockObj)
                {
                    if (!m_Commoditys.ContainsKey(CommodityId))
                    {
                        FastPCommodity PCommodity = new FastPCommodity(CommodityId);
                        m_Commoditys.Add(CommodityId, PCommodity);                        
                    }

                    mPCommodity = m_Commoditys[CommodityId];

                    if (Source == "TSE" && !TSECommoditys.ContainsKey(CommodityId)) { TSECommoditys.Add(CommodityId, mPCommodity); }
                    else if (Source == "OTC" && !OTCCommoditys.ContainsKey(CommodityId)) { OTCCommoditys.Add(CommodityId, mPCommodity); }
                    else if (Source == "TSEWRT" && !TSEWRTCommoditys.ContainsKey(CommodityId)) { TSEWRTCommoditys.Add(CommodityId, mPCommodity); }
                    else if (Source == "OTCWRT" && !OTCWRTCommoditys.ContainsKey(CommodityId)) { OTCWRTCommoditys.Add(CommodityId, mPCommodity); }
                    else if (Source == "FUT" && !FUTCommoditys.ContainsKey(CommodityId)) { FUTCommoditys.Add(CommodityId, mPCommodity); }
                    else if (Source == "OPT" && !OPTCommoditys.ContainsKey(CommodityId)) { OPTCommoditys.Add(CommodityId, mPCommodity); }
                }

                return mPCommodity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }        
        public FastPCommodity Get(string CommodityId)
        {
            lock (LockObj)
            {
                if (m_Commoditys.ContainsKey(CommodityId))
                    return m_Commoditys[CommodityId];
                else
                    return null;
            }
        }
        public FastPCommodity Get(string Source, string CommodityId)
        {
            lock (LockObj)
            {
                if (Source == "TSE" && !TSECommoditys.ContainsKey(CommodityId)) { return TSECommoditys[CommodityId]; }
                else if (Source == "OTC" && !OTCCommoditys.ContainsKey(CommodityId)) { return OTCCommoditys[CommodityId]; }
                else if (Source == "TSEWRT" && !TSEWRTCommoditys.ContainsKey(CommodityId)) { return TSEWRTCommoditys[CommodityId]; }
                else if (Source == "OTCWRT" && !OTCWRTCommoditys.ContainsKey(CommodityId)) { return OTCWRTCommoditys[CommodityId]; }
                else if (Source == "FUT" && !FUTCommoditys.ContainsKey(CommodityId)) { return FUTCommoditys[CommodityId]; }
                else if (Source == "OPT" && !OPTCommoditys.ContainsKey(CommodityId)) { return OPTCommoditys[CommodityId]; }                
            }

            return Get(CommodityId);
        }
        public List<FastPCommodity> Commoditys
        {
            get
            {
                List<FastPCommodity> L = null;

                lock (LockObj)
                {
                    L = m_Commoditys.Values.ToList<FastPCommodity>();
                }

                return L;
            }
        }
        public void Remove(string CommodityId)
        {
            FastPCommodity FastPCommodity = Get(CommodityId);

            if (FastPCommodity != null)
            {
                lock (LockObj)
                {
                    m_Commoditys.Remove(CommodityId);
                }

                FastPCommodity.Close();
            }
        }
        public void Close()
        {
            try
            {
                foreach (FastPCommodity FastPCommodity in Commoditys)
                    FastPCommodity.Close();
                
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }        
        public void RemoveNoneTradeCommodity()
        {
            try
            {
                foreach (FastPCommodity FastPCommodity in Commoditys)
                {
                    if (FastPCommodity.CommodityId == "FQuery" || FastPCommodity.CommodityId == "PQuery" || FastPCommodity.CommodityId == "TSE" || FastPCommodity.CommodityId == "OTC" || FastPCommodity.CommodityId == "TSEWRT" || FastPCommodity.CommodityId == "OTCWRT" || FastPCommodity.CommodityId == "FUT" || FastPCommodity.CommodityId == "OPT") { continue; }

                    if (FastPCommodity.TradeDate != DateTime.Today) { Remove(FastPCommodity.CommodityId); }
                }                
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }
    }
        
    public abstract class FastQuoteSource : DeriLib.TSModel.ITSFactory
    {
        protected QuoteFactorySetting m_QuoteSetting;
        protected FastPCommodityList m_PCommodityList;
        
        protected Queue m_ErrorPool = Queue.Synchronized(new Queue());        
        protected Queue m_PackagePool = Queue.Synchronized(new Queue());//接收行情待處理Queue                          
        protected int m_PacketNum;
        protected bool InitialOK = true;
        protected TimeSpan IniTime;       

        public FastQuoteSource(QuoteFactorySetting QuoteSetting)
        {
            this.m_QuoteSetting = QuoteSetting;
        }
        public QuoteFactorySetting QuoteSetting
        {
            get { return m_QuoteSetting; }
        }
        public FastPCommodityList PCommodityList
        {
            get { return m_PCommodityList; }
            set { m_PCommodityList = value; }
        }        
        public void SetReceivePacket(int i)
        {
            m_PacketNum = i;
        }
        
        protected void ErrorProcess(string str)
        {
            m_ErrorPool.Enqueue(str);        
        }

        #region ITSFactory 成員

        public int SendPacketNum
        {
            get { return 0; }
        }

        public int ReceivePacketNum
        {
            get { return m_PacketNum; }
        }

        public int ReadDBNum
        {
            get { return 0; }
        }

        public int WriteDBNum
        {
            get { return 0; }
        }

        public string DataSource
        {
            get { return QuoteSetting.DataSource; }
        }

        public string Note
        {
            get { return QuoteSetting.DataSource; }
        }
        public Queue ErrorQueue
        {
            get { return m_ErrorPool; }
        }
        public virtual bool Start()
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public virtual bool Close()
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public event DeriLib.TSModel.ErrorHandler ErrorFire;

        #endregion
    }
    public class FastQuoteSourceList
    {
        private Dictionary<string, FastQuoteSource> m_QuoteSources = new Dictionary<string, FastQuoteSource>();
        private object LockObj = new object();
        private Queue<string> m_ErrorPool = new Queue<string>();

        public FastQuoteSourceList()
        {

        }

        public FastQuoteSource Set(FastQuoteSource QuoteSource)
        {
            lock (LockObj)
            {
                if (!m_QuoteSources.ContainsKey(QuoteSource.QuoteSetting.DataSource))
                    m_QuoteSources.Add(QuoteSource.QuoteSetting.DataSource, QuoteSource);
            }

            return m_QuoteSources[QuoteSource.QuoteSetting.DataSource];
        }
        public FastQuoteSource Get(string DataSource)
        {
            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(DataSource))
                    return m_QuoteSources[DataSource];
                else
                    return null;
            }
        }
        public List<FastQuoteSource> QuoteSources
        {
            get
            {
                List<FastQuoteSource> L = null;

                lock (LockObj)
                {
                    L = m_QuoteSources.Values.ToList<FastQuoteSource>();
                }

                return L;
            }
        }
        public void Remove(string DataSource)
        {
            FastQuoteSource QuoteSource = null;

            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(DataSource))
                    QuoteSource = m_QuoteSources[DataSource];
            }

            if (QuoteSource != null)
                QuoteSource.Close();

            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(DataSource))
                    m_QuoteSources.Remove(DataSource);
            }
        }
        public Queue<string> ErrPool
        {
            get
            {
                lock (LockObj)
                {
                    foreach (FastQuoteSource QuoteSource in m_QuoteSources.Values)
                    {
                        while (QuoteSource.ErrorQueue.Count > 0)
                            m_ErrorPool.Enqueue(QuoteSource.ErrorQueue.Dequeue().ToString());
                    }
                }
                return m_ErrorPool;
            }
        }
        public bool ContainKey(string Key)
        {
            lock (LockObj)
            {
                if (m_QuoteSources.ContainsKey(Key))
                    return true;
                else
                    return false;
            }
        }        
        public void Close()
        {
            try
            {
                foreach (FastQuoteSource QuoteSource in QuoteSources)
                    QuoteSource.Close();

                lock (LockObj)
                {
                    m_QuoteSources.Clear();
                }
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }        
    }
    
    public class SimpleTFETSEQuoteSource : FastQuoteSource
    {
        private Thread ReceiveThread;
        private Thread DoThread;
        private Socket rvUdp = null;
        private Socket sdUdp = null;
        private EndPoint groupEP = null;
        private List<string> CMonth = new List<string>(new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" });
        private List<string> PMonth = new List<string>(new string[] { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" });        
        private QueryList QueryList = new QueryList();

        #region 變數
        int othercol = 17;
        string InformationTime;
        string InformationSeq;
        string VersionNo;

        int sBodyLength = 0;
        int Packetlength = 0;

        string sCommodityId;
        double sRiseLimitPrice = 0.0;
        double sReferencePrice = 0.0;
        double sFallLimitPrice = 0.0;

        string Prod_Kind;
        double Decimal_Locate = 0.0;
        double Strike_Decimal_Locate = 0.0;

        string MatchTime;
        double MatchPrice = 0.0;
        int MatchQuantity = 0;
        int MatchTOTALQty = 0;

        double BuyPriceBest1 = 0.0;
        int BuyQtyBest1 = 0;
        double BuyPriceBest2 = 0.0;
        int BuyQtyBest2 = 0;
        double BuyPriceBest3 = 0.0;
        int BuyQtyBest3 = 0;
        double BuyPriceBest4 = 0.0;
        int BuyQtyBest4 = 0;
        double BuyPriceBest5 = 0.0;
        int BuyQtyBest5 = 0;
        double SellPriceBest1 = 0.0;
        int SellQtyBest1 = 0;
        double SellPriceBest2 = 0.0;
        int SellQtyBest2 = 0;
        double SellPriceBest3 = 0.0;
        int SellQtyBest3 = 0;
        double SellPriceBest4 = 0.0;
        int SellQtyBest4 = 0;
        double SellPriceBest5 = 0.0;
        int SellQtyBest5 = 0;

        double BuyPriceDerived = 0.0;
        int BuyQtyDerived = 0;
        double SellPriceDerived = 0.0;
        int SellQtyDerived = 0;

        string DisclosureTime;
        int DurationTime = 0;

        int Match_seq;
        int Fx_Match_seq = 0;
        int Fx_PacketLost_Qty = 0;
        double best5DecimalLocate = 0.0;

        int Op_Match_seq = 0;
        int Op_PacketLost_Qty = 0;
                
        int sDisPlayTag = 0;
        int sFallRiseTag = 0;
        int nResult = 0;
        int nPos = 0;

        double AccountSum = 0;
        int AccountQuantity = 0;
        int AccountOrder = 0;
        double AccountSumTotal = 0;
        int AccountQuantityTotal = 0;

        string IndexCode = "";
        int IndexItems = 0;
        double IndexValue = 0.0;

        int Tse_Match_seq = 0;
        int Tse_PacketLost_Qty = 0;

        int StkCnt = 0;

        int Otc_Match_seq = 0;
        int Otc_PacketLost_Qty = 0;
        #endregion

        public SimpleTFETSEQuoteSource(QuoteFactorySetting QuoteSetting)
            : base(QuoteSetting)
        {
            IniTime = new TimeSpan(2, 0, 0);
        }
        public override bool Start()
        {
            InitialUDP();
            if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_File)
            {
                ReceiveThread = new Thread(new ThreadStart(ReadFile));
                ReceiveThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse2_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc2_Udp)
            {
                ReceiveThread = new Thread(new ThreadStart(ReadUdp));
                ReceiveThread.Start();
            }

            if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_Udp)
            {                

                DoThread = new Thread(new ThreadStart(DealWithFx));
                DoThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_Udp)
            {             
                DoThread = new Thread(new ThreadStart(DealWithOp));
                DoThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse2_Udp)
            {
                DoThread = new Thread(new ThreadStart(DealWithTse));
                DoThread.Start();
            }
            else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc2_Udp)
            {
                DoThread = new Thread(new ThreadStart(DealWithOtc));
                DoThread.Start();
            }

            return base.Start();
        }
        public override bool Close()
        {
            try
            {

                base.Close();
                //if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                if (DoThread != null && DoThread.IsAlive) { DoThread.Abort(); }
                if (ReceiveThread != null && ReceiveThread.IsAlive) { ReceiveThread.Abort(); }
                if (rvUdp != null) { rvUdp.Close(); }
                if (sdUdp != null) { sdUdp.Close(); }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        private void InitialUDP()
        {
            try
            {
                string filePath = m_QuoteSetting.LogFileFolder + "\\UDPSetting.ini";

                string temp = "";
                string key = "";
                string localip = "";
                
                int localport = 0;
                string groupip = "";
                int groupport = 0;

                localip = Util.ReadIniString("UDPRelaySetting", "LOCAL_IP", filePath);
                
                if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_Udp)                
                    key = "FX";                
                else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_Udp)                
                    key = "OP";                
                else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_Udp)                
                    key = "TSE";                
                else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_File || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_Udp)                
                    key = "OTC";
                else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse2_Udp)
                    key = "TSE2";
                else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc2_Udp)
                    key = "OTC2";

                temp = Util.ReadIniString("UDPRelaySetting", "LOCAL_" + key + "_PORT", filePath);
                int.TryParse(temp.ToString(),out localport);

                groupip = Util.ReadIniString("UDPRelaySetting", "MULTICAST_" + key + "_IP", filePath);

                temp = Util.ReadIniString("UDPRelaySetting", "MULTICAST_" + key + "_PORT", filePath);                
                int.TryParse(temp.ToString(), out groupport);

                if (localip == "" || localport == 0 || groupip == "" || groupport == 0) { return; }

                sdUdp = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                sdUdp.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.MulticastTimeToLive,1);
                EndPoint localEP = (EndPoint)new IPEndPoint(IPAddress.Parse(localip), localport);
                sdUdp.Bind(localEP);
                groupEP = new IPEndPoint(IPAddress.Parse(groupip), groupport);  
            }
            catch (Exception ex)
            {
                string gg = "";
                sdUdp = null;
            }
        }
        private void ReadFile()
        {
            int oldInByte = 0;
            int InByte = 0;
            int i = 0;
            int j = 0;
            ArrayList sbuffer = new ArrayList();
            FileStream fsInto = null;

            try
            {
                //string sFileName = Application.StartupPath + "\\20041029FxLog.txt";
                string sFileName = m_QuoteSetting.LogFileFolder + "\\" + DateTime.Today.ToString("yyyyMMdd") + "_" + m_QuoteSetting.DataSource + "_" + "Log.txt";
                fsInto = new FileStream(sFileName, FileMode.Open);

                TradeTimeMapping TradeTimeMapping = new TradeTimeMapping(m_QuoteSetting.QuoteSourceKind, m_QuoteSetting.Speed, m_QuoteSetting.FileStartTime.Replace(":", ""));

                while ((InByte = fsInto.ReadByte()) != -1)
                {
                    sbuffer.Add((byte)InByte);
                    i++;
                    if (oldInByte == 13 && InByte == 10)
                    {
                        byte[] ddbyte = new byte[i];
                        sbuffer.CopyTo(ddbyte);

                        TradeTimeMapping.DoTime(ddbyte);

                        //m_PackagePool.Enqueue(ddbyte);
                        if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_File) { DealWithFx(ddbyte); }
                        else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_File) { DealWithOp(ddbyte); }
                        else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_File) { DealWithTse(ddbyte); }
                        else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_File) { DealWithOtc(ddbyte); }

                        if (sdUdp != null) { sdUdp.SendTo(ddbyte, groupEP); }

                        sbuffer.Clear();
                        i = 0;
                        j++;

                        if (m_QuoteSetting.DataSendms != 0 && j % m_QuoteSetting.DataSendms == 0)
                        {
                            j = 0;
                            Thread.Sleep(1);
                        }
                    }
                    oldInByte = InByte;
                }

                fsInto.Close();
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                if (fsInto != null)
                    fsInto.Close();
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ReadFile_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }

        }
        private void ReadUdp()
        {
            try
            {
                rvUdp = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                EndPoint localEP = (EndPoint)new IPEndPoint(IPAddress.Parse(m_QuoteSetting.LocalIp), m_QuoteSetting.LocalPort);
                rvUdp.Bind(localEP);
                rvUdp.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(IPAddress.Parse(m_QuoteSetting.MultiCastIp), IPAddress.Parse(m_QuoteSetting.LocalIp)));

                byte[] bte;
                byte[] sUdpByte;
                int pos = -1;
                int epos = 0;
                List<byte> rBuffer = new List<byte>();

                EndPoint remoteEP = (EndPoint)new IPEndPoint(IPAddress.Any, 0);
                byte[] byteData = new byte[8192];
                int bytelength = 0;

                while (true)
                {
                    bytelength = rvUdp.ReceiveFrom(byteData, byteData.Length, SocketFlags.None, ref remoteEP);
                    sUdpByte = new byte[bytelength];
                    Array.Copy(byteData, sUdpByte, bytelength);
                    rBuffer.AddRange(sUdpByte);

                    for (; ; )
                    {
                        pos = rBuffer.IndexOf((byte)13, pos + 1);

                        if (pos == -1 || pos == rBuffer.Count - 1)
                            break;

                        if ((byte)rBuffer[pos + 1] != 10)
                            continue;

                        bte = new byte[pos + 2];
                        epos = rBuffer.IndexOf((byte)27);

                        if (epos > -1 && epos < pos + 2)
                            rBuffer.CopyTo(epos, bte, 0, pos + 2 - epos);
                        rBuffer.RemoveRange(0, pos + 2);
                        pos = -1;

                        //m_PackagePool.Enqueue(bte);
                        if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeFx_Udp) { DealWithFx(bte); }
                        else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.TfeOp_Udp) { DealWithOp(bte); }
                        else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Tse2_Udp) { DealWithTse(bte); }
                        else if (m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc_Udp || m_QuoteSetting.QuoteSourceKind == QuoteSourceKind.Otc2_Udp) { DealWithOtc(bte); }

                        if (sdUdp != null) { sdUdp.SendTo(bte,groupEP); }
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][ReadUdp_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
       
        #region 報價處理
        private void DealWithFx()
        {
            

            int i = 0;
            byte[] sCheckSum;
            byte[] bte;
            FastPCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            InformationTime = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00") + int.Parse(bte[6].ToString("x")).ToString("00");
                            InformationSeq = int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00") + int.Parse(bte[10].ToString("x")).ToString("00");
                            VersionNo = int.Parse(bte[11].ToString("x")).ToString("00");
                            sBodyLength = int.Parse(int.Parse(bte[12].ToString("x")).ToString("00") + int.Parse(bte[13].ToString("x")).ToString("00"));
                            Packetlength = sBodyLength + othercol;
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 1, 1));
                            int mKind = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 2, 1));

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                #region //TRANSMISSION_CODE_1
                                case 1:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I010 單一商品漲停幅揭示
                                            try
                                            {
                                                Prod_Kind = System.Text.UnicodeEncoding.Default.GetString(bte, 59, 1).Trim();
                                                Decimal_Locate = double.Parse(bte[60].ToString("x"));

                                                if (Decimal_Locate == 0)
                                                    Decimal_Locate = 1.0;
                                                else
                                                    Decimal_Locate = 1 / Math.Pow(10, Decimal_Locate);

                                                Strike_Decimal_Locate = double.Parse(bte[61].ToString("x"));

                                                if (Strike_Decimal_Locate == 0)
                                                    Strike_Decimal_Locate = 1.0;
                                                else
                                                    Strike_Decimal_Locate = 1 / Math.Pow(10, Strike_Decimal_Locate);

                                                sRiseLimitPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * Decimal_Locate;
                                                
                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                                           
                                                mPCommodity = m_PCommodityList.Set("FUT", sCommodityId);

                                                mPCommodity.TradeDate = DateTime.Today;

                                                mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                                                mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate = Decimal_Locate;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;
                                                
                                                DoSendWrite("FUT",mPCommodity,mPCommodity.QSimpleCommodity.QSimpleBase);
                                                
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI010 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion                                       
                                        default:                                            
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_2
                                case 2:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I020 成交價量揭示訊息
                                            try
                                            {

                                                MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");

                                                #region check seq start
                                                if (m_QuoteSetting.IsCheckLost)
                                                {
                                                    Match_seq = Convert.ToInt32(InformationSeq);

                                                    if (Match_seq != 0 && Match_seq != 1)
                                                    {
                                                        if (Match_seq - Fx_Match_seq != 1 && Match_seq > Fx_Match_seq)
                                                        {
                                                            Fx_PacketLost_Qty += Match_seq - Fx_Match_seq - 1;
                                                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][Lost Fx_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Fx_PacketLost_Qty + " Last:" + Fx_Match_seq + " Current:" + Match_seq);
                                                        }
                                                    }
                                                    else
                                                        Fx_PacketLost_Qty = 0;

                                                    //if (Match_seq > Fx_Match_seq)
                                                        Fx_Match_seq = Match_seq;
                                                }
                                                #endregion check seq end

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Get("TFE", sCommodityId);

                                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq))))
                                                {
                                                    MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    MatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));
                                                    MatchTOTALQty = int.Parse(int.Parse(bte[Packetlength - 16].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 15].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 14].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 13].ToString("x")).ToString("00"));

                                                    best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;

                                                    MatchPrice = MatchPrice * best5DecimalLocate;
                                                                                                                                                            
                                                    for (i = 0; i < (int)(bte[48] & 127); i++)
                                                    {
                                                        MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 49 + 8 * i, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[50 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[51 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[52 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[53 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[54 + 8 * i].ToString("x")).ToString("00")) * best5DecimalLocate;
                                                        MatchQuantity += int.Parse(int.Parse(bte[55 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[56 + 8 * i].ToString("x")).ToString("00"));                                                        
                                                    }

                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                                    DoSendWrite("FUT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI020 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2:
                                            #region //I080 委託簿揭示訊息
                                            try
                                            {
                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Get("TFE", sCommodityId);

                                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq) < int.Parse(InformationSeq))))
                                                {
                                                    BuyPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00"));
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    BuyPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 44, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00"));
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00"));
                                                    BuyPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00"));
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00"));
                                                    BuyPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00"));
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00"));
                                                    BuyPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[75].ToString("x")).ToString("00") + int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));

                                                    SellPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 84, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                                    SellPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 94, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                    SellPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 104, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00") + int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00"));
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00") + int.Parse(bte[113].ToString("x")).ToString("00"));
                                                    SellPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 114, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00") + int.Parse(bte[117].ToString("x")).ToString("00") + int.Parse(bte[118].ToString("x")).ToString("00") + int.Parse(bte[119].ToString("x")).ToString("00"));
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[120].ToString("x")).ToString("00") + int.Parse(bte[121].ToString("x")).ToString("00") + int.Parse(bte[122].ToString("x")).ToString("00") + int.Parse(bte[123].ToString("x")).ToString("00"));
                                                    SellPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 124, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[125].ToString("x")).ToString("00") + int.Parse(bte[126].ToString("x")).ToString("00") + int.Parse(bte[127].ToString("x")).ToString("00") + int.Parse(bte[128].ToString("x")).ToString("00") + int.Parse(bte[129].ToString("x")).ToString("00"));
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[130].ToString("x")).ToString("00") + int.Parse(bte[131].ToString("x")).ToString("00") + int.Parse(bte[132].ToString("x")).ToString("00") + int.Parse(bte[133].ToString("x")).ToString("00"));

                                                    BuyPriceDerived = 0.0;
                                                    BuyQtyDerived = 0;
                                                    SellPriceDerived = 0.0;
                                                    SellQtyDerived = 0;

                                                    if (int.Parse(bte[134].ToString("x")).ToString("00") == "01")
                                                    {
                                                        BuyPriceDerived = double.Parse(int.Parse(bte[135].ToString("x")).ToString("00") + int.Parse(bte[136].ToString("x")).ToString("00") + int.Parse(bte[137].ToString("x")).ToString("00") + int.Parse(bte[138].ToString("x")).ToString("00") + int.Parse(bte[139].ToString("x")).ToString("00"));
                                                        BuyQtyDerived = int.Parse(int.Parse(bte[140].ToString("x")).ToString("00") + int.Parse(bte[141].ToString("x")).ToString("00") + int.Parse(bte[142].ToString("x")).ToString("00") + int.Parse(bte[143].ToString("x")).ToString("00"));
                                                        SellPriceDerived = double.Parse(int.Parse(bte[144].ToString("x")).ToString("00") + int.Parse(bte[145].ToString("x")).ToString("00") + int.Parse(bte[146].ToString("x")).ToString("00") + int.Parse(bte[147].ToString("x")).ToString("00") + int.Parse(bte[148].ToString("x")).ToString("00"));
                                                        SellQtyDerived = int.Parse(int.Parse(bte[149].ToString("x")).ToString("00") + int.Parse(bte[150].ToString("x")).ToString("00") + int.Parse(bte[151].ToString("x")).ToString("00") + int.Parse(bte[152].ToString("x")).ToString("00"));

                                                        if (BuyQtyDerived > 0)
                                                        {
                                                            if (BuyPriceDerived > BuyPriceBest1 || BuyPriceBest1 == 0.0)
                                                            {
                                                                BuyPriceBest5 = BuyPriceBest4;
                                                                BuyQtyBest5 = BuyQtyBest4;
                                                                BuyPriceBest4 = BuyPriceBest3;
                                                                BuyQtyBest4 = BuyQtyBest3;
                                                                BuyPriceBest3 = BuyPriceBest2;
                                                                BuyQtyBest3 = BuyQtyBest2;
                                                                BuyPriceBest2 = BuyPriceBest1;
                                                                BuyQtyBest2 = BuyQtyBest1;
                                                                BuyPriceBest1 = BuyPriceDerived;
                                                                BuyQtyBest1 = BuyQtyDerived;
                                                            }
                                                            else if (BuyPriceDerived == BuyPriceBest1)
                                                            {
                                                                BuyQtyBest1 += BuyQtyDerived;
                                                            }
                                                        }

                                                        if (SellQtyDerived > 0)
                                                        {
                                                            if (SellPriceDerived < SellPriceBest1 || SellPriceBest1 == 0.0)
                                                            {
                                                                SellPriceBest5 = SellPriceBest4;
                                                                SellQtyBest5 = SellQtyBest4;
                                                                SellPriceBest4 = SellPriceBest3;
                                                                SellQtyBest4 = SellQtyBest3;
                                                                SellPriceBest3 = SellPriceBest2;
                                                                SellQtyBest3 = SellQtyBest2;
                                                                SellPriceBest2 = SellPriceBest1;
                                                                SellQtyBest2 = SellQtyBest1;
                                                                SellPriceBest1 = SellPriceDerived;
                                                                SellQtyBest1 = SellQtyDerived;
                                                            }
                                                            else if (SellPriceDerived == SellPriceBest1)
                                                            {
                                                                SellQtyBest1 += SellQtyDerived;
                                                            }
                                                        }
                                                    }

                                                    best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;

                                                    BuyPriceBest1 = BuyPriceBest1 * best5DecimalLocate;
                                                    BuyPriceBest2 = BuyPriceBest2 * best5DecimalLocate;
                                                    BuyPriceBest3 = BuyPriceBest3 * best5DecimalLocate;
                                                    BuyPriceBest4 = BuyPriceBest4 * best5DecimalLocate;
                                                    BuyPriceBest5 = BuyPriceBest5 * best5DecimalLocate;
                                                    SellPriceBest1 = SellPriceBest1 * best5DecimalLocate;
                                                    SellPriceBest2 = SellPriceBest2 * best5DecimalLocate;
                                                    SellPriceBest3 = SellPriceBest3 * best5DecimalLocate;
                                                    SellPriceBest4 = SellPriceBest4 * best5DecimalLocate;
                                                    SellPriceBest5 = SellPriceBest5 * best5DecimalLocate;

                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                                    DoSendWrite("FUT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);                                                    
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI080 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion                                        
                                        case 4:
                                            #region //I100 詢價揭示訊息
                                            try
                                            {
                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                DisclosureTime = int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00");
                                                DurationTime = int.Parse(int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00"));

                                                QueryCls QQ = QueryList.Add("F", sCommodityId, InformationTime, InformationSeq, DisclosureTime, DurationTime);

                                                if (QQ != null) { DoSendWriteQuery(QQ); }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI100 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion                                        
                                        default:                                            
                                            break;
                                    }
                                    break;
                                #endregion                                
                                default:                                    
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }

        }
        private void DealWithOp()
        {
            
            int i = 0;
            byte[] sCheckSum;
            byte[] bte;

            FastPCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            InformationTime = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00") + int.Parse(bte[6].ToString("x")).ToString("00");
                            InformationSeq = int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00") + int.Parse(bte[10].ToString("x")).ToString("00");
                            VersionNo = int.Parse(bte[11].ToString("x")).ToString("00");
                            sBodyLength = int.Parse(int.Parse(bte[12].ToString("x")).ToString("00") + int.Parse(bte[13].ToString("x")).ToString("00"));
                            Packetlength = sBodyLength + othercol;
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 1, 1));
                            int mKind = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 2, 1));

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                #region //TRANSMISSION_CODE_4
                                case 4:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I010 單一商品漲停幅揭示
                                            try
                                            {
                                                Prod_Kind = System.Text.UnicodeEncoding.Default.GetString(bte, 59, 1).Trim();
                                                Decimal_Locate = double.Parse(bte[60].ToString("x"));

                                                if (Decimal_Locate == 0)
                                                    Decimal_Locate = 1.0;
                                                else
                                                    Decimal_Locate = 1 / Math.Pow(10, Decimal_Locate);

                                                Strike_Decimal_Locate = double.Parse(bte[61].ToString("x"));

                                                if (Strike_Decimal_Locate == 0)
                                                    Strike_Decimal_Locate = 1.0;
                                                else
                                                    Strike_Decimal_Locate = 1 / Math.Pow(10, Strike_Decimal_Locate);
                                                
                                                sRiseLimitPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * Decimal_Locate;
                                                sFallLimitPrice = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * Decimal_Locate;
                                                
                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();

                                                mPCommodity = m_PCommodityList.Set("OPT", sCommodityId);

                                                mPCommodity.TradeDate = DateTime.Today;

                                                mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                                                mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate = Decimal_Locate;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                                                DoSendWrite("OPT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI010 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion                                        
                                        default:                                            
                                            break;
                                    }
                                    break;
                                #endregion
                                #region //TRANSMISSION_CODE_5
                                case 5:
                                    switch (mKind) //MESSAGE_KIND
                                    {
                                        case 1:
                                            #region //I020 成交價量揭示訊息
                                            try
                                            {
                                                MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");

                                                #region check seq start
                                                if (m_QuoteSetting.IsCheckLost)
                                                {
                                                    Match_seq = Convert.ToInt32(InformationSeq);

                                                    if (Match_seq != 0 && Match_seq != 1)
                                                    {
                                                        if (Match_seq - Op_Match_seq != 1 && Match_seq > Op_Match_seq)
                                                        {
                                                            Op_PacketLost_Qty += Match_seq - Op_Match_seq - 1;
                                                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][Lost Op_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Op_PacketLost_Qty + " Last:" + Op_Match_seq + " Current:" + Match_seq);
                                                        }
                                                    }
                                                    else
                                                        Op_PacketLost_Qty = 0;

                                                    //if (Match_seq > Op_Match_seq)
                                                        Op_Match_seq = Match_seq;
                                                }
                                                #endregion check seq end

                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Get("OPT", sCommodityId);

                                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq))))
                                                {
                                                    MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    MatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));
                                                    MatchTOTALQty = int.Parse(int.Parse(bte[Packetlength - 16].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 15].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 14].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 13].ToString("x")).ToString("00"));

                                                    best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;
                                                    MatchPrice = MatchPrice * best5DecimalLocate;
                                                    
                                                    for (i = 0; i < (int)(bte[48] & 127); i++)
                                                    {
                                                        MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 49 + 8 * i, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[50 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[51 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[52 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[53 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[54 + 8 * i].ToString("x")).ToString("00"));
                                                        MatchPrice = MatchPrice * best5DecimalLocate;
                                                        MatchQuantity += int.Parse(int.Parse(bte[55 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[56 + 8 * i].ToString("x")).ToString("00"));                                                        
                                                    }

                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                                    DoSendWrite("OPT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                                }                                                
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI020 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 2:
                                            #region //I080 委託簿揭示訊息
                                            try
                                            {                                              
                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                                mPCommodity = m_PCommodityList.Get("OPT", sCommodityId);

                                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq) < int.Parse(InformationSeq))))
                                                {

                                                    BuyPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00"));
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                                    BuyPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 44, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00"));
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00"));
                                                    BuyPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00"));
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00"));
                                                    BuyPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00"));
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00"));
                                                    BuyPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[75].ToString("x")).ToString("00") + int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));

                                                    SellPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 84, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                                    SellPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 94, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                                    SellPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 104, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00") + int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00"));
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00") + int.Parse(bte[113].ToString("x")).ToString("00"));
                                                    SellPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 114, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00") + int.Parse(bte[117].ToString("x")).ToString("00") + int.Parse(bte[118].ToString("x")).ToString("00") + int.Parse(bte[119].ToString("x")).ToString("00"));
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[120].ToString("x")).ToString("00") + int.Parse(bte[121].ToString("x")).ToString("00") + int.Parse(bte[122].ToString("x")).ToString("00") + int.Parse(bte[123].ToString("x")).ToString("00"));
                                                    SellPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 124, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[125].ToString("x")).ToString("00") + int.Parse(bte[126].ToString("x")).ToString("00") + int.Parse(bte[127].ToString("x")).ToString("00") + int.Parse(bte[128].ToString("x")).ToString("00") + int.Parse(bte[129].ToString("x")).ToString("00"));
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[130].ToString("x")).ToString("00") + int.Parse(bte[131].ToString("x")).ToString("00") + int.Parse(bte[132].ToString("x")).ToString("00") + int.Parse(bte[133].ToString("x")).ToString("00"));

                                                    BuyPriceDerived = 0.0;
                                                    BuyQtyDerived = 0;
                                                    SellPriceDerived = 0.0;
                                                    SellQtyDerived = 0;

                                                    if (int.Parse(bte[134].ToString("x")).ToString("00") == "01")
                                                    {
                                                        BuyPriceDerived = double.Parse(int.Parse(bte[135].ToString("x")).ToString("00") + int.Parse(bte[136].ToString("x")).ToString("00") + int.Parse(bte[137].ToString("x")).ToString("00") + int.Parse(bte[138].ToString("x")).ToString("00") + int.Parse(bte[139].ToString("x")).ToString("00"));
                                                        BuyQtyDerived = int.Parse(int.Parse(bte[140].ToString("x")).ToString("00") + int.Parse(bte[141].ToString("x")).ToString("00") + int.Parse(bte[142].ToString("x")).ToString("00") + int.Parse(bte[143].ToString("x")).ToString("00"));
                                                        SellPriceDerived = double.Parse(int.Parse(bte[144].ToString("x")).ToString("00") + int.Parse(bte[145].ToString("x")).ToString("00") + int.Parse(bte[146].ToString("x")).ToString("00") + int.Parse(bte[147].ToString("x")).ToString("00") + int.Parse(bte[148].ToString("x")).ToString("00"));
                                                        SellQtyDerived = int.Parse(int.Parse(bte[149].ToString("x")).ToString("00") + int.Parse(bte[150].ToString("x")).ToString("00") + int.Parse(bte[151].ToString("x")).ToString("00") + int.Parse(bte[152].ToString("x")).ToString("00"));

                                                        if (BuyQtyDerived > 0)
                                                        {
                                                            if (BuyPriceDerived > BuyPriceBest1 || BuyPriceBest1 == 0.0)
                                                            {
                                                                BuyPriceBest5 = BuyPriceBest4;
                                                                BuyQtyBest5 = BuyQtyBest4;
                                                                BuyPriceBest4 = BuyPriceBest3;
                                                                BuyQtyBest4 = BuyQtyBest3;
                                                                BuyPriceBest3 = BuyPriceBest2;
                                                                BuyQtyBest3 = BuyQtyBest2;
                                                                BuyPriceBest2 = BuyPriceBest1;
                                                                BuyQtyBest2 = BuyQtyBest1;
                                                                BuyPriceBest1 = BuyPriceDerived;
                                                                BuyQtyBest1 = BuyQtyDerived;
                                                            }
                                                            else if (BuyPriceDerived == BuyPriceBest1)
                                                            {
                                                                BuyQtyBest1 += BuyQtyDerived;
                                                            }
                                                        }

                                                        if (SellQtyDerived > 0)
                                                        {
                                                            if (SellPriceDerived < SellPriceBest1 || SellPriceBest1 == 0.0)
                                                            {
                                                                SellPriceBest5 = SellPriceBest4;
                                                                SellQtyBest5 = SellQtyBest4;
                                                                SellPriceBest4 = SellPriceBest3;
                                                                SellQtyBest4 = SellQtyBest3;
                                                                SellPriceBest3 = SellPriceBest2;
                                                                SellQtyBest3 = SellQtyBest2;
                                                                SellPriceBest2 = SellPriceBest1;
                                                                SellQtyBest2 = SellQtyBest1;
                                                                SellPriceBest1 = SellPriceDerived;
                                                                SellQtyBest1 = SellQtyDerived;
                                                            }
                                                            else if (SellPriceDerived == SellPriceBest1)
                                                            {
                                                                SellQtyBest1 += SellQtyDerived;
                                                            }
                                                        }
                                                    }

                                                    best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;

                                                    BuyPriceBest1 = BuyPriceBest1 * best5DecimalLocate;
                                                    BuyPriceBest2 = BuyPriceBest2 * best5DecimalLocate;
                                                    BuyPriceBest3 = BuyPriceBest3 * best5DecimalLocate;
                                                    BuyPriceBest4 = BuyPriceBest4 * best5DecimalLocate;
                                                    BuyPriceBest5 = BuyPriceBest5 * best5DecimalLocate;
                                                    SellPriceBest1 = SellPriceBest1 * best5DecimalLocate;
                                                    SellPriceBest2 = SellPriceBest2 * best5DecimalLocate;
                                                    SellPriceBest3 = SellPriceBest3 * best5DecimalLocate;
                                                    SellPriceBest4 = SellPriceBest4 * best5DecimalLocate;
                                                    SellPriceBest5 = SellPriceBest5 * best5DecimalLocate;

                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                                    DoSendWrite("OPT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI080 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        case 4:
                                            #region //I100 詢價揭示訊息
                                            try
                                            {
                                                sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                                DisclosureTime = int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00");
                                                DurationTime = int.Parse(int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00"));

                                                QueryCls QQ = QueryList.Add("O", sCommodityId, InformationTime, InformationSeq, DisclosureTime, DurationTime);

                                                if (QQ != null) { DoSendWriteQuery(QQ); }
                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI100 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                            }
                                            break;
                                            #endregion
                                        default:                                            
                                            break;
                                    }
                                    break;
                                #endregion                                
                                default:                                    
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithTse()
        {
            string InformationSeq;
            string InformationTime;
            int Packetlength = 0;
           
            string sCommodityId;            
            double sRiseLimitPrice = 0.0;
            double sReferencePrice = 0.0;
            double sFallLimitPrice = 0.0;

            int sDisPlayTag = 0;
            int sFallRiseTag = 0;
            int nResult = 0;
            int nPos = 0;

            string MatchTime;
            double MatchPrice = 0.0;
            int MatchQuantity = 0;
            int MatchTOTALQty = 0;
                                    
            double AccountSum = 0;
            int AccountQuantity = 0;
            int AccountOrder = 0;
            double AccountSumTotal = 0;
            int AccountQuantityTotal = 0;
           
            string IndexCode = "";
            int IndexItems = 0;
            double IndexValue = 0.0;

            double BuyPriceBest1 = 0.0;
            int BuyQtyBest1 = 0;
            double BuyPriceBest2 = 0.0;
            int BuyQtyBest2 = 0;
            double BuyPriceBest3 = 0.0;
            int BuyQtyBest3 = 0;
            double BuyPriceBest4 = 0.0;
            int BuyQtyBest4 = 0;
            double BuyPriceBest5 = 0.0;
            int BuyQtyBest5 = 0;
            double SellPriceBest1 = 0.0;
            int SellQtyBest1 = 0;
            double SellPriceBest2 = 0.0;
            int SellQtyBest2 = 0;
            double SellPriceBest3 = 0.0;
            int SellQtyBest3 = 0;
            double SellPriceBest4 = 0.0;
            int SellQtyBest4 = 0;
            double SellPriceBest5 = 0.0;
            int SellQtyBest5 = 0;

            int Match_seq;
            int Tse_Match_seq = 0;
            int Tse_PacketLost_Qty = 0;

            byte[] sCheckSum;
            byte[] bte;

            FastPCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();

                            Packetlength = int.Parse(int.Parse(bte[1].ToString("x")).ToString("00") + int.Parse(bte[2].ToString("x")).ToString("00"));
                            InformationSeq = int.Parse(bte[6].ToString("x")).ToString("00") + int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00");
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(bte[4].ToString("x"));

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                case 1:
                                    #region //集中市場個股基本資料
                                    try
                                    {
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                                        if (sCommodityId == "000000") { break; }

                                        sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00")) / 100;
                                        sRiseLimitPrice = double.Parse(int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00") + int.Parse(bte[34].ToString("x")).ToString("00")) / 100;
                                        sFallLimitPrice = double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00")) / 100;

                                        string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 41, 1).Trim();

                                        if (IsWarrantFlag == "Y")
                                            mPCommodity = m_PCommodityList.Set("TSEWRT", sCommodityId);
                                        else
                                            mPCommodity = m_PCommodityList.Set("TSE", sCommodityId);

                                        mPCommodity.TradeDate = DateTime.Today;

                                        mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                                        mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                                        mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = DateTime.Now.ToString("HHmmss");
                                        mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;                                        
                                        mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                                        if (IsWarrantFlag == "Y")
                                            DoSendWrite("TSEWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                        else
                                            DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse01 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 2:
                                    #region //集中市場競價交易成交統計資料
                                    try
                                    {
                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                                        mPCommodity = m_PCommodityList.Set("TSE", "1000");

                                        if (InformationSeq == "00000000") { break; }

                                        if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) <= int.Parse(InformationSeq))))
                                        {
                                            AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));
                                            AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                            if (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != null && mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != String.Empty)
                                            {
                                                AccountSum = AccountSumTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt;
                                                AccountQuantity = (int)(AccountQuantityTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty);
                                                MatchPrice = mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice;
                                            }
                                            else
                                            {
                                                AccountSum = AccountSumTotal;
                                                AccountQuantity = AccountQuantityTotal;                                                
                                                MatchPrice = 0.0;
                                            }

                                            if (!(AccountSum == 0.0 && AccountQuantity == 0 && AccountOrder == 0))
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchAmt = AccountSum;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt = AccountSumTotal;

                                                if (InformationTime != "999999")
                                                    DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                                else
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 1;
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse02 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 3:
                                    #region //集中市場競價交易指數統計資料
                                    try
                                    {
                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                                        IndexItems = int.Parse(int.Parse(bte[13].ToString("x")).ToString("00"));

                                        for (int k = 0; k < IndexItems; k++)
                                        {
                                            switch (k)
                                            {
                                                case 0:
                                                    IndexCode = "1000";//加　權 
                                                    break;
                                                case 1:
                                                    IndexCode = "1010";//無金融
                                                    break;
                                                case 2:
                                                    IndexCode = "1011";//無電子
                                                    break;
                                                case 3:
                                                    IndexCode = "1012";//化學工業類
                                                    break;
                                                case 4:
                                                    IndexCode = "1013";//生技醫療類
                                                    break;
                                                case 5:
                                                    IndexCode = "1001";//水泥類(原分類)
                                                    break;
                                                case 6:
                                                    IndexCode = "1002";//食品類(原分類)
                                                    break;
                                                case 7:
                                                    IndexCode = "1003";//塑化類(原分類)
                                                    break;
                                                case 8:
                                                    IndexCode = "1004";//紡纖類(原分類)
                                                    break;
                                                case 9:
                                                    IndexCode = "1005";//機電類(原分類)
                                                    break;
                                                case 10:
                                                    IndexCode = "1006";//造紙類(原分類)
                                                    break;
                                                case 11:
                                                    IndexCode = "1007";//營建類(原分類)
                                                    break;
                                                case 12:
                                                    IndexCode = "1008";//雜項類(原分類)
                                                    break;
                                                case 13:
                                                    IndexCode = "1009";//金融類(原分類)
                                                    break;
                                                case 14:
                                                    IndexCode = "1100";//水泥類
                                                    break;
                                                case 15:
                                                    IndexCode = "1200";//食品類
                                                    break;
                                                case 16:
                                                    IndexCode = "1300";//塑膠類
                                                    break;
                                                case 17:
                                                    IndexCode = "1400";//紡纖類
                                                    break;
                                                case 18:
                                                    IndexCode = "1500";//電機類
                                                    break;
                                                case 19:
                                                    IndexCode = "1600";//電器類
                                                    break;
                                                case 20:
                                                    IndexCode = "1700";//化工類
                                                    break;
                                                case 21:
                                                    IndexCode = "1800";//玻璃類
                                                    break;
                                                case 22:
                                                    IndexCode = "1900";//造紙類
                                                    break;
                                                case 23:
                                                    IndexCode = "2000";//鋼鐵類
                                                    break;
                                                case 24:
                                                    IndexCode = "2100";//橡膠類
                                                    break;
                                                case 25:
                                                    IndexCode = "2200";//汽車類
                                                    break;
                                                case 26:
                                                    IndexCode = "2300";//電子類
                                                    break;
                                                case 27:
                                                    IndexCode = "2500";//營建類
                                                    break;
                                                case 28:
                                                    IndexCode = "2600";//運輸類
                                                    break;
                                                case 29:
                                                    IndexCode = "2700";//觀光類
                                                    break;
                                                case 30:
                                                    IndexCode = "2800";//金融類
                                                    break;
                                                case 31:
                                                    IndexCode = "2900";//百貨類
                                                    break;
                                                case 32:
                                                    IndexCode = "9900";//其它類
                                                    break;
                                                case 33:
                                                    IndexCode = "1014";//無金融電子
                                                    break;
                                                case 34:
                                                    IndexCode = "1015";//油電燃氣類
                                                    break;
                                                case 35:
                                                    IndexCode = "1016";//半導體類
                                                    break;
                                                case 36:
                                                    IndexCode = "1017";//電腦週邊設備類
                                                    break;
                                                case 37:
                                                    IndexCode = "1018";//光電類
                                                    break;
                                                case 38:
                                                    IndexCode = "1019";//通信網路類
                                                    break;
                                                case 39:
                                                    IndexCode = "1020";//電子零組件類
                                                    break;
                                                case 40:
                                                    IndexCode = "1021";//電子通路類
                                                    break;
                                                case 41:
                                                    IndexCode = "1022";//資訊服務類
                                                    break;
                                                case 42:
                                                    IndexCode = "1023";//其他電子類
                                                    break;
                                                default:
                                                    break;
                                            }

                                            IndexValue = double.Parse(int.Parse(bte[14 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[15 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[16 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[17 + 4 * k].ToString("x")).ToString("00")) / 100;

                                            mPCommodity = m_PCommodityList.Set("TSE", IndexCode);

                                            if (InformationSeq == "00000000")
                                            {
                                                mPCommodity.TradeDate = DateTime.Today;

                                                mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                                mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                                continue;
                                            }

                                            if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999"))
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                                if (IndexCode == "1000" && InformationTime == "999999") { mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 2; }

                                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse03 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 6:
                                    #region //集中市場競價交易即時行情資訊
                                    try
                                    {
                                        nPos = 21;

                                        MatchPrice = 0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;                                                                                
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;
                                        
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        sDisPlayTag = (int)bte[19];
                                        sFallRiseTag = (int)(bte[20] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost )
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Tse_Match_seq != 1 && Match_seq > Tse_Match_seq)
                                                {
                                                    Tse_PacketLost_Qty += Match_seq - Tse_Match_seq - 1;
                                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Lost Tse_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Tse_PacketLost_Qty + " Last:" + Tse_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Tse_PacketLost_Qty = 0;

                                            //if (Match_seq > Tse_Match_seq)
                                                Tse_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        mPCommodity = m_PCommodityList.Set("TSE", sCommodityId);

                                        if (mPCommodity != null)
                                        {
                                            if (MatchPrice != 0.0)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                            }
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        
                                        if (mPCommodity != null)
                                        {
                                            if (IsHasBidAsk)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse06 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 10:
                                    #region //新編台灣指數資料
                                    try
                                    {
                                        InformationTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        IndexCode = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim(); ;
                                        IndexValue = double.Parse(int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00") + int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00")) / 100;

                                        mPCommodity = m_PCommodityList.Set("TSE", IndexCode);

                                        if (InformationSeq == "00000000")
                                        {
                                            mPCommodity.TradeDate = DateTime.Today;

                                            mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                            mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                            mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                            mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                            mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                            mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                            mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                            DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                            break;
                                        }


                                        if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq))))
                                        {
                                            mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                            mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                            mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                            mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                            DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);                                            
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse10 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 17:
                                    #region //第二IP集中市場競價交易即時行情資料
                                    try
                                    {
                                        nPos = 21;

                                        MatchPrice = 0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;
                                                                                
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        sDisPlayTag = (int)bte[19];
                                        sFallRiseTag = (int)(bte[20] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost )
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Tse_Match_seq != 1 && Match_seq > Tse_Match_seq)
                                                {
                                                    Tse_PacketLost_Qty += Match_seq - Tse_Match_seq - 1;
                                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse2_Error][Lost Tse_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Tse_PacketLost_Qty + " Last:" + Tse_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Tse_PacketLost_Qty = 0;

                                            //if (Match_seq > Tse_Match_seq)
                                                Tse_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        mPCommodity = m_PCommodityList.Set("TSEWRT", sCommodityId);

                                        if (mPCommodity != null)
                                        {
                                            if (MatchPrice != 0.0)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                                DoSendWrite("TSEWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                            }
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        if (mPCommodity != null)
                                        {
                                            if (IsHasBidAsk)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                                DoSendWrite("TSEWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse17 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                                                
                                default:                                    
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithOtc()
        {
           
            byte[] sCheckSum;
            byte[] bte;

            FastPCommodity mPCommodity = null;

            try
            {
                while (true)
                {
                    if (!InitialOK) { continue; }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            mPCommodity = null;

                            bte = (byte[])m_PackagePool.Dequeue();
                             
                            Packetlength = int.Parse(int.Parse(bte[1].ToString("x")).ToString("00") + int.Parse(bte[2].ToString("x")).ToString("00"));
                            InformationSeq = int.Parse(bte[6].ToString("x")).ToString("00") + int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00");
                            sCheckSum = new byte[Packetlength - 3];

                            int tCode = int.Parse(bte[4].ToString("x"));

                            m_PacketNum++;

                            #region //TRANSMISSION_CODE
                            switch (tCode)
                            {
                                case 1:
                                    #region //上櫃個股基本資料
                                    try
                                    {
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                                        if (sCommodityId == "000000") { break; }

                                        sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00")) / 100;
                                        sRiseLimitPrice = double.Parse(int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00") + int.Parse(bte[34].ToString("x")).ToString("00")) / 100;
                                        sFallLimitPrice = double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00")) / 100;

                                        string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 41, 1).Trim();

                                        if (IsWarrantFlag == "Y")
                                            mPCommodity = m_PCommodityList.Set("OTCWRT", sCommodityId);
                                        else
                                            mPCommodity = m_PCommodityList.Set("OTC", sCommodityId);

                                        mPCommodity.TradeDate = DateTime.Today;

                                        mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                                        mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                                        mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = DateTime.Now.ToString("HHmmss");
                                        mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                                        if (IsWarrantFlag == "Y")
                                            DoSendWrite("OTCWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                        else
                                            DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc01 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 2:
                                    #region //上櫃等價交易成交統計資料
                                    try
                                    {
                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                                        mPCommodity = m_PCommodityList.Set("OTC", "4000");

                                        if (InformationSeq == "00000000") { break; }

                                        if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) <= int.Parse(InformationSeq))))
                                        {
                                            AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));
                                            AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                            if (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != null && mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != String.Empty)
                                            {
                                                AccountSum = AccountSumTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt;
                                                AccountQuantity = (int)(AccountQuantityTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty);
                                                MatchPrice = mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice;
                                            }
                                            else
                                            {
                                                AccountSum = AccountSumTotal;
                                                AccountQuantity = AccountQuantityTotal;
                                                MatchPrice = 0.0;
                                            }

                                            if (!(AccountSum == 0.0 && AccountQuantity == 0 && AccountOrder == 0))
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchAmt = AccountSum;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt = AccountSumTotal;

                                                if (InformationTime != "999999")
                                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                                else
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 1;
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc02 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 3:
                                    #region //上櫃等價交易指數統計資料
                                    try
                                    {
                                        InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                                        IndexItems = int.Parse(int.Parse(bte[13].ToString("x")).ToString("00"));

                                        for (int k = 0; k < IndexItems; k++)
                                        {
                                            switch (k)
                                            {
                                                case 0:
                                                    IndexCode = "4000";//上　櫃
                                                    break;
                                                case 1:
                                                    IndexCode = "4001";//電子類
                                                    break;
                                                case 2:
                                                    IndexCode = "4002";//食品類
                                                    break;
                                                case 3:
                                                    IndexCode = "4003";//塑膠類
                                                    break;
                                                case 4:
                                                    IndexCode = "4004";//紡纖類
                                                    break;
                                                case 5:
                                                    IndexCode = "4005";//電機類
                                                    break;
                                                case 6:
                                                    IndexCode = "4006";//電器類
                                                    break;
                                                case 7:
                                                    IndexCode = "4007";//玻璃類
                                                    break;
                                                case 8:
                                                    IndexCode = "4008";//鋼鐵類
                                                    break;
                                                case 9:
                                                    IndexCode = "4009";//橡膠類
                                                    break;
                                                case 10:
                                                    IndexCode = "4010";//營建類
                                                    break;
                                                case 11:
                                                    IndexCode = "4011";//航運類
                                                    break;
                                                case 12:
                                                    IndexCode = "4012";//觀光類
                                                    break;
                                                case 13:
                                                    IndexCode = "4013";//金融類
                                                    break;
                                                case 14:
                                                    IndexCode = "4014";//百貨類
                                                    break;
                                                case 15:
                                                    IndexCode = "4015";//化工類
                                                    break;
                                                case 16:
                                                    IndexCode = "4016";//生技醫療類
                                                    break;
                                                case 17:
                                                    IndexCode = "4017";//油電燃氣類
                                                    break;
                                                case 18:
                                                    IndexCode = "4018";//半導體類
                                                    break;
                                                case 19:
                                                    IndexCode = "4019";//電腦週邊設備類
                                                    break;
                                                case 20:
                                                    IndexCode = "4020";//光電類
                                                    break;
                                                case 21:
                                                    IndexCode = "4021";//通信網路類
                                                    break;
                                                case 22:
                                                    IndexCode = "4022";//電子零組件類
                                                    break;
                                                case 23:
                                                    IndexCode = "4023";//電子通路類
                                                    break;
                                                case 24:
                                                    IndexCode = "4024";//資訊服務類
                                                    break;
                                                default:
                                                    break;
                                            }

                                            IndexValue = double.Parse(int.Parse(bte[14 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[15 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[16 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[17 + 4 * k].ToString("x")).ToString("00")) / 100;

                                            mPCommodity = m_PCommodityList.Set("OTC", IndexCode);

                                            if (InformationSeq == "00000000")
                                            {
                                                mPCommodity.TradeDate = DateTime.Today;

                                                mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                                mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                                mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                                DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                                continue;
                                            }

                                            if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999"))
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                                if (IndexCode == "4000" && InformationTime == "999999") { mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 2; }

                                                DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc03 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                
                                case 6:
                                    #region //上櫃等價交易即時行情資訊
                                    try
                                    {
                                        nPos = 21;

                                        MatchPrice = 0.0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;                                        
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;

                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        sDisPlayTag = (int)bte[19];
                                        sFallRiseTag = (int)(bte[20] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost )
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Otc_Match_seq != 1 && Match_seq > Otc_Match_seq)
                                                {
                                                    Otc_PacketLost_Qty += Match_seq - Otc_Match_seq - 1;
                                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Lost Otc_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Otc_PacketLost_Qty + " Last:" + Otc_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Otc_PacketLost_Qty = 0;

                                            //if (Match_seq > Otc_Match_seq)
                                                Otc_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        mPCommodity = m_PCommodityList.Set("OTC", sCommodityId);

                                        if (mPCommodity != null)
                                        {
                                            if (MatchPrice != 0.0)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                                DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                            }
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        if (mPCommodity != null)
                                        {   
                                            if (IsHasBidAsk)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                                DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc06 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion
                                case 12:
                                    #region //新編櫃買指數資料
                                    try
                                    {
                                        StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                                        for (int i = 0; i < StkCnt; i++)
                                        {
                                            try
                                            {
                                                InformationTime = int.Parse(bte[17 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 13].ToString("x")).ToString("00");
                                                IndexCode = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 13, 6).Trim(); ;
                                                IndexValue = double.Parse(int.Parse(bte[20 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[23 + i * 13].ToString("x")).ToString("00")) / 100;

                                                mPCommodity = m_PCommodityList.Set("OTC", IndexCode);

                                                if (InformationSeq == "00000000")
                                                {
                                                    mPCommodity.TradeDate = DateTime.Today;

                                                    mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                                    mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                                    mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                                    mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                                    mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                                    continue;
                                                }

                                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999"))
                                                {
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                                }
                                            }
                                            catch (Exception eg)
                                            {
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc12 ERROR " + "][" + eg.Message + "][" + eg.StackTrace + "]");
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc12 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                
                                case 17:
                                    #region //第二IP上櫃股票等價交易即時行情資料
                                    try
                                    {
                                        nPos = 21;

                                        MatchPrice = 0;
                                        MatchQuantity = 0;
                                        MatchTOTALQty = 0;
                                        BuyPriceBest1 = 0;
                                        BuyQtyBest1 = 0;
                                        BuyPriceBest2 = 0;
                                        BuyQtyBest2 = 0;
                                        BuyPriceBest3 = 0;
                                        BuyQtyBest3 = 0;
                                        BuyPriceBest4 = 0;
                                        BuyQtyBest4 = 0;
                                        BuyPriceBest5 = 0;
                                        BuyQtyBest5 = 0;
                                        SellPriceBest1 = 0;
                                        SellQtyBest1 = 0;
                                        SellPriceBest2 = 0;
                                        SellQtyBest2 = 0;
                                        SellPriceBest3 = 0;
                                        SellQtyBest3 = 0;
                                        SellPriceBest4 = 0;
                                        SellQtyBest4 = 0;
                                        SellPriceBest5 = 0;
                                        SellQtyBest5 = 0;

                                        //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                                        sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                                        if (sCommodityId == "000000") { break; }

                                        MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                                        sDisPlayTag = (int)bte[19];
                                        sFallRiseTag = (int)(bte[20] & 3);

                                        #region//check seq start
                                        if (m_QuoteSetting.IsCheckLost )
                                        {
                                            Match_seq = Convert.ToInt32(InformationSeq);

                                            if (Match_seq != 0 && Match_seq != 1)
                                            {
                                                if (Match_seq - Otc_Match_seq != 1 && Match_seq > Otc_Match_seq)
                                                {
                                                    Otc_PacketLost_Qty += Match_seq - Otc_Match_seq - 1;
                                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc2_Error][Lost Otc_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Otc_PacketLost_Qty + " Last:" + Otc_Match_seq + " Current:" + Match_seq);
                                                }
                                            }
                                            else
                                                Otc_PacketLost_Qty = 0;

                                            //if (Match_seq > Otc_Match_seq)
                                                Otc_Match_seq = Match_seq;
                                        }
                                        #endregion//check seq end

                                        nResult = sDisPlayTag >> 7;

                                        if (nResult == 1)
                                        {
                                            MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                            MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                            nPos = nPos + 7;
                                        }
                                        else
                                        {
                                            MatchPrice = 0.0;
                                            MatchQuantity = 0;
                                        }

                                        mPCommodity = m_PCommodityList.Set("OTCWRT", sCommodityId);

                                        if (mPCommodity != null)
                                        {
                                            if (MatchPrice != 0.0)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                                DoSendWrite("OTCWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                            }
                                        }

                                        bool IsHasBidAsk = false;

                                        //買進五擋
                                        nResult = (sDisPlayTag & 112) >> 4;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }
                                        //賣出五擋
                                        nResult = (sDisPlayTag & 14) >> 1;

                                        if (nResult > 0) { IsHasBidAsk = true; }

                                        for (int j = 0; j < nResult; j++)
                                        {
                                            switch (j)
                                            {
                                                case 0:
                                                    SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 1:
                                                    SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 2:
                                                    SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 3:
                                                    SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                case 4:
                                                    SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                                    SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                                    break;
                                                default:
                                                    break;
                                            }
                                            nPos = nPos + 7;
                                        }

                                        if (mPCommodity != null)
                                        {
                                            if (IsHasBidAsk)
                                            {
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                                mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                                DoSendWrite("OTCWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc17 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                    }
                                    break;
                                    #endregion                                
                                default:                                    
                                    break;
                            }
                            #endregion

                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc__Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithFx(byte[] bte)
        {
            
            int i = 0;

            byte[] sCheckSum;
            
            FastPCommodity mPCommodity = null;

            try
            {
                InformationTime = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00") + int.Parse(bte[6].ToString("x")).ToString("00");
                InformationSeq = int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00") + int.Parse(bte[10].ToString("x")).ToString("00");
                VersionNo = int.Parse(bte[11].ToString("x")).ToString("00");
                sBodyLength = int.Parse(int.Parse(bte[12].ToString("x")).ToString("00") + int.Parse(bte[13].ToString("x")).ToString("00"));
                Packetlength = sBodyLength + othercol;
                sCheckSum = new byte[Packetlength - 3];

                int tCode = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 1, 1));
                int mKind = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 2, 1));

                m_PacketNum++;

                #region //TRANSMISSION_CODE
                switch (tCode)
                {
                    #region //TRANSMISSION_CODE_1
                    case 1:
                        switch (mKind) //MESSAGE_KIND
                        {
                            case 1:
                                #region //I010 單一商品漲停幅揭示
                                try
                                {
                                    Prod_Kind = System.Text.UnicodeEncoding.Default.GetString(bte, 59, 1).Trim();
                                    Decimal_Locate = double.Parse(bte[60].ToString("x"));

                                    if (Decimal_Locate == 0)
                                        Decimal_Locate = 1.0;
                                    else
                                        Decimal_Locate = 1 / Math.Pow(10, Decimal_Locate);

                                    Strike_Decimal_Locate = double.Parse(bte[61].ToString("x"));

                                    if (Strike_Decimal_Locate == 0)
                                        Strike_Decimal_Locate = 1.0;
                                    else
                                        Strike_Decimal_Locate = 1 / Math.Pow(10, Strike_Decimal_Locate);

                                    sRiseLimitPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * Decimal_Locate;
                                    sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * Decimal_Locate;
                                    sFallLimitPrice = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * Decimal_Locate;

                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();

                                    mPCommodity = m_PCommodityList.Set("FUT", sCommodityId);

                                    mPCommodity.TradeDate = DateTime.Today;

                                    mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                                    mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate = Decimal_Locate;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                                    DoSendWrite("FUT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI010 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            default:
                                break;
                        }
                        break;
                    #endregion
                    #region //TRANSMISSION_CODE_2
                    case 2:
                        switch (mKind) //MESSAGE_KIND
                        {
                            case 1:
                                #region //I020 成交價量揭示訊息
                                try
                                {
                                    MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");

                                    #region check seq start
                                    if (m_QuoteSetting.IsCheckLost)
                                    {
                                        Match_seq = Convert.ToInt32(InformationSeq);

                                        if (Match_seq != 0 && Match_seq != 1)
                                        {
                                            if (Match_seq - Fx_Match_seq != 1 && Match_seq > Fx_Match_seq)
                                            {
                                                Fx_PacketLost_Qty += Match_seq - Fx_Match_seq - 1;
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][Lost Fx_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Fx_PacketLost_Qty + " Last:" + Fx_Match_seq + " Current:" + Match_seq);
                                            }
                                        }
                                        else
                                            Fx_PacketLost_Qty = 0;

                                        //if (Match_seq > Fx_Match_seq)
                                            Fx_Match_seq = Match_seq;
                                    }
                                    #endregion check seq end

                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();

                                    //if (sCommodityId != "TXFD3") { return; }

                                    mPCommodity = m_PCommodityList.Get("TFE", sCommodityId);

                                    if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq))))
                                    {
                                        MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                        MatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));
                                        MatchTOTALQty = int.Parse(int.Parse(bte[Packetlength - 16].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 15].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 14].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 13].ToString("x")).ToString("00"));

                                        //if (MatchTOTALQty == 50263)
                                        //    sCommodityId = "TXFD3";

                                        best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;

                                        MatchPrice = MatchPrice * best5DecimalLocate;

                                        for (i = 0; i < (int)(bte[48] & 127); i++)
                                        {
                                            MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 49 + 8 * i, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[50 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[51 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[52 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[53 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[54 + 8 * i].ToString("x")).ToString("00")) * best5DecimalLocate;
                                            MatchQuantity += int.Parse(int.Parse(bte[55 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[56 + 8 * i].ToString("x")).ToString("00"));                                            
                                        }

                                        mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                        DoSendWrite("FUT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI020 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            case 2:
                                #region //I080 委託簿揭示訊息
                                try
                                {
                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                    //if (sCommodityId != "TXFD3") { return; }
                                    mPCommodity = m_PCommodityList.Get("TFE", sCommodityId);

                                    if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq) < int.Parse(InformationSeq))))
                                    {
                                        BuyPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00"));
                                        BuyQtyBest1 = int.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                        BuyPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 44, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00"));
                                        BuyQtyBest2 = int.Parse(int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00"));
                                        BuyPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00"));
                                        BuyQtyBest3 = int.Parse(int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00"));
                                        BuyPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00"));
                                        BuyQtyBest4 = int.Parse(int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00"));
                                        BuyPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[75].ToString("x")).ToString("00") + int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                        BuyQtyBest5 = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));

                                        SellPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 84, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                        SellQtyBest1 = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                        SellPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 94, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                        SellQtyBest2 = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                        SellPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 104, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00") + int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00"));
                                        SellQtyBest3 = int.Parse(int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00") + int.Parse(bte[113].ToString("x")).ToString("00"));
                                        SellPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 114, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00") + int.Parse(bte[117].ToString("x")).ToString("00") + int.Parse(bte[118].ToString("x")).ToString("00") + int.Parse(bte[119].ToString("x")).ToString("00"));
                                        SellQtyBest4 = int.Parse(int.Parse(bte[120].ToString("x")).ToString("00") + int.Parse(bte[121].ToString("x")).ToString("00") + int.Parse(bte[122].ToString("x")).ToString("00") + int.Parse(bte[123].ToString("x")).ToString("00"));
                                        SellPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 124, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[125].ToString("x")).ToString("00") + int.Parse(bte[126].ToString("x")).ToString("00") + int.Parse(bte[127].ToString("x")).ToString("00") + int.Parse(bte[128].ToString("x")).ToString("00") + int.Parse(bte[129].ToString("x")).ToString("00"));
                                        SellQtyBest5 = int.Parse(int.Parse(bte[130].ToString("x")).ToString("00") + int.Parse(bte[131].ToString("x")).ToString("00") + int.Parse(bte[132].ToString("x")).ToString("00") + int.Parse(bte[133].ToString("x")).ToString("00"));

                                        BuyPriceDerived = 0.0;
                                        BuyQtyDerived = 0;
                                        SellPriceDerived = 0.0;
                                        SellQtyDerived = 0;

                                        if (int.Parse(bte[134].ToString("x")).ToString("00") == "01")
                                        {
                                            BuyPriceDerived = double.Parse(int.Parse(bte[135].ToString("x")).ToString("00") + int.Parse(bte[136].ToString("x")).ToString("00") + int.Parse(bte[137].ToString("x")).ToString("00") + int.Parse(bte[138].ToString("x")).ToString("00") + int.Parse(bte[139].ToString("x")).ToString("00"));
                                            BuyQtyDerived = int.Parse(int.Parse(bte[140].ToString("x")).ToString("00") + int.Parse(bte[141].ToString("x")).ToString("00") + int.Parse(bte[142].ToString("x")).ToString("00") + int.Parse(bte[143].ToString("x")).ToString("00"));
                                            SellPriceDerived = double.Parse(int.Parse(bte[144].ToString("x")).ToString("00") + int.Parse(bte[145].ToString("x")).ToString("00") + int.Parse(bte[146].ToString("x")).ToString("00") + int.Parse(bte[147].ToString("x")).ToString("00") + int.Parse(bte[148].ToString("x")).ToString("00"));
                                            SellQtyDerived = int.Parse(int.Parse(bte[149].ToString("x")).ToString("00") + int.Parse(bte[150].ToString("x")).ToString("00") + int.Parse(bte[151].ToString("x")).ToString("00") + int.Parse(bte[152].ToString("x")).ToString("00"));

                                            if (BuyQtyDerived > 0)
                                            {
                                                if (BuyPriceDerived > BuyPriceBest1 || BuyPriceBest1 == 0.0)
                                                {
                                                    BuyPriceBest5 = BuyPriceBest4;
                                                    BuyQtyBest5 = BuyQtyBest4;
                                                    BuyPriceBest4 = BuyPriceBest3;
                                                    BuyQtyBest4 = BuyQtyBest3;
                                                    BuyPriceBest3 = BuyPriceBest2;
                                                    BuyQtyBest3 = BuyQtyBest2;
                                                    BuyPriceBest2 = BuyPriceBest1;
                                                    BuyQtyBest2 = BuyQtyBest1;
                                                    BuyPriceBest1 = BuyPriceDerived;
                                                    BuyQtyBest1 = BuyQtyDerived;
                                                }
                                                else if (BuyPriceDerived == BuyPriceBest1)
                                                {
                                                    BuyQtyBest1 += BuyQtyDerived;
                                                }
                                            }

                                            if (SellQtyDerived > 0)
                                            {
                                                if (SellPriceDerived < SellPriceBest1 || SellPriceBest1 == 0.0)
                                                {
                                                    SellPriceBest5 = SellPriceBest4;
                                                    SellQtyBest5 = SellQtyBest4;
                                                    SellPriceBest4 = SellPriceBest3;
                                                    SellQtyBest4 = SellQtyBest3;
                                                    SellPriceBest3 = SellPriceBest2;
                                                    SellQtyBest3 = SellQtyBest2;
                                                    SellPriceBest2 = SellPriceBest1;
                                                    SellQtyBest2 = SellQtyBest1;
                                                    SellPriceBest1 = SellPriceDerived;
                                                    SellQtyBest1 = SellQtyDerived;
                                                }
                                                else if (SellPriceDerived == SellPriceBest1)
                                                {
                                                    SellQtyBest1 += SellQtyDerived;
                                                }
                                            }
                                        }

                                        best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;

                                        BuyPriceBest1 = BuyPriceBest1 * best5DecimalLocate;
                                        BuyPriceBest2 = BuyPriceBest2 * best5DecimalLocate;
                                        BuyPriceBest3 = BuyPriceBest3 * best5DecimalLocate;
                                        BuyPriceBest4 = BuyPriceBest4 * best5DecimalLocate;
                                        BuyPriceBest5 = BuyPriceBest5 * best5DecimalLocate;
                                        SellPriceBest1 = SellPriceBest1 * best5DecimalLocate;
                                        SellPriceBest2 = SellPriceBest2 * best5DecimalLocate;
                                        SellPriceBest3 = SellPriceBest3 * best5DecimalLocate;
                                        SellPriceBest4 = SellPriceBest4 * best5DecimalLocate;
                                        SellPriceBest5 = SellPriceBest5 * best5DecimalLocate;

                                        mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                        DoSendWrite("FUT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI080 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            case 4:
                                #region //I100 詢價揭示訊息
                                try
                                {
                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                    DisclosureTime = int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00");
                                    DurationTime = int.Parse(int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00"));

                                    QueryCls QQ = QueryList.Add("F", sCommodityId, InformationTime, InformationSeq, DisclosureTime, DurationTime);

                                    if (QQ != null) { DoSendWriteQuery(QQ); }
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error][" + "FxI100 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            default:
                                break;
                        }
                        break;
                    #endregion
                    default:
                        break;
                }
                #endregion
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithFx_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }

        }
        private void DealWithOp(byte[] bte)
        {
            
            int i = 0;
            byte[] sCheckSum;
            
            FastPCommodity mPCommodity = null;

            try
            {
                InformationTime = int.Parse(bte[3].ToString("x")).ToString("00") + int.Parse(bte[4].ToString("x")).ToString("00") + int.Parse(bte[5].ToString("x")).ToString("00") + int.Parse(bte[6].ToString("x")).ToString("00");
                InformationSeq = int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00") + int.Parse(bte[10].ToString("x")).ToString("00");
                VersionNo = int.Parse(bte[11].ToString("x")).ToString("00");
                sBodyLength = int.Parse(int.Parse(bte[12].ToString("x")).ToString("00") + int.Parse(bte[13].ToString("x")).ToString("00"));
                Packetlength = sBodyLength + othercol;
                sCheckSum = new byte[Packetlength - 3];

                int tCode = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 1, 1));
                int mKind = int.Parse(System.Text.UnicodeEncoding.Default.GetString(bte, 2, 1));

                m_PacketNum++;

                #region //TRANSMISSION_CODE
                switch (tCode)
                {
                    #region //TRANSMISSION_CODE_4
                    case 4:
                        switch (mKind) //MESSAGE_KIND
                        {
                            case 1:
                                #region //I010 單一商品漲停幅揭示
                                try
                                {
                                    Prod_Kind = System.Text.UnicodeEncoding.Default.GetString(bte, 59, 1).Trim();
                                    Decimal_Locate = double.Parse(bte[60].ToString("x"));

                                    if (Decimal_Locate == 0)
                                        Decimal_Locate = 1.0;
                                    else
                                        Decimal_Locate = 1 / Math.Pow(10, Decimal_Locate);

                                    Strike_Decimal_Locate = double.Parse(bte[61].ToString("x"));

                                    if (Strike_Decimal_Locate == 0)
                                        Strike_Decimal_Locate = 1.0;
                                    else
                                        Strike_Decimal_Locate = 1 / Math.Pow(10, Strike_Decimal_Locate);

                                    sRiseLimitPrice = double.Parse(int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00")) * Decimal_Locate;
                                    sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00") + int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00")) * Decimal_Locate;
                                    sFallLimitPrice = double.Parse(int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00")) * Decimal_Locate;
                                    
                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();

                                    mPCommodity = m_PCommodityList.Set("OPT", sCommodityId);

                                    mPCommodity.TradeDate = DateTime.Today;

                                    mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                                    mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate = Decimal_Locate;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                                    DoSendWrite("OPT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI010 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            default:
                                break;
                        }
                        break;
                    #endregion
                    #region //TRANSMISSION_CODE_5
                    case 5:
                        switch (mKind) //MESSAGE_KIND
                        {
                            case 1:
                                #region //I020 成交價量揭示訊息
                                try
                                {
                                    MatchTime = int.Parse(bte[34].ToString("x")).ToString("00") + int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00");

                                    #region check seq start
                                    if (m_QuoteSetting.IsCheckLost)
                                    {
                                        Match_seq = Convert.ToInt32(InformationSeq);

                                        if (Match_seq != 0 && Match_seq != 1)
                                        {
                                            if (Match_seq - Op_Match_seq != 1 && Match_seq > Op_Match_seq)
                                            {
                                                Op_PacketLost_Qty += Match_seq - Op_Match_seq - 1;
                                                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][Lost Op_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Op_PacketLost_Qty + " Last:" + Op_Match_seq + " Current:" + Match_seq);
                                            }
                                        }
                                        else
                                            Op_PacketLost_Qty = 0;

                                        //if (Match_seq > Op_Match_seq)
                                            Op_Match_seq = Match_seq;
                                    }
                                    #endregion check seq end

                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                    mPCommodity = m_PCommodityList.Get("OPT", sCommodityId);

                                    if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq))))
                                    {
                                        MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 38, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[39].ToString("x")).ToString("00") + int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                        MatchQuantity = int.Parse(int.Parse(bte[44].ToString("x")).ToString("00") + int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00"));
                                        MatchTOTALQty = int.Parse(int.Parse(bte[Packetlength - 16].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 15].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 14].ToString("x")).ToString("00") + int.Parse(bte[Packetlength - 13].ToString("x")).ToString("00"));

                                        best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;
                                        MatchPrice = MatchPrice * best5DecimalLocate;
                                        
                                        for (i = 0; i < (int)(bte[48] & 127); i++)
                                        {
                                            MatchPrice = System.Text.UnicodeEncoding.Default.GetString(bte, 49 + 8 * i, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[50 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[51 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[52 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[53 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[54 + 8 * i].ToString("x")).ToString("00"));
                                            MatchPrice = MatchPrice * best5DecimalLocate;
                                            MatchQuantity += int.Parse(int.Parse(bte[55 + 8 * i].ToString("x")).ToString("00") + int.Parse(bte[56 + 8 * i].ToString("x")).ToString("00"));                                        
                                        }

                                        mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                        DoSendWrite("OPT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI020 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            case 2:
                                #region //I080 委託簿揭示訊息
                                try
                                {
                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 20).Trim();
                                    mPCommodity = m_PCommodityList.Get("OPT", sCommodityId);

                                    if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq) < int.Parse(InformationSeq))))
                                    {

                                        BuyPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 34, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00") + int.Parse(bte[38].ToString("x")).ToString("00") + int.Parse(bte[39].ToString("x")).ToString("00"));
                                        BuyQtyBest1 = int.Parse(int.Parse(bte[40].ToString("x")).ToString("00") + int.Parse(bte[41].ToString("x")).ToString("00") + int.Parse(bte[42].ToString("x")).ToString("00") + int.Parse(bte[43].ToString("x")).ToString("00"));
                                        BuyPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 44, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[45].ToString("x")).ToString("00") + int.Parse(bte[46].ToString("x")).ToString("00") + int.Parse(bte[47].ToString("x")).ToString("00") + int.Parse(bte[48].ToString("x")).ToString("00") + int.Parse(bte[49].ToString("x")).ToString("00"));
                                        BuyQtyBest2 = int.Parse(int.Parse(bte[50].ToString("x")).ToString("00") + int.Parse(bte[51].ToString("x")).ToString("00") + int.Parse(bte[52].ToString("x")).ToString("00") + int.Parse(bte[53].ToString("x")).ToString("00"));
                                        BuyPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 54, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[55].ToString("x")).ToString("00") + int.Parse(bte[56].ToString("x")).ToString("00") + int.Parse(bte[57].ToString("x")).ToString("00") + int.Parse(bte[58].ToString("x")).ToString("00") + int.Parse(bte[59].ToString("x")).ToString("00"));
                                        BuyQtyBest3 = int.Parse(int.Parse(bte[60].ToString("x")).ToString("00") + int.Parse(bte[61].ToString("x")).ToString("00") + int.Parse(bte[62].ToString("x")).ToString("00") + int.Parse(bte[63].ToString("x")).ToString("00"));
                                        BuyPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 64, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[65].ToString("x")).ToString("00") + int.Parse(bte[66].ToString("x")).ToString("00") + int.Parse(bte[67].ToString("x")).ToString("00") + int.Parse(bte[68].ToString("x")).ToString("00") + int.Parse(bte[69].ToString("x")).ToString("00"));
                                        BuyQtyBest4 = int.Parse(int.Parse(bte[70].ToString("x")).ToString("00") + int.Parse(bte[71].ToString("x")).ToString("00") + int.Parse(bte[72].ToString("x")).ToString("00") + int.Parse(bte[73].ToString("x")).ToString("00"));
                                        BuyPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 74, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[75].ToString("x")).ToString("00") + int.Parse(bte[76].ToString("x")).ToString("00") + int.Parse(bte[77].ToString("x")).ToString("00") + int.Parse(bte[78].ToString("x")).ToString("00") + int.Parse(bte[79].ToString("x")).ToString("00"));
                                        BuyQtyBest5 = int.Parse(int.Parse(bte[80].ToString("x")).ToString("00") + int.Parse(bte[81].ToString("x")).ToString("00") + int.Parse(bte[82].ToString("x")).ToString("00") + int.Parse(bte[83].ToString("x")).ToString("00"));

                                        SellPriceBest1 = System.Text.UnicodeEncoding.Default.GetString(bte, 84, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[85].ToString("x")).ToString("00") + int.Parse(bte[86].ToString("x")).ToString("00") + int.Parse(bte[87].ToString("x")).ToString("00") + int.Parse(bte[88].ToString("x")).ToString("00") + int.Parse(bte[89].ToString("x")).ToString("00"));
                                        SellQtyBest1 = int.Parse(int.Parse(bte[90].ToString("x")).ToString("00") + int.Parse(bte[91].ToString("x")).ToString("00") + int.Parse(bte[92].ToString("x")).ToString("00") + int.Parse(bte[93].ToString("x")).ToString("00"));
                                        SellPriceBest2 = System.Text.UnicodeEncoding.Default.GetString(bte, 94, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[95].ToString("x")).ToString("00") + int.Parse(bte[96].ToString("x")).ToString("00") + int.Parse(bte[97].ToString("x")).ToString("00") + int.Parse(bte[98].ToString("x")).ToString("00") + int.Parse(bte[99].ToString("x")).ToString("00"));
                                        SellQtyBest2 = int.Parse(int.Parse(bte[100].ToString("x")).ToString("00") + int.Parse(bte[101].ToString("x")).ToString("00") + int.Parse(bte[102].ToString("x")).ToString("00") + int.Parse(bte[103].ToString("x")).ToString("00"));
                                        SellPriceBest3 = System.Text.UnicodeEncoding.Default.GetString(bte, 104, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[105].ToString("x")).ToString("00") + int.Parse(bte[106].ToString("x")).ToString("00") + int.Parse(bte[107].ToString("x")).ToString("00") + int.Parse(bte[108].ToString("x")).ToString("00") + int.Parse(bte[109].ToString("x")).ToString("00"));
                                        SellQtyBest3 = int.Parse(int.Parse(bte[110].ToString("x")).ToString("00") + int.Parse(bte[111].ToString("x")).ToString("00") + int.Parse(bte[112].ToString("x")).ToString("00") + int.Parse(bte[113].ToString("x")).ToString("00"));
                                        SellPriceBest4 = System.Text.UnicodeEncoding.Default.GetString(bte, 114, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[115].ToString("x")).ToString("00") + int.Parse(bte[116].ToString("x")).ToString("00") + int.Parse(bte[117].ToString("x")).ToString("00") + int.Parse(bte[118].ToString("x")).ToString("00") + int.Parse(bte[119].ToString("x")).ToString("00"));
                                        SellQtyBest4 = int.Parse(int.Parse(bte[120].ToString("x")).ToString("00") + int.Parse(bte[121].ToString("x")).ToString("00") + int.Parse(bte[122].ToString("x")).ToString("00") + int.Parse(bte[123].ToString("x")).ToString("00"));
                                        SellPriceBest5 = System.Text.UnicodeEncoding.Default.GetString(bte, 124, 1).Trim() == "-" ? -1 : 1 * double.Parse(int.Parse(bte[125].ToString("x")).ToString("00") + int.Parse(bte[126].ToString("x")).ToString("00") + int.Parse(bte[127].ToString("x")).ToString("00") + int.Parse(bte[128].ToString("x")).ToString("00") + int.Parse(bte[129].ToString("x")).ToString("00"));
                                        SellQtyBest5 = int.Parse(int.Parse(bte[130].ToString("x")).ToString("00") + int.Parse(bte[131].ToString("x")).ToString("00") + int.Parse(bte[132].ToString("x")).ToString("00") + int.Parse(bte[133].ToString("x")).ToString("00"));

                                        BuyPriceDerived = 0.0;
                                        BuyQtyDerived = 0;
                                        SellPriceDerived = 0.0;
                                        SellQtyDerived = 0;

                                        if (int.Parse(bte[134].ToString("x")).ToString("00") == "01")
                                        {
                                            BuyPriceDerived = double.Parse(int.Parse(bte[135].ToString("x")).ToString("00") + int.Parse(bte[136].ToString("x")).ToString("00") + int.Parse(bte[137].ToString("x")).ToString("00") + int.Parse(bte[138].ToString("x")).ToString("00") + int.Parse(bte[139].ToString("x")).ToString("00"));
                                            BuyQtyDerived = int.Parse(int.Parse(bte[140].ToString("x")).ToString("00") + int.Parse(bte[141].ToString("x")).ToString("00") + int.Parse(bte[142].ToString("x")).ToString("00") + int.Parse(bte[143].ToString("x")).ToString("00"));
                                            SellPriceDerived = double.Parse(int.Parse(bte[144].ToString("x")).ToString("00") + int.Parse(bte[145].ToString("x")).ToString("00") + int.Parse(bte[146].ToString("x")).ToString("00") + int.Parse(bte[147].ToString("x")).ToString("00") + int.Parse(bte[148].ToString("x")).ToString("00"));
                                            SellQtyDerived = int.Parse(int.Parse(bte[149].ToString("x")).ToString("00") + int.Parse(bte[150].ToString("x")).ToString("00") + int.Parse(bte[151].ToString("x")).ToString("00") + int.Parse(bte[152].ToString("x")).ToString("00"));

                                            if (BuyQtyDerived > 0)
                                            {
                                                if (BuyPriceDerived > BuyPriceBest1 || BuyPriceBest1 == 0.0)
                                                {
                                                    BuyPriceBest5 = BuyPriceBest4;
                                                    BuyQtyBest5 = BuyQtyBest4;
                                                    BuyPriceBest4 = BuyPriceBest3;
                                                    BuyQtyBest4 = BuyQtyBest3;
                                                    BuyPriceBest3 = BuyPriceBest2;
                                                    BuyQtyBest3 = BuyQtyBest2;
                                                    BuyPriceBest2 = BuyPriceBest1;
                                                    BuyQtyBest2 = BuyQtyBest1;
                                                    BuyPriceBest1 = BuyPriceDerived;
                                                    BuyQtyBest1 = BuyQtyDerived;
                                                }
                                                else if (BuyPriceDerived == BuyPriceBest1)
                                                {
                                                    BuyQtyBest1 += BuyQtyDerived;
                                                }
                                            }

                                            if (SellQtyDerived > 0)
                                            {
                                                if (SellPriceDerived < SellPriceBest1 || SellPriceBest1 == 0.0)
                                                {
                                                    SellPriceBest5 = SellPriceBest4;
                                                    SellQtyBest5 = SellQtyBest4;
                                                    SellPriceBest4 = SellPriceBest3;
                                                    SellQtyBest4 = SellQtyBest3;
                                                    SellPriceBest3 = SellPriceBest2;
                                                    SellQtyBest3 = SellQtyBest2;
                                                    SellPriceBest2 = SellPriceBest1;
                                                    SellQtyBest2 = SellQtyBest1;
                                                    SellPriceBest1 = SellPriceDerived;
                                                    SellQtyBest1 = SellQtyDerived;
                                                }
                                                else if (SellPriceDerived == SellPriceBest1)
                                                {
                                                    SellQtyBest1 += SellQtyDerived;
                                                }
                                            }
                                        }

                                        best5DecimalLocate = mPCommodity.QSimpleCommodity.QSimpleBase.DecimalLocate;

                                        BuyPriceBest1 = BuyPriceBest1 * best5DecimalLocate;
                                        BuyPriceBest2 = BuyPriceBest2 * best5DecimalLocate;
                                        BuyPriceBest3 = BuyPriceBest3 * best5DecimalLocate;
                                        BuyPriceBest4 = BuyPriceBest4 * best5DecimalLocate;
                                        BuyPriceBest5 = BuyPriceBest5 * best5DecimalLocate;
                                        SellPriceBest1 = SellPriceBest1 * best5DecimalLocate;
                                        SellPriceBest2 = SellPriceBest2 * best5DecimalLocate;
                                        SellPriceBest3 = SellPriceBest3 * best5DecimalLocate;
                                        SellPriceBest4 = SellPriceBest4 * best5DecimalLocate;
                                        SellPriceBest5 = SellPriceBest5 * best5DecimalLocate;

                                        mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                        mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                        DoSendWrite("OPT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI080 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            case 4:
                                #region //I100 詢價揭示訊息
                                try
                                {
                                    sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 14, 10).Trim();
                                    DisclosureTime = int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00");
                                    DurationTime = int.Parse(int.Parse(bte[28].ToString("x")).ToString("00") + int.Parse(bte[29].ToString("x")).ToString("00"));

                                    QueryCls QQ = QueryList.Add("O", sCommodityId, InformationTime, InformationSeq, DisclosureTime, DurationTime);

                                    if (QQ != null) { DoSendWriteQuery(QQ); }
                                }
                                catch (Exception ex)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error][" + "OpI100 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                                }
                                break;
                                #endregion
                            default:
                                break;
                        }
                        break;
                    #endregion
                    default:
                        break;
                }
                #endregion
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOp_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithTse(byte[] bte)
        {
            

            byte[] sCheckSum;
            
            FastPCommodity mPCommodity = null;

            try
            {
                Packetlength = int.Parse(int.Parse(bte[1].ToString("x")).ToString("00") + int.Parse(bte[2].ToString("x")).ToString("00"));
                InformationSeq = int.Parse(bte[6].ToString("x")).ToString("00") + int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00");
                sCheckSum = new byte[Packetlength - 3];

                int tCode = int.Parse(bte[4].ToString("x"));

                m_PacketNum++;

                #region //TRANSMISSION_CODE
                switch (tCode)
                {
                    case 1:
                        #region //集中市場個股基本資料
                        try
                        {
                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                            if (sCommodityId == "000000") { break; }

                            sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00")) / 100;
                            sRiseLimitPrice = double.Parse(int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00") + int.Parse(bte[34].ToString("x")).ToString("00")) / 100;
                            sFallLimitPrice = double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00")) / 100;

                            string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 41, 1).Trim();

                            if (IsWarrantFlag == "Y")
                                mPCommodity = m_PCommodityList.Set("TSEWRT", sCommodityId);
                            else
                                mPCommodity = m_PCommodityList.Set("TSE", sCommodityId);

                            mPCommodity.TradeDate = DateTime.Today;

                            mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                            mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                            mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = DateTime.Now.ToString("HHmmss");
                            mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                            mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                            mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                            mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                            if (IsWarrantFlag == "Y")
                                DoSendWrite("TSEWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                            else
                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse01 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 2:
                        #region //集中市場競價交易成交統計資料
                        try
                        {
                            InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                            mPCommodity = m_PCommodityList.Set("TSE", "1000");

                            if (InformationSeq == "00000000") { break; }

                            if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) <= int.Parse(InformationSeq))))
                            {
                                AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));
                                AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                if (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != null && mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != String.Empty)
                                {
                                    AccountSum = AccountSumTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt;
                                    AccountQuantity = (int)(AccountQuantityTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty);
                                    MatchPrice = mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice;
                                }
                                else
                                {
                                    AccountSum = AccountSumTotal;
                                    AccountQuantity = AccountQuantityTotal;
                                    MatchPrice = 0.0;
                                }

                                if (!(AccountSum == 0.0 && AccountQuantity == 0 && AccountOrder == 0))
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchAmt = AccountSum;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt = AccountSumTotal;

                                    if (InformationTime != "999999")
                                        DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                    else
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 1;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse02 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 3:
                        #region //集中市場競價交易指數統計資料
                        try
                        {
                            InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                            IndexItems = int.Parse(int.Parse(bte[13].ToString("x")).ToString("00"));

                            for (int k = 0; k < IndexItems; k++)
                            {
                                switch (k)
                                {
                                    case 0:
                                        IndexCode = "1000";//加　權 
                                        break;
                                    case 1:
                                        IndexCode = "1010";//無金融
                                        break;
                                    case 2:
                                        IndexCode = "1011";//無電子
                                        break;
                                    case 3:
                                        IndexCode = "1012";//化學工業類
                                        break;
                                    case 4:
                                        IndexCode = "1013";//生技醫療類
                                        break;
                                    case 5:
                                        IndexCode = "1001";//水泥類(原分類)
                                        break;
                                    case 6:
                                        IndexCode = "1002";//食品類(原分類)
                                        break;
                                    case 7:
                                        IndexCode = "1003";//塑化類(原分類)
                                        break;
                                    case 8:
                                        IndexCode = "1004";//紡纖類(原分類)
                                        break;
                                    case 9:
                                        IndexCode = "1005";//機電類(原分類)
                                        break;
                                    case 10:
                                        IndexCode = "1006";//造紙類(原分類)
                                        break;
                                    case 11:
                                        IndexCode = "1007";//營建類(原分類)
                                        break;
                                    case 12:
                                        IndexCode = "1008";//雜項類(原分類)
                                        break;
                                    case 13:
                                        IndexCode = "1009";//金融類(原分類)
                                        break;
                                    case 14:
                                        IndexCode = "1100";//水泥類
                                        break;
                                    case 15:
                                        IndexCode = "1200";//食品類
                                        break;
                                    case 16:
                                        IndexCode = "1300";//塑膠類
                                        break;
                                    case 17:
                                        IndexCode = "1400";//紡纖類
                                        break;
                                    case 18:
                                        IndexCode = "1500";//電機類
                                        break;
                                    case 19:
                                        IndexCode = "1600";//電器類
                                        break;
                                    case 20:
                                        IndexCode = "1700";//化工類
                                        break;
                                    case 21:
                                        IndexCode = "1800";//玻璃類
                                        break;
                                    case 22:
                                        IndexCode = "1900";//造紙類
                                        break;
                                    case 23:
                                        IndexCode = "2000";//鋼鐵類
                                        break;
                                    case 24:
                                        IndexCode = "2100";//橡膠類
                                        break;
                                    case 25:
                                        IndexCode = "2200";//汽車類
                                        break;
                                    case 26:
                                        IndexCode = "2300";//電子類
                                        break;
                                    case 27:
                                        IndexCode = "2500";//營建類
                                        break;
                                    case 28:
                                        IndexCode = "2600";//運輸類
                                        break;
                                    case 29:
                                        IndexCode = "2700";//觀光類
                                        break;
                                    case 30:
                                        IndexCode = "2800";//金融類
                                        break;
                                    case 31:
                                        IndexCode = "2900";//百貨類
                                        break;
                                    case 32:
                                        IndexCode = "9900";//其它類
                                        break;
                                    case 33:
                                        IndexCode = "1014";//無金融電子
                                        break;
                                    case 34:
                                        IndexCode = "1015";//油電燃氣類
                                        break;
                                    case 35:
                                        IndexCode = "1016";//半導體類
                                        break;
                                    case 36:
                                        IndexCode = "1017";//電腦週邊設備類
                                        break;
                                    case 37:
                                        IndexCode = "1018";//光電類
                                        break;
                                    case 38:
                                        IndexCode = "1019";//通信網路類
                                        break;
                                    case 39:
                                        IndexCode = "1020";//電子零組件類
                                        break;
                                    case 40:
                                        IndexCode = "1021";//電子通路類
                                        break;
                                    case 41:
                                        IndexCode = "1022";//資訊服務類
                                        break;
                                    case 42:
                                        IndexCode = "1023";//其他電子類
                                        break;
                                    default:
                                        break;
                                }

                                IndexValue = double.Parse(int.Parse(bte[14 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[15 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[16 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[17 + 4 * k].ToString("x")).ToString("00")) / 100;

                                mPCommodity = m_PCommodityList.Set("TSE", IndexCode);

                                if (InformationSeq == "00000000")
                                {
                                    mPCommodity.TradeDate = DateTime.Today;

                                    mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                    mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                    DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                    continue;
                                }

                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999"))
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                    if (IndexCode == "1000" && InformationTime == "999999") { mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 2; }

                                    DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse03 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 6:
                        #region //集中市場競價交易即時行情資訊
                        try
                        {
                            nPos = 21;

                            MatchPrice = 0;
                            MatchQuantity = 0;
                            MatchTOTALQty = 0;                            
                            BuyPriceBest1 = 0;
                            BuyQtyBest1 = 0;
                            BuyPriceBest2 = 0;
                            BuyQtyBest2 = 0;
                            BuyPriceBest3 = 0;
                            BuyQtyBest3 = 0;
                            BuyPriceBest4 = 0;
                            BuyQtyBest4 = 0;
                            BuyPriceBest5 = 0;
                            BuyQtyBest5 = 0;
                            SellPriceBest1 = 0;
                            SellQtyBest1 = 0;
                            SellPriceBest2 = 0;
                            SellQtyBest2 = 0;
                            SellPriceBest3 = 0;
                            SellQtyBest3 = 0;
                            SellPriceBest4 = 0;
                            SellQtyBest4 = 0;
                            SellPriceBest5 = 0;
                            SellQtyBest5 = 0;

                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                            if (sCommodityId == "000000") { break; }

                            MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                            sDisPlayTag = (int)bte[19];
                            sFallRiseTag = (int)(bte[20] & 3);

                            #region//check seq start
                            if (m_QuoteSetting.IsCheckLost)
                            {
                                Match_seq = Convert.ToInt32(InformationSeq);

                                if (Match_seq != 0 && Match_seq != 1)
                                {
                                    if (Match_seq - Tse_Match_seq != 1 && Match_seq > Tse_Match_seq)
                                    {
                                        Tse_PacketLost_Qty += Match_seq - Tse_Match_seq - 1;
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][Lost Tse_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Tse_PacketLost_Qty + " Last:" + Tse_Match_seq + " Current:" + Match_seq);
                                    }
                                }
                                else
                                    Tse_PacketLost_Qty = 0;

                                //if (Match_seq > Tse_Match_seq)
                                    Tse_Match_seq = Match_seq;
                            }
                            #endregion//check seq end

                            nResult = sDisPlayTag >> 7;

                            if (nResult == 1)
                            {
                                MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                nPos = nPos + 7;
                            }
                            else
                            {
                                MatchPrice = 0.0;
                                MatchQuantity = 0;
                            }

                            mPCommodity = m_PCommodityList.Set("TSE", sCommodityId);

                            if (mPCommodity != null)
                            {
                                if (MatchPrice != 0.0)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                    DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                }
                            }

                            bool IsHasBidAsk = false;

                            //買進五擋
                            nResult = (sDisPlayTag & 112) >> 4;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }
                            //賣出五擋
                            nResult = (sDisPlayTag & 14) >> 1;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }

                            if (mPCommodity != null)
                            {
                                if (IsHasBidAsk)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                    DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse06 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 10:
                        #region //新編台灣指數資料
                        try
                        {
                            InformationTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                            IndexCode = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim(); ;
                            IndexValue = double.Parse(int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00") + int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00")) / 100;

                            mPCommodity = m_PCommodityList.Set("TSE", IndexCode);

                            if (InformationSeq == "00000000")
                            {
                                mPCommodity.TradeDate = DateTime.Today;

                                mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                                break;
                            }


                            if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq))))
                            {
                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                DoSendWrite("TSE", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse10 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 17:
                        #region //第二IP集中市場競價交易即時行情資料
                        try
                        {
                            nPos = 21;

                            MatchPrice = 0;
                            MatchQuantity = 0;
                            MatchTOTALQty = 0;
                            BuyPriceBest1 = 0;
                            BuyQtyBest1 = 0;
                            BuyPriceBest2 = 0;
                            BuyQtyBest2 = 0;
                            BuyPriceBest3 = 0;
                            BuyQtyBest3 = 0;
                            BuyPriceBest4 = 0;
                            BuyQtyBest4 = 0;
                            BuyPriceBest5 = 0;
                            BuyQtyBest5 = 0;
                            SellPriceBest1 = 0;
                            SellQtyBest1 = 0;
                            SellPriceBest2 = 0;
                            SellQtyBest2 = 0;
                            SellPriceBest3 = 0;
                            SellQtyBest3 = 0;
                            SellPriceBest4 = 0;
                            SellQtyBest4 = 0;
                            SellPriceBest5 = 0;
                            SellQtyBest5 = 0;

                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                            if (sCommodityId == "000000") { break; }

                            MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                            sDisPlayTag = (int)bte[19];
                            sFallRiseTag = (int)(bte[20] & 3);

                            #region//check seq start
                            if (m_QuoteSetting.IsCheckLost)
                            {
                                Match_seq = Convert.ToInt32(InformationSeq);

                                if (Match_seq != 0 && Match_seq != 1)
                                {
                                    if (Match_seq - Tse_Match_seq != 1 && Match_seq > Tse_Match_seq)
                                    {
                                        Tse_PacketLost_Qty += Match_seq - Tse_Match_seq - 1;
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse2_Error][Lost Tse_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Tse_PacketLost_Qty + " Last:" + Tse_Match_seq + " Current:" + Match_seq);
                                    }
                                }
                                else
                                    Tse_PacketLost_Qty = 0;

                                //if (Match_seq > Tse_Match_seq)
                                    Tse_Match_seq = Match_seq;
                            }
                            #endregion//check seq end

                            nResult = sDisPlayTag >> 7;

                            if (nResult == 1)
                            {
                                MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                nPos = nPos + 7;
                            }
                            else
                            {
                                MatchPrice = 0.0;
                                MatchQuantity = 0;
                            }

                            mPCommodity = m_PCommodityList.Set("TSEWRT", sCommodityId);

                            if (mPCommodity != null)
                            {
                                if (MatchPrice != 0.0)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                    DoSendWrite("TSEWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                }
                            }

                            bool IsHasBidAsk = false;

                            //買進五擋
                            nResult = (sDisPlayTag & 112) >> 4;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }
                            //賣出五擋
                            nResult = (sDisPlayTag & 14) >> 1;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }

                            if (mPCommodity != null)
                            {
                                if (IsHasBidAsk)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                    DoSendWrite("TSEWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error][" + "Tse17 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    default:
                        break;
                }
                #endregion
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithTse_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DealWithOtc(byte[] bte)
        {
            

            byte[] sCheckSum;
            
            FastPCommodity mPCommodity = null;

            try
            {
                Packetlength = int.Parse(int.Parse(bte[1].ToString("x")).ToString("00") + int.Parse(bte[2].ToString("x")).ToString("00"));
                InformationSeq = int.Parse(bte[6].ToString("x")).ToString("00") + int.Parse(bte[7].ToString("x")).ToString("00") + int.Parse(bte[8].ToString("x")).ToString("00") + int.Parse(bte[9].ToString("x")).ToString("00");
                sCheckSum = new byte[Packetlength - 3];

                int tCode = int.Parse(bte[4].ToString("x"));

                m_PacketNum++;

                #region //TRANSMISSION_CODE
                switch (tCode)
                {
                    case 1:
                        #region //上櫃個股基本資料
                        try
                        {
                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();

                            if (sCommodityId == "000000") { break; }

                            sReferencePrice = double.Parse(int.Parse(bte[29].ToString("x")).ToString("00") + int.Parse(bte[30].ToString("x")).ToString("00") + int.Parse(bte[31].ToString("x")).ToString("00")) / 100;
                            sRiseLimitPrice = double.Parse(int.Parse(bte[32].ToString("x")).ToString("00") + int.Parse(bte[33].ToString("x")).ToString("00") + int.Parse(bte[34].ToString("x")).ToString("00")) / 100;
                            sFallLimitPrice = double.Parse(int.Parse(bte[35].ToString("x")).ToString("00") + int.Parse(bte[36].ToString("x")).ToString("00") + int.Parse(bte[37].ToString("x")).ToString("00")) / 100;

                            string IsWarrantFlag = System.Text.UnicodeEncoding.Default.GetString(bte, 41, 1).Trim();

                            if (IsWarrantFlag == "Y")
                                mPCommodity = m_PCommodityList.Set("OTCWRT", sCommodityId);
                            else
                                mPCommodity = m_PCommodityList.Set("OTC", sCommodityId);

                            mPCommodity.TradeDate = DateTime.Today;

                            mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(sCommodityId);
                            mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(sCommodityId);

                            mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = DateTime.Now.ToString("HHmmss");
                            mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                            mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = sFallLimitPrice;
                            mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = sReferencePrice;
                            mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = sRiseLimitPrice;

                            if (IsWarrantFlag == "Y")
                                DoSendWrite("OTCWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                            else
                                DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc01 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 2:
                        #region //上櫃等價交易成交統計資料
                        try
                        {
                            InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");

                            mPCommodity = m_PCommodityList.Set("OTC", "4000");

                            if (InformationSeq == "00000000") { break; }

                            if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) <= int.Parse(InformationSeq))))
                            {
                                AccountSumTotal = double.Parse(int.Parse(bte[13].ToString("x")).ToString("00") + int.Parse(bte[14].ToString("x")).ToString("00") + int.Parse(bte[15].ToString("x")).ToString("00") + int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00") + int.Parse(bte[19].ToString("x")).ToString("00") + int.Parse(bte[20].ToString("x")).ToString("00"));
                                AccountQuantityTotal = int.Parse(int.Parse(bte[21].ToString("x")).ToString("00") + int.Parse(bte[22].ToString("x")).ToString("00") + int.Parse(bte[23].ToString("x")).ToString("00") + int.Parse(bte[24].ToString("x")).ToString("00") + int.Parse(bte[25].ToString("x")).ToString("00") + int.Parse(bte[26].ToString("x")).ToString("00") + int.Parse(bte[27].ToString("x")).ToString("00") + int.Parse(bte[28].ToString("x")).ToString("00"));

                                if (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != null && mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq != String.Empty)
                                {
                                    AccountSum = AccountSumTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt;
                                    AccountQuantity = (int)(AccountQuantityTotal - mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty);
                                    MatchPrice = mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice;
                                }
                                else
                                {
                                    AccountSum = AccountSumTotal;
                                    AccountQuantity = AccountQuantityTotal;
                                    MatchPrice = 0.0;
                                }

                                if (!(AccountSum == 0.0 && AccountQuantity == 0 && AccountOrder == 0))
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchAmt = AccountSum;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalAmt = AccountSumTotal;

                                    if (InformationTime != "999999")
                                        DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                    else
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 1;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc02 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 3:
                        #region //上櫃等價交易指數統計資料
                        try
                        {
                            InformationTime = int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00") + int.Parse(bte[12].ToString("x")).ToString("00");
                            IndexItems = int.Parse(int.Parse(bte[13].ToString("x")).ToString("00"));

                            for (int k = 0; k < IndexItems; k++)
                            {
                                switch (k)
                                {
                                    case 0:
                                        IndexCode = "4000";//上　櫃
                                        break;
                                    case 1:
                                        IndexCode = "4001";//電子類
                                        break;
                                    case 2:
                                        IndexCode = "4002";//食品類
                                        break;
                                    case 3:
                                        IndexCode = "4003";//塑膠類
                                        break;
                                    case 4:
                                        IndexCode = "4004";//紡纖類
                                        break;
                                    case 5:
                                        IndexCode = "4005";//電機類
                                        break;
                                    case 6:
                                        IndexCode = "4006";//電器類
                                        break;
                                    case 7:
                                        IndexCode = "4007";//玻璃類
                                        break;
                                    case 8:
                                        IndexCode = "4008";//鋼鐵類
                                        break;
                                    case 9:
                                        IndexCode = "4009";//橡膠類
                                        break;
                                    case 10:
                                        IndexCode = "4010";//營建類
                                        break;
                                    case 11:
                                        IndexCode = "4011";//航運類
                                        break;
                                    case 12:
                                        IndexCode = "4012";//觀光類
                                        break;
                                    case 13:
                                        IndexCode = "4013";//金融類
                                        break;
                                    case 14:
                                        IndexCode = "4014";//百貨類
                                        break;
                                    case 15:
                                        IndexCode = "4015";//化工類
                                        break;
                                    case 16:
                                        IndexCode = "4016";//生技醫療類
                                        break;
                                    case 17:
                                        IndexCode = "4017";//油電燃氣類
                                        break;
                                    case 18:
                                        IndexCode = "4018";//半導體類
                                        break;
                                    case 19:
                                        IndexCode = "4019";//電腦週邊設備類
                                        break;
                                    case 20:
                                        IndexCode = "4020";//光電類
                                        break;
                                    case 21:
                                        IndexCode = "4021";//通信網路類
                                        break;
                                    case 22:
                                        IndexCode = "4022";//電子零組件類
                                        break;
                                    case 23:
                                        IndexCode = "4023";//電子通路類
                                        break;
                                    case 24:
                                        IndexCode = "4024";//資訊服務類
                                        break;
                                    default:
                                        break;
                                }

                                IndexValue = double.Parse(int.Parse(bte[14 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[15 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[16 + 4 * k].ToString("x")).ToString("00") + int.Parse(bte[17 + 4 * k].ToString("x")).ToString("00")) / 100;

                                mPCommodity = m_PCommodityList.Set("OTC", IndexCode);

                                if (InformationSeq == "00000000")
                                {
                                    mPCommodity.TradeDate = DateTime.Today;

                                    mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                    mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                    mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                    continue;
                                }

                                if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999"))
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                    if (IndexCode == "4000" && InformationTime == "999999") { mPCommodity.QSimpleCommodity.QSimpleMatch.MatchSeq = 2; }

                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc03 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 6:
                        #region //上櫃等價交易即時行情資訊
                        try
                        {
                            nPos = 21;

                            MatchPrice = 0.0;
                            MatchQuantity = 0;
                            MatchTOTALQty = 0;
                            BuyPriceBest1 = 0;
                            BuyQtyBest1 = 0;
                            BuyPriceBest2 = 0;
                            BuyQtyBest2 = 0;
                            BuyPriceBest3 = 0;
                            BuyQtyBest3 = 0;
                            BuyPriceBest4 = 0;
                            BuyQtyBest4 = 0;
                            BuyPriceBest5 = 0;
                            BuyQtyBest5 = 0;
                            SellPriceBest1 = 0;
                            SellQtyBest1 = 0;
                            SellPriceBest2 = 0;
                            SellQtyBest2 = 0;
                            SellPriceBest3 = 0;
                            SellQtyBest3 = 0;
                            SellPriceBest4 = 0;
                            SellQtyBest4 = 0;
                            SellPriceBest5 = 0;
                            SellQtyBest5 = 0;

                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                            if (sCommodityId == "000000") { break; }

                            MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                            sDisPlayTag = (int)bte[19];
                            sFallRiseTag = (int)(bte[20] & 3);

                            #region//check seq start
                            if (m_QuoteSetting.IsCheckLost)
                            {
                                Match_seq = Convert.ToInt32(InformationSeq);

                                if (Match_seq != 0 && Match_seq != 1)
                                {
                                    if (Match_seq - Otc_Match_seq != 1 && Match_seq > Otc_Match_seq)
                                    {
                                        Otc_PacketLost_Qty += Match_seq - Otc_Match_seq - 1;
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][Lost Otc_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Otc_PacketLost_Qty + " Last:" + Otc_Match_seq + " Current:" + Match_seq);
                                    }
                                }
                                else
                                    Otc_PacketLost_Qty = 0;

                                //if (Match_seq > Otc_Match_seq)
                                    Otc_Match_seq = Match_seq;
                            }
                            #endregion//check seq end

                            nResult = sDisPlayTag >> 7;

                            if (nResult == 1)
                            {
                                MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                nPos = nPos + 7;
                            }
                            else
                            {
                                MatchPrice = 0.0;
                                MatchQuantity = 0;
                            }

                            mPCommodity = m_PCommodityList.Set("OTC", sCommodityId);

                            if (mPCommodity != null)
                            {
                                if (MatchPrice != 0.0)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                }
                            }

                            bool IsHasBidAsk = false;

                            //買進五擋
                            nResult = (sDisPlayTag & 112) >> 4;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }
                            //賣出五擋
                            nResult = (sDisPlayTag & 14) >> 1;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }

                            if (mPCommodity != null)
                            {
                                if (IsHasBidAsk)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                    DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc06 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 12:
                        #region //新編櫃買指數資料
                        try
                        {
                            StkCnt = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00"));

                            for (int i = 0; i < StkCnt; i++)
                            {
                                try
                                {
                                    InformationTime = int.Parse(bte[17 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[18 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[19 + i * 13].ToString("x")).ToString("00");
                                    IndexCode = System.Text.UnicodeEncoding.Default.GetString(bte, 11 + i * 13, 6).Trim(); ;
                                    IndexValue = double.Parse(int.Parse(bte[20 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[21 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[22 + i * 13].ToString("x")).ToString("00") + int.Parse(bte[23 + i * 13].ToString("x")).ToString("00")) / 100;

                                    mPCommodity = m_PCommodityList.Set("OTC", IndexCode);

                                    if (InformationSeq == "00000000")
                                    {
                                        mPCommodity.TradeDate = DateTime.Today;

                                        mPCommodity.QSimpleCommodity.QSimpleMatch = new QSimpleMatch(IndexCode);
                                        mPCommodity.QSimpleCommodity.QSimpleBest5 = new QSimpleBest5(IndexCode);

                                        mPCommodity.QSimpleCommodity.QSimpleBase.InformationTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.FallLimitPrice = 0.0;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.ReferencePrice = IndexValue;
                                        mPCommodity.QSimpleCommodity.QSimpleBase.RiseLimitPrice = 0.0;

                                        DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBase);

                                        continue;
                                    }

                                    if (mPCommodity != null && (mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == null || mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq == string.Empty || (int.Parse(mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq) < int.Parse(InformationSeq)) || InformationTime == "999999"))
                                    {
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = InformationTime;
                                        mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = IndexValue;

                                        DoSendWrite("OTC", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                    }
                                }
                                catch (Exception eg)
                                {
                                    ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc12 ERROR " + "][" + eg.Message + "][" + eg.StackTrace + "]");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc12 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    case 17:
                        #region //第二IP上櫃股票等價交易即時行情資料
                        try
                        {
                            nPos = 21;

                            MatchPrice = 0;
                            MatchQuantity = 0;
                            MatchTOTALQty = 0;
                            BuyPriceBest1 = 0;
                            BuyQtyBest1 = 0;
                            BuyPriceBest2 = 0;
                            BuyQtyBest2 = 0;
                            BuyPriceBest3 = 0;
                            BuyQtyBest3 = 0;
                            BuyPriceBest4 = 0;
                            BuyQtyBest4 = 0;
                            BuyPriceBest5 = 0;
                            BuyQtyBest5 = 0;
                            SellPriceBest1 = 0;
                            SellQtyBest1 = 0;
                            SellPriceBest2 = 0;
                            SellQtyBest2 = 0;
                            SellPriceBest3 = 0;
                            SellQtyBest3 = 0;
                            SellPriceBest4 = 0;
                            SellQtyBest4 = 0;
                            SellPriceBest5 = 0;
                            SellQtyBest5 = 0;

                            //sCommodityCode = int.Parse(int.Parse(bte[10].ToString("x")).ToString("00") + int.Parse(bte[11].ToString("x")).ToString("00"));
                            sCommodityId = System.Text.UnicodeEncoding.Default.GetString(bte, 10, 6).Trim();
                            if (sCommodityId == "000000") { break; }

                            MatchTime = int.Parse(bte[16].ToString("x")).ToString("00") + int.Parse(bte[17].ToString("x")).ToString("00") + int.Parse(bte[18].ToString("x")).ToString("00");
                            sDisPlayTag = (int)bte[19];
                            sFallRiseTag = (int)(bte[20] & 3);

                            #region//check seq start
                            if (m_QuoteSetting.IsCheckLost)
                            {
                                Match_seq = Convert.ToInt32(InformationSeq);

                                if (Match_seq != 0 && Match_seq != 1)
                                {
                                    if (Match_seq - Otc_Match_seq != 1 && Match_seq > Otc_Match_seq)
                                    {
                                        Otc_PacketLost_Qty += Match_seq - Otc_Match_seq - 1;
                                        ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc2_Error][Lost Otc_Match]" + " Seq Time:" + MatchTime + " LostQty:" + Otc_PacketLost_Qty + " Last:" + Otc_Match_seq + " Current:" + Match_seq);
                                    }
                                }
                                else
                                    Otc_PacketLost_Qty = 0;

                                //if (Match_seq > Otc_Match_seq)
                                    Otc_Match_seq = Match_seq;
                            }
                            #endregion//check seq end

                            nResult = sDisPlayTag >> 7;

                            if (nResult == 1)
                            {
                                MatchPrice = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                MatchTOTALQty = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                nPos = nPos + 7;
                            }
                            else
                            {
                                MatchPrice = 0.0;
                                MatchQuantity = 0;
                            }

                            mPCommodity = m_PCommodityList.Set("OTCWRT", sCommodityId);

                            if (mPCommodity != null)
                            {
                                if (MatchPrice != 0.0)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTime = MatchTime;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchPrice = MatchPrice;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchQty = MatchQuantity;
                                    mPCommodity.QSimpleCommodity.QSimpleMatch.MatchTotalQty = MatchTOTALQty;

                                    DoSendWrite("OTCWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleMatch);
                                }
                            }

                            bool IsHasBidAsk = false;

                            //買進五擋
                            nResult = (sDisPlayTag & 112) >> 4;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        BuyPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        BuyPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        BuyPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        BuyPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        BuyPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        BuyQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }
                            //賣出五擋
                            nResult = (sDisPlayTag & 14) >> 1;

                            if (nResult > 0) { IsHasBidAsk = true; }

                            for (int j = 0; j < nResult; j++)
                            {
                                switch (j)
                                {
                                    case 0:
                                        SellPriceBest1 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest1 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 1:
                                        SellPriceBest2 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest2 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 2:
                                        SellPriceBest3 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest3 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 3:
                                        SellPriceBest4 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest4 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    case 4:
                                        SellPriceBest5 = double.Parse(int.Parse(bte[nPos].ToString("x")).ToString("00") + int.Parse(bte[nPos + 1].ToString("x")).ToString("00") + int.Parse(bte[nPos + 2].ToString("x")).ToString("00")) / 100;
                                        SellQtyBest5 = int.Parse(int.Parse(bte[nPos + 3].ToString("x")).ToString("00") + int.Parse(bte[nPos + 4].ToString("x")).ToString("00") + int.Parse(bte[nPos + 5].ToString("x")).ToString("00") + int.Parse(bte[nPos + 6].ToString("x")).ToString("00"));
                                        break;
                                    default:
                                        break;
                                }
                                nPos = nPos + 7;
                            }

                            if (mPCommodity != null)
                            {
                                if (IsHasBidAsk)
                                {
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationTime = DateTime.Now.ToString("HHmmss");
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.InformationSeq = InformationSeq;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest1 = BuyPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest2 = BuyPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest3 = BuyPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest4 = BuyPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyPriceBest5 = BuyPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest1 = BuyQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest2 = BuyQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest3 = BuyQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest4 = BuyQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.BuyQtyBest5 = BuyQtyBest5;

                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest1 = SellPriceBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest2 = SellPriceBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest3 = SellPriceBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest4 = SellPriceBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellPriceBest5 = SellPriceBest5;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest1 = SellQtyBest1;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest2 = SellQtyBest2;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest3 = SellQtyBest3;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest4 = SellQtyBest4;
                                    mPCommodity.QSimpleCommodity.QSimpleBest5.SellQtyBest5 = SellQtyBest5;

                                    DoSendWrite("OTCWRT", mPCommodity, mPCommodity.QSimpleCommodity.QSimpleBest5);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error][" + "Otc17 ERROR " + "][" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                        break;
                        #endregion
                    default:
                        break;
                }
                #endregion              
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrorProcess("[FastQuote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][DealWithOtc_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoSendWrite(string Source, FastPCommodity FastPCommodity, object obj)
        {
            if (Source == "TSE") { m_PCommodityList.TSE.Send(obj); }
            else if (Source == "OTC") { m_PCommodityList.OTC.Send(obj); }
            else if (Source == "TSEWRT") { m_PCommodityList.TSEWRT.Send(obj); }
            else if (Source == "OTCWRT") { m_PCommodityList.OTCWRT.Send(obj); }
            else if (Source == "FUT") { m_PCommodityList.FUT.Send(obj); }
            else if (Source == "OPT") { m_PCommodityList.OPT.Send(obj); }

            FastPCommodity.Send(obj);
        }
        private void DoSendWriteQuery(QueryCls obj)
        {
            if (obj.FOFlag == "F") { m_PCommodityList.FQuery.Send(obj); }
            else { m_PCommodityList.OQuery.Send(obj); }
        }
        #endregion
    }
}
