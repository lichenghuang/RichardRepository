﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using DeriLib.WarrantSearch;
using System.Threading;
using System.Timers;
using WarrantSearch;

namespace DeriLib.Com.WarrantSearch
{
    [Guid("1BF5CA53-5064-4c24-8200-1DAF0A08616C")]
    [ComVisible(true)]
    public interface ComWarrantSearch_Interface
    {
        string[] GetWarrants(string Filter);
    }

    [Guid("2C358DFF-B1FC-484b-95A8-629F5408C629"),
    ClassInterface(ClassInterfaceType.None)]
    [ComVisible(true)]
    public class ComWarrantSearch : ComWarrantSearch_Interface
    {
        public string[] GetWarrants(string Filter)
        {
            string[] S = new string[1];
            WarrantInfo[] f = new WarrantInfo[1];

            if (Filter != "")
                Filter = " and " + Filter;

            try
            {
                Filter = "warrantid<>'' " + Filter;
                WarrantService sWarrantService = new WarrantService();
                f = sWarrantService.GetWarrants(Filter);
            }
            catch(Exception ex)
            {
            }

            if (f != null && f.Length > 0)
            {
                S = new string[f.Length];

                for (int i = 0; i < f.Length; i++)
                    S[i] = f[i].WarrId;
            }

            return S;
        }
    }
}
