﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;

namespace PatsQuote
{
    public class PatsQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "0840";
        public string SubCommodity = "TWS";
        public string RemotIp = "";
        public int RemotPort = 7442;
        public string ID = "";
        public string PSWD = "";

        public PatsQuoteFactorySetting()
        {
        }
        public PatsQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public PatsQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }

    public class PatsQuoteSource : QuoteSource
    {
        private Thread RoutineThread;
        private string DBConnectString = "";
        private string SubCommodity = "";
        private TimeSpan RecoverTime;
        private string RemotIp = "";
        private int RemotPort = 7442;
        private string ID = "";
        private string PSWD = "";
        private bool RecoverFlag = false;
        private bool RecoverFlag2 = false;
        private GMSLib.MOMClient MOMClient = null;
        private Hashtable SettleDateHt = Hashtable.Synchronized(new Hashtable());

        private Dictionary<string, PCommodity> Commoditys = new Dictionary<string, PCommodity>();  

        public PatsQuoteSource(PatsQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            SubCommodity = QuoteSetting.SubCommodity;
            RemotIp = QuoteSetting.RemotIp;
            RemotPort = QuoteSetting.RemotPort;
            ID = QuoteSetting.ID;
            PSWD = QuoteSetting.PSWD;
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);
        }
        public override bool Start()
        {
            MOMClient = new GMSLib.MOMClient("pats", RemotIp, RemotPort, ID, PSWD, false);

            MOMClient.ReturnMsg += new GMSLib.MOMClient.ReturnMsgHandler(Pats_MsgArrived);
            MOMClient.ReturnData += new GMSLib.MOMClient.ReturnDataHandler(Pats_DataArrived);
            GMSLib.ReturnMsgData iReturnMsgData = MOMClient.Connect();

            if (iReturnMsgData.MsgNo <0)
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Pats_Connect_Error] " + "[" + iReturnMsgData.Msgstr + "]");

            foreach (string s in SubCommodity.Split(','))
            {
                MOMClient.TopicSubscribe("com.gcsc.OFQuote."+s);
                MOMClient.TopicGetImage("com.gcsc.OFQuote."+s);
                //MOMClient.TopicSubscribe("com.gcsc.OFQuote.SGX.TW.AUG11");
            }
            
            //MOMClient.TopicSubscribe("com.gcsc.OFQuote");
            //MOMClient.TopicGetImage("com.gcsc.OFQuote");

            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            return base.Start();
        }

        private void Pats_DataArrived(object objMsg)
        {
            try
            {
                GMSLib.MessageData sMessageData = new GMSLib.MessageData();
                                
                PatsObjDefLib.PriceStruct dd = (PatsObjDefLib.PriceStruct)sMessageData.GetData(objMsg, typeof(PatsObjDefLib.PriceStruct));

                string CommodityId = GetCommodityId(sMessageData.MessageHeader.sName);

                if (CommodityId == "") { return; }

                m_PacketNum++;

                PCommodity mPCommodity = m_PCommodityList.Set(CommodityId.Substring(0, 3), CommodityId, Market.TFE, CommodityKind.Future);

                if (!Commoditys.ContainsKey(CommodityId)) { Commoditys.Add(CommodityId,mPCommodity); }

                double referenceP = 0.0;
                double riseP = 0.0;
                double fallP = 0.0;
                double.TryParse(dd.pvCurrStl.Price,out referenceP);
                double.TryParse(dd.LimitUp.Price, out riseP);
                double.TryParse(dd.LimitDown.Price, out fallP);
                string informationtime = ((int)dd.ReferencePrice.Hour).ToString("00") + ((int)dd.ReferencePrice.Minute).ToString("00") + ((int)dd.ReferencePrice.Second).ToString("00");
                string seqno = DateTime.Now.ToString("HHmmssff");

                if (Math.Round(mPCommodity.QCommodity.Base.ReferencePrice, 2) != Math.Round(referenceP, 2))
                {
                    string settledate = GetMaturity(CommodityId.Substring(3));
                    
                    DeriLib.Util.ExecSqlCmd("EXEC spCommodityExtra '" + CommodityId + "','TFE','Future','" + settledate + "',0.0", m_QuoteSetting.DBConnectString);
                                        
                    mPCommodity.IsLocalCommodity = true;
                    mPCommodity.SetBase(Market.TFE, CommodityKind.Future, CommodityType.None, "TWS", "新加坡摩台期", DateTime.Today, informationtime, "", CommodityId.Substring(3), 0, referenceP, riseP, fallP, 0.0, 0.0, 0.0, 0.0, 1, "I", 1, 1, "", "");
                    DoSendWrite(mPCommodity.QCommodity.Base);
                }

                string openinformationtime = ((int)dd.Opening.Hour).ToString("00") + ((int)dd.Opening.Minute).ToString("00") + ((int)dd.Opening.Second).ToString("00") + "00";

                if (mPCommodity.QCommodity.Open.OpenTime == null || mPCommodity.QCommodity.Open.OpenTime == "" || int.Parse(openinformationtime) > int.Parse(mPCommodity.QCommodity.Open.OpenTime))
                {
                    double openP = 0.0;
                    double.TryParse(dd.Opening.Price, out openP);

                    mPCommodity.SetOpen(openinformationtime, openP);
                    DoSendWrite(mPCommodity.QCommodity.Open);
                }

                string best5informationtime = ((int)dd.Bid.Hour).ToString("00") + ((int)dd.Bid.Minute).ToString("00") + ((int)dd.Bid.Second).ToString("00") + "00";

                if (mPCommodity.QCommodity.Best5.InformationTime == null || mPCommodity.QCommodity.Best5.InformationTime == "" || mPCommodity.QCommodity.Best5.InformationTime == "" || int.Parse(best5informationtime) > int.Parse(mPCommodity.QCommodity.Best5.InformationTime))
                {
                    double bid1P = 0.0;
                    double ask1P = 0.0;
                    int bid1Qty = dd.Bid.Volume;
                    int ask1Qty = dd.Offer.Volume;

                    double.TryParse(dd.Bid.Price, out bid1P);
                    double.TryParse(dd.Offer.Price, out ask1P);

                    mPCommodity.SetBest5(best5informationtime, seqno, bid1P, bid1Qty, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, ask1P, ask1Qty, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0);
                    DoSendWrite(mPCommodity.QCommodity.Best5);
                }

                string lastinformationtime = ((int)dd.Last0.Hour).ToString("00") + ((int)dd.Last0.Minute).ToString("00") + ((int)dd.Last0.Second).ToString("00") + "00";
                int totalQ = dd.Total.Volume;
                double lastP = 0.0;
                double.TryParse(dd.Last0.Price,out lastP);
                int Qty = dd.Last0.Volume;

                if (totalQ != mPCommodity.QCommodity.Match.MatchTotalQty)
                {
                    mPCommodity.SetMatch(lastinformationtime, seqno, 1, lastinformationtime, lastP, Qty, 0.0, 0.0, totalQ, 0, 0, 0);
                    DoSendWrite(mPCommodity.QCommodity.Match);
                }

                /*string highinformationtime = ((int)dd.High.Hour).ToString("00") + ((int)dd.High.Minute).ToString("00") + ((int)dd.High.Second).ToString("00");
                string lowinformationtime = ((int)dd.Low.Hour).ToString("00") + ((int)dd.Low.Minute).ToString("00") + ((int)dd.Low.Second).ToString("00");

                if (mPCommodity.QCommodity.HighLow.InformationTime == null || int.Parse(highinformationtime) > int.Parse(mPCommodity.QCommodity.HighLow.InformationTime))
                {
                    double highP = 0.0;
                    double.TryParse(dd.High.Price, out highP);

                    mPCommodity.SetHighLow(highinformationtime,"", highP,mPCommodity.QCommodity.HighLow.DayLowPrice,highinformationtime);
                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                }
                if (mPCommodity.QCommodity.HighLow.InformationTime == null || int.Parse(lowinformationtime) > int.Parse(mPCommodity.QCommodity.HighLow.InformationTime))
                {
                    double lowP = 0.0;
                    double.TryParse(dd.Low.Price, out lowP);

                    mPCommodity.SetHighLow(highinformationtime, "", mPCommodity.QCommodity.HighLow.DayHighPrice, lowP, lowinformationtime);
                    DoSendWrite(mPCommodity.QCommodity.HighLow);
                }
                
                string closeinformationtime = ((int)dd.Closing.Hour).ToString("00") + ((int)dd.Closing.Minute).ToString("00") + ((int)dd.Closing.Second).ToString("00");

                if (mPCommodity.QCommodity.Close.InformationTime == null || int.Parse(closeinformationtime) > int.Parse(mPCommodity.QCommodity.Close.InformationTime))
                {
                    double closeP = 0.0;
                    double.TryParse(dd.Closing.Price, out closeP);
                    int closeQ = dd.Closing.Volume;

                    mPCommodity.SetClose(closeinformationtime, "",mPCommodity.QCommodity.HighLow.DayHighPrice,mPCommodity.QCommodity.HighLow.DayHighPrice,mPCommodity.QCommodity.Open.OpenPrice,mPCommodity.QCommodity.Best5.BuyPriceBest1,mPCommodity.QCommodity.Best5.SellPriceBest1,closeP,DateTime.Today,0,dd.Total.Volume,0.0,closeP);
                    DoSendWrite(mPCommodity.QCommodity.Close);
                }*/

                if (DateTime.Now.TimeOfDay.TotalHours > 14 && DateTime.Now.TimeOfDay.TotalHours < 14.5)
                {
                    string closeinformationtime = ((int)dd.Closing.Hour).ToString("00") + ((int)dd.Closing.Minute).ToString("00") + ((int)dd.Closing.Second).ToString("00");

                    if (mPCommodity.QCommodity.Close.InformationTime == null || mPCommodity.QCommodity.Close.InformationTime == "" || int.Parse(closeinformationtime) > int.Parse(mPCommodity.QCommodity.Close.InformationTime))
                    {
                        double closeP = 0.0;
                        double.TryParse(dd.Closing.Price, out closeP);
                        int closeQ = dd.Closing.Volume;

                        mPCommodity.SetClose(closeinformationtime, "", mPCommodity.QCommodity.HighLow.DayHighPrice, mPCommodity.QCommodity.HighLow.DayHighPrice, mPCommodity.QCommodity.Open.OpenPrice, mPCommodity.QCommodity.Best5.BuyPriceBest1, mPCommodity.QCommodity.Best5.SellPriceBest1, closeP, DateTime.Today, 0, dd.Total.Volume, 0.0, closeP);
                        DoSendWrite(mPCommodity.QCommodity.Close);
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Pats_DataArrived_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        
        private void Pats_MsgArrived(GMSLib.ReturnMsgData MsgData)
        {
            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Pats_MsgArrived_Error][" + MsgData.MsgNo.ToString() + "] " + "[連線失敗]");
            //Close();            
        }
        private string GetCommodityId(string Topic)
        {
            try
            {
                if (Topic == null || Topic == "") { return ""; }

                string commodityid = Topic.Split('.')[4];
                string mon = Topic.Split('.')[5];

                if (commodityid == "TW") { commodityid = "TWS"; }
                else { return ""; }

                if (mon.Length != 5) { return ""; }

                switch (mon.Substring(0,3))
                {
                    case "JAN":
                        mon = "20"+mon.Substring(3)+"01";
                        break;
                    case "FEB":
                        mon = "20" + mon.Substring(3) + "02";
                        break;
                    case "MAR":
                        mon = "20" + mon.Substring(3) + "03";
                        break;
                    case "APR":
                        mon = "20" + mon.Substring(3) + "04";
                        break;
                    case "MAY":
                        mon = "20" + mon.Substring(3) + "05";
                        break;
                    case "JUN":
                        mon = "20" + mon.Substring(3) + "06";
                        break;
                    case "JUL":
                        mon = "20" + mon.Substring(3) + "07";
                        break;
                    case "AUG":
                        mon = "20" + mon.Substring(3) + "08";
                        break;
                    case "SEP":
                        mon = "20" + mon.Substring(3) + "09";
                        break;
                    case "OCT":
                        mon = "20" + mon.Substring(3) + "10";
                        break;
                    case "NOV":
                        mon = "20" + mon.Substring(3) + "11";
                        break;
                    case "DEC":
                        mon = "20" + mon.Substring(3) + "12";
                        break;
                    default:
                        break;
                }

                return commodityid+mon;
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Pats_GetCommodityId_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return "";
            }
        }
        private string GetMaturity(string SettleMonth)
        {
            string settleday = "";

            if (SettleDateHt.ContainsKey(SettleMonth))
                return SettleDateHt[SettleMonth].ToString();

            try
            {
                settleday = SettleMonth.Substring(0, 4) + "/" + SettleMonth.Substring(4, 2) + "/" + "01";
                DataView dv = DeriLib.Util.ExecSqlQry("select min(tradedate) from (select  top 2 * from tradedate where country='TWN' and istrade='Y' and tradedate<dateadd(m,1,'" + settleday + "') order by tradedate desc) a", m_QuoteSetting.DBConnectString);

                if (dv.Count > 0)
                    settleday = dv[0][0].ToString();

                SettleDateHt.Add(SettleMonth, settleday);

                return settleday;
            }
            catch (Exception ex)
            {
                ErrorProcess("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][GetMaturity_Error] [" + ex.Message + "][" + ex.StackTrace + "]");
                return settleday;
            }
        }
        public override bool Close()
        {
            try
            {
                MOMClient.ReturnMsg -= new GMSLib.MOMClient.ReturnMsgHandler(Pats_MsgArrived);
                MOMClient.ReturnData -= new GMSLib.MOMClient.ReturnDataHandler(Pats_DataArrived);

                MOMClient.Close();
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private void RecoverData()
        {
            try
            {
                List<string> PList = new List<string>();

                foreach (PCommodity P in Commoditys.Values)
                {
                    try
                    {
                        P.SetClose(DateTime.Now.ToString("HHmmss"), DateTime.Now.ToString("HHmmss"), P.QCommodity.HighLow.DayHighPrice, P.QCommodity.HighLow.DayHighPrice, P.QCommodity.Open.OpenPrice, P.QCommodity.Best5.BuyPriceBest1, P.QCommodity.Best5.SellPriceBest1, P.QCommodity.Match.MatchPrice, DateTime.Today, 0, P.QCommodity.Match.MatchTotalQty, 0.0, P.QCommodity.Match.MatchPrice);
                        DoSendWrite(P.QCommodity.Close);
                    }
                    catch (Exception ex)
                    {
                        m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RecoverData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                    }
                }
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RecoverData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;
                        RecoverFlag2 = false;
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        RecoverData();
                        RecoverFlag = true;
                    }

                    if (Math.Abs(nowts.Subtract(new TimeSpan(8,30,0)).TotalMinutes) < 1 && !RecoverFlag2)
                    {
                        MOMClient.ReturnMsg -= new GMSLib.MOMClient.ReturnMsgHandler(Pats_MsgArrived);
                        MOMClient.ReturnData -= new GMSLib.MOMClient.ReturnDataHandler(Pats_DataArrived);

                        MOMClient.Close();

                        MOMClient = new GMSLib.MOMClient("pats", RemotIp, RemotPort, ID, PSWD, false);

                        MOMClient.ReturnMsg += new GMSLib.MOMClient.ReturnMsgHandler(Pats_MsgArrived);
                        MOMClient.ReturnData += new GMSLib.MOMClient.ReturnDataHandler(Pats_DataArrived);
                        GMSLib.ReturnMsgData iReturnMsgData = MOMClient.Connect();

                        if (iReturnMsgData.MsgNo < 0)
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Pats_Connect_Error] " + "[" + iReturnMsgData.Msgstr + "]");

                        foreach (string s in SubCommodity.Split(','))
                        {
                            MOMClient.TopicSubscribe("com.gcsc.OFQuote." + s);
                            MOMClient.TopicGetImage("com.gcsc.OFQuote." + s);
                            //MOMClient.TopicSubscribe("com.gcsc.OFQuote.SGX.TW.AUG11");
                        }

                        RecoverFlag2 = true;
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }

        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }

    }    
}

