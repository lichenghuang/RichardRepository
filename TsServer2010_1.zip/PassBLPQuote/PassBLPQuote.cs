﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
//using log4net;

namespace PassBLPQuote
{    
        public class PassBLPQuoteFactorySetting : QuoteFactorySetting
        {
            public string RecoverTime = "07:44";        
            public string RemotIp = "127.0.0.1";
            public int RemotPort = 8194;        

            public PassBLPQuoteFactorySetting()
            {
            }
            public PassBLPQuoteFactorySetting(string Service)
                : base(Service)
            {
            }
            public PassBLPQuoteFactorySetting(string Service, string DataSource, string Note)
                : base(Service, DataSource, Note)
            {
            }
        }

        public class PassBLPQuoteSource : QuoteSource
        {
            //private static readonly ILog log = LogManager.GetLogger(typeof(PassBLPQuoteSource));

            private Thread RoutineThread;
            private string DBConnectString = "";
            private TimeSpan tsRecover;
            //private TimeSpan RecoverTime2;
            //private TimeSpan TransCloseTime;
            private bool RecoverFlag = false;
            //private bool RecoverFlag2 = false;
            //private bool TransCloseFlag = false;
            private string RemotIp = "";
            private int RemotePort = 0;
            Dictionary<string, string> dicIntlMonth = new Dictionary<string, string>();
            Dictionary<string, string> dicMonth = new Dictionary<string, string>();
            Dictionary<string, string> dicYstCls = new Dictionary<string, string>();

            private IPAddress addrLocal;
            private string sIP2;
            private int iPort2;

            private UdpClient BBclient2;
            private IPEndPoint BBrep2;

            private string _sBlpIP = string.Empty;
            private string _sLocalIP = string.Empty;

            public PassBLPQuoteSource(PassBLPQuoteFactorySetting QuoteSetting)
                : base((QuoteFactorySetting)QuoteSetting)
            {
                DBConnectString = QuoteSetting.DBConnectString;
                RemotIp = QuoteSetting.RemotIp;
                RemotePort = QuoteSetting.RemotPort;
                tsRecover = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);

                dicIntlMonth["01"] = dicIntlMonth["1"] = "F"; dicIntlMonth["F"] = "01";
                dicIntlMonth["02"] = dicIntlMonth["2"] = "G"; dicIntlMonth["G"] = "02";
                dicIntlMonth["03"] = dicIntlMonth["3"] = "H"; dicIntlMonth["H"] = "03";
                dicIntlMonth["04"] = dicIntlMonth["4"] = "J"; dicIntlMonth["J"] = "04";
                dicIntlMonth["05"] = dicIntlMonth["5"] = "K"; dicIntlMonth["K"] = "05";
                dicIntlMonth["06"] = dicIntlMonth["6"] = "M"; dicIntlMonth["M"] = "06";
                dicIntlMonth["07"] = dicIntlMonth["7"] = "N"; dicIntlMonth["N"] = "07";
                dicIntlMonth["08"] = dicIntlMonth["8"] = "Q"; dicIntlMonth["Q"] = "08";
                dicIntlMonth["09"] = dicIntlMonth["9"] = "U"; dicIntlMonth["U"] = "09";
                dicIntlMonth["10"] = "V"; dicIntlMonth["V"] = "10";
                dicIntlMonth["11"] = "X"; dicIntlMonth["X"] = "11";
                dicIntlMonth["12"] = "Z"; dicIntlMonth["Z"] = "12";

                dicMonth["01"] = "A";
                dicMonth["02"] = "B";
                dicMonth["03"] = "C";
                dicMonth["04"] = "D";
                dicMonth["05"] = "E";
                dicMonth["06"] = "F";
                dicMonth["07"] = "G";
                dicMonth["08"] = "H";
                dicMonth["09"] = "I";
                dicMonth["10"] = "J";
                dicMonth["11"] = "K";
                dicMonth["12"] = "L";

                IPAddress addrDest2 = null;
                string sHostName = string.Empty;
                try
                {
                    sHostName = Dns.GetHostName();
                    IPHostEntry iphostentry = Dns.GetHostEntry(sHostName);
                    foreach (IPAddress ipaddress in iphostentry.AddressList)
                    {
                        if (ipaddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            if (ipaddress.ToString().StartsWith("172.31.1."))
                            { _sBlpIP = ipaddress.ToString(); }
                            else
                            { _sLocalIP = ipaddress.ToString(); }
                        }
                    }

                    addrLocal = IPAddress.Parse(_sBlpIP);

                    sIP2 = "224.5.6.7";
                    addrDest2 = IPAddress.Parse(sIP2);
                    iPort2 = 5002;

                    BBrep2 = new IPEndPoint(addrDest2, 0);
                    BBclient2 = new UdpClient();
                    BBclient2.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                    BBclient2.Client.Bind(new IPEndPoint(IPAddress.Any, iPort2));
                    BBclient2.JoinMulticastGroup(addrDest2, addrLocal);
                }
                catch (Exception ex)
                {
                    m_ErrorPool.Enqueue("[" + DateTime.Now.ToString("HH:mm:ss") + "][PassBLPQuoteSource][" + ex.Message + "][" + ex.StackTrace + "]");
                }
            }

            public override bool Start()
            {                
                LoadData();

                if (RoutineThread == null)
                {
                    RoutineThread = new Thread(new ThreadStart(RoutineWork));
                    RoutineThread.Start();
                }

                if (_tDataWorker == null)
                {
                    _tDataWorker = new Thread(new ThreadStart(deqData));
                    _tDataWorker.Start();
                }

                return base.Start();
            }

            public override bool Close()
            {
                try
                {
                    if (_tDataWorker != null && _tDataWorker.IsAlive) { _tDataWorker.Abort(); _tDataWorker = null; }

                    if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); RoutineThread = null; }

                    base.Close();

                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }

            private Thread _tDataWorker = null;
            private void deqData()
            {
                byte[] baData = new byte[1024];
                while (true)
                {
                    try
                    {
                        byte[] bbpac = BBclient2.Receive(ref BBrep2);
                        string sData = System.Text.Encoding.ASCII.GetString(bbpac);
                        if (sData.StartsWith("TsServer"))
                        { m_PackagePool.Enqueue(sData); }
                    }
                    catch (Exception ex)
                    { m_ErrorPool.Enqueue("[" + DateTime.Now.ToString("HH:mm:ss") + "][PassBLPQuote][deqData]" + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                }
            }

            private void RoutineWork()
            {
                try
                {
                    for (; ; )
                    {
                        TimeSpan tsNow = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

                        if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                        {
                            RecoverFlag = false;
                            //RecoverFlag2 = false;
                            //TransCloseFlag = false;
                        }

                        if (Math.Abs(tsNow.Subtract(tsRecover).TotalMinutes) < 1 && !RecoverFlag)
                        {
                            ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                            RecoverFlag = true;
                        }

                        //if (Math.Abs(tsNow.Subtract(RecoverTime2).TotalMinutes) < 1 && !RecoverFlag2)
                        //{
                        //    ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        //    RecoverFlag2 = true;
                        //}

                        //if (Math.Abs(tsNow.Subtract(TransCloseTime).TotalMinutes) < 1 && !TransCloseFlag)
                        //{
                        //    ThreadPool.QueueUserWorkItem(new WaitCallback(TransCloseWork));
                        //    TransCloseFlag = true;
                        //}

                        while (m_PackagePool.Count > 0)
                        {
                            try
                            {
                                string sBlpData = m_PackagePool.Dequeue().ToString();
                                DealWithQuote(sBlpData);
                            }
                            catch (Exception ex)
                            {
                                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                            }
                        }

                        Thread.Sleep(1000);
                    }
                }
                catch (ThreadAbortException taex)
                {
                }
                catch (Exception ex)
                {
                    m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                }
            }

            //private void TransCloseWork(Object stateInfo)
            //{
            //    try
            //    {
            //        foreach (PCommodity P in m_PCommodityList.Commoditys)
            //        {
            //            if (P.QCommodity.Base.CommodityId.IndexOf("HK") > -1 || P.QCommodity.Base.CommodityId.IndexOf("STW") > -1 || P.QCommodity.Base.CommodityId.IndexOf("SCN") > -1)
            //            {
            //                P.SetClose(DateTime.Now.ToString("HHmmss"), DateTime.Now.ToString("HHmmssff"), P.QCommodity.HighLow.DayHighPrice, P.QCommodity.HighLow.DayLowPrice, 0.0, P.QCommodity.Best5.BuyPriceBest1, P.QCommodity.Best5.SellPriceBest1, P.QCommodity.Match.MatchPrice, DateTime.Today, 0, P.QCommodity.Match.MatchTotalQty, 0.0, P.QCommodity.Match.MatchPrice);
            //                DoSendWrite(P.QCommodity.Close);
            //            }
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][TransCloseWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            //    }
            //}       

            private void ReStartWork(Object stateInfo)
            {
                try
                {
                    if (_tDataWorker != null && _tDataWorker.IsAlive) { _tDataWorker.Abort(); _tDataWorker = null; }

                    m_PacketNum = 0;

                    LoadData();

                    if (_tDataWorker == null) { _tDataWorker = new Thread(new ThreadStart(deqData)); _tDataWorker.Start(); }
                }
                catch (Exception ex)
                { m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString("HH:mm:ss") + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
            }

            private Dictionary<string, string> _dicComdtyId = new Dictionary<string, string>();
            private Dictionary<string, string> _dicInnerCode = new Dictionary<string, string>();
            private Dictionary<string, bool> _dicTsQuote = new Dictionary<string, bool>();
            private Dictionary<string, bool> _dicTibco = new Dictionary<string, bool>();
            private Dictionary<string, string> _dicExch = new Dictionary<string, string>();

            private void LoadData()
            {
                try
                {
                    #region 交易商品

                    string sComdtyKind = string.Empty;
                    string sInnerCode = string.Empty;
                    string sComdtyId = string.Empty;
                    string sExch = string.Empty;

                    //============================================================

                    _dicTsQuote.Clear();
                    _dicTibco.Clear();

                    string sql = "SELECT BLPProd,TsQuote,Tibco,Exch FROM BLPSetting";
                    DataView dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);
                    foreach (DataRowView dr in dv)
                    {
                        string sBLPProd = string.Empty;
                        if (dr["BLPProd"] != DBNull.Value && !String.IsNullOrEmpty(dr["BLPProd"].ToString()))
                        { sBLPProd = dr["BLPProd"].ToString().Trim(); }

                        if (dr["TsQuote"] != DBNull.Value && !String.IsNullOrEmpty(dr["TsQuote"].ToString()))
                        {
                            string sFlag = dr["TsQuote"].ToString().Trim();
                            if (sFlag.Equals("Y")) { _dicTsQuote[sBLPProd] = true; }
                            else if (sFlag.Equals("N")) { _dicTsQuote[sBLPProd] = false; }
                        }

                        if (dr["Tibco"] != DBNull.Value && !String.IsNullOrEmpty(dr["Tibco"].ToString()))
                        {
                            string sFlag = dr["Tibco"].ToString().Trim();
                            if (sFlag.Equals("Y")) { _dicTibco[sBLPProd] = true; }
                            else if (sFlag.Equals("N")) { _dicTibco[sBLPProd] = false; }
                        }

                        if (dr["Exch"] != DBNull.Value && !String.IsNullOrEmpty(dr["Exch"].ToString()))
                        {
                            _dicExch[sBLPProd] = dr["Exch"].ToString().Trim();
                        }
                    }

                    _dicTsQuote["CNH"] = true;
                    _dicTibco["CNH"] = true;
                    _dicExch["CNH"] = "V_INDEX";
                    //============================================================

                    _dicInnerCode.Clear();
                    _dicComdtyId.Clear();
                    
                    m_PCommodityList.Commoditys.Clear();

                    sql = "SELECT comdty.InnerCode,comdty.CommodityId,comdty.CommodityNm,comdty.SettlementMonth,comdty.CommodityKind,comdty.DecimalLocate,comdty.Unit,comdty.MaturityDate,pb.ReferencePrice,pb.RiseLimitPrice,pb.FallLimitPrice FROM Commodity comdty,PBase pb WHERE comdty.CommodityId=pb.CommodityId AND (comdty.InnerCode LIKE '% Index' OR comdty.InnerCode LIKE '% Equity' OR comdty.InnerCode LIKE '% Comdty' OR comdty.InnerCode LIKE '% Curncy') ORDER BY comdty.MaturityDate";
                    dv = DeriLib.Util.ExecSqlQry(sql, m_QuoteSetting.DBConnectString);

                    foreach (DataRowView dr in dv)
                    {
                        sComdtyKind = string.Empty;
                        sInnerCode = string.Empty;
                        sComdtyId = string.Empty;

                        try
                        {
                            if (dr["CommodityKind"] != DBNull.Value && !String.IsNullOrEmpty(dr["CommodityKind"].ToString())) { sComdtyKind = dr["CommodityKind"].ToString().Trim(); }
                            if (dr["InnerCode"] != DBNull.Value && !String.IsNullOrEmpty(dr["InnerCode"].ToString())) { sInnerCode = dr["InnerCode"].ToString().Trim(); }
                            if (dr["CommodityId"] != DBNull.Value && !String.IsNullOrEmpty(dr["CommodityId"].ToString())) { sComdtyId = dr["CommodityId"].ToString().Trim(); }

                            PCommodity PP = null;
                            if (sComdtyKind.Equals("Future"))
                            {
                                if (!sInnerCode.EndsWith("M CMPN Curncy") && !sInnerCode.EndsWith("W CMPN Curncy"))  //期貨(一般和虛擬，但不包含遠期合約(紐約報價或預定報價))
                                {
                                    string sCont = string.Empty;
                                    if (dr["SettlementMonth"] != DBNull.Value && !String.IsNullOrEmpty(dr["SettlementMonth"].ToString()))
                                    {
                                        sCont = dr["SettlementMonth"].ToString().Trim();
                                        PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Future);
                                        PP.QCommodity.Base.CommodityKind = CommodityKind.Future;
                                        PP.QCommodity.Base.SettleMentMonth = sCont;
                                    }
                                }
                            }
                            else if (sComdtyKind.EndsWith("Stock"))
                            {
                                PP = m_PCommodityList.Set(sInnerCode, sComdtyId, Market.None, CommodityKind.Stock);
                                PP.QCommodity.Base.CommodityKind = CommodityKind.Stock;
                            }

                            if (PP != null)
                            {
                                PP.QCommodity.Base.CommodityCode = "";
                                PP.QCommodity.Base.CommodityNm = dr["CommodityNm"].ToString().Trim();
                                PP.QCommodity.Base.Market = Market.None;
                                PP.QCommodity.Base.DecimalLocate = dr["DecimalLocate"] != DBNull.Value ? Convert.ToDouble(dr["DecimalLocate"].ToString()) : 1.0;
                                PP.QCommodity.Base.Unit = dr["Unit"] != DBNull.Value ? Convert.ToInt32(dr["Unit"].ToString()) : 1;

                                PP.QCommodity.Base.ReferencePrice = dr["ReferencePrice"] != DBNull.Value ? Convert.ToDouble(dr["ReferencePrice"].ToString()) : 0;
                                PP.QCommodity.Base.RiseLimitPrice = dr["RiseLimitPrice"] != DBNull.Value ? Convert.ToDouble(dr["RiseLimitPrice"].ToString()) : 0;
                                PP.QCommodity.Base.FallLimitPrice = dr["FallLimitPrice"] != DBNull.Value ? Convert.ToDouble(dr["FallLimitPrice"].ToString()) : 0;

                                PP.QCommodity.HighLow.DayLowPrice = PP.QCommodity.Base.ReferencePrice;
                                PP.QCommodity.HighLow.DayHighPrice = PP.QCommodity.Base.ReferencePrice;

                                PP.QCommodity.Base.InformationTime = DateTime.Now.ToString("HHmmssff");
                                PP.QCommodity.Base.InformationSeq = DateTime.Now.ToString("HHmmssff");

                                PP.QCommodity.Base.TradeDate = DateTime.Today;
                                
                                _dicComdtyId[sInnerCode] = sComdtyId;
                                _dicInnerCode[sComdtyId] = sInnerCode;
                            }
                        }
                        catch (Exception ex)
                        { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
                    }

                    //============================================================

                    #endregion
                }
                catch (Exception ex)
                { m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][LoadData_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]"); }
            }
            
            private void DealWithQuote(string sData)
            {
                string[] saData = sData.Split(',');
                try
                {
                    string sComdtyId = saData[1];
                     
                    if (_dicInnerCode.ContainsKey(sComdtyId))
                    {
                        string sInnerCode = _dicInnerCode[sComdtyId];
                        string sBLPProd = sInnerCode.Substring(0, sInnerCode.IndexOf(' ') - 2);
                        PCommodity mPCommodity = m_PCommodityList.Get(sComdtyId);
                        if (mPCommodity == null) { return; }

                        m_PacketNum++;

                        string sTime = DateTime.Now.ToString("HHmmssff");
                        string sSeq = DateTime.Now.ToString("HHmmssff");

                        bool bSendFlag = false;
                        if (!String.IsNullOrEmpty(saData[3])) { mPCommodity.QCommodity.Match.MatchPrice = Convert.ToDouble(saData[3]); bSendFlag = true; }
                        //if (!String.IsNullOrEmpty(saData[])) { mPCommodity.QCommodity.Match.MatchQty = Convert.ToInt32(saData[]); }
                        //if (!String.IsNullOrEmpty(saData[])) { mPCommodity.QCommodity.Match.MatchTotalQty = Convert.ToInt32(saData[]); }
                        if (bSendFlag)
                        {
                            mPCommodity.QCommodity.Match.InformationTime = sTime;
                            mPCommodity.QCommodity.Match.InformationSeq = sSeq;
                            mPCommodity.QCommodity.Match.MatchTime = sTime;
                            if (mPCommodity.QCommodity.Match.MatchPrice != 0.0) { mPCommodity.QCommodity.Match.MatchPrices = mPCommodity.QCommodity.Match.MatchPrice; }
                            if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                            { DoSendWrite(mPCommodity.QCommodity.Match); }
                        }
                        
                        bSendFlag = false;
                        if (!String.IsNullOrEmpty(saData[5])) { mPCommodity.QCommodity.Best5.BuyPriceBest1 = Convert.ToDouble(saData[5]); bSendFlag = true; }
                        if (!String.IsNullOrEmpty(saData[6])) { mPCommodity.QCommodity.Best5.BuyQtyBest1 = Convert.ToInt32(saData[6]); bSendFlag = true; }
                        if (!String.IsNullOrEmpty(saData[7])) { mPCommodity.QCommodity.Best5.BuyPriceBest2 = Convert.ToDouble(saData[7]); }
                        if (!String.IsNullOrEmpty(saData[8])) { mPCommodity.QCommodity.Best5.BuyQtyBest2 = Convert.ToInt32(saData[8]); }
                        if (!String.IsNullOrEmpty(saData[9])) { mPCommodity.QCommodity.Best5.BuyPriceBest3 = Convert.ToDouble(saData[9]); }
                        if (!String.IsNullOrEmpty(saData[10])) { mPCommodity.QCommodity.Best5.BuyQtyBest3 = Convert.ToInt32(saData[10]); }
                        if (!String.IsNullOrEmpty(saData[11])) { mPCommodity.QCommodity.Best5.BuyPriceBest4 = Convert.ToDouble(saData[11]); }
                        if (!String.IsNullOrEmpty(saData[12])) { mPCommodity.QCommodity.Best5.BuyQtyBest4 = Convert.ToInt32(saData[12]); }
                        if (!String.IsNullOrEmpty(saData[13])) { mPCommodity.QCommodity.Best5.BuyPriceBest5 = Convert.ToDouble(saData[13]); }
                        if (!String.IsNullOrEmpty(saData[14])) { mPCommodity.QCommodity.Best5.BuyQtyBest5 = Convert.ToInt32(saData[14]); }
                        if (!String.IsNullOrEmpty(saData[15])) { mPCommodity.QCommodity.Best5.SellPriceBest1 = Convert.ToDouble(saData[15]); bSendFlag = true; }
                        if (!String.IsNullOrEmpty(saData[16])) { mPCommodity.QCommodity.Best5.SellQtyBest1 = Convert.ToInt32(saData[16]); bSendFlag = true; }
                        if (!String.IsNullOrEmpty(saData[17])) { mPCommodity.QCommodity.Best5.SellPriceBest2 = Convert.ToDouble(saData[17]); }
                        if (!String.IsNullOrEmpty(saData[18])) { mPCommodity.QCommodity.Best5.SellQtyBest2 = Convert.ToInt32(saData[18]); }
                        if (!String.IsNullOrEmpty(saData[19])) { mPCommodity.QCommodity.Best5.SellPriceBest3 = Convert.ToDouble(saData[19]); }
                        if (!String.IsNullOrEmpty(saData[20])) { mPCommodity.QCommodity.Best5.SellQtyBest3 = Convert.ToInt32(saData[20]); }
                        if (!String.IsNullOrEmpty(saData[21])) { mPCommodity.QCommodity.Best5.SellPriceBest4 = Convert.ToDouble(saData[21]); }
                        if (!String.IsNullOrEmpty(saData[22])) { mPCommodity.QCommodity.Best5.SellQtyBest4 = Convert.ToInt32(saData[22]); }
                        if (!String.IsNullOrEmpty(saData[23])) { mPCommodity.QCommodity.Best5.SellPriceBest5 = Convert.ToDouble(saData[23]); }
                        if (!String.IsNullOrEmpty(saData[24])) { mPCommodity.QCommodity.Best5.SellQtyBest5 = Convert.ToInt32(saData[24]); }
                        if (bSendFlag)
                        {
                            mPCommodity.QCommodity.Best5.InformationTime = sTime;
                            mPCommodity.QCommodity.Best5.InformationSeq = sSeq;
                            mPCommodity.QCommodity.Best5.BuyPriceBest1s = mPCommodity.QCommodity.Best5.BuyPriceBest1;
                            if (mPCommodity.QCommodity.Best5.BuyPriceBest1s == 0.0 && mPCommodity.QCommodity.Match != null) { mPCommodity.QCommodity.Best5.BuyPriceBest1s = mPCommodity.QCommodity.Match.MatchPrice; }
                            mPCommodity.QCommodity.Best5.SellPriceBest1s = mPCommodity.QCommodity.Best5.SellPriceBest1;
                            if (mPCommodity.QCommodity.Best5.SellPriceBest1s == 0.0 && mPCommodity.QCommodity.Match != null) { mPCommodity.QCommodity.Best5.SellPriceBest1s = mPCommodity.QCommodity.Match.MatchPrice; }
                            if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                            { DoSendWrite(mPCommodity.QCommodity.Best5); }
                        }

                        //bSendFlag = false;
                        //double dHigh = 0;
                        //if (!String.IsNullOrEmpty(saData[25]) && Double.TryParse(saData[25], out dHigh))
                        //{
                        //    if (mPCommodity.QCommodity.HighLow.DayHighPrice < dHigh)
                        //    { mPCommodity.QCommodity.HighLow.DayHighPrice = dHigh; bSendFlag = true; }
                        //}
                        //double dLow = 0;
                        //if (!String.IsNullOrEmpty(saData[26]) && Double.TryParse(saData[26], out dLow)) 
                        //{
                        //    if (mPCommodity.QCommodity.HighLow.DayLowPrice > dLow)
                        //    { mPCommodity.QCommodity.HighLow.DayLowPrice = dLow; bSendFlag = true; }
                        //}
                        //if (bSendFlag)
                        //{
                        //    mPCommodity.QCommodity.HighLow.InformationTime = sTime;
                        //    mPCommodity.QCommodity.HighLow.InformationSeq = sSeq;
                        //    mPCommodity.QCommodity.HighLow.ShowTime = sTime;
                        //    if (_dicTibco.ContainsKey(sBLPProd) && _dicTibco[sBLPProd])
                        //    { DoSendWrite(mPCommodity.QCommodity.HighLow); }
                        //}
                    }                    
                }
                catch (Exception ex)
                {
                    m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString("HH:mm:ss") + "][DealWithQuote_Error][" + ex.Message + "][" + ex.StackTrace + "]");
                }
            }

            private void DoSendWrite(object obj)
            {
                PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

                object obj2;
                bool iscopy = false;

                if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
                else { obj2 = obj; iscopy = false; }

                mPCommodity.Send(obj2);

                if (m_QuoteSetting.IsWriteToDb)
                {
                    if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    { obj2 = ((ICopy)obj).Copy(); }

                    m_WriteDBPool.Enqueue(obj2);
                }
            }
        }
    
}
