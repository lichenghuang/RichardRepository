﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Timers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using DeriLib.Client;
using DeriLib.Client.Quote;
using Derivative.PriceModel;
using DeriLib.TSModel;
using DeriLib.Quote;
using TIBCO.Rendezvous;

namespace TibcoQuote
{
    public class TibcoQuoteFactorySetting : QuoteFactorySetting
    {
        public string RecoverTime = "0840";        
        public int TibcoService = 8250;
        public string TibcoNetwork = "";
        public string TibcoDaemon = "";
        public string TibcoSubject = "";

        public TibcoQuoteFactorySetting()
        {
        }
        public TibcoQuoteFactorySetting(string Service)
            : base(Service)
        {
        }
        public TibcoQuoteFactorySetting(string Service, string DataSource, string Note)
            : base(Service, DataSource, Note)
        {
        }
    }
    public class TibcoQuoteSource: QuoteSource
    {
        private Thread RoutineThread;
        private Thread ListenerThread;
        private string DBConnectString = "";
        private TimeSpan RecoverTime;
        private int TibcoService = 8250;
        private string TibcoNetwork = "";
        private string TibcoDaemon = "";
        private string TibcoSubject = "";
        private bool RecoverFlag = false;
        private Transport transport = null;
        private object LockObj = new object();

        public TibcoQuoteSource(TibcoQuoteFactorySetting QuoteSetting)
            : base((QuoteFactorySetting)QuoteSetting)
        {
            DBConnectString = QuoteSetting.DBConnectString;
            RecoverTime = new TimeSpan(int.Parse(QuoteSetting.RecoverTime.Substring(0, 2)), int.Parse(QuoteSetting.RecoverTime.Substring(3, 2)), 0);
            TibcoService = QuoteSetting.TibcoService;
            TibcoNetwork = QuoteSetting.TibcoNetwork;
            TibcoDaemon = QuoteSetting.TibcoDaemon;
            TibcoSubject = QuoteSetting.TibcoSubject;
        }
        public override bool Start()
        {
            try
            {
                RoutineThread = new Thread(new ThreadStart(RoutineWork));
                RoutineThread.Start();

                base.Start();

                TIBCO.Rendezvous.Environment.Open();

                transport = new NetTransport(TibcoService.ToString(), TibcoNetwork, TibcoDaemon);

                Listener listener = new Listener(TIBCO.Rendezvous.Queue.Default, transport, TibcoSubject, null);
                listener.MessageReceived += new MessageReceivedEventHandler(listener_MessageReceived);

                ListenerThread = new Thread(new ThreadStart(DoDispatch));
                ListenerThread.Start();

                return true;
            }
            catch (Exception ex)
            {                
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][Start_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return false;              
            }
        }
        public override bool Close()
        {
            try
            {
                if (ListenerThread != null && ListenerThread.IsAlive) { ListenerThread.Abort(); }
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                base.Close();

                TIBCO.Rendezvous.Environment.Close();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    TimeSpan nowts = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, 0);

                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        RecoverFlag = false;                        
                    }

                    if (Math.Abs(nowts.Subtract(RecoverTime).TotalMinutes) < 1 && !RecoverFlag)
                    {
                        ThreadPool.QueueUserWorkItem(new WaitCallback(ReStartWork));
                        RecoverFlag = true;
                    }

                    while (m_PackagePool.Count > 0)
                    {
                        try
                        {
                            object obj = m_PackagePool.Dequeue();
                            DealWithQuote(obj);
                        }
                        catch (Exception ex)
                        {
                            m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                        }
                    }

                    Thread.Sleep(1);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DoDispatch()
        {
            while (true)
            {
                try
                {
                    TIBCO.Rendezvous.Queue.Default.Dispatch();
                }
                catch
                {
                    break;
                }
            }
        }

        private void listener_MessageReceived(object listener, MessageReceivedEventArgs messageReceivedEventArgs)
        {
            TIBCO.Rendezvous.Message message = messageReceivedEventArgs.Message;

            m_PacketNum++;
            m_PackagePool.Enqueue(message);
        }

        private void ReStartWork(Object stateInfo)
        {
            try
            {                
                
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + DateTime.Now.ToString() + "][ReStartWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }        
        private void DealWithQuote(object obj)
        {
            int j = 0;
            PCommodity mPCommodity = null;
            DateTime dt1;
            bool b;

            try
            {
                Type iType = obj.GetType();

                
            }
            catch (Exception ex)
            {
                m_ErrorPool.Enqueue("[Quote][" + m_QuoteSetting.DataSource + "][" + DateTime.Now.ToString() + "][WCFLimitDealWithQuote_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
         
        }
        private void DoSendWrite(object obj)
        {
            PCommodity mPCommodity = ((IQCommodity)obj).GetQCommodity().PCommodity;

            object obj2;
            bool iscopy = false;

            if (m_QuoteSetting.IsSendTicks) { obj2 = ((ICopy)obj).Copy(); iscopy = true; }
            else { obj2 = obj; iscopy = false; }

            mPCommodity.Send(obj2);

            if (m_QuoteSetting.IsWriteToDb)
            {
                if (m_QuoteSetting.IsWriteTicks && !iscopy)
                    obj2 = ((ICopy)obj).Copy();

                m_WriteDBPool.Enqueue(obj2);
            }
        }
    }
}
