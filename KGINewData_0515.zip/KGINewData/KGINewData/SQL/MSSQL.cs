﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace SQL
{
    public static class MSSQL
    {
        #region SQL Server Utilities
        /// <summary>
        /// 執行一個SQL Server的SQL指令,回傳所查詢到的DataTable
        /// </summary>
        public static DataTable QuerySQL(SqlConnection conn, string strSql)
        {
            try
            {
                SqlCommand command = new SqlCommand(strSql, conn);
                command.CommandTimeout = 0;
                SqlDataReader dataReader = command.ExecuteReader();
                DataTable result = DataReaderToDataTables(dataReader)[0];
                dataReader.Close();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + " " + strSql);
            }
        }
        /// <summary>
        /// 執行一個SQL Server的SQL指令
        /// </summary>
        public static int ExecuteSQL(SqlConnection conn, string strSql)
        {
            int effRecord = 0;

            SqlCommand command = new SqlCommand(strSql, conn);
            command.CommandTimeout = 0;
            command.ExecuteNonQuery();

            return effRecord;
        }
        /// <summary>
        /// 執行一個SQL Server的SQL指令
        /// </summary>
        public static int ExecuteSQL(SqlConnection conn, SqlCommand command)
        {
            int effRecord = 0;

            //SqlCommand command = new SqlCommand(strSql, conn);
            command.Connection = conn;
            command.CommandTimeout = 0;
            command.ExecuteNonQuery();

            return effRecord;
        }
        /// <summary>
        /// 執行一個SQL Server的SQL指令,並回傳第一筆的指定欄位(string),沒有資料回傳"",
        /// 如果欄位名稱為"EOF",則判斷是否有資料,有回傳:"NOTEOF",沒有則回傳"EOF"
        /// </summary>
        public static string QuerySQL(SqlConnection conn, string strSql, string columnName)
        {
            try
            {
                SqlCommand command = new SqlCommand(strSql, conn);
                command.CommandTimeout = 0;
                SqlDataReader dataReader = command.ExecuteReader();
                string columnValue = "";
                if ("EOF".Equals(columnName))
                {
                    if (dataReader.HasRows == false)
                        columnValue = "EOF";
                    else
                        columnValue = "NOTEOF";
                    dataReader.Close();
                    return columnValue;
                }
                if (dataReader.HasRows == false)
                    columnValue = "";
                else
                {
                    dataReader.Read();
                    columnValue = dataReader[columnName].ToString();
                }
                dataReader.Close();
                return columnValue;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + " " + strSql);
            }

        }
        /// <summary>
        /// 把SqlDataReader轉成DataTable陣列
        /// </summary>
        public static DataTable[] DataReaderToDataTables(SqlDataReader dataReader)
        {
            ArrayList TableArrayList = new ArrayList();

            do
            {
                DataTable NewDataTable = new DataTable();
                DataTable TableSchema = dataReader.GetSchemaTable();
                for (int i = 1; i <= TableSchema.Rows.Count; i++)
                    NewDataTable.Columns.Add(TableSchema.Rows[i - 1]["ColumnName"].ToString(), System.Type.GetType(TableSchema.Rows[i - 1]["DataType"].ToString()));

                while (dataReader.Read() == true)
                {
                    DataRow NewDataRow = NewDataTable.NewRow();
                    for (int i = 1; i <= dataReader.FieldCount; i++)
                        NewDataRow[i - 1] = dataReader[i - 1];
                    NewDataTable.Rows.Add(NewDataRow);
                }
                TableArrayList.Add(NewDataTable);
            }
            while (dataReader.NextResult() == true);

            DataTable[] ReturnDataTable = new DataTable[TableArrayList.Count];
            for (int i = 1; i <= TableArrayList.Count; i++)
                ReturnDataTable[i - 1] = (DataTable)TableArrayList[i - 1];
            dataReader.Close();

            return ReturnDataTable;
        }
        #endregion
    }
}
