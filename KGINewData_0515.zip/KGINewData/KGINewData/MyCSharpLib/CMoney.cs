﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace MyCSharpLib
{
    public class CMoney
    {
        //取得 Query 的參數
        static string arg_1 = "5";
        static string str_srvlocation = "10.60.0.191";
        //string str_cnport = "1433";
        static string str_cnport = "";
        //static string sqlstr0 = "SELECT * FROM [ETN基本資料表] ";

        public static DataTable ExecCMoneyQry(string sqlstr0)
        {
            DataTable dt = new DataTable();
            int recordCount = 0;
            //string tableName = "ETN基本資料表";
            //讀取 CMoney 資料
            CMADODB5.CMConnection cn = new CMADODB5.CMConnection();
            ADODB.Recordset rs1 = cn.CMExecute(ref arg_1, str_srvlocation, str_cnport, sqlstr0);
            List<string> lstCol = new List<string>();
            List<string> lstType = new List<string>();
            if (rs1.EOF == false)
            {
                for (int idx = 0; idx < rs1.Fields.Count; idx++)
                {
                    //lstCol.Add(rs1.Fields[idx].Name);
                    //lstType.Add("varchar(255)");
                    dt.Columns.Add(rs1.Fields[idx].Name.ToString(), System.Type.GetType("System.String"));
                }
                //DBUtil.CreateTable(this.m_cnVOLDB, tableName, lstCol.ToArray(), lstType.ToArray());


                //填入資料
                while (rs1.EOF == false)
                {
                    DataRow row = dt.NewRow();
                    List<string> lstValue = new List<string>();
                    for (int idx = 0; idx < rs1.Fields.Count; idx++)
                    {
                        //lstValue.Add(rs1.Fields[idx].Value.ToString());

                        row[rs1.Fields[idx].Name] = rs1.Fields[idx].Value.ToString();

                    }
                    dt.Rows.Add(row);
                    rs1.MoveNext();
                    recordCount++;
                }
            }

            return dt;

        }
    }
}
