﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Threading.Tasks;
using System.Data.SqlClient;
//using KGI.Net.Mail;
//using Utility;
using MyCSharpLib;

namespace TEST
{
    class Program
    {
        static DataTable etnBasicData;
        static void Main(string[] args)
        {
            //寄信測試
            SendMail.SendMailer();  

            //CMoney SQL測試
            //string sqlquery = "SELECT TOP(100) * FROM [ETN基本資料表]";
            //etnBasicData = CMoney.ExecCMoneyQry(sqlquery);
            //CSVUtlity.SaveToCSV(etnBasicData, $".\\CMoney_TEST_CSV.csv");

            //MS SQL測試
            //string DataSource = "10.19.1.45";
            //string InitialCatalog = "testEDIS";
            //string UserID = "sa";
            //string UserPwd = "dw910770";

            //SqlConnection conn = new SqlConnection($"Data Source={DataSource};Initial Catalog={InitialCatalog};User ID={UserID};Password={UserPwd}");

            //using (conn)
            //{
            //    string sqlquery = "SELECT TOP(10) * FROM [BrokerNameID]";
            //    conn.Open();
            //    etnBasicData = MSSQL.QuerySQL(conn, sqlquery);
            //    //string aa = SQL.MSSQL.QuerySQL(conn, sqlquery,"BrokerName");

            //    CSVUtlity.SaveToCSV(etnBasicData, $".\\MSSQL_TEST_CSV.csv");
            //    conn.Close();
            //}

            Console.ReadLine();
        }

    }



    public class SendMail
    {
        public static void SendMailer()
        {
            try
            {
              
                string updatTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                KGIMailMessage ms = new KGIMailMessage();
                ms.From = "licheng@kgi.com";
                string mailTo = "licheng@kgi.com";
                ms.Subject = " [測試信件3] ";
                ms.Body = "測試信件內文";
                ms.Send(ms.From, mailTo, null, null, ms.Body, ms.Subject);
                Console.WriteLine("郵件寄送完成");
                Console.ReadLine();
                //MailService ms = new MailService();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.ReadLine();
            }
        }
        
    }

}
