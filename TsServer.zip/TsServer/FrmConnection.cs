﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using DeriLib.TSModel;

namespace TSServer
{
    public partial class FrmConnection : Form
    {
        private Thread RoutineThread;
        private DataTable dt = new DataTable("dt");
        private ITSServer iITSServer = null;
        private ITSServer iITSServerFast = null;

        public FrmConnection()
        {
            InitializeComponent();
        }

        private void FrmConnection_Load(object sender, EventArgs e)
        {
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            dt.Columns.Add("IP", typeof(string));
            dt.Columns.Add("Port", typeof(int));
            dt.Columns.Add("LoginTime", typeof(string));
            dt.Columns.Add("SubNumber", typeof(int));
            dt.Columns.Add("SubList", typeof(string));
            dt.Columns.Add("Service", typeof(string));
            dt.PrimaryKey = new DataColumn[] { dt.Columns["IP"], dt.Columns["Port"] };

            grd.DataSource = dt;
                        
            iITSServer = frmTSServer.iMain.GetService("Quote");
            iITSServerFast = frmTSServer.iMain.GetService("FastQuote");
        }

        private void FrmConnection_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
            }
            catch
            {
            }
        }
        private void Setdt(IClientState ClientState,string Service)
        {
            try
            {
                DataRow dr;
                DataRow[] drs;
                string str = "";

                drs = dt.Select("IP='" + ClientState.IP + "' and Port =" + ClientState.Port.ToString());

                if (drs.Length == 0)
                {
                    dr = dt.NewRow();
                    dr["IP"] = ClientState.IP;
                    dr["Port"] = ClientState.Port;
                    dr["LoginTime"] = ClientState.LoginTime.ToString("HH:mm:ss");
                    dr["Service"] = Service;

                    List<string> L = ClientState.SubList;

                    foreach (string s in L)
                        if (s != "") { str += s + ","; }

                    if (str.Length > 0) { str = str.Substring(0, str.Length - 1); }

                    dr["SubNumber"] = L.Count;
                    dr["SubList"] = str;
                    dt.Rows.Add(dr);
                }                
            }
            catch
            {
            }
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    if (iITSServer == null && iITSServerFast == null) { Thread.Sleep(1000); continue; }

                    List<string> L = new List<string>();
                    List<DataRow> J = new List<DataRow>();

                    if (iITSServer != null)
                    {
                        foreach (IClientState ClientState in iITSServer.ClientStates)
                        {
                            L.Add(ClientState.IP + ":" + ClientState.Port.ToString());
                            Setdt(ClientState, iITSServer.Service);
                        }
                    }

                    if (iITSServerFast != null)
                    {
                        foreach (IClientState ClientState in iITSServerFast.ClientStates)
                        {
                            L.Add(ClientState.IP + ":" + ClientState.Port.ToString());
                            Setdt(ClientState, iITSServerFast.Service);
                        }
                    }

                    foreach(DataRow dr in dt.Rows)
                        if (!L.Contains(dr["IP"].ToString() +":"+ dr["Port"].ToString())) { J.Add(dr); }

                    foreach (DataRow dr in J)
                        dr.Delete();

                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                string gg = "";
            }
        }

        private void mnuClick(object sender, EventArgs e)
        {
            Infragistics.Win.UltraWinGrid.UltraGridRow row = grd.ActiveRow;

            if (row == null) { return; }

            ToolStripMenuItem mItem = (ToolStripMenuItem)sender;

            if (mItem.Tag.ToString() == "Del")
            {
                string ip = row.Cells["IP"].Text;
                int port = 0;

                int.TryParse(row.Cells["Port"].Text, out port);

                if (row.Cells["Service"].Text == "Quote") { iITSServer.RemoveClientState(ip, port); }
                else if (row.Cells["Service"].Text == "FastQuote") { iITSServerFast.RemoveClientState(ip, port); }                
            }             
        }
        
    }
}
