﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;


namespace newCMoneyQuery
{
    class RUtility
    {
        /// <summary>
        /// 將CSV文件的數據讀取到DataTable中
        /// </summary>
        /// <param name="fileName">CSV文件路徑</param>
        /// <returns>返回讀取了CSV數據的DataTable</returns>
        public static DataTable ConvertCSVtoDataTable(string strFilePath, bool isheader)
        {

            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath, Encoding.GetEncoding("Big5")))
            {
                if (isheader == false)
                {
                    //string[] headers = { "CommodityId", "CommodityNm", "MatchTime", "LastP", "LastQ", "TotalQ", "Bid1P", "Bid1Q", "Ask1P", "Ask1Q", "UnderlyingId", "Kind", "InformationSeq", "InformationTime", "MatchSeq", "Bid2P", "Bid2Q", "Ask2P", "Ask2Q", "Bid3P", "Bid3Q", "Ask3P", "Ask3Q", "Bid4P", "Bid4Q", "Ask4P", "Ask4Q", "Bid5P", "Bid5Q", "Ask5P", "Ask5Q", "Maturity", "Strike", "RecTime" };
                    string[] headers = sr.ReadLine().Split(','); //若無特別指定, 則將第一列內容當表頭, 計算欄位數
                    int count = 1;
                    foreach (string header in headers)  //write specific header 
                    {
                        dt.Columns.Add("第" + count.ToString() + "欄");
                        count++;
                    }
                }
                else
                {
                    string[] headers = sr.ReadLine().Split(',');
                    foreach (string header in headers)  //read header from csv file
                    {
                        dt.Columns.Add(header);
                    }
                }

                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < rows.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }

            }

            return dt;
        }
    }

}
