﻿using System;
using System.Collections.Generic;
using System.Linq;
using EDLib;
using EDLib.SQL;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace newCMoneyQuery
{
    class Program
    {
        static DataTable summary;
        static string lastTDate = TradeDate.LastNTradeDate(1).ToString("yyyyMMdd");//"20170713";//
        static DataTable InitializeTables()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("StockNo", typeof(string));
            dt.Columns.Add("StockName", typeof(string));
            dt.Columns.Add("Industry", typeof(string));
            dt.Columns.Add("Price", typeof(string));  //輸出格式先一律設為string
            dt.Columns.Add("Volume", typeof(string)); //輸出格式先一律設為string
            return dt;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(lastTDate);
            Console.WriteLine("Cmoney Data Query Begins...");
            try
            {
                DataTable dt1 = new DataTable();
                DataTable dt2 = new DataTable();
                DataTable dt3 = new DataTable();
                DataTable dt4 = new DataTable();
                string sqlStr1 = "SELECT * from [上市櫃公司基本資料] A where A.[年度]='2019' ";
                string sqlStr2 = $"SELECT * from [日收盤還原表排行] A where A.[日期]='{lastTDate}' ";
                string strPath1 = ".\\權證標的.csv";
                string strPath2 = ".\\日收盤還原表排行.csv";
                dt1 = CMoney.ExecCMoneyQry(sqlStr1);
                dt2 = CMoney.ExecCMoneyQry(sqlStr2);
                //dt3 = RUtility.ConvertCSVtoDataTable(strPath1, true);
                //dt4 = RUtility.ConvertCSVtoDataTable(strPath2, true);
                //Utility.SaveToCSV(dt1, ".\\上市櫃公司基本資料.csv", true);
                //Utility.SaveToCSV(dt2, ".\\日收盤還原表排行.csv", true);
                //Utility.SaveToCSV(dt3, ".\\權證標的_output.csv", true);
                //Utility.SaveToCSV(dt4, ".\\日收盤還原表排行.csv", true);


                //合併dt1與dt2的資料
                var query = (from row1 in dt1.AsEnumerable()
                            join row2 in dt2.AsEnumerable() on
                            //row1["股票代號"] equals row2["股票代號"]
                            //row1.Field<string>("股票代號") equals row2.Field<string>("股票代號")
                            new { StockNo = row1.Field<string>("股票代號") }
                            equals
                            new { StockNo = row2.Field<string>("股票代號") }
                            into temp
                            from obj in temp.DefaultIfEmpty()
                            //where obj != null  //直接濾掉obj為null的資料
                             select new
                            {
                                StockNo = row1.Field<string>("股票代號"),
                                StockName = row1.Field<string>("股票名稱"),
                                Industry = row1["產業名稱"],
                                 //Price = obj["收盤價"],
                                 //Volume = obj["成交量"],
                                 Price = obj == null ? "N/A" : obj["收盤價"],  //若obj為null, 則顯示N/A, 否則顯示收盤價資料
                                 Volume = obj == null ? "N/A" : obj["成交量"], //若obj為null, 則顯示N/A, 否則顯示成交量資料
                             });

                #region 顯示於Console_1
                //foreach (DataRow row in dt2.Rows)
                //{
                //    var temp = dt2.Select($"股票代號 = '{row["股票代號"]}'");  //以DataTable.Select方法進行篩選; 可篩選dt2的欄位

                //    if (temp.Length != 0)
                //        //row["收盤價"] = temp[0]["收盤價"];
                //        Console.WriteLine(row["股票代號"] + " 收盤價=" + temp[0]["收盤價"].ToString() + "");
                //    //else
                //    //row["收盤價"] = 0;
                //}
                #endregion

                #region 顯示於Console_2
                //object temp1 = dt2.Select("股票代號='1101'")[0]["收盤價"];
                //Console.WriteLine("特定篩選:" + temp1.ToString() + "");

                //object temp2 = dt2.Compute("count(股票代號)", "股票代號='1101'");
                //Console.WriteLine("筆數計算:" + temp2.ToString() + "");

                //object temp3 = dt2.Compute("sum(收盤價)", "");
                //Console.WriteLine("欄位總和計算:" + temp3.ToString() + "");

                //object temp4 = dt2.Compute("avg(收盤價)", "");
                //Console.WriteLine("欄位平均計算:" + temp4.ToString() + "");

                //object temp5 = dt2.Compute("min(收盤價)", "");
                //Console.WriteLine("欄位最小值:" + temp5.ToString() + "");

                //object temp6 = dt2.Compute("max(收盤價)", "");
                //Console.WriteLine("欄位最大值:" + temp6.ToString() + "");
                #endregion


                #region 顯示於Console_3
                //foreach (var r in query)
                //{
                //    Console.WriteLine("StockNo={0}, StockName={1}, Price={2}, Volume={3}", r.StockNo, r.StockName, r.Price, r.Volume);
                //}
                #endregion

                #region 輸出到DataTable & 寫到CSV
                //DataTable summary = InitializeTables();
                //foreach (var row in query)
                //{
                //    DataRow newRow = summary.NewRow();
                //    //newRow["StockNo"] = row["股票代號"];
                //    //newRow["StockName"] = row["股票名稱"];
                //    //newRow["Industry"] = row["產業名稱"];
                //    //newRow["Price"] = row["收盤價"];
                //    //newRow["Volume"] = row["成交量"];
                //    newRow["StockNo"] = row.StockNo;
                //    newRow["StockName"] = row.StockName;
                //    newRow["Industry"] = row.Industry;
                //    newRow["Price"] = row.Price;
                //    newRow["Volume"] = row.Volume;
                //    summary.Rows.Add(newRow);
                //}
                //Utility.SaveToCSV(summary, ".\\summary.csv", true);
                #endregion

                Console.WriteLine("Cmoney Data Query Done...");
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.ReadLine();
            }

            }
    }
}
