#include<stdio.h>
#include<string.h>
void sub_str(char *a, char *b, int c, int d)
{
	int l = strlen(b);
	//printf("%d\n",l) ;
	int i;
	if (l > d)
	{
		for (i = 0; i <= (d - c); i++)
		{
			a[i] = b[i + c];
			//printf("%c\n",a[i]) ;
		}
		a[d - c + 1] = '\0';
	}
	//printf("%s\n",a) ; 
}

void AddComma(char *input, char *output) {
	char txt[2000], txt1[2000];
	FILE *f1, *f2;
	int filems1, filems2;
	
	filems1 = fopen_s(&f1, input,"r");
	filems2 = fopen_s(&f2, output, "w+");
	
	while (fgets(txt, sizeof(txt), f1) != NULL) {
		//date
		sub_str(txt1, txt, 0, 16);
		fprintf(f2, "%s,", txt1);
		//id
		sub_str(txt1, txt, 17, 22);
		fprintf(f2, "%s,", txt1);
		//name
		sub_str(txt1, txt, 23, 42);
		fprintf(f2, "%s,", txt1);
		//ttom
		sub_str(txt1, txt, 43, 46);
		fprintf(f2, "%s,", txt1);
		//inout
		sub_str(txt1, txt, 47, 55);
		fprintf(f2, "%s,", txt1);
		//strike
		sub_str(txt1, txt, 56, 63);
		fprintf(f2, "%s,", txt1);
		//ratio
		sub_str(txt1, txt, 64, 71);
		fprintf(f2, "%s,", txt1);
		//buyiv
		sub_str(txt1, txt, 72, 79);
		fprintf(f2, "%s,", txt1);
		//selliv
		sub_str(txt1, txt, 80, 87);
		fprintf(f2, "%s,", txt1);
		//tickdiff
		sub_str(txt1, txt, 88, 90);
		fprintf(f2, "%s,", txt1);
		//spreaddiff
		sub_str(txt1, txt, 91, 98);
		fprintf(f2, "%s,", txt1);
		//buyvol
		sub_str(txt1, txt, 99, 106);
		fprintf(f2, "%s,", txt1);
		//sellvol
		sub_str(txt1, txt, 107, 114);
		fprintf(f2, "%s,", txt1);
		//buyprice
		sub_str(txt1, txt, 115, 122);
		fprintf(f2, "%s,", txt1);
		//sellprice
		sub_str(txt1, txt, 123, 130);
		fprintf(f2, "%s,", txt1);
		//stockbuyprice
		sub_str(txt1, txt, 131, 138);
		fprintf(f2, "%s,", txt1);
		//stocksellprice
		sub_str(txt1, txt, 139, 146);
		fprintf(f2, "%s,", txt1);
		//stockcloseprice
		sub_str(txt1, txt, 147, 154);
		fprintf(f2, "%s,", txt1);
		//c or p
		sub_str(txt1, txt, 155, 155);
		fprintf(f2, "%s,", txt1);
		//lastupdate
		sub_str(txt1, txt, 156, 163);
		fprintf(f2, "%s\n", txt1);
		//printf("%s",txt) ;
		//fprintf(f2,"%s %s %s %s %s\n",ID,Type,Ttom,PX,OPT_TYPE) ;
		//printf("----\n") ;  
	}
	fclose(f1);
	fclose(f2); 
}

void AddCommaR(char *input, char *output) {
	char txt[2000], txt1[2000];
	FILE *f1, *f2;
	int filems1, filems2;

	filems1 = fopen_s(&f1, input, "r");
	filems2 = fopen_s(&f2, output, "w+");
	while (fgets(txt, sizeof(txt), f1) != NULL) {
		//date
		sub_str(txt1, txt, 0, 7);
		fprintf(f2, "%s,", txt1);
		//Period
		sub_str(txt1, txt, 8, 10);
		fprintf(f2, "%s,", txt1);
		//wid
		sub_str(txt1, txt, 11, 16);
		fprintf(f2, "%s,", txt1);
		//name
		sub_str(txt1, txt, 17, 36);
		fprintf(f2, "%s,", txt1);
		//TTOM
		sub_str(txt1, txt, 37, 44);
		fprintf(f2, "%s,", txt1);
		//duration
		sub_str(txt1, txt, 45, 48);
		fprintf(f2, "%s,", txt1);
		//EX_price
		sub_str(txt1, txt, 49, 56);
		fprintf(f2, "%s,", txt1);
		//price_depth
		sub_str(txt1, txt, 57, 65);
		fprintf(f2, "%s,", txt1);
		//EX_ratio
		sub_str(txt1, txt, 66, 73);
		fprintf(f2, "%s,", txt1);
		//closeprice.w
		sub_str(txt1, txt, 74, 81);
		fprintf(f2, "%s,", txt1);
		//closeprice.u
		sub_str(txt1, txt, 82, 89);
		fprintf(f2, "%s,", txt1);
		//buyiv
		sub_str(txt1, txt, 90, 97);
		fprintf(f2, "%s,", txt1);
		//selliv
		sub_str(txt1, txt, 98, 105);
		fprintf(f2, "%s,", txt1);
		//period_buyiv
		sub_str(txt1, txt, 106, 113);
		fprintf(f2, "%s,", txt1);
		//period_selliv
		sub_str(txt1, txt, 114, 121);
		fprintf(f2, "%s,", txt1);
		//period_maxbuyiv
		sub_str(txt1, txt, 122, 129);
		fprintf(f2, "%s,", txt1);
		//period_maxselliv
		sub_str(txt1, txt, 130, 137);
		fprintf(f2, "%s,", txt1);
		//period_bsiv_diff
		sub_str(txt1, txt, 138, 146);
		fprintf(f2, "%s,", txt1);
		//bstick_diff
		sub_str(txt1, txt, 147, 149);
		fprintf(f2, "%s,", txt1);
		//bsdiff_ratio
		sub_str(txt1, txt, 150, 157);
		fprintf(f2, "%s,", txt1);
		//Buyvol
		sub_str(txt1, txt, 158, 165);
		fprintf(f2, "%s,", txt1);
		//Sellvol
		sub_str(txt1, txt, 166, 173);
		fprintf(f2, "%s,", txt1);
		//Closeiv
		sub_str(txt1, txt, 174, 181);
		fprintf(f2, "%s,", txt1);
		//Buyivdiff
		sub_str(txt1, txt, 182, 190);
		fprintf(f2, "%s,", txt1);
		//CPtype
		sub_str(txt1, txt, 191, 191);
		fprintf(f2, "%s,", txt1);
		//updatedate
		sub_str(txt1, txt, 192, 199);
		fprintf(f2, "%s,", txt1);
		//id.u
		sub_str(txt1, txt, 200, 211);
		fprintf(f2, "%s,", txt1);
		//name.u
		sub_str(txt1, txt, 212, 231);
		fprintf(f2, "%s,", txt1);
		//issuer.id
		sub_str(txt1, txt, 232, 241);
		fprintf(f2, "%s,", txt1);
		//issuer.name
		sub_str(txt1, txt, 242, 261);
		fprintf(f2, "%s,", txt1);
		//data1
		sub_str(txt1, txt, 262, 269);
		fprintf(f2, "%s,", txt1);
		//buyiv_sd
		sub_str(txt1, txt, 270, 277);
		fprintf(f2, "%s,", txt1);
		//selliv_sd
		sub_str(txt1, txt, 278, 285);
		fprintf(f2, "%s\n", txt1);
	}
	fclose(f1);
	fclose(f2);
}

#pragma warning( disable : 4996 )
int main()
{
	char date[10];
	printf("Please input date(MMdd):");
	scanf("%s", date);

	char input[40] = "H:\\sfiData\\ivtest\\WDSOTC2019";
	strcat(input, date);
	strcat(input, ".txt");
	char output[40] = "H:\\sfiData\\ivtest\\OTC\\";  //OTC sfi���Ӹ��
	strcat(output, date);
	strcat(output, ".csv");

	printf("%s %s\n", input, output);
	AddComma(input, output);

	strcpy(input, "H:\\sfiData\\ivtest\\WDSTWSE2019");
	strcat(input, date);
	strcat(input, ".txt");
	strcpy(output, "H:\\sfiData\\ivtest\\TWSE\\");  //TWSE sfi���Ӹ��
	strcat(output, date);
	strcat(output, ".csv");

	printf("%s %s\n", input, output);
	AddComma(input, output);

	strcpy(input, "H:\\sfiData\\ivtest\\WROTC2019");
	strcat(input, date);
	strcat(input, ".txt");
	strcpy(output, "H:\\sfiData\\ivtest\\OTCR\\OTCR");  //OTC sfi���
	strcat(output, date);
	strcat(output, ".csv");

	printf("%s %s\n", input, output);
	AddCommaR(input, output);

	strcpy(input, "H:\\sfiData\\ivtest\\WRTWSE2019");
	strcat(input, date);
	strcat(input, ".txt");
	strcpy(output, "H:\\sfiData\\ivtest\\TWSER\\TWSER");  //TWSE sfi���
	strcat(output, date);
	strcat(output, ".csv");

	printf("%s %s\n", input, output);
	AddCommaR(input, output);

}
