﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Threading;
using System.Runtime.Serialization;
using DeriLib.Quote;
using DeriLib.TSModel;

namespace TSServer
{
    public partial class Main : Form
    {
        private DataSet ds = new DataSet("ds");
        private Hashtable ServiceSettingHt = new Hashtable();
        private Hashtable DataSourceSettingHt = new Hashtable();
        private Hashtable DataSourceSortMap = new Hashtable();
        private Hashtable ServicHt = Hashtable.Synchronized(new Hashtable());
        private Hashtable WCFServicHt = Hashtable.Synchronized(new Hashtable());
        public Queue ErrQueue = Queue.Synchronized(new Queue());
        private Queue m_ServiceErrQueue = Queue.Synchronized(new Queue());
        private object LockObj = new object();
        private Thread RoutineThread;
        private DataView DataSourceDv = null;
        private bool InitialFlag = true;
        delegate void hd(string Service,KeyValuePair<string, ITSFactory> de);

        public Main()
        {
            InitializeComponent();
            ReadSetting();
            PrepareMainDs();
            SetForm();
            LoadService();
            ReadUserSetting();
            
            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
        }
        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }
        
        private void SetForm()
        {
            try
            {
                if (grdMain.DataSource == null)
                    grdMain.DataSource = ds;

                grdMain.DisplayLayout.Bands[0].Columns[0].Header.Caption = "";
                grdMain.DisplayLayout.Bands[0].Columns[1].Header.Caption = "Service";
                grdMain.DisplayLayout.Bands[0].Columns[2].Header.Caption = "Note";
                grdMain.DisplayLayout.Bands[0].Columns[3].Header.Caption = "Connections";
                grdMain.DisplayLayout.Bands[0].Columns[4].Header.Caption = "Last Start Time";
                grdMain.DisplayLayout.Bands[0].Columns[5].Header.Caption = "Last Error";
                grdMain.DisplayLayout.Bands[1].Columns[0].Header.Caption = "";
                grdMain.DisplayLayout.Bands[1].Columns[1].Header.Caption = "Service";
                grdMain.DisplayLayout.Bands[1].Columns[2].Header.Caption = "DataSource";
                grdMain.DisplayLayout.Bands[1].Columns[3].Header.Caption = "Note";
                grdMain.DisplayLayout.Bands[1].Columns[4].Header.Caption = "Rv Packets";
                grdMain.DisplayLayout.Bands[1].Columns[5].Header.Caption = "Sd Packets";
                grdMain.DisplayLayout.Bands[1].Columns[6].Header.Caption = "D/R Packets";
                grdMain.DisplayLayout.Bands[1].Columns[7].Header.Caption = "D/W Packets";
                grdMain.DisplayLayout.Bands[1].Columns[8].Header.Caption = "Last Start Time";
                grdMain.DisplayLayout.Bands[1].Columns[9].Header.Caption = "Last Error";
                                
                grdMain.DisplayLayout.Bands[1].Columns[1].Hidden = true;

                grdMain.DisplayLayout.Bands[0].Columns[0].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.Button;
                grdMain.DisplayLayout.Bands[0].Columns[0].ButtonDisplayStyle = Infragistics.Win.UltraWinGrid.ButtonDisplayStyle.Always;
                grdMain.DisplayLayout.Bands[0].Columns[0].CellButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                grdMain.DisplayLayout.Bands[0].Columns[0].CellButtonAppearance.ForeColor = Color.White;
                grdMain.DisplayLayout.Bands[0].Columns[0].Width = 50;
                grdMain.DisplayLayout.Bands[1].Columns[0].Style = Infragistics.Win.UltraWinGrid.ColumnStyle.Button;
                grdMain.DisplayLayout.Bands[1].Columns[0].ButtonDisplayStyle = Infragistics.Win.UltraWinGrid.ButtonDisplayStyle.Always;
                grdMain.DisplayLayout.Bands[1].Columns[0].CellButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                grdMain.DisplayLayout.Bands[1].Columns[0].CellButtonAppearance.ForeColor = Color.White;
                grdMain.DisplayLayout.Bands[1].Columns[0].Width = 50;
                                
                grdMain.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
                grdMain.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.False;
                grdMain.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.False;
                grdMain.DisplayLayout.Override.AllowRowFiltering = Infragistics.Win.DefaultableBoolean.False;

                grdMain.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.Select;
                grdMain.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.Default;
                grdMain.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.RowSelect;
                grdMain.DisplayLayout.Override.ActiveRowAppearance.BackColor = Color.Yellow;
                grdMain.DisplayLayout.Override.ActiveRowAppearance.ForeColor = Color.Black;                
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][SetForm_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ReadSetting()
        {
            try
            {                
                Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
                ConfigurationSectionCollection ServiceGroup = config.GetSectionGroup("Service").Sections;

                foreach (ConfigurationSection iServiceSetting in ServiceGroup)
                {
                    try
                    {
                        Hashtable ht = (Hashtable)System.Configuration.ConfigurationManager.GetSection(iServiceSetting.SectionInformation.SectionName);
                        ServiceSetting mServiceSetting = (ServiceSetting)Assembly.LoadFrom(ht["Assembly"].ToString()).CreateInstance(ht["Type"].ToString(), false, BindingFlags.CreateInstance, null, new object[] { iServiceSetting.SectionInformation.Name, "" }, null, null);
                        foreach (DictionaryEntry de in ht)
                            SetSettingField(mServiceSetting, de);
                        ServiceSettingHt.Add(iServiceSetting.SectionInformation.Name, mServiceSetting);
                    }
                    catch (Exception ex1)
                    {
                        ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][ReadSetting_Error] " + "[" + ex1.Message + "][" + ex1.StackTrace + "]");
                    }
                }

                SortedDictionary<int, ConfigurationSection> f = new SortedDictionary<int, ConfigurationSection>();

                ConfigurationSectionCollection DataSourceGroup = config.GetSectionGroup("DataSource").Sections;

                foreach (ConfigurationSection iDataSourceSetting in DataSourceGroup)
                {
                    try
                    {                        
                        Hashtable ht = (Hashtable)System.Configuration.ConfigurationManager.GetSection(iDataSourceSetting.SectionInformation.SectionName);
                        f.Add(int.Parse(ht["Sort"].ToString()), iDataSourceSetting);
                        DataSourceSortMap.Add(iDataSourceSetting.SectionInformation.Name, int.Parse(ht["Sort"].ToString()));
                    }
                    catch (Exception ex1)
                    {
                        ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][ReadSetting_Error] " + "[" + ex1.Message + "][" + ex1.StackTrace + "]");
                    }
                }

                foreach (ConfigurationSection iDataSourceSetting in f.Values)
                {
                    try
                    {
                        Hashtable ht = (Hashtable)System.Configuration.ConfigurationManager.GetSection(iDataSourceSetting.SectionInformation.SectionName);
                        
                        DataSourceSetting mDataSourceSetting = (DataSourceSetting)Assembly.LoadFrom(ht["Assembly"].ToString()).CreateInstance(ht["Type"].ToString(), false, BindingFlags.CreateInstance, null, new object[] { ht["Service"].ToString(), iDataSourceSetting.SectionInformation.Name, "" }, null, null);
                        foreach (DictionaryEntry de in ht)
                            SetSettingField(mDataSourceSetting, de);
                        DataSourceSettingHt.Add(iDataSourceSetting.SectionInformation.Name, mDataSourceSetting);
                    }
                    catch (Exception ex1)
                    {
                        ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][ReadSetting_Error] " + "[" + ex1.Message + "][" + ex1.StackTrace + "]");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][ReadSetting_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void SetSettingField(object Q, DictionaryEntry de)
        {
            try
            {
                string key = de.Key.ToString();
                string val = de.Value.ToString();
                int a;
                bool b;
                double c;

                if (key == "Type" || key == "Sort")
                    return;

                if (key == "SubCommodity")
                    Q.GetType().InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { val });
                else if (int.TryParse(val, out a))
                    Q.GetType().InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { a });
                else if (bool.TryParse(val, out b))
                    Q.GetType().InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { b });
                else if (double.TryParse(val, out c))
                    Q.GetType().InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { c });
                else
                {
                    if (key == "LogFileFolder")
                        val = Application.StartupPath;
                    Q.GetType().InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { val });
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][SetSettingField_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        /*private void SetSettingField(Type t, object Q, DictionaryEntry de)
        {
            try
            {
                string key = de.Key.ToString();
                string val = de.Value.ToString();
                int a;
                bool b;
                double c;

                if (int.TryParse(val,out a))
                    t.InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { a });
                else if (bool.TryParse(val, out b))
                    t.InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { b });
                else if (double.TryParse(val, out c))
                    t.InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { c });
                else
                    t.InvokeMember(key, BindingFlags.SetField, null, Q, new Object[] { val });
            }
            catch(Exception ex)
            {
            }
        }*/
        private void LoadService()
        {
            try
            {
                DataRow dr = null;

                foreach(object obj in ServiceSettingHt.Values)
                {
                    ServiceSetting mServiceSetting = (ServiceSetting)obj;

                    dr = ds.Tables["dtP"].NewRow();

                    dr["Service"] = mServiceSetting.Service;
                    dr["Note"] = mServiceSetting.Note;
                    dr["Action"] = "Start";
                    
                    ds.Tables["dtP"].Rows.Add(dr);
                }

                /*foreach (object obj in DataSourceSettingHt.Values)
                {
                    DataSourceSetting mDataSourceSetting = (DataSourceSetting)obj;

                    dr = ds.Tables["dtS"].NewRow();

                    dr["Service"] = mDataSourceSetting.Service;
                    dr["DataSource"] = mDataSourceSetting.DataSource;
                    dr["Note"] = mDataSourceSetting.Note;
                    dr["Action"] = "Start";

                    ds.Tables["dtS"].Rows.Add(dr);
                }*/

                SortedList tmplist = new SortedList();

                foreach (object obj in DataSourceSettingHt.Values)
                    tmplist.Add(DataSourceSortMap[((DataSourceSetting)obj).DataSource], obj);

                foreach (object obj in tmplist.Values)
                {
                    DataSourceSetting mDataSourceSetting = (DataSourceSetting)obj;

                    dr = ds.Tables["dtS"].NewRow();

                    dr["Service"] = mDataSourceSetting.Service;
                    dr["DataSource"] = mDataSourceSetting.DataSource;
                    dr["Note"] = mDataSourceSetting.Note;
                    dr["Action"] = "Start";

                    ds.Tables["dtS"].Rows.Add(dr);
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][LoadService_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void PrepareMainDs()
        {
            DataTable dtP = new DataTable("dtP");
            dtP.Columns.Add("Action", typeof(string));
            dtP.Columns.Add("Service", typeof(string));
            dtP.Columns.Add("Note", typeof(string));
            dtP.Columns.Add("ConnectNum", typeof(int));
            dtP.Columns.Add("LSTime", typeof(string));
            dtP.Columns.Add("LSError", typeof(string));            
            dtP.PrimaryKey = new DataColumn[] { dtP.Columns["Service"] };

            ds.Tables.Add(dtP);

            DataTable dtS = new DataTable("dtS");
            dtS.Columns.Add("Action", typeof(string));
            dtS.Columns.Add("Service", typeof(string));
            dtS.Columns.Add("DataSource", typeof(string));
            dtS.Columns.Add("Note", typeof(string));
            dtS.Columns.Add("RvP", typeof(int));
            dtS.Columns.Add("SdP", typeof(int));
            dtS.Columns.Add("DRP", typeof(int));
            dtS.Columns.Add("DWP", typeof(int));
            dtS.Columns.Add("LSTime", typeof(string));
            dtS.Columns.Add("LSError", typeof(string));
            dtS.PrimaryKey = new DataColumn[] { dtS.Columns["DataSource"] };

            ds.Tables.Add(dtS);

            ds.Relations.Add("MainFK", dtP.Columns["Service"], dtS.Columns["Service"], false);

            DataSourceDv = ds.DefaultViewManager.CreateDataView(ds.Tables["dtS"]);
        }
        public Queue ServiceErrQueue
        {
            get
            {
                lock (LockObj)
                {
                    foreach (DeriLib.TSModel.ITSServer t in ServicHt.Values)
                    {
                        while (t.ErrorQueue.Count > 0)
                            m_ServiceErrQueue.Enqueue(t.ErrorQueue.Dequeue());
                    }
                }

                return m_ServiceErrQueue;
            }
        }

        private void grdMain_InitializeRow(object sender, Infragistics.Win.UltraWinGrid.InitializeRowEventArgs e)
        {            
            /*if (e.Row.Band.Index == 0)
            {
                if (e.Row.Cells["Action"].Text == "Start")
                {
                    Infragistics.Win.UltraWinGrid.UltraGridChildBand cb = (Infragistics.Win.UltraWinGrid.UltraGridChildBand)e.Row.ChildBands.All[0];

                    foreach (Infragistics.Win.UltraWinGrid.UltraGridRow row in cb.Rows)
                    {
                        row.Cells["Action"].Value = "Start";
                        row.Cells["Action"].ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                        row.Cells["Action"].Activation = Infragistics.Win.UltraWinGrid.Activation.Disabled;
                    }
                }
                else if (e.Row.Cells["Action"].Text == "Close")
                {              
                    Infragistics.Win.UltraWinGrid.UltraGridChildBand cb = (Infragistics.Win.UltraWinGrid.UltraGridChildBand)e.Row.ChildBands.All[0];

                    foreach (Infragistics.Win.UltraWinGrid.UltraGridRow row in cb.Rows)
                    {
                        row.Cells["Action"].Value = "Start";
                        row.Cells["Action"].ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                        row.Cells["Action"].Activation = Infragistics.Win.UltraWinGrid.Activation.NoEdit;
                    }
                }
            }*/   
        }

        private void grdMain_ClickCellButton(object sender, Infragistics.Win.UltraWinGrid.CellEventArgs e)
        {
            try
            {
                lock (LockObj)
                {
                    if (e.Cell.Band.Index == 0)
                    {
                        string svc = e.Cell.Row.Cells["Service"].Text;

                        if (ServiceSettingHt.ContainsKey(svc))
                            ServiceTurn(e.Cell, svc);
                    }
                    else if (e.Cell.Band.Index == 1)
                    {
                        string dsc = e.Cell.Row.Cells["DataSource"].Text;

                        DataSourceTurn(e.Cell, dsc);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][grdMain_ClickCellButton_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        public ITSServer GetService(string svc)
        {
            try
            {
                if (ServicHt.ContainsKey(svc)) { return (ITSServer)ServicHt[svc]; }
                else { return null; }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][GetService_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
                return null;
            }

        }
        public List<ITSServer> GetServices
        {            
            get
            {
                List<ITSServer> L = new List<ITSServer>();

                foreach(ITSServer T in ServicHt.Values)
                    L.Add(T);
                
                return L;
            }         
        }
        private void ServiceTurn(Infragistics.Win.UltraWinGrid.UltraGridCell cell,string svc)
        {
            cell.Activation = Infragistics.Win.UltraWinGrid.Activation.Disabled;

            try
            {
                ServiceSetting S = (ServiceSetting)ServiceSettingHt[svc];
                if (cell.Text == "Start")
                {
                    if (!ServicHt.ContainsKey(svc))
                    {
                        ITSServer mITSServer = (ITSServer)Assembly.LoadFrom(S.Assembly).CreateInstance(S.EntityType, false, BindingFlags.CreateInstance, null, new object[] { S }, null, null);
                        mITSServer.Start();
                        ServicHt.Add(svc, mITSServer);
                        if (!InitialFlag)
                            AddWCF(mITSServer);
                        cell.Value = "Close";
                        cell.ButtonAppearance.BackColor = Color.Green;

                        /*Infragistics.Win.UltraWinGrid.U*-)ltraGridChildBand cb = (Infragistics.Win.UltraWinGrid.UltraGridChildBand)cell.Row.ChildBands.All[0];

                        foreach (Infragistics.Win.UltraWinGrid.UltraGridRow row in cb.Rows)
                        {
                            row.Cells["Action"].Value = "Start";
                            row.Cells["Action"].ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                            row.Cells["Action"].Activation = Infragistics.Win.UltraWinGrid.Activation.NoEdit;
                        }*/
                    }
                }
                else if (cell.Text == "Close")
                {
                    if (ServicHt.ContainsKey(svc))
                    {
                        Infragistics.Win.UltraWinGrid.UltraGridChildBand cb = (Infragistics.Win.UltraWinGrid.UltraGridChildBand)cell.Row.ChildBands.All[0];

                        foreach (Infragistics.Win.UltraWinGrid.UltraGridRow row in cb.Rows)
                        {
                            row.Cells["Action"].Value = "Start";
                            row.Cells["Action"].ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                            //row.Cells["Action"].Activation = Infragistics.Win.UltraWinGrid.Activation.Disabled;
                        }

                        ITSServer mITSServer = (ITSServer)ServicHt[svc];
                        mITSServer.Close();
                        ServicHt.Remove(svc);
                        RemoveWCF(mITSServer);
                        cell.Value = "Start";
                        cell.ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                        //cell.ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][ServiceTurn_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }

            cell.Activation = Infragistics.Win.UltraWinGrid.Activation.NoEdit;
        }
        private void AddWCF(ITSServer mITSServer)
        {
            try
            {
                if (!WCFServicHt.ContainsKey(mITSServer.Service))
                {
                    //NetTcpBinding f = new NetTcpBinding();
                    NetNamedPipeBinding f = new NetNamedPipeBinding();                    
                    f.OpenTimeout = new TimeSpan(0, 1, 0);
                    f.ReceiveTimeout = TimeSpan.MaxValue;
                    f.SendTimeout = TimeSpan.MaxValue;
                    f.CloseTimeout = new TimeSpan(0, 1, 0);
                    f.MaxBufferPoolSize = 10048576;
                    f.MaxBufferSize = 10048576;
                    f.MaxReceivedMessageSize = 10048576;
                    f.ReaderQuotas.MaxDepth = 32;
                    f.ReaderQuotas.MaxStringContentLength = 10048576;
                    f.ReaderQuotas.MaxArrayLength = 10048576;
                    f.ReaderQuotas.MaxBytesPerRead = 10048576;

                    NetTcpBinding g = new NetTcpBinding();
                    
                    g.OpenTimeout = new TimeSpan(0, 1, 0);
                    g.ReceiveTimeout = TimeSpan.MaxValue;
                    g.SendTimeout = TimeSpan.MaxValue;
                    g.CloseTimeout = new TimeSpan(0, 1, 0);
                    g.MaxBufferPoolSize = 10048576;
                    g.MaxBufferSize = 10048576;
                    g.MaxReceivedMessageSize = 10048576;
                    g.ReaderQuotas.MaxDepth = 32;
                    g.ReaderQuotas.MaxStringContentLength = 10048576;
                    g.ReaderQuotas.MaxArrayLength = 10048576;
                    g.ReaderQuotas.MaxBytesPerRead = 10048576;
                    
                    g.Security.Mode = SecurityMode.None;
                    g.Security.Transport.ClientCredentialType = TcpClientCredentialType.None;

                    //ServiceHost host = new ServiceHost(mITSServer, new Uri[] { new Uri("net.tcp://localhost:7887"), new Uri("net.pipe://localhost/" + Guid.NewGuid().ToString()) });
                    ServiceHost host = new ServiceHost(mITSServer, new Uri[] { new Uri("net.tcp://localhost"), new Uri("net.pipe://localhost/" + Guid.NewGuid().ToString()) });
                    
                    ServiceSetting s = (ServiceSetting)ServiceSettingHt[mITSServer.Service];
                    
                    Type t = Assembly.LoadFrom(s.Assembly).GetType(s.ServiceType);
                    host.AddServiceEndpoint(t, f, mITSServer.Service);
                    host.AddServiceEndpoint(t, g, mITSServer.Service);
                    host.Authorization.PrincipalPermissionMode = PrincipalPermissionMode.None;                    
                                        
                    SetMaxItemsInObjectGraph(host);

                    ServiceThrottlingBehavior stb = new ServiceThrottlingBehavior();
                    stb.MaxConcurrentCalls = 1000;
                    stb.MaxConcurrentSessions = 1000;
                    host.Description.Behaviors.Add(stb);

                    host.Open();

                    WCFServicHt.Add(mITSServer.Service, host);
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][AddWCF_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void SetMaxItemsInObjectGraph(ServiceHost host)
        {
            try
            {
                foreach (ServiceEndpoint ep in host.Description.Endpoints)
                {
                    foreach (OperationDescription op in ep.Contract.Operations)
                    {
                        DataContractSerializerOperationBehavior dataContractBehavior = op.Behaviors[typeof(DataContractSerializerOperationBehavior)] as DataContractSerializerOperationBehavior;

                        if (dataContractBehavior != null)
                            dataContractBehavior.MaxItemsInObjectGraph = int.MaxValue;
                    }

                }

            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][SetMaxItemsInObjectGraph_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void RemoveWCF(ITSServer mITSServer)
        {
            try
            {
                if (WCFServicHt.ContainsKey(mITSServer.Service))
                {
                    ServiceHost f = (ServiceHost)WCFServicHt[mITSServer.Service];
                    f.Close();
                    WCFServicHt.Remove(mITSServer.Service);
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][RemoveWCF_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void DataSourceTurn(Infragistics.Win.UltraWinGrid.UltraGridCell cell, string dsc)
        {
            cell.Activation = Infragistics.Win.UltraWinGrid.Activation.Disabled;

            try
            {
                DataSourceSetting D = (DataSourceSetting)DataSourceSettingHt[dsc];

                if (cell.Text == "Start")
                {
                    if (ServicHt.ContainsKey(D.Service))
                    {
                        ITSServer mITSServer = (ITSServer)ServicHt[D.Service];                        
                        mITSServer.AddDataSource((ITSFactory)Assembly.LoadFrom(D.Assembly).CreateInstance(D.EntityType, false, BindingFlags.CreateInstance, null, new object[] { D }, null, null));
                        cell.Value = "Close";
                        cell.ButtonAppearance.BackColor = Color.Green;
                    }
                }
                else if (cell.Text == "Close")
                {
                    if (ServicHt.ContainsKey(D.Service))
                    {
                        ITSServer mITSServer = (ITSServer)ServicHt[D.Service];
                        mITSServer.RemoveDataSource(D.DataSource);
                        cell.Value = "Start";
                        cell.ButtonAppearance.BackColor = Color.FromArgb(255, 73, 73);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Main][" + DateTime.Now.ToString() + "][DataSourceTurn_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }

            cell.Activation = Infragistics.Win.UltraWinGrid.Activation.NoEdit;
        }
        public new void Close()
        {
            WriteToUserSetting();

            if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }

            lock (LockObj)
            {
                foreach (ITSServer mITSServer in ServicHt.Values)
                    mITSServer.Close();
            }
        }
        private void WriteToUserSetting()
        {
            try
            {
                string serviceonlist = "";
                string datasourceonlist = "";

                TSServer.Properties.Settings.Default.Service = "";
                TSServer.Properties.Settings.Default.DataSource = "";

                //List<string> serviceonlist = TSServer.Properties.Settings.Default.Service.Split(',').ToList<string>();
                SortedList tmplist = new SortedList();

                foreach (ITSServer I in ServicHt.Values)
                {
                    serviceonlist += I.Service + ",";


                    foreach (ITSFactory J in I.DataSources.Values)
                    {
                        //datasourceonlist += J.DataSource + ",";
                        tmplist.Add(DataSourceSortMap[J.DataSource], J.DataSource);
                    }

                    foreach(string s in tmplist.Values)
                        datasourceonlist += s + ",";
                }

                if (serviceonlist.Length > 0)
                    serviceonlist = serviceonlist.Substring(0, serviceonlist.Length - 1);
                if (datasourceonlist.Length > 0)
                    datasourceonlist = datasourceonlist.Substring(0,datasourceonlist.Length-1);

                TSServer.Properties.Settings.Default.Service = serviceonlist;
                TSServer.Properties.Settings.Default.DataSource = datasourceonlist;

                Properties.Settings.Default.Save();
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][WriteToUserSetting_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ReadUserSetting()
        {
            InitialFlag = true;

            List<string> serviceonlist = TSServer.Properties.Settings.Default.Service.Split(',').ToList<string>();

            foreach (string S in serviceonlist)
            {
                if (ServiceSettingHt.ContainsKey(S))
                {
                    foreach (Infragistics.Win.UltraWinGrid.UltraGridRow dr in grdMain.Rows)
                    {
                        if (dr.Band.Index == 0 && dr.Cells["Service"].Text == S)
                            ServiceTurn(dr.Cells["Action"],S);
                    }
                }
            }

            List<string> datasourceonlist = TSServer.Properties.Settings.Default.DataSource.Split(',').ToList<string>();

            foreach (string D in datasourceonlist)
            {
                if (DataSourceSettingHt.ContainsKey(D))
                {                    
                    foreach (Infragistics.Win.UltraWinGrid.UltraGridRow dr in grdMain.Rows)
                    {
                        if (!dr.HasChild())
                            continue;
                        Infragistics.Win.UltraWinGrid.UltraGridRow dr1 = dr.GetChild(Infragistics.Win.UltraWinGrid.ChildRow.First);
                        SetDataSourceStart(dr1,D);
                    }
                }
            }

            foreach (string S in serviceonlist)
                if (ServicHt.ContainsKey(S)) { AddWCF((ITSServer)ServicHt[S]); }

            InitialFlag = false;
        }
        private void SetDataSourceStart(Infragistics.Win.UltraWinGrid.UltraGridRow dr,string DataSource)
        {
            if (dr.Band.Index == 1 && dr.Cells["DataSource"].Text == DataSource)
                DataSourceTurn(dr.Cells["Action"], DataSource);
            else
            {
                Infragistics.Win.UltraWinGrid.UltraGridRow dr1 = dr.GetSibling(Infragistics.Win.UltraWinGrid.SiblingRow.Next);

                if (dr1 != null)
                    SetDataSourceStart(dr1, DataSource);
            }
        }
        private void SetDs(string Service,KeyValuePair<string, ITSFactory> de)
        {
            lock (((ICollection)ds.Tables["dtS"].Rows).SyncRoot)
            {
                DataSourceDv.RowFilter = "Service='" + Service + "' and DataSource='" + de.Value.DataSource + "'";
            }
                        
            if (DataSourceDv.Count > 0)
            {
                DataSourceDv[0].BeginEdit();
                DataSourceDv[0]["DRP"] = de.Value.ReadDBNum;
                DataSourceDv[0]["DWP"] = de.Value.WriteDBNum;
                DataSourceDv[0]["RvP"] = de.Value.ReceivePacketNum;
                DataSourceDv[0]["SdP"] = de.Value.SendPacketNum;
                DataSourceDv[0].EndEdit();
            }
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    List<DeriLib.TSModel.ITSServer> L = new List<ITSServer>();

                    lock (LockObj)
                    {
                        foreach (DeriLib.TSModel.ITSServer t in ServicHt.Values)
                            L.Add(t);
                    }

                    foreach (DeriLib.TSModel.ITSServer t in L)
                    {
                        foreach (KeyValuePair<string,ITSFactory> de in t.DataSources)
                        {
                            if (this.InvokeRequired)
                                grdMain.BeginInvoke(new hd(SetDs), new object[] { t.Service,de });                            
                        }                         
                    }
                    

                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                ErrQueue.Enqueue("[Quote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
    }
}
