﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DeriLib.Quote;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Configuration;
using DeriLib.TSModel;

namespace TSServer
{
    public partial class frmTSServer : Form
    {
        private bool IsReBoot = false;
        private bool IsTradeDate = false;
        private delegate void ShowListHandler(string str);
        private bool InitialFlag = false;
        private StreamWriter gStateLog = null;//錯誤寫檔        
        public static Main iMain = null;
        public static FrmConnection iFrmConnection = null;
        private Thread RoutineThread;
        private object LockObj = new object();
        private bool notFinishClearLogWork = true;
        private bool notFinishReBoot = true;
        
        public frmTSServer()
        {
            InitializeComponent();
        }
        private void TSServer_Load(object sender, EventArgs e)
        {            
            this.Hide();

            CheckTradeDate();

            IniStateLogLog();

            RoutineThread = new Thread(new ThreadStart(RoutineWork));
            RoutineThread.Start();

            ReadXml();
            iMain = new Main();

            WriteToStateLog("[" + DateTime.Now.ToString() + "][TSServer Start] ");
        }
        private void TSServer_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
                notifyIcon1.Visible = true;
            }
        }
        private void TSServer_Activated(object sender, EventArgs e)
        {
            if (!InitialFlag)
            {
                this.Hide();
                notifyIcon1.Visible = true;
                InitialFlag = true;
            }
        }
        private void TSServer_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                /*this.Hide();
                e.Cancel = true;
                notifyIcon1.Visible = true;*/
                //if (MessageBox.Show("是否離開TSServer??", "TSServer", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                //    e.Cancel = true;
                //else
                //{
                    notifyIcon1.Visible = false;
                    if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                    iMain.Close();
                    if (iFrmConnection != null) { iFrmConnection.Close(); }
                    
                    //foreach (ITSServer T in iMain.GetServices)
                    //    T.Close();

                    WriteToStateLog("[" + DateTime.Now.ToString() + "][TSServer Close] ");
                    this.Dispose();
                //}
            }
            catch (Exception ex)
            {
                WriteToStateLog("[" + DateTime.Now.ToString() + "][TSServer_FormClosing_Error] " + "[" + ex.Message + "][" + ex.Source + "]");
            }
        }
        private void notifyIcon1_DoubleClick(object sender, MouseEventArgs e)
        {
            ShowTs();
        }

        private void mnuClick(object sender, EventArgs e)
        {
            try
            {
                ToolStripMenuItem mItem = (ToolStripMenuItem)sender;

                if (mItem.Tag.ToString() == "Main")
                {
                    ShowMain();
                }
                else if (mItem.Tag.ToString() == "ShowConnections")
                {
                    foreach (Form iForm in Application.OpenForms)
                    {
                        if (iForm.GetType() == typeof(FrmConnection))
                        {
                            iForm.BringToFront();
                            return;
                        }
                    }

                    FrmConnection sFrmConnection = new FrmConnection();
                    sFrmConnection.StartPosition = FormStartPosition.CenterScreen;
                    sFrmConnection.Show();

                    iFrmConnection = sFrmConnection;
                }
                else if (mItem.Tag.ToString() == "Show")
                {
                    ShowTs();
                }  
                else if (mItem.Tag.ToString() == "Minimize")
                {
                    this.Hide();                    
                    notifyIcon1.Visible = true;
                }  
                else if (mItem.Tag.ToString() == "Exit")
                {
                    notifyIcon1.Visible = false;
                    if (RoutineThread != null && RoutineThread.IsAlive) { RoutineThread.Abort(); }
                    iMain.Close();
                    if (iFrmConnection != null) { iFrmConnection.Close(); }

                    //foreach (ITSServer T in iMain.GetServices)
                    //    T.Close();

                    WriteToStateLog("[" + DateTime.Now.ToString() + "][TSServer Close] ");
                    this.Dispose();
                }

            }
            catch (Exception ex)
            {
                WriteToStateLog("[" + DateTime.Now.ToString() + "][mnuClick_Error] " + "[" + ex.Message + "][" + ex.Source + "]");
            }
        }
        private void ReadXml()
        {
            if (ConfigurationManager.AppSettings["IsReBoot"] != null) { bool.TryParse(ConfigurationManager.AppSettings["IsReBoot"], out IsReBoot); }
        }
        private void ShowTs()
        {
            this.Show();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Normal;
            this.Activate();
            notifyIcon1.Visible = false;
        }
        private void ShowMain()
        {
            iMain.Show();
        }
        private void RoutineWork()
        {
            try
            {
                for (; ; )
                {
                    if (DateTime.Now.TimeOfDay.TotalHours > 1 && DateTime.Now.TimeOfDay.TotalHours < 1.1)
                    {
                        notFinishClearLogWork = true;
                        notFinishReBoot = true;
                    }
                    if (DateTime.Now.TimeOfDay.TotalHours >= 1.5 && DateTime.Now.TimeOfDay.TotalHours < 1.6 && notFinishClearLogWork)
                    {
                        ClearStateLogFile();
                        CheckTradeDate();
                        notFinishClearLogWork = false;
                    }
                    if (IsReBoot && DateTime.Now.TimeOfDay.TotalHours >= 23.01 && DateTime.Now.TimeOfDay.TotalHours < 23.015 && notFinishReBoot)
                    {
                        if (IsTradeDate)
                        {
                            Process ps = new Process();
                            ps.StartInfo.FileName = Application.StartupPath + "\\ReBoot.exe";
                            ps.StartInfo.Arguments = "TsServer.exe";
                            ps.Start();
                            ps.WaitForExit();
                        }

                        notFinishReBoot = false;
                    }

                    if (iMain != null)
                    {
                        while (iMain.ErrQueue.Count > 0)
                            WriteToStateLog(iMain.ErrQueue.Dequeue().ToString());

                        while (iMain.ServiceErrQueue.Count > 0)
                            lsOutPut.BeginInvoke(new ShowListHandler(ListShow), iMain.ServiceErrQueue.Dequeue().ToString());
                    }
   
                    Thread.Sleep(1000);
                }
            }
            catch (ThreadAbortException ex2)
            {
            }
            catch (Exception ex)
            {
                WriteToStateLog("[Quote][" + DateTime.Now.ToString() + "][RoutineWork_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        public void ClearStateLogFile()
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(Environment.CurrentDirectory);
                FileInfo[] fi = di.GetFiles();
                foreach (FileInfo fiTemp in fi)
                {
                    if (fiTemp.Name.IndexOf("Log", 0) != -1 && fiTemp.CreationTime.AddDays(3) < DateTime.Now)
                        fiTemp.Delete();
                }
            }
            catch (Exception ex)
            {
                WriteToStateLog("[Quote][" + DateTime.Now.ToString() + "][ClearStateLogFile_Error] " + "[" + ex.Message + "][" + ex.StackTrace + "]");
            }
        }
        private void ListShow(string str)
        {
            lock(LockObj)
            {
                if (lsOutPut.Items.Count > 100)
                    lsOutPut.Items.RemoveAt(lsOutPut.Items.Count - 1);
                
                lsOutPut.Items.Insert(0,str);
            }
        }
        private void IniStateLogLog()
        {
            try
            {
                if (gStateLog != null) { gStateLog.Close(); }

                gStateLog = File.AppendText(DateTime.Today.ToString("yyyyMMdd") + "TsServer_StateLog.txt");
            }
            catch (Exception ex)
            {                
            }
        }
        public void WriteToStateLog(string str)
        {
            try
            {
                lsOutPut.BeginInvoke(new ShowListHandler(ListShow), str);

                lock (gStateLog)
                {
                    gStateLog.WriteLine(str);
                    gStateLog.Flush();
                }
            }
            catch (Exception ex)
            {
            }
        }
        private void CheckTradeDate()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
            ConfigurationSectionCollection ServiceGroup = config.GetSectionGroup("Service").Sections;

            Hashtable ht = (Hashtable)System.Configuration.ConfigurationManager.GetSection(ServiceGroup["Quote"].SectionInformation.SectionName);

            string connstr = ht["DBConnectString"].ToString();
            DataView dv = DeriLib.Util.ExecSqlQry("select IsTrade from TradeDate where country='TWN' and convert(varchar,TradeDate,112)=convert(varchar,getdate(),112)", connstr);

            if (dv.Count == 0) { IsTradeDate = true; }
            else
            {
                if (dv[0]["IsTrade"].ToString() == "Y") { IsTradeDate = true; }
                else { IsTradeDate = false; }
            }
        }

        private void reBootTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process ps = new Process();
            ps.StartInfo.FileName = Application.StartupPath + "\\ReBoot.exe";
            ps.StartInfo.Arguments = "TsServer.exe";
            ps.Start();
            ps.WaitForExit();
        }
    }
}
